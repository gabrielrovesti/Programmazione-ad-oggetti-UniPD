#include <iostream>
#include <vector>
using namespace std;

class App
{
private:
    double MB;
    bool internet;
public:
    App(double m, bool i) : MB(m), internet(i) {}
    double getMB() const {return MB;}
    double getInternet() const {return internet;}
    virtual App* clone() const=0;
    virtual ~App();
};

class FreeApp : public App
{
private:
    bool open;
public:
    FreeApp(double m, bool i, bool o) : App(m, i), open(o) {}
    bool isOpen() const {return open;}
    FreeApp* clone() const
    {
        return new FreeApp(*this);
    }
};

class Exc {};

class PayApp : public App
{
private:
    double prezzo;
public:
    double getPrezzo() const {return prezzo;}
    PayApp(double m, bool i, double p) : App(m, i)
    {
        if(p)
        {
            prezzo=p;
        }
        else
            throw Exc();
    }
    PayApp* clone() const
    {
        return new PayApp(*this);
    }
};

class aiPhone
{
private:
    vector<App*> v;
    double capMax;
public:
    double installaApp(const App& a)
    {
        if(a.getMB()<=capMax)
        {
            v.push_back(const_cast<App*>(&a));
            capMax=capMax-a.getMB();
            return capMax;
        }
        else
            throw Exc();
    }

    vector<PayApp> F(double p) const
    {
        vector<PayApp> vec;
        vector<App*>::const_iterator i; //!!!!!!!!!!!!!!!!
        for(i=v.begin(); i!=v.end(); ++i)
        {
            if(PayApp* a=dynamic_cast<PayApp*>(*i))
            {
                if(a->getInternet() && a->getPrezzo()<=p)
                {
                     vec.push_back(*(a->clone()));
                }
            }
        }
        return vec;
    }

    FreeApp* G() const
    {
        double max=0;
        FreeApp* p=0;
        vector<App*>::const_iterator i;
        for(i=v.begin(); i!=v.end(); ++i)
        {
            if(FreeApp* f = dynamic_cast<FreeApp*>(*i))
            {
                if(f->isOpen() && f->getMB()>max)
                {
                    p=f;
                    max=f->getMB();
                }
            }
        }
        if(p)
        {
            return p;
        }
        else
            throw Exc();
    }
};

int main()
{
    cout << "Hello World!" << endl;
    return 0;
}

