#include "Raz.h"
Raz::Raz(int n,int d) :num(n),den(d)
{
if(den<=0)
	den=1;
}
Raz Raz::inverso() const
{
    return Raz(den,num);
}
Raz::operator double() const
{
    return num/den;
}
Raz Raz::operator+(const Raz& r) const
{
    Raz aux;
    aux.num=(den*r.den)/den*num+(den*r.den)/r.den*r.num;
    aux.den=den*r.den;
    return aux;
}
Raz Raz::operator*(const Raz& r) const
{
    return Raz(num*r.num,den*r.den);
}
Raz Raz::operator++(int a)
{
    Raz aux=*this;
    num=num+den;
    return aux;
}
Raz Raz::uno()
{
    return Raz(1,1);
}
ostream& operator<<(ostream& os,const Raz& r)
{
    os<<r.num<<'/'<<r.den;
    return os;
}
