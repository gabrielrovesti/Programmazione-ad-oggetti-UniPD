#ifndef RAZ_H
#define RAZ_H
#include<iostream>
using std::ostream;
class Raz{
private:
    int num;
    int den;

public:
    Raz(int=0,int=1);
    Raz inverso() const;
    operator double() const;
    Raz operator+(const Raz&) const;
    Raz operator*(const Raz&) const;
    Raz operator++(int);        //non ritorna l-valore
    static Raz uno();
    friend ostream& operator<<(ostream&,const Raz&);//funzione esterna amica



};

#endif
