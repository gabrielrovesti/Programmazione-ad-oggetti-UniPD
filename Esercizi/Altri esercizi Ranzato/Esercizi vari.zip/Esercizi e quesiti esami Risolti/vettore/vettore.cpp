#include "vettore.h"
#include <iostream>
using std::ostream;

vettore::vettore(int s, int n)
{
    size=s;
    p=new int[s];
    for(int i=0; i<s; i++)
    {
        p[i]=n;
    }
}

vettore::vettore(const vettore& v)
{
    size=v.size;
    p=new int[v.size];
    for(int i=0; i<size; i++)
    {
        p[i]=v.p[i];
    }
}

bool vettore::operator==(const vettore& v) const
{
    if(size!=v.size) return false;
    for(int i=0; i<size; i++)
    {
        if(p[i]!=v.p[i]) return false;
    }
    return true;
}

int& vettore::operator[](int i) const
{
    return *(p+i);
}

vettore& vettore::operator=(const vettore& v)
{
    if(this!=&v)
    {
        delete[] p;
        size=v.size;
        p=new int[v.size];
        for(int i=0; i<size; i++)
        {
           p[i]=v.p[i];
        }
    }
    return *this;
}

int vettore::getSize() const
{
    return size;
}

ostream& operator<<(ostream& os, const vettore& v)
{
    int size=v.getSize();
    for(int i=0; i<size; i++)
    {
        return os<<v[i]<<" ";
    }
}
