#ifndef VETTORE_H
#define VETTORE_H
#include <iostream>
using std::ostream;
class vettore
{
private:
    int size;
    int *p;
public:
    vettore(int =1, int =0);
    vettore(const vettore&);
    bool operator==(const vettore&) const;
    int& operator[](int) const;
    vettore& operator=(const vettore&);
    int getSize() const;
};
ostream& operator<<(ostream&, const vettore&);
#endif // VETTORE_H
