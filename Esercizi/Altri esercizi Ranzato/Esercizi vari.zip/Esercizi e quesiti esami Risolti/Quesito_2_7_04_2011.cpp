#include<iostream>
using namespace std;

class A {
private:
int x;
public:
A(int k=0): x(k) { cout << "A(int) ";}
~A() { cout << "~A ";}
};
class B : public A {
public:
static A a;
A F(A a=A()) { return a; }
B() : A(3) { cout << "B() ";}
~B() { cout << "~B ";}
};
A B::a(1);
int main() {
A a(1); cout << "UNO" << endl;
B b; cout << "DUE" << endl;
b.F(); cout << "TRE" << endl;
b.F(2); cout << "QUATTRO" << endl;
return 0;
}
