#include<vector>
using namespace std;

template<class T>
void tolgi_min(vector<T>& v)
{
    typename vector<T>::iterator it;
    typename vector<T>::iterator it_temp=v.begin();
    T temp=v[0];
    for(it=v.begin()+1; it!=v.end(); it++)
    {
        if(*it<temp)
        {
            temp=*it;
            it_temp=it;

        }
    }
    T temp2=*(--v.end());
    *(--v.end())=temp;
    *(it_temp)=temp2;
    v.pop_back();
}

int main()
{

}

