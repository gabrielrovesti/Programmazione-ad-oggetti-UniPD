#include <iostream>

class Z
{
private:
    int x;
};

class B
{
private:
    Z z;
public:
    B(const B& b) {z=b.z;}
};

class D : public B
{
private:
    Z y;
public:
    D& operator=(const D& d)
    {
        y=d.y;
        B::B(d);
    }
};

using namespace std;

int main()
{
    cout << "Hello World!" << endl;
    return 0;
}

