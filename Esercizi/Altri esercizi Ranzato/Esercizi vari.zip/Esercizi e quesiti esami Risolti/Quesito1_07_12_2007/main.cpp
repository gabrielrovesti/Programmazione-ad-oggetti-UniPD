#include <iostream>
#include <vector>
using namespace std;

class Biglietto
{
private:
    double distanza;
    static double prezzoBase;
public:
    Biglietto(double d=0) : distanza(d) {}
    double getDistanza() const {return distanza;}
    double getPrezzoBase() const {return prezzoBase;}
    virtual double prezzo() const=0;
    virtual ~Biglietto();
};
double Biglietto::prezzoBase(0.1);

class BigliettoPrimaClasse : public Biglietto
{
public:
    BigliettoPrimaClasse(double d=0) : Biglietto(d) {}
    double prezzo() const
    {
        if(getDistanza()<100)
        {
            return (getDistanza()*getPrezzoBase())+(getDistanza()*getPrezzoBase())*0.3;
        }
        else
        {
            return (getDistanza()*getPrezzoBase())+(getDistanza()*getPrezzoBase())*0.2;
        }
    }
};

class BigliettoSecondaClasse : public Biglietto
{
private:
    bool prenotazione;
    static double costoPrenotazione;
public:
    bool getPrenotazione() const {return prenotazione;}
    double prezzo() const
    {
        if(prenotazione)
        {
            return getDistanza()*getPrezzoBase()+costoPrenotazione;
        }
        else
            return getDistanza()*getPrezzoBase();
    }
};
double BigliettoSecondaClasse::costoPrenotazione(5);

class TrenoPieno
{
private:
    int classe;
public:
    TrenoPieno(int c) : classe(c) {}
};

class Treno
{
private:
    class BigliettoSmart
    {
    public:
        Biglietto* punt;
        BigliettoSmart(Biglietto* p=0) : punt(p) {}
        ~BigliettoSmart() {delete punt;}
        BigliettoSmart(const BigliettoSmart& b) : punt(b.punt) {}
        bool operator==(const BigliettoSmart& b)
        {
            return punt==b.punt;
        }
        BigliettoSmart& operator=(const BigliettoSmart& b)
        {
            punt=b.punt;
            return *this;
        }
        Biglietto& operator*() const
        {
            return *punt;
        }
        Biglietto* operator->() const
        {
            return punt;
        }
    };

    vector<BigliettoSmart> v;
    int maxPosti1;
    int maxPostiPrenotabili2;
public:
    Treno(int p1, int p2) : maxPosti1(p1), maxPostiPrenotabili2(p2) {}
    int* bigliettiVenduti() const
    {
        int* A= new int[3];
        A[0]=A[1]=A[2]=0;
        vector<BigliettoSmart>::const_iterator i;
        for(i=v.begin(); i!=v.end(); ++i)
        {
            if(dynamic_cast<BigliettoPrimaClasse*>(&(**i)))
            {
                A[0]++;
            }
            if(BigliettoSecondaClasse* b2=dynamic_cast<BigliettoSecondaClasse*>(&(**i)))
            {
                if(b2->getPrenotazione())
                {
                    A[1]++;
                }
                else
                {
                    A[2]++;
                }
            }
        }
        return A;
    }

    void vendiBiglietto(const Biglietto& b)
    {
        if(dynamic_cast<const BigliettoPrimaClasse*>(&b))
        {
            if(maxPosti1)
            {
                maxPosti1--;
                v.push_back(BigliettoSmart(const_cast<Biglietto*>(&b)));
            }
            else
                throw TrenoPieno(1);
        }
        else if(const BigliettoSecondaClasse* b2= dynamic_cast<const BigliettoSecondaClasse*>(&b))
        {
            if(b2->getPrenotazione() && maxPostiPrenotabili2)
            {
                maxPostiPrenotabili2--;
                v.push_back(BigliettoSmart(const_cast<Biglietto*>(&b)));
            }
            else if(!b2->getPrenotazione())
            {
                v.push_back(const_cast<Biglietto*>(&b));
            }
            else
                throw TrenoPieno(2);
        }
    }

    double incasso() const
    {
        vector<BigliettoSmart>::const_iterator i;
        double incasso=0;
        for(i=v.begin(); i!=v.end(); ++i)
        {
            incasso=incasso+(*i)->prezzo();
        }
        return incasso;
    }
};

int main()
{
    cout << "Hello World!" << endl;
    return 0;
}

