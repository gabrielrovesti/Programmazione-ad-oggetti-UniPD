#include <iostream>

using namespace std;

namespace ns {
class C {
public:
C(int n=0) : x(n) {}
private:
friend int f();
int x;
};

int f() {
ns::C c;
return c.x;}
}


int main() {
ns::f();
return 0;
}
