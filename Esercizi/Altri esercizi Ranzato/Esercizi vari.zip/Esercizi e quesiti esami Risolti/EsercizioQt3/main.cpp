#include "mainwindow.h"
#include <QApplication>
#include "MyWidget.h"S
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MyWidget widget;
    widget.show();

    return a.exec();
}
