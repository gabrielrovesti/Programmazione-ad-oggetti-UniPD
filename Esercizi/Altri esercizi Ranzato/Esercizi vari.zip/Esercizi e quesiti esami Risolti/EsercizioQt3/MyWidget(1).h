#ifndef MYWIDGET_H
#define MYWIDGET_H

#include <QApplication>
#include <QFont>
#include <QPushButton>
#include <QWidget>
#include <QLCDNumber>
#include <QSlider>
#include <QVBoxLayout>

class MyWidget : public QWidget
{
public:
    MyWidget(QWidget* parent=0) : QWidget(parent){
        QPushButton* quit=new QPushButton(tr("Quit"));
        quit->setFont(QFont("Times", 18, QFont::Bold));
        QLCDNumber* lcd=new QLCDNumber(3);
        lcd->setSegmentStyle(QLCDNumber::Filled);
        QSlider* slider=new QSlider(Qt::Horizontal);
        slider->setRange(0, 10);
        slider->setValue(5);
        connect(quit, SIGNAL(clicked()), qApp, SLOT(quit()));
        connect(slider, SIGNAL(valueChanged(int)), lcd, SLOT(display(int)));
        QVBoxLayout* layout=new QVBoxLayout;
        layout->addWidget(quit);
        layout->addWidget(lcd);
        layout->addWidget(slider);
        setLayout(layout);
    }
};

#endif // MYWIDGET_H
