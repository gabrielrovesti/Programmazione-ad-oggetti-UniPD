#include "mywidget.h"
#include "lcdrange.h"
#include <QApplication>
#include <QFont>
#include <QGridLayout>
#include <QPushButton>
#include <QWidget>
#include <QVBoxLayout>

MyWidget::MyWidget(QWidget* parent) : QWidget(parent)
{
    QPushButton* quit=new QPushButton(tr("Quit"));
    quit->setFont(QFont("Times", 18, QFont::Bold));
    connect(quit, SIGNAL(clicked()), qApp, SLOT(quit()));
    QGridLayout* grid=new QGridLayout;
    LCDRange* previousRange= 0;
    for(int row=0; row<3; ++row)
    {
        for(int column=0; column<3; ++column)
        {
            LCDRange* lcdRange=new LCDRange;
            grid->addWidget(lcdRange, row, column);
            if(previousRange)
            connect(lcdRange, SIGNAL(valueChanged(int)), previousRange, SLOT(setValue(int)));
            previousRange=lcdRange;
        }
    }
    QVBoxLayout* vblayout=new QVBoxLayout;
    vblayout->addWidget(quit);
    vblayout->addLayout(grid);
    setLayout(vblayout);
}
