#ifndef MYWIDGET_H
#define MYWIDGET_H

#include <QWidget>
class MyWidget : public QWidget
{
public:
    MyWidget(QWidget* parent=0);
};

#endif // MYWIDGET_H
