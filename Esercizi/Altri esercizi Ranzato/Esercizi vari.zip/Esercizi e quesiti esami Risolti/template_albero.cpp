#include<iostream>
using namespace std;

template <class T>
class albero {
public:
	albero();
	albero(const albero&); 
	albero& operator=(const albero&);
	~albero();	
	bool operator==(const albero&) const;
	friend ostream& opertaor<< <T> (ostream&, const albero&);
private:
	class nodo {
	public:
		T info; //parametro di tipo T
		nodo *sx, *cx, *dx; //sottoalberi sinistro, centr, destro
		nodo(const T&, nodo* =0, nodo* =0, nodo* =0); //costruttore
		~nodo(); //distruzione profonda
	};
	
	nodo* radice; //puntatore alla radice, albero vuoto: radice=0

	static nodo* copia(nodo* p);
	static bool uguali(nodo* a, nodo* b); //uguaglianza ricorsiva, ho bisogno dell'uguaglianza di puntatori a nodo e non di nodi
	static ostream& stampa(ostream&, nodo*);
};


template <class T> //implementazione ugualiana puntatori a nodo
static bool albero<T>::uguali(typename albero<T>::nodo* a, typename albero<T>::nodo * b) {
	if(!a && !b) return true;
	if((a && !b) || (!a && b)) return false;
	// a !== && b !=0
	return (a->info == b->info) && uguali(a->sx, b->sx) && uguali(a->cx, b->cx) && uguali(a->dx, b->dx);
}

template <class T> //implementazione == fra alberi
bool albero<T>::operator==(const albero<T>& a) const {
	return uguali(radice, a.radice);
}

template <class T>
albero<T>::albero(): radice(0) {};

template <class T>
albero<T>::albero(const albero& a): radice(copia(a.radice)) {};

template <class T>
albero<T>& albero<T>::operator=(const albero<T>& a) {
	if(this != &a) {
		delete radice; //distruzione deep
		radice = copia(a.radice);
	}
	return *this;
}

template <class T>
albero<T>::~albero() {
	delete radice; //giorgio gay
}

template <class T>
static albero<T>::nodo* copia(typename albero<T>::nodo *const p) {
	if(!p) return 0;
	//p punta alla radice di un albero non vuoto
	return new nodo(p->info, copia(p->sx), copia(p->cx), copia(p->dx));
}

template <class T>
albero<T>::nodo::nodo(const T& t, typename albero<T>::nodo* s, typename albero<T>::nodo* c, typename albero<T>::nodo* d): info(t), sx(s), cx(c), dx(d) {}

template <class T>
albero<T>::nodo::~nodo() {
	if(!sx && !cx && !dx) return;
	//almeno un sottoalbero e' non vuoto
	delete sx; //recursive calls of ~nodo()
	delete cx; 
	delete dx;
}

//finire per casa!!!!!!!!!! 

template <class T> 
static ostream& albero<T>::stampa(ostream& os, nodo* a) {
	
}

template <class T> 
ostream& operator<< (ostream& os, const albero<T>& a) {

}

