#ifndef MYWIDGET_H
#define MYWIDGET_H
#include <QApplication>
#include <QFont>
#include <QPushButton>
#include <QWidget>
#include <QLCDNumber>
#include <QSlider>
#include <QVBoxLayout>
class MyWidget : public QWidget
{
public:
    MyWidget(QWidget* parent=0) : QWidget(parent){
        setWindowTitle("I'm a Qwidget");
        resize(200, 120);
        QPushButton* quit=new QPushButton(tr("Qiut"), this);
        quit->setFont(QFont("Times", 18, QFont::Bold));
        connect(quit, SIGNAL(clicked()), qApp, SLOT(quit()));
        QVBoxLayout* layout=new QVBoxLayout;
        layout->addWidget(quit);
        setLayout(layout);
    }

};
#endif // MYWIDGET_H
