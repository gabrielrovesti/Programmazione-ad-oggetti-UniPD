#include <iostream>

using namespace std;

template <class T, int size>
class C
{
    friend ostream& operator<< <T, size>(ostream&, const C<T, size>&);
private:
    class MultiInfo
    {
    private:
        int molt;
        T info;
    public:
        T* getPointerInfo() const {return &info;}
        T getInfo() const {return info;}
        int getMolt() const {return molt;}
        MultiInfo(int m, const T& i) : molt(m), info(i) {}
    };
    MultiInfo* A;
public:
    C(const T& t, int k)
    {
        A=new MultiInfo[size];
        for(int i=0; i<size; ++i)
        {
            if(k>=1)
            {
                A[i]=MultiInfo(t, k);
            }
            else
                A[i]=MultiInfo(t, 0);
        }
    }

    C(const C& c)
    {
        A=new MultiInfo[size];
        for(int i=0; i<size; ++i)
        {
            A[i]=c.A[i];
        }
    }

    C& operator=(const C& c)
    {
        if(this!=&c)
        {
            delete A;
            for(int i=0; i<size; ++i)
            {
                A[i]=c.A[i];
            }
        }
        return *this;
    }

    ~C()
    {
        if(A)
            delete[] A;
    }
    T* operator[] (int k)
    {
        if(k>=0 && k<size)
        {
            return A[k].getPointerInfo();
        }
        else
            return 0;
    }

    int occorrenze(const T& t) const
    {
        int count=0;
        for(int i=0; i<size; ++i)
        {
            if(A[i].getInfo()==t)
            {
                count=count+A[i].getMolt();
            }
        }
        return count;
    }
};

template <class T, int size>
ostream& operator<<(ostream& o, const C<T, size>& c)
{
    for(int i=0; i<size; ++i)
    {
        o<<c.A[i].getInfo();
        o<<c.A[i].getMolt();
    }
    return o;
}

int main()
{
    cout << "Hello World!" << endl;
    return 0;
}

