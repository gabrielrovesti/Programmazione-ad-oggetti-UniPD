#include <iostream>
#include <vector>
#include <list>
using namespace std;

class Opera
{
private:
    string titolo;
public:
    virtual bool disponibile(int) const=0;
    virtual void setPrestito(bool) =0;
    virtual bool operator==(const Opera& op)
    {
        return titolo==op.titolo;
    }
    string getTitolo() const
    {
        return titolo;
    }
};

class Libro : public Opera
{
private:
    string autore;
    bool prestito;
public:
    friend ostream& operator<<(ostream&, const Libro&);
    virtual bool disponibile(int annoAttuale) const
    {
        return prestito;
    }

    virtual void setPrestito(bool b)
    {
        prestito=b;
    }

    virtual bool operator==(const Opera& op)
    {
        const Libro* l=dynamic_cast<const Libro*> (&op);
        return Opera::operator==(op) && autore==l->autore;
    }

    string getAutore() const
    {
        return autore;
    }
};

ostream& operator<<(ostream& os, const Libro& l)
{
    os<<l.getTitolo()<<" "<<l.autore;
    return os;
}

class Riviste : public Opera
{
private:
    int anno;
    static int maxAnni;
public:
    friend ostream& operator<<(ostream&, const Riviste&);
    virtual bool disponibile(int annoAttuale) const
    {
        return annoAttuale-anno<maxAnni;
    }
    virtual bool operator==(const Opera& op)
    {
        const Riviste* r=dynamic_cast<const Riviste*> (&op);
        return Opera::operator==(op) && anno==r->anno;
    }
    int getAnno() const
    {
        return anno;
    }
};
ostream& operator<<(ostream& os, const Riviste& r)
{
    os<<r.getTitolo()<<" "<<r.anno;
    return os;
}


class Dvd : public Opera
{
private:
    vector<string> lingue;
    bool prestito;
public:
    friend ostream& operator<<(ostream&, const Dvd&);
    virtual bool disponibile(int annoAttuale) const
    {
        return prestito;
    }
    virtual void setPrestito(bool b)
    {
        prestito=b;
    }

    virtual bool operator==(const Opera& op)
    {
        return Opera::operator==(op);
    }

    bool cercaLingua(string l) const
    {
        vector<string>::const_iterator i;
        bool trovata=false;
        for(i=lingue.begin(); i!=lingue.end() && !trovata; ++i)
        {
                if(*i==l)
                {
                    trovata=true;
                }
                return trovata;
        }
    }
};

ostream& operator<<(ostream& os, const Dvd& d)
{
    os<<d.getTitolo()<<endl;
    vector<string>::const_iterator i;
    for(i=(d.lingue).begin(); i!=(d.lingue).end(); ++i)
    {
        os<<(*i)<<endl;
    }
    return os;
}

class NonPresente {};

class Biblioteca
{
private:
    vector<Opera*> bib;
    list<Opera*> prest;
public:
    friend ostream& operator<<(ostream&, const Biblioteca&);
    void presta(Opera* op)
    {
        vector<Opera*>::iterator i;
        bool trovato=false;
        for(i=bib.begin(); i!=bib.end() && !trovato; ++i)
        {
            if(*(*i)==*op)
            {
                trovato=true;
            }
        }
        if(!trovato)
        {
            throw NonPresente();
        }
        else
        {
            prest.push_back(*i);
        }
        if(!dynamic_cast<Riviste*>(*i))
        {
            (*i)->setPrestito(true);
        }
    }

    void aggiungi(Opera* op)
    {
        bib.push_back(op);
    }

    vector<Opera*> consultabili(int anno) const
    {
        vector<Opera*> v;
        vector<Opera*>::const_iterator i;
        for(i=bib.begin(); i!=bib.end(); ++i)
        {
            if((*i)->disponibile(anno))
            {
                 v.push_back(*i);
            }
        }
        return v;
    }

vector<Opera*> cerca(string s) const
    {
        vector<Opera*> v;
        vector<Opera*>::const_iterator i;
        for(i=bib.begin(); i!=bib.end(); ++i)
        {
            if(Libro* l=dynamic_cast<Libro*>(*i))
            {
                if(s==l->getTitolo())
                {
                    v.push_back(*i);
                }
                else if(s==l->getAutore())
                {
                    v.push_back(*i);
                }
            }
            if(Riviste* r=dynamic_cast<Riviste*>(*i))
            {
                if(s==r->getTitolo())
                {
                    v.push_back(*i);
                }
            }
            if(Dvd* d=dynamic_cast<Dvd*>(*i))
            {
                if(s==d->getTitolo())
                {
                    v.push_back(*i);
                }
                if((d)->cercaLingua(s))
                {
                    v.push_back(*i);
                }
            }
        }
        return v;
    }
};

ostream& operator<<(ostream& os, const Biblioteca& b)
{
    vector<Opera*>::const_iterator i;
    for(i=(b.bib).begin(); i!=(b.bib).end(); ++i)
    {
        if(Libro* l=dynamic_cast<Libro*>(*i))
        {
            os<<"Libro:"<<endl;
            os<<*l<<endl;
        }
        if(Riviste* r=dynamic_cast<Riviste*>(*i))
        {
            os<<"Rivista:"<<endl;
            os<<*r<<endl;
        }
        if(Dvd* d=dynamic_cast<Dvd*>(*i))
        {
            os<<"Dvd:"<<endl;
            os<<*d<<endl;
        }
    }
    return os;
}

int main()
{
    return 0;
}


