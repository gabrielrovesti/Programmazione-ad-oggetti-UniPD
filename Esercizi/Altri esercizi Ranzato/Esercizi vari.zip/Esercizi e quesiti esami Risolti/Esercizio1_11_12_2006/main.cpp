#include <iostream>
#include <vector>
using namespace std;

class Abbonato
{
public:
   virtual double costoAttuale() const=0;
   virtual ~Abbonato();
};

class AbbonatoTempo : public Abbonato
{
private:
    int sec;
    static double tariffaTemp;
public:
    AbbonatoTempo(int s) : sec(s) {}
    int getSec() const {return sec;}
    double costoAttuale() const {return sec*tariffaTemp;}
};
double AbbonatoTempo::tariffaTemp=0.2;

class AbbonatoTraffico : public Abbonato
{
private:
    double kb;
    static double tariffaKB;
public:
    AbbonatoTraffico(double k) : kb(k) {}
    double getKB() const {return kb;}
    double costoAttuale() const {return kb*tariffaKB;}
};
double AbbonatoTraffico::tariffaKB=0.1;

class FilialeSlowWeb
{
private:
    vector<Abbonato*> v;
    double sc;
    int s;
    double k;
public:
    void inserisci(const Abbonato& a)
    {
        Abbonato* ab = const_cast<Abbonato*>(&a);
        v.push_back(ab);
    }

    double bolletta(const Abbonato& a) const
    {
        if(const AbbonatoTempo* at=dynamic_cast<const AbbonatoTempo*>(&a))
        {
            if(at->getSec()>s)
            {
                return at->costoAttuale()-sc;
            }
            else
                return at->costoAttuale();
        }
        else
        {
            const AbbonatoTraffico* atr=dynamic_cast<const AbbonatoTraffico*>(&a);
            if(atr->getKB()>k)
            {
                    return atr->costoAttuale()-sc;
            }
            else
                return atr->costoAttuale();
        }
    }

    double totaleBollette() const
    {
        double bolletta=0;
        vector<Abbonato*>::const_iterator i;
        for(i=v.begin(); i!=v.end(); ++i)
        {
            bolletta=bolletta+this->bolletta(**i);
        }
        return bolletta;
    }

};

int main()
{
    cout << "Hello World!" << endl;
    return 0;
}

