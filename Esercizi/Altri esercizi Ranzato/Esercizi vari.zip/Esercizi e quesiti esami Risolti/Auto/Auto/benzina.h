#ifndef BENZINA_H
#define BENZINA_H
#include "auto.h"
class Benzina : public Auto
{
private:
    static double bonusEco4;
    bool Euro4;
public:
    Benzina(int cf=0, bool b=true) : Auto(cf), Euro4(b) {};
    virtual double tassa() const;
};

#endif // BENZINA_H
