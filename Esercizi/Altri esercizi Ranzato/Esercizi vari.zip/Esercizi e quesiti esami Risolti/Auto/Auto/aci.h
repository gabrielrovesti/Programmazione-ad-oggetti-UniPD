#ifndef ACI_H
#define ACI_H
#include "auto.h"
#include <vector>
using namespace std;
class ACI
{
private:
    vector<Auto*> v;
public:
    void aggiungiAuto(const Auto& a);
    double incassaBolli() const;
};

#endif // ACI_H
