#include "auto.h"
#include "benzina.h"

double Benzina::tassa() const
{
    if(Euro4)
    {
        return getCavalliFiscali()*getTassaPerCf()-bonusEco4;
    }
    else
        return getCavalliFiscali()*getTassaPerCf();
}
