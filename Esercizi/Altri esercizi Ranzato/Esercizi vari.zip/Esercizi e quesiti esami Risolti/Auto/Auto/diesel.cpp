#include "auto.h"
#include "diesel.h"

double Diesel::tassa() const
{
    return getCavalliFiscali()*getTassaPerCf()+tassaDiesel;
}
