#include "auto.h"

Auto::Auto(int cf)
{
    cv=cf;
}
