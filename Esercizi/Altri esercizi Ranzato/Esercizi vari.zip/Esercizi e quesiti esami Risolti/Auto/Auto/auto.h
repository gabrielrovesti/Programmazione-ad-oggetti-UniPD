#ifndef AUTO_H
#define AUTO_H

class Auto
{
private:
    int cv;
    static double tassaPerCv;
protected:
    Auto(int);
    virtual ~Auto() {}
public:
    double getCavalliFiscali() const {return cv;}
    static double getTassaPerCf() {return tassaPerCv;}
    virtual double tassa() const = 0;
};
double Auto::tassaPerCv=5;


#endif // AUTO_H
