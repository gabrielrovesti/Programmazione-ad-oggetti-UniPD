#include <vector>
#include "aci.h"
#include "auto.h"
using namespace std;
void ACI::aggiungiAuto(const Auto& a)
{
    Auto & t = const_cast<Auto&>(a);
    v.push_back(&t);
}

double ACI::incassaBolli() const
{
    vector<Auto*>::const_iterator it;
    double bolloTotale=0;
    for(it=v.begin(); it!=v.end(); it++)
    {
        bolloTotale=bolloTotale+(*it)->tassa();
    }
    return bolloTotale;
}
