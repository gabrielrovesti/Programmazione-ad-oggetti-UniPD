#include <iostream>
#include <vector>
#include "auto.h"
#include "benzina.h"
#include "diesel.h"
#include "aci.h"
using namespace std;

int main()
{
    Benzina fiat(60, false), lancia(60, true);
    Diesel bmw(90), audi(80);
    ACI a;
    a.aggiungiAuto(fiat); a.aggiungiAuto(lancia);
    a.aggiungiAuto(bmw); a.aggiungiAuto(audi);
    cout<<a.incassaBolli()<<endl;
}

