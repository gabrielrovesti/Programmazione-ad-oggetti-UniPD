#ifndef DIESEL_H
#define DIESEL_H
#include "auto.h"
class Diesel : public Auto
{
private:
    static double tassaDiesel;
public:
    Diesel(int cf=0) : Auto(cf) {};
    virtual double tassa() const;
};

#endif // DIESEL_H
