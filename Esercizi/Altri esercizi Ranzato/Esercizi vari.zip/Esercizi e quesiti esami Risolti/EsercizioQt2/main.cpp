#include "mainwindow.h"
#include <QApplication>
#include <QFont>
#include <QPushButton>
#include <QWidget>
#include <QVBoxLayout>
int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QWidget window;
    window.setWindowTitle("I'm a QWidget");
    window.resize(300, 220);
    QPushButton quit("Quit", &window);
    quit.setFont(QFont("Times", 28, QFont::Bold));
    quit.setGeometry(60, 80, 200, 60);
    QObject::connect(&quit, SIGNAL(clicked()), &app, SLOT(quit()));
    window.show();

    return app.exec();
}
