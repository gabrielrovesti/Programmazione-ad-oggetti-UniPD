class C {
public:
int */*const*/ p;   //tolgo il const perch� nell'assegnazione (*) assegna il valore di y.p a x.p ma x.p � costante e non pu� essere modificato!
C(int a=0): p(new int(a))
{ }
};
main() {
C x(3);
C y;
x=y;    // (*)
C z(y);
}
