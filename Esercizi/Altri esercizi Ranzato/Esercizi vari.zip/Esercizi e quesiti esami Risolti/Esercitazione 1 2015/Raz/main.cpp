//file main.cpp
#include <iostream>
#include "../Raz.h"
using namespace std;

int main()
{
    Raz r;
    double d=r.unTerzo();
    cout<<d;
}
