//file Raz.cpp
#include "Raz.h" //includo il file header con la sola definizione dei metodi della classe Raz
#include <iostream>
using std::endl;

Raz::Raz(){}

Raz::Raz(int a, int b) /*: num(a), den(b) */{num=a; den=b;}

Raz Raz::inverso() const {Raz s; s.num=den; s.den=num; return s;}

Raz::operator double() const {double d=num/den; return d;}

Raz Raz::operator++(int) {num+=den; return *this;}

bool Raz::operator==(Raz r) const
{
    if(num/den==r.num/r.den)
    {
        return true;
    }
    else
    {
        return false;
    }
}

double Raz::unTerzo() {double x=((double)1/3); return x;}

ostream& operator<<(ostream& os, const Raz& r) {os<<r.num<<' '<<r.den<<endl; return os;}
