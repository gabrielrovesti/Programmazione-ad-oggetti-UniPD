//file "Raz.h"
#ifndef RAZ_H
#define RAZ_H
#include<iostream>
using std::ostream;
class Raz{
friend ostream& operator<<(ostream&, const Raz&);   //dichiaro amico l'overloading dell'operatore di output perch� lo voglio dichiarare esterno
private:
    int num;
    int den;
public:
    Raz();  //costruttore di default
    Raz(int num, int den);  //costruttore a due parametri
    Raz inverso() const;    //metodo inverso costante perch� non modifica l'oggetto di invocazione
    operator double() const;    //ridefinisco l'operatore esplicito di conversione da Raz a double
    Raz operator++(int);    //ridefinisco l'operatore ++ postfisso(si differenzia dall'infisso passandogli int come parametro)
    bool operator==(Raz r) const;   //ridefinisco l'operatore == costante perch� non modifica l'oggetto di invocazione
    static double unTerzo();    //metodo statico unTerzo perch� non ha oggetto di invocazione e ritorna sempre 1/3
};
#endif
