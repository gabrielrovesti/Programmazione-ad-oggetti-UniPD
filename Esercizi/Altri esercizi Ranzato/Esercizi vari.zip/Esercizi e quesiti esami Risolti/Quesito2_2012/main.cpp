#include <iostream>
using namespace std;

class A
{
protected:
    int x;
public:
    A(int k=0) : x(k) {cout<<"A(int) ";}
    ~A() {cout<<"~A() ";}
    operator double() const {cout<<"operator double() "; return x;} //operatore esplicito di conversione da A a double
};

class B : public A
{
public:
    static A a;
    const A& a2;
    A F(A a=A()) {return a;}
    B(int k=3, const A& a3=0) : A(k), a2(a3) {cout<<"B() ";}
    ~B() {cout<<"~B ";}
    B(const B& b) : a2(b) {cout <<a2<<" ";}
};
A B::a(1);


int main()
{
    A a(1); cout<<"UNO"<<endl;
    // A(int) A(int) UNO

    B b; cout<<"DUE"<<endl;
    //A(int) ~A() A(int) B() DUE

    B b2(a); cout<<"TRE"<<endl;
    //operator double() A(int) ~A() A(int) B() TRE

    B b3(a, a); cout<<"QUATTRO"<<endl;
    //operator double() A(int) B() QUATTRO

    B b4=b3; cout<<"CINQUE"<<endl;
    //operator double() 1 " " CINQUE

    b.F(); cout<<"SEI"<<endl;
    //A(int) ~A() ~A() ~A()

    b.F(2); cout<<"SETTE"<<endl;
    //A(int) ~A() ~A() ~A()

    //~B() ~A() ~B() ~A() ~B() ~A() ~B() ~A() ~A() ~A()
    return 0;
}
