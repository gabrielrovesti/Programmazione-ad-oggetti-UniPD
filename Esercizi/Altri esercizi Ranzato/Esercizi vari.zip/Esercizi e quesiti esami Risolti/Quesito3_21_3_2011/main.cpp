#include <iostream>
#include <string>
#include <vector>
#include <typeinfo>
using namespace std;
class AgenziaEDS;

class PaccoBase
{
private:
    string mittente;
    string destinatario;
    double peso;
    static double tariffa;
public:
    PaccoBase(string m, string d, double p) : mittente(m), destinatario(d), peso(p) {}
    virtual double costo() const {return tariffa*peso;}
    double getPeso() const {return peso;}
    string getDestinatario() const {return destinatario;}
    string getMittente() const {return mittente;}
    virtual ~PaccoBase() {} //ATTENZIONE!!!
};
double PaccoBase::tariffa=10;

class PaccoDue : public PaccoBase
{
private:
    static double tariffaDue;
public:
    PaccoDue(string m, string d, double p) : PaccoBase(m,d,p) {}
    double costo() const { return PaccoBase::costo()+tariffaDue;}
    double getTariffaDue() const {return tariffaDue;}
};
double PaccoDue::tariffaDue=2;

class PaccoFast : public PaccoBase
{
private:
    bool overnight;
    static double tariffaFast;
    static double tariffaNight;
public:
    PaccoFast(string m, string d, double p, bool o=false) : PaccoBase(m,d,p), overnight(o) {}
    double getTariffaFast() const {return tariffaFast;}
    double getTariffaNight() const {return tariffaNight;}
    bool isOvernight() const {return overnight;}
    void setOvernight(bool o) {overnight=o;}
    double costo() const
    {
        if(overnight)
        {
            return PaccoBase::costo()+getPeso()*tariffaFast+tariffaNight;
        }
        else
            return PaccoBase::costo()+getPeso()*tariffaFast;
    }
};
double PaccoFast::tariffaFast=5;
double PaccoFast::tariffaNight=7;

class AgenziaEDS
{
private:
    vector<PaccoBase*> v;
public:
    AgenziaEDS(vector<PaccoBase*> vec) : v(vec) {}
    friend ostream& operator <<(ostream&, const AgenziaEDS&);
    vector<PaccoFast> cerca(string d, double pes) const
    {
        vector<PaccoFast> vec;
        vector<PaccoBase*>::const_iterator i;
        for(i=v.begin(); i!=v.end(); ++i)
        {
            if(PaccoFast* p=dynamic_cast<PaccoFast*>(*i))
            {
                if(p->getDestinatario()==d && p->getPeso()>pes && p->isOvernight())
                {
                    PaccoFast pf(*p);
                    vec.push_back(pf);
                }
            }
        }
        return vec;
    }

    void modifica(string m)
    {
        vector<PaccoBase*>::iterator i;
        for(i=v.begin(); i!=v.end(); ++i)
        {
            if(PaccoBase* p=dynamic_cast<PaccoBase*>(*i))
            {
                if(p->getMittente()==m)
                {
                    PaccoFast* pf=new PaccoFast(p->getDestinatario(), p->getMittente(), p->getPeso(), true);
                    PaccoBase* pb=pf;
                    delete p;
                    v.erase(i);
                    v.push_back(pb);
                }
            }
        }
    }
};

ostream& operator<<(ostream& o, const AgenziaEDS& a)
{
    vector<PaccoBase*>::const_iterator it;
    double costo=0;
    for(it=(a.v).begin(); it!=(a.v).end(); ++it)
    {
        costo=costo+(*it)->costo();
    }
    o<<costo<<" ";
    for(it=(a.v).begin(); it!=(a.v).end(); ++it)
    {
        if(dynamic_cast<PaccoBase*>(*it))
        {
            o<<"Pacco Base"<<" ";
            o<<(*it)->costo();
        }
        else if(PaccoDue* p=dynamic_cast<PaccoDue*>(*it))
        {
            o<<"Pacco Due"<<" ";
            o<<(*it)->costo();
            o<<(p)->getTariffaDue();
        }
        else
        {
            PaccoFast* l=dynamic_cast<PaccoFast*>(*it);
            o<<"Pacco Fast"<<" ";
            o<<(*it)->costo()<<" ";
            o<<l->getTariffaFast();
            o<<l->getTariffaNight();
        }
    }
    return o;
}

int main()
{
    cout << "Hello World!" << endl;
    return 0;
}

