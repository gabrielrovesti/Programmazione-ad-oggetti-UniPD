#ifndef TRENOPIENO_H
#define TRENOPIENO_H
class TrenoPieno{
private:
    bool prima;
public:
    TrenoPieno(bool pr=false):prima(pr){}
};
#endif