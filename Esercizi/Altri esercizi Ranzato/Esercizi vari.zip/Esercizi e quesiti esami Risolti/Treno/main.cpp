//
//  main.cpp
//  Treno
//
//  Created by alberto adami on 17/03/13.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[])
{

    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}

