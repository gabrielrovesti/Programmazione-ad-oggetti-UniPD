#include "mainwindow.h"
#include <QApplication>
#include <QLabel>
#include <qpushbutton.h>
int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QPushButton hello("Hello world!");
    hello.show();

    return QApplication::exec();
}
