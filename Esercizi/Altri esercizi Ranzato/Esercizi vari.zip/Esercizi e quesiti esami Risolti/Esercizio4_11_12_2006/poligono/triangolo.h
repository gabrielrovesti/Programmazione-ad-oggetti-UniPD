#ifndef TRIANGOLO_H
#define TRIANGOLO_H
#include "punto.h"
#include "poligono.h"

class triangolo : public poligono
{
public:
    triangolo(const punto v[]) : poligono(3, v) {}
    virtual double area() const;
};

#endif // TRIANGOLO_H
