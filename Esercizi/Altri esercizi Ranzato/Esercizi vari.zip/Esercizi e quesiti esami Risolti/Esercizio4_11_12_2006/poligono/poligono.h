#ifndef POLIGONO_H
#define POLIGONO_H
#include "punto.h"
class poligono
{
protected:
    int nvertici;
    punto* pp;
public:
    poligono(int, const punto v[]);
    ~poligono();
    poligono(const poligono&);
    poligono& operator=(const poligono&);
    virtual double perimetro() const;
};

#endif // POLIGONO_H
