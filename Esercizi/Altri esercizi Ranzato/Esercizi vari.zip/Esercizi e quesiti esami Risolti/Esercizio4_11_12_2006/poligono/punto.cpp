#include "punto.h"
#include <math.h>
#include <stdio.h>

punto::punto(int a, int b)
{
    x=a;
    y=b;
}

double punto::getX() const
{
    return x;
}


double punto::getY() const
{
    return y;
}


double punto::lung(const punto& p1, const punto& p2)
{
    return sqrt(pow((p2.getX()-p1.getX()), 2)+pow((p2.getY()-p1.getY()), 2));
}

