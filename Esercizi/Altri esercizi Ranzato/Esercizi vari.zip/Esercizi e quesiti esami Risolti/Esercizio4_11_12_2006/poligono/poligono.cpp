#include "poligono.h"
#include "punto.h"

poligono::poligono(int nv, const punto V[])
{
    nvertici=nv;
    pp=new punto[nv];
    for(int i=0; i<nvertici; i++)
    {
       pp[i]=V[i];
    }
}

poligono::poligono(const poligono& pol)
{
    nvertici=pol.nvertici;
    for(int i=0; i<nvertici; i++)
    {
       pp[i]=pol.pp[i];
    }
}

poligono& poligono::operator=(const poligono& pol)
{
    nvertici=pol.nvertici;
    for(int i=0; i<nvertici; i++)
    {
       pp[i]=pol.pp[i];
    }
    return *this;
}

poligono::~poligono()
{
    delete pp;
}

double poligono::perimetro() const
{
    int i=0;
    double per=0;
    while(i<nvertici-1)
    {
        per = per+punto::lung(pp[i], pp[i+1]);
        i++;
    }
    per=per+per+punto::lung(pp[i], pp[0]);
    return per;
}
