#ifndef TRI_RETTANGOLO_H
#define TRI_RETTANGOLO_H
#include "punto.h"
#include "poligono.h"
#include "triangolo.h"

class tri_rettangolo : public triangolo
{
public:
    tri_rettangolo(const punto v[]) : triangolo(v) {};
    virtual double perimetro() const;
    virtual double area() const;
};

#endif // TRI_RETTANGOLO_H
