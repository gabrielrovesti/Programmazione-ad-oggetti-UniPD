#ifndef PUNTO_H
#define PUNTO_H

class punto
{
private:
    double x, y;
public:
    punto(int= 0, int= 0);
    double getX() const;
    double getY() const;
    static double lung(const punto& p1, const punto& p2);
};

#endif // PUNTO_H
