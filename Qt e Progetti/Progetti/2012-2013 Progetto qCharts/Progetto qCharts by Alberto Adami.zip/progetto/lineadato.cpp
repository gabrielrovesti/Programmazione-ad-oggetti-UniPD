//
//  lineadato.cpp
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#include "lineadato.h"
#include <QComboBox>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
LineaDato::LineaDato(QWidget* parent):QWidget(parent)
{
    QHBoxLayout* dato=new QHBoxLayout();
    title=new QLineEdit();
    artista=new QLineEdit();
    combo=new QComboBox();
    combo->insertItem(1,"Cd Fisico");
    combo->insertItem(2,"Cd Digitale");
    combo->insertItem(3,"Cd Corriere");
    combo->setCurrentIndex(0);
    numcanzoni=new QSpinBox();
    numcanzoni->setValue(0);
    numcanzoni->setRange(0,100);
    numcanzoni->setAccelerated(true);
    prezzo=new QDoubleSpinBox();
    prezzo->setValue(0.0);
    prezzo->setMinimum(0.0);
    prezzo->setMaximum(200.0);
    prezzo->setAccelerated(true);
    cunitario=new QDoubleSpinBox();
    cunitario->setValue(0.0);
    cunitario->setMinimum(0.0);
    cunitario->setMaximum(50.0);
    cunitario->setAccelerated(true);
    ctrasporto=new QDoubleSpinBox();
    ctrasporto->setValue(0.0);
    ctrasporto->setMinimum(0.0);
    ctrasporto->setMaximum(300.0);
    ctrasporto->setAccelerated(true);
    prezzo->setEnabled(true);
    cunitario->setEnabled(false);
    ctrasporto->setEnabled(false);
    dato->addWidget(title);
    dato->addWidget(artista);
    dato->addWidget(numcanzoni);
    dato->addWidget(combo);
    dato->addWidget(prezzo);
    dato->addWidget(cunitario);
    dato->addWidget(ctrasporto);
    setLayout(dato);            //installo su this
    connect(combo,SIGNAL(currentIndexChanged(int)),this,SLOT(Change(int)));
}
QString LineaDato::GetTitle() const
{
    return title->text();
}
QString LineaDato::GetArtista() const
{
    return artista->text();
}
int LineaDato::GetNumCanzoni() const
{
    return numcanzoni->value();
}
double LineaDato::GetPrezzo() const
{
    return prezzo->value();
}
double LineaDato::GetCunitario() const
{
    return cunitario->value();
}
double LineaDato::GetCtrasporto() const
{
    return ctrasporto->value();
}
void LineaDato::Change(int i)
{
    if(i==0)
    {
        prezzo->setEnabled(true);
        cunitario->setEnabled(false);
        ctrasporto->setEnabled(false);
        ctrasporto->setValue(0);
        cunitario->setValue(0);
    }
    else
        if(i==1)
        {
            prezzo->setEnabled(false);
            cunitario->setEnabled(true);
            ctrasporto->setEnabled(false);
            prezzo->setValue(0);
            ctrasporto->setValue(0);
        }
    else
        if(i==2)
        {
            prezzo->setEnabled(true);
            ctrasporto->setEnabled(true);
            cunitario->setEnabled(false);
            cunitario->setValue(0);
        }          
}
bool LineaDato::IsFisico() const
{
    return combo->currentIndex()==0;
}
bool LineaDato::IsDigitale() const
{
    return combo->currentIndex()==1;
}
bool LineaDato::IsCorriere() const
{
    return combo->currentIndex()==2;
}
