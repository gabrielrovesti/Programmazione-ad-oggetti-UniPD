//
//  input.cpp
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#include "input.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QDialogButtonBox>
#include <QPushButton>
#include <QMessageBox>
#include <string>
using std::string;
Input::Input(QWidget *parent,Valori* v,int ele) :QDialog(parent),val(v),n(ele)
{
    setWindowTitle("Inserimento dati");
    setModal(true);     //creo un dialog "bloccante"
    resize(900,600);
    QDialog::reject();
    QHBoxLayout* intestazione=new QHBoxLayout();//il layout contentente l'intestazione
    QLabel* titolo=new QLabel("Titolo");
    QLabel* artista=new QLabel("Artista");
    QLabel* num=new QLabel("n. canzoni");
    QLabel* tipo=new QLabel("Tipo");
    QLabel* prezzob=new QLabel("Prezzo");
    QLabel* prezzou=new QLabel("P. Unitario");
    QLabel* prezzot=new QLabel("P. Trasporto");
    intestazione->addSpacing(100);
    intestazione->addWidget(titolo);
    intestazione->addSpacing(100);
    intestazione->addWidget(artista);
    intestazione->addSpacing(40);
    intestazione->addWidget(num);
    intestazione->addSpacing(40);
    intestazione->addWidget(tipo);
    intestazione->addWidget(prezzob);
    intestazione->addWidget(prezzou);
    intestazione->addWidget(prezzot);
    QVBoxLayout* layout=new QVBoxLayout();
    layout->addLayout(intestazione);
    QVBoxLayout* container=new QVBoxLayout();
    QWidget *viewport = new QWidget();
    for(int i=0;i<n;i++)
    {
        LineaDato* dato=new LineaDato(this);
        container->addWidget(dato);
        lista.push_back(dato);
    }
    viewport->setLayout(container);
    area=new QScrollArea();
    area->setWidgetResizable(true);
    area->setWidget(viewport);
    layout->addWidget(area);
    QDialogButtonBox * button=new QDialogButtonBox;
    QPushButton* ok=new QPushButton("ok");
    QPushButton* annulla=new QPushButton("Annulla");
    ok->setFont(QFont("Times",18,QFont::Black));
    annulla->setFont(QFont("Times",18,QFont::Black));
    button->addButton(ok,QDialogButtonBox::ActionRole);
    button->addButton(annulla,QDialogButtonBox::ActionRole);
    layout->addWidget(button);
    connect(annulla,SIGNAL(clicked()),this,SLOT(close()));
    connect(ok,SIGNAL(clicked()),this,SLOT(Create()));
    connect(this,SIGNAL(Ok()),this,SLOT(close()));
    setLayout(layout);
}
bool Input::Isok() const
{
    bool ok=true;
    for(QList<LineaDato*>::const_iterator it=lista.begin();it!=lista.end() && ok;++it)
        if((*it)->GetTitle()==""||(*it)->GetArtista()=="")
            ok=false;
    for(QList<LineaDato*>::const_iterator it=lista.begin()+1;it!=lista.end() &&ok;it++)
        for(QList<LineaDato*>::ConstIterator ite=lista.begin();ite!=it && ok;ite++)
            if(((*it)->GetTitle()==(*ite)->GetTitle()) && (*it)->GetArtista()==(*ite)->GetArtista())
                    ok=false;
    return ok;
}
void Input::Create() throw(ErrorInput)
try
{
    if(!Isok())
        throw ErrorInput();
    else
    {
        if(val && val->Size())
               val->DeleteAll();//svuoto val dai vecchi valori
        for(QList<LineaDato*>::const_iterator it=lista.begin();it!=lista.end();++it)
        {
            CdMusicale* p=0;
            string titolo=((*it)->GetTitle()).toStdString();
            string artista=((*it)->GetArtista()).toStdString();
            int num=(*it)->GetNumCanzoni();
            if((*it)->IsFisico())
            {
                double prezzo=(*it)->GetPrezzo();
                p=new CdFisico(titolo,artista,num,prezzo);
            }
            if((*it)->IsDigitale())
            {
                double unit=(*it)->GetCunitario();
                p=new CdDigitale(titolo,artista,num,unit);
            }
            if((*it)->IsCorriere())
            {
                double prezzo=(*it)->GetPrezzo();
                double trasporto=(*it)->GetCtrasporto();
                p=new CdCorriere(titolo,artista,num,prezzo,trasporto);
            }
            if(val)
               val->Aggiungi(*p);
            emit Ok();
        }
    }
}
catch(ErrorInput i)
{
    QMessageBox::critical(0,"Errore!","Errore nei dati inseriti, e'' stato lasciato un campo vuoto o ripetuto un dato!");
}
