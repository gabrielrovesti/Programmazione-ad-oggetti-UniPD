//
//  newwindow.h
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#ifndef NEWWINDOW_H
#define NEWWINDOW_H
#include <QDialog>
#include <QRadioButton>
#include <QPushButton>
#include <QSpinBox>
#include "valori.h"
#include "input.h"
#include "error.h"
class NewWindow : public QDialog
{
Q_OBJECT
public:
      NewWindow(Valori* =0,QWidget *parent =0);
      bool IsZero() const;
      int Value() const;
private:
     int n;           //il numero di elementi da creare attualmente
     Valori* va;      //un puntatore a valori costanti
     QSpinBox* ndati;
     QPushButton* ok;
     QPushButton* annulla;
     QRadioButton* pointchart;
     QRadioButton* linechart;
     QRadioButton* barchart;
private slots:
     void ClickedPointChart();
     void ClickedLineChart();
     void ClickedBarChart();
     void ClickedOk() throw(Zero);
     void ChangeEle(int);
     void CreateChart();
signals:
     void Point(); //creato un PointChart
     void Bar();//creato un BarChart
     void Line();//creato un LineChart
     void New();
};
#endif // INPUTWINDOW_H
/*
La classe NewWindow rappresenta una finestra per la creazione di un nuovo Chart chiedendo il numero di dati del
nuovo Chart e il tipo di Chart che inizialmente si vuole rappresentare.
E' stato scelto da ereditare da QDialog in modo da creare una finestra "bloccante" che non permette di interagire
con altri elementi del programma fino a che non si ha finito di interagire con NewWindow.
Il costruttore riceve il puntatore all'oggetto di tipo valori in modo da fare l'operazione di "svuotamento" e inserire
i nuovi dati se la creazione avviene con successo.
*/
