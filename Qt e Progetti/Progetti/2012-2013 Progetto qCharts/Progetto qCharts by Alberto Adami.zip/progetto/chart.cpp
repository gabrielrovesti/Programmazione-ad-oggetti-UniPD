//
//  chart.cpp
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#include "chart.h"
Chart::Chart():dati(0),origine(QPointF(0,0)),xdistanza(0.0)
{
}
Chart::Chart(const QPointF & o, double x, const Dati & d):dati(const_cast<Dati*>(&d)),origine(o),xdistanza(x)
{
    QPointF inizio(origine.x()+20,origine.y());
    DatiNorm dn(d,450);
    for(int i=0;i<dn.Size();++i)
    {
        QPointF punto(inizio.x()+i*xdistanza,inizio.y()-dn[i]);
        points.push_back(punto);
    }

}
Dati& Chart::GetDati() const
{
    return *dati;
}
int Chart::Size() const
{
    return points.size();
}
bool Chart::IsEmpty() const
{
    return Size()==0;
}
QPointF Chart::GetOrigine() const
{
    return origine;
}
double Chart::Spazio() const
{
    return points[points.size()-1].x();
}
QPointF& Chart::operator [](int i) const
{
    vector<QPointF>::const_iterator it=points.begin()+i;
    return const_cast<QPointF&>(*it);
}
double Chart::GetDistanza() const
{
    return xdistanza;
}
Chart::~Chart()
{
    delete dati;
}
