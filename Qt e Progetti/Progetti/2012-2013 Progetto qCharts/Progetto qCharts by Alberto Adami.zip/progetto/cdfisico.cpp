//
//  cdfisico.cpp
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#include "cdfisico.h"
#include "cdcorriere.h"
CdFisico::CdFisico():CdMusicale(),costo(0.0)
{
}
CdFisico::CdFisico(string t, string a, int num, double p):CdMusicale(t,a,num),costo(p)
{
}
double CdFisico::GetCosto() const
{
    return costo;
}
void CdFisico::SetCosto(double c)
{
    costo=c;
}
bool CdFisico::operator ==(const CdMusicale& f) const
{
    if(dynamic_cast<const CdFisico*>(&f) && !dynamic_cast<const CdCorriere*>(&f))
    {
        const CdFisico& f1=dynamic_cast<const CdFisico&>(f);
        return GetArtista()==f1.GetArtista() && GetTitolo()==f1.GetTitolo() && GetNum()==f1.GetNum() && GetCosto()==f1.GetCosto();
    }
    return false;
}
bool CdFisico::operator !=(const CdMusicale& f) const
{
    if(dynamic_cast<const CdFisico*>(&f) && !dynamic_cast<const CdCorriere*>(&f))
    {
        const CdFisico& f1=dynamic_cast<const CdFisico&>(f);
        return !(GetArtista()==f1.GetArtista() && GetTitolo()==f1.GetTitolo() && GetNum()==f1.GetNum() && GetCosto()==f1.GetCosto());
    }
    return true;
}
double CdFisico::prezzo() const
{
    return costo;
}
