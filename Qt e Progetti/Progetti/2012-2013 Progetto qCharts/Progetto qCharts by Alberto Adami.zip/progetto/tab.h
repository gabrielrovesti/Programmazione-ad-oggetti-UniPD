//
//  tab.h
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#ifndef TABWIDGET_H
#define TABWIDGET_H
#include <QTabWidget>
#include <QScrollArea>
#include "table.h"
#include "canvas.h"
#include "valori.h"
#include "error.h"
class Tab : public QTabWidget
{
    Q_OBJECT
private:
    Valori* val;
    Table* tabella;
    Canvas* canvas;
    QScrollArea* area;

public:
     Tab(Valori*,QWidget *parent = 0);    
signals:
     void Close();
     void Remove();
     void NewRow();
     void InsertOk();
     void RemRow(int);
     void Last();
public slots:
     void DrawLine();
     void DrawBar();
     void DrawPoint();
     void Open();
     void AddElement() throw(Max);
     void RemoveElement();
     void InsertToValori() throw(ErrorAdd);
     void CloseAll();
};

#endif // TABWIDGET_H
/*
La classe Tab è il centralwidget della MainWindow e in una pagina vengono rappresentati i dati e in un altra il chart
corrispondente.
*/
