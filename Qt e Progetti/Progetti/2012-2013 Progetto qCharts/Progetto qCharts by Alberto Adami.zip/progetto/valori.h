//
//  valori.h
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#ifndef VALORI_H
#define VALORI_H
#include "cdmusicale.h"
#include "cdcorriere.h"
#include "cddigitale.h"
#include "cdfisico.h"
#include <vector>
using std::vector;
class Valori
{
private:
    vector<CdMusicale*> ogg;
public:
    Valori();
    void Delete(int);
    void Aggiungi(const CdMusicale&);
    int Size() const;
    bool IsEmpty() const;
    void DeleteAll();       //svuota l'intero vector e dealloca prima i puntatori
    bool operator==(const Valori&) const;
    bool operator!=(const Valori&) const;
    CdMusicale* operator[](int i) const;
    void Change(int,const CdMusicale&);
    ~Valori();  //distruttore profondo
};
#endif // VALORI_H
/*
La classe Valori contiene l'insieme dei puntatori a cdmusicali che si trovano attualmente in memoria.
*/
