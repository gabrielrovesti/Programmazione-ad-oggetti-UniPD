//
//  cddigitale.h
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#ifndef CDDIGITALE_H
#define CDDIGITALE_H
#include "cdfisico.h"
class CdDigitale : public CdMusicale
{
double prezzocanzone;               //il prezzo base per una canzone di un cd
public:
    CdDigitale();
    CdDigitale(string,string,int,double);
    double GetPrezzoUnitario() const;
    virtual bool operator==(const CdMusicale&) const;
    virtual bool operator!=(const CdMusicale&) const;
    void SetPrezzoUnitario(double);
    virtual double prezzo() const;
};

#endif // CDDIGITALE_H
/*
La classe CdDigitale rappresenta un cd acquistabile presso un sito web su forma digitale, quindi il prezzo sarà dato dal n°
di canzoni per il prezzo unitario.
La classe CdDigitale implementa il metodo prezzo();
*/
