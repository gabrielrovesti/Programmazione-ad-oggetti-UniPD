//
//  linechart.cpp
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#include "linechart.h"
LineChart::LineChart(const QPointF & i, double x, const Dati& dn):Chart(i,x,dn)
{
}
void LineChart::Draw(QPainter &p) const
{
    p.setPen(Qt::darkGreen);
    for(int i=0;i<Size()-1;++i)
    {
        QLineF linea(points[i],points[i+1]);
        p.drawLine(linea);
    }
    if(Size()>1)
    {
    for(int i=0;i<Size();++i)
    {
        QString index;
        index.setNum(i+1);
        p.setPen(QPen(Qt::black,3));
        QPointF punto(points[i].x(),GetOrigine().y()+20);
        p.drawText(punto,index);
        QPointF py1(GetOrigine().x()+5,points[i].y());
        QPointF py2(GetOrigine().x()-5,points[i].y());
        p.setPen(QPen(Qt::black,3));
        p.drawLine(QLineF(py1,py2));
    }
    for(int i=0;i<Size();++i)
    {
        p.setFont(QFont("arial",7,Qt::black));
        QString value(QString::number(GetDati()[i]));
        p.drawText(QPointF(GetOrigine().x()-25,points[i].y()),value);
    }
    }
}
