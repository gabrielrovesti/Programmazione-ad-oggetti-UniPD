//
//  newwindow.cpp
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#include "newwindow.h"
#include <QLabel>
#include <QDialogButtonBox>
#include <QVBoxLayout>
#include <QGroupBox>
#include <QMessageBox>
NewWindow::NewWindow(Valori* v,QWidget *parent) :QDialog(parent),n(0),va(v)

{
    setWindowTitle("Crea un nuovo grafico");
    resize(700,400);
    setModal(true);
    QDialog::reject();//con il tasto esc esco dalla finestra
    QLabel* label=new QLabel("Inserisci il numero di dati del grafico");
    ndati=new QSpinBox();
    ndati->setRange(0,99);
    ndati->setValue(0);
    ndati->setAccelerated(true);
    QHBoxLayout* inputlayout= new QHBoxLayout();
    inputlayout->addWidget(label);
    inputlayout->addWidget(ndati);
    QGroupBox* tipografico=new QGroupBox(tr("Chart"));
    QLabel* grafico=new QLabel("Sciegli il tipo di grafico che vuoi creare");
    linechart=new QRadioButton("LineChart");
    pointchart=new QRadioButton("PointChart");
    barchart=new QRadioButton("BarChart");
    barchart->setCheckable(true);
    linechart->setCheckable(true);
    pointchart->setCheckable(true);
    barchart->setChecked(false);
    linechart->setChecked(true);
    pointchart->setChecked(false);
    QVBoxLayout* buttongrafico=new QVBoxLayout();
    buttongrafico->addWidget(grafico);
    buttongrafico->addWidget(linechart);
    buttongrafico->addWidget(pointchart);
    buttongrafico->addWidget(barchart);
    buttongrafico->addStretch();
    ok=new QPushButton(tr("ok"));
    annulla=new QPushButton(tr("Annulla"));
    ok->setFont(QFont("Times",18,QFont::Black));
    annulla->setFont(QFont("Times",18,QFont::Black));
    tipografico->setLayout(buttongrafico);
    QDialogButtonBox* button=new QDialogButtonBox(Qt::Horizontal);
    button->addButton(ok,QDialogButtonBox::ActionRole);
    button->addButton(annulla,QDialogButtonBox::ActionRole);
    QVBoxLayout* container=new QVBoxLayout();//il layout principale
    container->addLayout(inputlayout);
    container->addWidget(tipografico);
    container->addWidget(button);
    setLayout(container);//lo installo su this
    connect(ok,SIGNAL(clicked()),this,SLOT(ClickedOk()));
    connect(ndati,SIGNAL(valueChanged(int)),this,SLOT(ChangeEle(int)));
    connect(annulla,SIGNAL(clicked()),this,SLOT(close()));
    connect(barchart,SIGNAL(clicked()),this,SLOT(ClickedBarChart()));
    connect(pointchart,SIGNAL(clicked()),this,SLOT(ClickedPointChart()));
    connect(linechart,SIGNAL(clicked()),this,SLOT(ClickedLineChart()));
}
void NewWindow::ClickedBarChart()
{
    barchart->setChecked(true);
    linechart->setChecked(false);
    pointchart->setChecked(false);
}
void NewWindow::ClickedLineChart()
{
    linechart->setChecked(true);
    pointchart->setChecked(false);
    barchart->setChecked(false);
}
void NewWindow::ClickedPointChart()
{
    pointchart->setChecked(true);
    linechart->setChecked(false);
    barchart->setChecked(false);
}

void NewWindow::ClickedOk() throw(Zero)
try
{
    if(!ndati->value())
    {
        throw Zero();
    }
    else{
        Input* input=new Input(this,va,n);
        connect(input,SIGNAL(Ok()), this,SLOT(CreateChart()));
        connect(input,SIGNAL(Ok()),this,SLOT(close()));
        input->show();
    }
}
catch(Zero z)
{

    QMessageBox::critical(this,"Errore!","Il numero di dati deve essere maggiore di zero!");
}
void NewWindow::CreateChart()
{
    emit New();//emetto il segnale per dire che la creazione è avvenuta con successo
    if(barchart->isChecked())
        emit Bar();
        else
    if(linechart->isChecked())
        emit Line();
    else
    if(pointchart->isChecked())
        emit Point();
}
void NewWindow::ChangeEle(int x)
{
    n=x;
}
int NewWindow::Value() const
{
    return ndati->value();
}
