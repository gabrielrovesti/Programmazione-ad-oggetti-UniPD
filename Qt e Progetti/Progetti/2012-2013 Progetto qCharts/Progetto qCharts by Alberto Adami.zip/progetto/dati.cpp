//
//  dati.cpp
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#include "dati.h"
Dati::Dati(const Valori& v)
{
    for(int i=0;i<v.Size();++i)
    {
        double val=v[i]->prezzo();//chiamata del metodo virtuale
        d.push_back(val);
    }
}
int Dati::Size() const
{
    return d.size();
}
bool Dati::IsEmpty() const
{
    return d.size()==0;
}
double& Dati::operator [](int i) const
{
    vector<double>::const_iterator it=d.begin()+i;
    return const_cast<double&>(*it);
}
double Dati::max() const
{
    vector<double>::const_iterator it=d.begin();
    double massimo=*it;
    ++it;
    for(;it!=d.end();++it)
    {
        if((*it)>massimo)
            massimo=(*it);
    }
    return massimo;
}
