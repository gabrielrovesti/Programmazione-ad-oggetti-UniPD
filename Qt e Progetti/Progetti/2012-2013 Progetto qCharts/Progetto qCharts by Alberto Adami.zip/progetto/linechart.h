//
//  linechart.h
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#ifndef LINECHART_H
#define LINECHART_H
#include <QPointF>
#include "chart.h"
class LineChart : public Chart
{
public:
    LineChart(const QPointF&,double,const Dati&);
    virtual void Draw(QPainter &) const;
};

#endif // LINECHART_H
