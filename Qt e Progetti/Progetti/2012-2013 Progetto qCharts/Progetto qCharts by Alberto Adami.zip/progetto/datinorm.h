//
//  datinorm.h
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#ifndef DATINORM_H
#define DATINORM_H
#include <vector>
#include "dati.h"
using std::vector;
class DatiNorm
{
private:
    vector<double> norm;
    double max;
public:
    DatiNorm(const Dati&,double =200);
    int Size() const;
    bool IsEmpty() const;
    double Max() const;
    double& operator[](int) const;
};
#endif // DATINORM_H
/*
La classe DatiNorm rappresenta i dati normalizzati in modo da visualizzarli nei chart in modo proporzionato.
*/
