//
//  cdfisico.h
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#ifndef CDFISICO_H
#define CDFISICO_H
#include "cdmusicale.h"
class CdFisico : public CdMusicale
{
private:
    double costo;
public:
    CdFisico();
    CdFisico(string,string,int,double);
    virtual double prezzo() const;
    double GetCosto() const;
    virtual bool operator==(const CdMusicale&) const;
    virtual bool operator!=(const CdMusicale&) const;
    void SetCosto(double);
};
#endif // CDFISICO_H
/*
La classe CdFisico rappresenta un cd acquistabile in un negozio e che quindi ha un prezzo fisso.
La calsse CdFisico implementa il metodo virtuale costo di Cdmusicale.
*/
