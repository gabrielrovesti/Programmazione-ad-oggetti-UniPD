//
//  elementrow.cpp
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#include "elementrow.h"
#include <QString>
#include <string>
using std::string;
ElementRow::ElementRow(Valori* v, int i,QObject* parent,CdMusicale* cdt):QObject(parent),cd(cdt),val(v),num(i)
{
    titolo=new QLineEdit();
    titolo->setText("");
    artista=new QLineEdit();
    artista->setText("");
    numcanzoni=new QSpinBox();
    numcanzoni->setAccelerated(true);
    numcanzoni->setValue(0);
    numcanzoni->setRange(0,100);
    combo=new QComboBox();
    combo->insertItem(1,"Cd Fisico");
    combo->insertItem(2,"Cd Digitale");
    combo->insertItem(3,"Cd Corriere");
    combo->setCurrentIndex(0);
    prezzobase=new QDoubleSpinBox();
    prezzobase->setRange(0,200.0);
    prezzobase->setValue(0.0);
    prezzobase->setAccelerated(true);
    prezzounitario=new QDoubleSpinBox();
    prezzounitario->setRange(0,50.0);
    prezzounitario->setValue(0.0);
    prezzounitario->setAccelerated(true);
    prezzotrasporto=new QDoubleSpinBox();
    prezzotrasporto->setRange(0,300.0);
    prezzotrasporto->setValue(0.0);
    prezzotrasporto->setAccelerated(true);
    prezzobase->setEnabled(true);
    prezzounitario->setEnabled(false);
    prezzotrasporto->setEnabled(false);
    connect(combo,SIGNAL(currentIndexChanged(int)),this,SLOT(ChangeTipo(int)));
    string stitolo=cd->GetTitolo();
    string sartista=cd->GetArtista();
    int numc=cd->GetNum();
    if(dynamic_cast<CdFisico*>(cd) && !dynamic_cast<CdCorriere*>(cd))
    {
        CdFisico* fisico=dynamic_cast<CdFisico*>(cd);
        double prezzob=fisico->GetCosto();
        titolo->setText(QString::fromStdString(stitolo));
        artista->setText(QString::fromStdString(sartista));
        numcanzoni->setValue(numc);
        combo->setCurrentIndex(0);
        prezzobase->setValue(prezzob);
    }
    else
        if(dynamic_cast<CdDigitale*>(cd))
        {
            CdDigitale* digitale=dynamic_cast<CdDigitale*>(cd);
            double prezzou=digitale->GetPrezzoUnitario();
            titolo->setText(QString::fromStdString(stitolo));
            artista->setText(QString::fromStdString(sartista));
            numcanzoni->setValue(numc);
            combo->setCurrentIndex(1);
            prezzounitario->setValue(prezzou);
        }
    else
            if(dynamic_cast<CdCorriere*>(cd))
            {
                CdCorriere* corriere=dynamic_cast<CdCorriere*>(cd);
                double prezzob=corriere->GetCosto();
                double prezzot=corriere->GetAggiuntivo();
                titolo->setText(QString::fromStdString(stitolo));
                artista->setText(QString::fromStdString(sartista));
                numcanzoni->setValue(numc);
                combo->setCurrentIndex(2);
                prezzobase->setValue(prezzob);
                prezzotrasporto->setValue(prezzot);
            }
    connect(combo,SIGNAL(currentIndexChanged(int)),this,SLOT(ChangeTypePointer(int)));
    connect(titolo,SIGNAL(textChanged(QString)),this,SLOT(ChangeTitolo(QString)));
    connect(artista,SIGNAL(textChanged(QString)),this,SLOT(ChangeArtista(QString)));
    connect(numcanzoni,SIGNAL(valueChanged(int)),this,SLOT(ChangeNum(int)));
    connect(prezzobase,SIGNAL(valueChanged(double)),this,SLOT(ChangeBase(double)));
    connect(prezzounitario,SIGNAL(valueChanged(double)),this,SLOT(ChangeUnit(double)));
    connect(prezzotrasporto,SIGNAL(valueChanged(double)),this,SLOT(ChangeTrasp(double)));
}
void ElementRow::ChangeTipo(int i)
{
    if(i==0)
    {
        prezzobase->setEnabled(true);
        prezzounitario->setEnabled(false);
        prezzotrasporto->setEnabled(false);
        prezzotrasporto->setValue(0);
        prezzounitario->setValue(0);
        prezzobase->setValue(0);
    }
    else
        if(i==1)
        {
            prezzobase->setEnabled(false);
            prezzounitario->setEnabled(true);
            prezzotrasporto->setEnabled(false);
            prezzotrasporto->setValue(0);
            prezzounitario->setValue(0);
            prezzobase->setValue(0);
        }
    else
        if(i==2)
        {
            prezzobase->setEnabled(true);
            prezzounitario->setEnabled(false);
            prezzotrasporto->setEnabled(true);
            prezzotrasporto->setValue(0);
            prezzounitario->setValue(0);
            prezzobase->setValue(0);
        }

}
void ElementRow::ChangeTypePointer(int i)
{
    string stitolo=cd->GetTitolo();
    string sartista=cd->GetArtista();
    int numcanz=cd->GetNum();
    if(i==0)
    {
        cd=new CdFisico(stitolo,sartista,numcanz,0.0);
        if(num<val->Size())
            val->Change(num,*cd);
    }
    else
        if(i==1)
        {
            cd=new CdDigitale(stitolo,sartista,numcanz,0.0);
            if(num<val->Size())
                val->Change(num,*cd);
        }
    else
            if(i==2)
            {
                cd=new CdCorriere(stitolo,sartista,numcanz,0.0,0.0);
                if(num<val->Size())
                    val->Change(num,*cd);
            }
    if(num<val->Size())//se è la riga di un elemento inserito in val
        emit Change();

}
QLineEdit* ElementRow::GetTitolo() const
{
    return titolo;
}
QLineEdit* ElementRow::GetArtista() const
{
    return artista;
}
QSpinBox* ElementRow::GetNum() const
{
    return numcanzoni;
}
QComboBox* ElementRow::GetTipo() const
{
    return combo;
}
QDoubleSpinBox* ElementRow::GetBase() const
{
    return prezzobase;
}
QDoubleSpinBox* ElementRow::GetUnit() const
{
    return prezzounitario;
}
QDoubleSpinBox* ElementRow::GetTrasp() const
{
    return prezzotrasporto;
}
void ElementRow::ChangeArtista(QString a)
{
    cd->SetArtista(a.toStdString());
}
void ElementRow::ChangeTitolo(QString t)
{
    cd->SetTitolo(t.toStdString());
}
void ElementRow::ChangeNum(int i)
{
    cd->SetNum(i);
    emit Change();
}
void ElementRow::ChangeBase(double b)
{

    if(dynamic_cast<CdFisico*>(cd))
    {
        CdFisico* fisico=dynamic_cast<CdFisico*>(cd);
        fisico->SetCosto(b);
        if(num<val->Size())
            emit Change();
    }
}
void ElementRow::ChangeUnit(double un)
{
    if(dynamic_cast<CdDigitale*>(cd))
    {
        CdDigitale* digitale=dynamic_cast<CdDigitale*>(cd);
        digitale->SetPrezzoUnitario(un);
        if(num<val->Size())
            emit Change();
    }
}
void ElementRow::ChangeTrasp(double tra)
{
    if(dynamic_cast<CdCorriere*>(cd))
    {
        CdCorriere* corriere=dynamic_cast<CdCorriere*>(cd);
        corriere->SetAggiuntivo(tra);
        if(num<val->Size())
            emit Change();
    }
}
CdMusicale* ElementRow::GetCdMusicale() const
{
    return cd;
}
