//
//  table.h
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#ifndef TABLE_H
#define TABLE_H
#include <QTableWidget>
#include <QComboBox>
#include <QSpinBox>
#include <QDoubleSpinBox>
#include <QList>
#include "valori.h"
#include "elementrow.h"
class Table : public QTableWidget
{
    Q_OBJECT
private:
   Valori* val;
   QList<ElementRow*> lista;
public:
     Table(Valori* =0,QWidget *parent = 0);
     CdMusicale* GetCd(int);
     ~Table();
signals:
     void Changed();
public slots:
     void InsertNewDato(int);
     void removeRow(int );
     void NewValori();
     void ClearAll();
    
};

#endif // TABLE_H
