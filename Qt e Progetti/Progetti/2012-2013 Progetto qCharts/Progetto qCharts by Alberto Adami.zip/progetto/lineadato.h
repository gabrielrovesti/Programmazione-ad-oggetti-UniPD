//
//  lineadato.h
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#ifndef INPUTWINDOW_H
#define INPUTWINDOW_H
#include <QWidget>
#include <QPushButton>
#include <QDoubleSpinBox>
#include <QSpinBox>
#include <QLineEdit>
#include <QComboBox>
#include <QString>
class LineaDato : public QWidget
{
Q_OBJECT
private:
    QLineEdit* title;
    QLineEdit* artista;
    QComboBox* combo;
    QSpinBox* numcanzoni;
    QDoubleSpinBox* prezzo;
    QDoubleSpinBox* cunitario;
    QDoubleSpinBox* ctrasporto;

public:
     LineaDato(QWidget* =0);
     QString GetTitle() const;
     QString GetArtista() const;
     int GetNumCanzoni() const;
     double GetPrezzo() const;
     double GetCunitario() const;
     double GetCtrasporto() const;
     bool IsFisico() const;
     bool IsDigitale() const;
     bool IsCorriere() const;
private slots:
     void Change(int);
};
#endif // INPUTWINDOW_H
/*
La classe LineaDato serve a rappresentare una linea di input nella finestra di inserimento dei dati.
*/

