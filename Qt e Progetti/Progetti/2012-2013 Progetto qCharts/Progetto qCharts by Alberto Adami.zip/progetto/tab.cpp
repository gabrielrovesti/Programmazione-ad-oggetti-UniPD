//
//  tab.cpp
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#include "tab.h"
#include <QMessageBox>
#include <QScrollBar>
Tab::Tab(Valori* v,QWidget *parent):QTabWidget(parent),val(v)
{
    area=new QScrollArea();
    tabella=new Table(val);
    canvas=new Canvas(val,this);
    area->setWidget(canvas);
    addTab(tabella,"Dati");
    addTab(area,"Chart");
    setCurrentWidget(tabella);
    connect(this,SIGNAL(Close()),canvas,SLOT(CloseChart()));
    connect(this,SIGNAL(InsertOk()),canvas,SLOT(Aggiorna()));
    connect(this,SIGNAL(Remove()),canvas,SLOT(Aggiorna()));
    connect(tabella,SIGNAL(Changed()),canvas,SLOT(Aggiorna()));
}
void Tab::Open()
{
    tabella->NewValori();
    QScrollBar* barv=area->verticalScrollBar();
    QScrollBar* baro=area->horizontalScrollBar();
    baro->setValue(0);
    barv->setValue(0);
}
void Tab::AddElement() throw(Max)
try
{
    int row=tabella->rowCount();
    if(row<=99)
    {
        tabella->InsertNewDato(row);
        setTabEnabled(1,false);
        emit NewRow();
    }
    else
        throw Max();
}
catch(Max m)
{
    QMessageBox::warning(0,"Attenzione","E' gia' stato raggiunto il numero massimo di elementi!");
}
void Tab::RemoveElement()
{
    int row=tabella->currentRow();
    if(row>=0)
    {
    if(row==val->Size())//è stato eliminato l'ultimo elemento che non era ancora stato inserito
    {
        emit Last();
        setTabEnabled(1,true);
    }
    tabella->removeRow(row);
    emit Remove();
    if(!tabella->rowCount())
        emit Close();
    }
}
void Tab::CloseAll()
{
    tabella->ClearAll();
    canvas->CloseChart();
    QScrollBar* barv=area->verticalScrollBar();
    QScrollBar* baro=area->horizontalScrollBar();
    baro->setValue(0);
    barv->setValue(0);
    setTabEnabled(1,true);
    setCurrentIndex(0);
}
void Tab::InsertToValori() throw(ErrorAdd)
try
{
    int row=tabella->rowCount();
    CdMusicale* cd=tabella->GetCd(row-1);
    if(cd->GetArtista()=="" || cd->GetTitolo()=="")
            throw ErrorAdd();
    val->Aggiungi(*cd);
    setTabEnabled(1,true);
    emit InsertOk();
}
catch(ErrorAdd e)
{
    QMessageBox::warning(0,"Attenzione","Inserimento del dato non riuscito!");

}
void Tab::DrawLine()
{
    canvas->drawLine();
    if(canvas->isEnabled())
        setCurrentIndex(1);
}
void Tab::DrawBar()
{
    canvas->drawBar();
    if(canvas->isEnabled())
        setCurrentIndex(1);
}
void Tab::DrawPoint()
{
    canvas->drawPoint();
    if(canvas->isEnabled())
        setCurrentIndex(1);
}
