//
//  cdcorriere.h
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#ifndef CDCORRIERE_H
#define CDCORRIERE_H
#include "cdfisico.h"
class CdCorriere : public CdFisico
{
private:
    double aggiuntivo;              //il prezzo aggiuntivo dovuto al trasporto
public:
    CdCorriere();
    CdCorriere(string,string,int,double,double);
    double GetAggiuntivo() const;
    void SetAggiuntivo(double);
    bool operator==(const CdMusicale&) const;
    bool operator !=(const CdMusicale&) const;
    virtual double prezzo() const;
};
#endif // CDCORRIERE_H
/*
La classe CdCorriere rappresenta un cd su supporto fisico acquistato presso un corriere.
Quindi oltre al prezzo base del cd, vi è un ulteriore prezzo di trasporto.
La classe CdCorriere implementa il metodo virtuale prezzo().
*/
