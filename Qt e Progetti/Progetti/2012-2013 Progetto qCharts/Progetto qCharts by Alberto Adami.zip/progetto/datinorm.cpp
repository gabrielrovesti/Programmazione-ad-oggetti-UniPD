//
//  datinorm.cpp
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#include "datinorm.h"
DatiNorm::DatiNorm(const Dati & d,double massimo):max(massimo)
{
    double maxt=d.max();
    for(int i=0;i<d.Size();++i)
    {
        double value=max*d[i]/maxt;
        norm.push_back(value);
    }
}
int DatiNorm::Size() const
{
    return norm.size();
}
bool DatiNorm::IsEmpty() const
{
    return norm.size()==0;
}
double DatiNorm::Max() const
{
    return max;
}
double& DatiNorm::operator [](int i) const
{
    vector<double>::const_iterator it=norm.begin()+i;//it punta all'iesimo elemento
    return const_cast<double&>(*it);
}
