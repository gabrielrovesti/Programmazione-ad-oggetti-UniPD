//
//  cdmusicale.cpp
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#include "cdmusicale.h"
CdMusicale::CdMusicale():titolo(""),artista(""),num(0)
{
}
CdMusicale::CdMusicale(string t, string a, int n):titolo(t),artista(a),num(n)
{
}
string CdMusicale::GetArtista() const
{
    return artista;
}
string CdMusicale::GetTitolo() const
{
    return titolo;
}
int CdMusicale::GetNum() const
{
    return num;
}
void CdMusicale::SetArtista(string a)
{
    artista=a;
}
void CdMusicale::SetTitolo(string t)
{
    titolo=t;
}
void CdMusicale::SetNum(int n)
{
    num=n;
}
CdMusicale::~CdMusicale()
{
}
