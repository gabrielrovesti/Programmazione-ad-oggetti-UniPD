//
//  elementrow.h
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#ifndef ELEMENTROW_H
#define ELEMENTROW_H
#include <QObject>
#include <QSpinBox>
#include <QComboBox>
#include <QDoubleSpinBox>
#include <QLineEdit>
#include <QString>
#include "valori.h"
class ElementRow : public QObject
{
    Q_OBJECT
private:
    QLineEdit* titolo;
    QLineEdit* artista;
    QSpinBox* numcanzoni;
    QComboBox* combo;
    QDoubleSpinBox* prezzobase;
    QDoubleSpinBox* prezzounitario;
    QDoubleSpinBox* prezzotrasporto;
    CdMusicale* cd;
    Valori* val;
    int num;        //il numero di row che rappresenta
public:
     ElementRow(Valori *,int,QObject* =0,CdMusicale* =new CdFisico());
     QLineEdit* GetTitolo() const;
     QLineEdit* GetArtista() const;
     QSpinBox* GetNum() const;
     QComboBox* GetTipo() const;
     QDoubleSpinBox* GetBase() const;
     QDoubleSpinBox* GetUnit() const;
     QDoubleSpinBox* GetTrasp() const;
     CdMusicale* GetCdMusicale() const;
private slots:
     void ChangeTitolo(QString);
     void ChangeArtista(QString);
     void ChangeNum(int);
     void ChangeTipo(int);
     void ChangeTypePointer(int);
     void ChangeBase(double);
     void ChangeUnit(double);
     void ChangeTrasp(double);
signals:
     void Change();
};
#endif // ELEMENTROW_H
