//
//  barchart.h
//Created by alberto adami.
//  Copyright (c) 2013 alberto adami.All rights reserved.
//

#ifndef BARCHART_H
#define BARCHART_H
#include "chart.h"
class BarChart : public Chart
{
private:
    double width;
public:
    BarChart(const QPointF&,double,double,const Dati&);
    double GetWidth() const;
    virtual void Draw(QPainter &) const;
    virtual double Spazio() const;
};
#endif // BARCHART_H
