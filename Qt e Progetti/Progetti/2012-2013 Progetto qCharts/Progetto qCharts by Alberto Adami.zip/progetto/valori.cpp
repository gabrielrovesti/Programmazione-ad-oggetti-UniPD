//
//  valori.cpp
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#include "valori.h"
Valori::Valori()
{
}
int Valori::Size() const
{
    return ogg.size();
}
bool Valori::IsEmpty() const
{
    return ogg.size()==0;
}
void Valori::Aggiungi(const CdMusicale& c)
{
    CdMusicale* cd=const_cast<CdMusicale*>(&c);
    ogg.push_back(cd);
}
void Valori::Delete(int i)
{
    vector<CdMusicale*>::iterator it=ogg.begin()+i;
    if(*it)
        delete *it;      //dealloco dallo heap l'oggetto puntato da i
    ogg.erase(it);      //elimino l'oggetto dal vector
}
void Valori::DeleteAll()
{
    for(vector<CdMusicale*>::const_iterator it=ogg.begin();it!=ogg.end();++it)
        delete *it;
    ogg.clear();//svuoto il vector
}
CdMusicale* Valori::operator [](int i) const
{
    vector<CdMusicale*>::const_iterator it=ogg.begin()+i;
    return *it;
}
void Valori::Change(int i, const CdMusicale & c)
{
    CdMusicale* cd=const_cast<CdMusicale*>(&c);
    delete ogg[i];
    ogg[i]=cd;
}
Valori::~Valori()
{
    for(vector<CdMusicale*>::iterator it=ogg.begin();it!=ogg.end();++it)
         delete *it;        //faccio una distruzione profonda degli oggetti puntati dal vector
}
bool Valori::operator ==(const Valori& v) const
{
    bool ok=true;
    if(Size()!=v.Size())
        ok=false;
    for(int i=0;i<Size()&& ok;++i)
        if((*ogg[i])!=(*v.ogg[i]))//chiamata a metodo virtuale
            ok=false;
    return ok;
}
bool Valori::operator !=(const Valori& v) const
{
    bool ok=true;
    if(Size()!=v.Size())
        ok=false;
    for(int i=0;i<Size()&& ok;++i)
        if((*ogg[i])!=(*v.ogg[i]))//chiamata a metodo virtuale
            ok=false;
    return !ok;
}
