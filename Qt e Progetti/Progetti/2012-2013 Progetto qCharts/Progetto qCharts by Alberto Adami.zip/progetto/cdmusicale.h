//
//  cdmusicale.h
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#ifndef CDMUSICALE_H
#define CDMUSICALE_H
#include<string>
using std::string;
class CdMusicale
{
private:
    string titolo;                  //il tiolo del cd
    string artista;                 //l'artista del cd
    int num;                        //il numero di canzoni del cd
public:
    CdMusicale();
    CdMusicale(string,string,int);
    string GetTitolo() const;
    string GetArtista() const;
    int GetNum() const;
    void SetTitolo(string);
    void SetArtista(string);
    void SetNum(int);
    virtual double prezzo() const=0;        //metodo virtuale puro
    virtual bool operator==(const CdMusicale&) const=0;
    virtual bool operator!=(const CdMusicale&) const=0;
    virtual ~CdMusicale();
};
#endif // CDMUSICALE_H
/*
La classe CdMusicale rappresenta un cd musicale genererico ed è rappresentato dal numero di canzoni,
artista e titolo.
La classe Cdmusicale è una classe astratta, infatti il metodo virtuale puro prezzo sarà definito nelle
calssi derivate da cdmusicale.Quindi non è pessibile dichiarare oggetti della calsse Cdmusicale.
*/
