//
//  pointchart.cpp
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#include "pointchart.h"
PointChart::PointChart(const QPointF & o, double x, const Dati &dn):Chart(o,x,dn)
{
}
void PointChart::Draw(QPainter &p) const
{

    for(int i=0;i<Size();++i)
    {
        p.setPen(QPen(Qt::red,4));
        QPointF punto=points[i];
        p.drawPoint(punto);
        QString index;
        index.setNum(i+1);
        p.setPen(QPen(Qt::black,3));
        QPointF puntoi(points[i].x(),GetOrigine().y()+20);
        p.drawText(puntoi,index);
        QPointF py1(GetOrigine().x()+5,points[i].y());
        QPointF py2(GetOrigine().x()-5,points[i].y());
        p.setPen(QPen(Qt::black,3));
        p.drawLine(QLineF(py1,py2));
    }
    for(int i=0;i<Size();++i)
    {
        p.setFont(QFont("arial",7,Qt::black));
        QString value(QString::number(GetDati()[i]));
        p.drawText(QPointF(GetOrigine().x()-25,points[i].y()),value);
    }
}
