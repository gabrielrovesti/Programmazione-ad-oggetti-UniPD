//
//  error.h
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#ifndef ERROR_H
#define ERROR_H
#include <QString>
class Zero{};           //quando viene scielto di inserire 0 dati nuovi,cosa non possibile
class ErrorInput{};     //errore che si verifica quando si ha lasciato un campo dati vuoto o si è ripetuto un dati
class DatiVuoti{        //quando si prova a salvare o chiudere e non ci sono dati
private:
    bool chiusura;
public:
    DatiVuoti(bool c=false):chiusura(c){}   //costruttore
    bool GetChiusura() const
    {
        return chiusura;
    }
};
class ErrorOpen{    //errore che si verifica nell'apertura di un file
private:
    QString error;
 public:
    ErrorOpen(QString e):error(e){}
    QString Error() const{return error;}
};
class OnlyRead{};
class ErrorSave{};//errore che può verificare nel salvataggio dei dati
class ErrorAdd{};   //errore che si verifica quando si inserisce un cd già presente o che ha campi dati vuoti
class Max{};//errore che si verifica quando viene chiesto di aggiungere un elemento ma è già stato raggiunto il max
#endif
/*
Le precedenti classi sono classi che servono per la gestione delle varie eccezioni che si possono verificare durante
l'esecuzione del programma.Non è stata gestito l'errore che si verifica quando viene aperto un file xml non creato
con l'applicazione QCharts  in quanto si assume che solo i file xml creati da  QCharts verranno aperti.
*/
