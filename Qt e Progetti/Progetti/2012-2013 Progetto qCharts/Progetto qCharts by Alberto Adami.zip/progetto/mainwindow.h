//
//  mainwindow.h
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>
#include <QToolBar>
#include <QMenu>
#include <QString>
#include <QCloseEvent>
#include <QAction>
#include <QFile>
#include <QXmlStreamWriter>
#include <QXmlStreamReader>
#include "newwindow.h"
#include "valori.h"
#include "error.h"
#include "tab.h"
class MainWindow : public QMainWindow
{
Q_OBJECT
private:
    QString fileopen;           //il nome del file attualmeno aperto, se ce ne è uno.
    Valori val;                // valori attualmente aperti
    Tab* tab;                   //il widget principale della mainwindow
    QAction *NewAction;
    QAction *OpenAction;
    QAction* SaveAction;
    QAction* SaveAsaction;
    QAction* CloseAction;
    QAction* QuitAction;
    QAction* barchart;
    QAction* linechart;
    QAction* pointchart;
    QAction* aggiungi;
    QAction* remove;
    QAction* inserimento;
    QMenu* FileMenu;
    QMenu* VisualizzaMenu;
    QMenu* ModificaMenu;
    QToolBar* File;
    QToolBar* Chart;
    QToolBar* Modifica;
    void SaveXml(QFile&) throw(ErrorSave);
    void OpenXml(QString,Valori&) throw(ErrorOpen);
    void SaveAsClose(QCloseEvent*)throw(OnlyRead);
public:
     MainWindow(QWidget *parent = 0);
protected:
     virtual void closeEvent(QCloseEvent *);
private  slots:
     void CloseAllAction();
     void CloseFile() throw(DatiVuoti);
     void NewFile();
     void CreateCorrect();
     void NewElement();
     void InsertNew();
     void OpenFile();
     void Save() throw(DatiVuoti,OnlyRead);
     void SaveAs() throw(DatiVuoti,OnlyRead);
     void DeleteLast();
     void ShowBar();
     void ShowLine();
     void ShowPoint();
};
#endif // MAINWINDOW_H
