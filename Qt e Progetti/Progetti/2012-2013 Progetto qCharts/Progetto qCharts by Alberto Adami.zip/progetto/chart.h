//
//  chart.h
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#ifndef CHART_H
#define CHART_H
#include<QPainter>
#include<vector>
#include "datinorm.h"
#include "dati.h"
using std::vector;
class Chart
{
private:
    Dati* dati;
    QPointF origine;
    double xdistanza;
protected:
    vector<QPointF> points;
public:
    Chart(const QPointF&,double,const Dati&);
    Chart();
    int Size() const;
    bool IsEmpty() const;
    double GetDistanza() const;
    virtual double Spazio() const;
    QPointF GetOrigine() const;
    Dati& GetDati() const;
    virtual void Draw(QPainter&) const=0;
    virtual QPointF& operator[](int) const;
    virtual ~Chart();
};
#endif // CHART_H
