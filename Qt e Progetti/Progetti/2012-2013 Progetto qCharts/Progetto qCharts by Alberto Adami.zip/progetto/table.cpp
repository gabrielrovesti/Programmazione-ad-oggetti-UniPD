//
//  table.cpp
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#include "table.h"
#include <QStringList>
#include <string>
using std::string;
Table::Table(Valori* v,QWidget *parent):QTableWidget(parent),val(v)
{
    setColumnCount(7);
    QStringList header;
    header<<"Titolo"<<"Artista"<<"N.Canzoni"<<"Tipo"<<"Prezzo"<<"Prezzo Unitario"<<"Prezzo Trasporto";
    setHorizontalHeaderLabels(header);
    setRowCount(0);
}
void Table::removeRow(int row)
{
    QList<ElementRow*>::iterator it=lista.begin()+row;
    if(val->Size()>row)
    {
        val->Delete(row);
        delete *it;
        lista.erase(it);
        emit Changed();
    }
    else
    //sto eliminando la riga del nuovo elemento che non è stato inserito in val!
    {
        delete (*it)->GetCdMusicale();//dealloco il cd dallo heap
        delete *it;
        lista.erase(it);
    }
    QTableWidget::removeRow(row);
}
void Table::InsertNewDato(int i)
{
    insertRow(i);
    ElementRow* element=new ElementRow(val,i,this);
    lista.push_back(element);
    connect(element,SIGNAL(Change()),this,SIGNAL(Changed()));
    setCellWidget(i,0,element->GetTitolo());
    setCellWidget(i,1,element->GetArtista());
    setCellWidget(i,2,element->GetNum());
    setCellWidget(i,3,element->GetTipo());
    setCellWidget(i,4,element->GetBase());
    setCellWidget(i,5,element->GetUnit());
    setCellWidget(i,6,element->GetTrasp());
    setCurrentCell(i,0);
}
void Table::ClearAll()
{
    for(int i=rowCount();i>=0;i--)
            QTableWidget::removeRow(i);
    for(QList<ElementRow*>::const_iterator it=lista.begin();it!=lista.end();++it)
            delete *it;
    lista.clear();
}
void Table::NewValori()
{
        ClearAll();
        for(int i=0;i<val->Size();++i)
        {
            insertRow(i);
            ElementRow* element=new ElementRow(val,i,this,(*val)[i]);
            lista.push_back(element);
            connect(element,SIGNAL(Change()),this,SIGNAL(Changed()));
            setCellWidget(i,0,element->GetTitolo());
            setCellWidget(i,1,element->GetArtista());
            setCellWidget(i,2,element->GetNum());
            setCellWidget(i,3,element->GetTipo());
            setCellWidget(i,4,element->GetBase());
            setCellWidget(i,5,element->GetUnit());
            setCellWidget(i,6,element->GetTrasp());
        }
}
CdMusicale* Table::GetCd(int i)
{
    QList<ElementRow*>::const_iterator it=lista.begin()+i;
    return (*it)->GetCdMusicale();
}
Table::~Table()
{
    for(QList<ElementRow*>::const_iterator it=lista.begin();it!=lista.end();++it)
        delete *it;
}
