//
//  canvas.cpp
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#include "canvas.h"
#include <QPainter>
#include <QString>
Canvas::Canvas(Valori* v,QWidget *parent):QWidget(parent),val(v),chart(0),origine(50,550),estremox(800,550),estremoy(50,20)
{
    resize(1000,650);
}
void Canvas::SetOrigine(const QPointF & o)
{
    origine=o;
    update();
}
void Canvas::SetEstremoX(const QPointF & ex)
{
    estremox=ex;
    update();
}
void Canvas::SetEstremoY(const QPointF & ey)
{
    estremoy=ey;
    update();
}
void Canvas::drawBar()
{
    if(chart)
        delete chart;
    Dati*dati =new Dati(*val);
    chart=new BarChart(origine,20,30 ,*dati);
    update();
}
void Canvas::drawLine()
{
    if(chart)
        delete chart;
    Dati* dati=new Dati(*val);
    chart=new LineChart(origine,50,*dati);
    update();
}
void Canvas::drawPoint()
{
    if(chart)
        delete chart;
    Dati* dati=new Dati(*val);
    chart=new PointChart(origine,50,*dati);
    update();
}
void Canvas::CloseChart()
{
    resize(1000,650);
    delete chart;
    chart=0;
    origine=QPointF(50,550);
    estremox=QPointF(800,550);
    estremoy=QPointF(50,20);
    //rimetto i valori standart di origine,estremox e estremoy
    update();
}
void Canvas::Aggiorna()
{
    if(dynamic_cast<LineChart*>(chart))
    {
        double distanza=chart->GetDistanza();
        delete chart;
        Dati* dati=new Dati(*val);
        chart=new LineChart(origine,distanza,*dati);
     }
    else
        if(dynamic_cast<BarChart*>(chart))
         {
            BarChart* bar=dynamic_cast<BarChart*>(chart);
            double distanza=bar->GetDistanza();
            double width=bar->GetWidth();
            delete chart;
            Dati*dati =new Dati(*val);
            chart=new BarChart(origine,distanza-width,width ,*dati);
        }
    else
            if(dynamic_cast<PointChart*>(chart))
             {
                double distanza=chart->GetDistanza();
                delete chart;
                Dati* dati=new Dati(*val);
                chart=new PointChart(origine,distanza,*dati);
            }
    update();
}
void Canvas::paintEvent(QPaintEvent *)
{
    if(chart)
    {
        if(chart->Spazio()>=estremox.x()-30)
        {
            QPointF newestremox(chart->Spazio()+50,estremox.y());
            SetEstremoX(newestremox);
            resize(newestremox.x()+100,650);
        }
        else if(chart->Spazio()<estremox.x()+500)
        {
            QPointF newestremox(chart->Spazio()+50,estremox.y());
            SetEstremoX(newestremox);
            resize(newestremox.x()+100,650);
        }
    }
    QPainter painter(this);
    painter.setPen(QPen(Qt::black,4));
    QLineF xaxes(estremox,origine);
    QLineF yaxes(origine,estremoy);
    QLineF xpunta1(estremox,QPointF(estremox.x()-20,estremox.y()+10));
    QLineF xpunta2(estremox,QPointF(estremox.x()-20,estremox.y()-10));
    QLineF ypunta1(estremoy,QPointF(estremoy.x()+10,estremoy.y()+20));
    QLineF ypunta2(estremoy,QPointF(estremoy.x()-10,estremoy.y()+20));
    painter.drawLine(xaxes);
    painter.drawLine(yaxes);
    painter.drawLine(xpunta1);
    painter.drawLine(xpunta2);
    painter.drawLine(ypunta1);
    painter.drawLine(ypunta2);
    painter.drawText(origine.x()-15,origine.y()+15,"O");
    painter.drawText(estremox.x()-10,estremox.y()+20,"X");
    painter.drawText(estremoy.x()-20,estremoy.y()+10,"Y");
    if(chart)
        chart->Draw(painter);//chiamata a metodo virtuale che disegna il chart
}
Canvas::~Canvas()
{
    delete chart;
}
