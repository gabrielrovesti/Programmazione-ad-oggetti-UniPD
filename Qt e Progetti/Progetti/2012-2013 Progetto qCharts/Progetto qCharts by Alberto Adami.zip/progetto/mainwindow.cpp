//
//  mainwindow.cpp
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#include "mainwindow.h"
#include <QMenuBar>
#include <QFileDialog>
#include <QDir>
#include <QStatusBar>
#include <QMessageBox>
#include <string>
using std::string;
MainWindow::MainWindow(QWidget *parent) :QMainWindow(parent),val()
{
    setGeometry(180,100,1300,800);
    setWindowTitle(tr("QChart"));
    OpenAction=new QAction(QIcon(":/Images/open.png"),tr("Apri"),this);
    OpenAction->setShortcuts(QKeySequence::Open);               //creo un accesso veloce
    NewAction=new QAction(QIcon(":/Images/new.png"),tr("Nuovo"),this);
    NewAction->setShortcuts(QKeySequence::New);                 //creo un accesso veloce
    SaveAction=new QAction(QIcon(":/Images/save.png") ,tr("Salva"),this);
    SaveAction->setShortcuts(QKeySequence::Save);               //creo un accesso veloce
    SaveAsaction=new QAction(tr("Salva con nome"),this);
    SaveAsaction->setShortcut(QKeySequence::SaveAs);          //creo un accesso veloce
    CloseAction=new QAction(QIcon(":/Images/close.png"),tr("Chiudi"),this);
    CloseAction->setShortcuts(QKeySequence::Close);             //creo un accesso veloce
    QuitAction=new QAction(tr("Esci"),this);
    QuitAction->setShortcuts(QKeySequence::Quit);               //creo un accesso veloce
    barchart=new QAction(QIcon(":/Images/barchart.jpeg"),tr("Barchart"),this);
    linechart=new QAction(QIcon(":/Images/linechart.jpg"),tr("Linechart"),this);
    pointchart=new QAction(QIcon(":/Images/pointchart.png"),tr("PointChart"),this);
    aggiungi=new QAction(QIcon(":/Images/add.png"),tr("Aggiungi"),this);
    remove=new QAction(QIcon(":/Images/remove.png"),tr("Rimuovi"),this);
    inserimento=new QAction(QIcon(":/Images/Ok.png"),tr("Inserisci"),this);
    FileMenu =new QMenu(tr("File"),this);
    FileMenu->addAction(OpenAction);
    FileMenu->addAction(NewAction);
    FileMenu->addAction(SaveAction);
    FileMenu->addAction(SaveAsaction);
    FileMenu->addAction(CloseAction);
    FileMenu->addAction(QuitAction);
    VisualizzaMenu =new QMenu(tr("Visualizza"),this);
    VisualizzaMenu->addAction(barchart);
    VisualizzaMenu->addAction(linechart);
    VisualizzaMenu->addAction(pointchart);
    ModificaMenu= new QMenu(tr("Modifica"),this);
    ModificaMenu->addAction(aggiungi);
    ModificaMenu->addAction(remove);
    ModificaMenu->addAction(inserimento);
    menuBar()->addMenu(FileMenu);
    menuBar()->addMenu(VisualizzaMenu);
    menuBar()->addMenu(ModificaMenu);
    menuBar()->addSeparator();
    statusBar();//creo una status bar
    File=addToolBar(tr("File"));
    File->addAction(OpenAction);
    File->addAction(NewAction);
    File->addAction(SaveAction);
    File->addAction(CloseAction);
    Chart=addToolBar(tr("Chart"));
    Chart->addAction(barchart);
    Chart->addAction(linechart);
    Chart->addAction(pointchart);
    Modifica=addToolBar(tr("Modifica"));
    Modifica->addAction(aggiungi);
    Modifica->addAction(remove);
    Modifica->addAction(inserimento);
    aggiungi->setEnabled(false);
    remove->setEnabled(false);
    inserimento->setEnabled(false);
    barchart->setEnabled(false);
    linechart->setEnabled(false);
    pointchart->setEnabled(false);
    tab=new Tab(&val,this);
    setCentralWidget(tab);
    connect(NewAction,SIGNAL(triggered()),this,SLOT(NewFile()));
    connect(OpenAction,SIGNAL(triggered()),this,SLOT(OpenFile()));
    connect(SaveAction,SIGNAL(triggered()),this,SLOT(Save()));
    connect(SaveAsaction,SIGNAL(triggered()),this,SLOT(SaveAs()));
    connect(CloseAction,SIGNAL(triggered()),this,SLOT(CloseFile()));
    connect(CloseAction,SIGNAL(triggered()),tab,SLOT(CloseAll()));
    connect(CloseAction,SIGNAL(triggered()),this,SLOT(CloseAllAction()));
    connect(QuitAction,SIGNAL(triggered()),this,SLOT(close()));
    connect(aggiungi,SIGNAL(triggered()),tab,SLOT(AddElement()));
    connect(remove,SIGNAL(triggered()),tab,SLOT(RemoveElement()));
    connect(inserimento,SIGNAL(triggered()),tab,SLOT(InsertToValori()));
    connect(linechart,SIGNAL(triggered()),tab,SLOT(DrawLine()));
    connect(linechart,SIGNAL(triggered()),this,SLOT(ShowLine()));
    connect(barchart,SIGNAL(triggered()),tab,SLOT(DrawBar()));
    connect(barchart,SIGNAL(triggered()),this,SLOT(ShowBar()));
    connect(pointchart,SIGNAL(triggered()),tab,SLOT(DrawPoint()));
    connect(pointchart,SIGNAL(triggered()),this,SLOT(ShowPoint()));
    connect(tab,SIGNAL(Last()),this,SLOT(DeleteLast()));
    connect(tab,SIGNAL(NewRow()),this,SLOT(NewElement()));
    connect(tab,SIGNAL(InsertOk()),this,SLOT(InsertNew()));
    connect(tab,SIGNAL(Close()),this,SLOT(CloseAllAction()));
    statusBar()->showMessage(tr("Pronto"));
}
void MainWindow::NewFile()
{
    NewWindow* crea=new NewWindow(&val,this);
    connect(crea,SIGNAL(Bar()),tab,SLOT(DrawBar()));
    connect(crea,SIGNAL(Bar()),this,SLOT(ShowBar()));
    connect(crea,SIGNAL(Line()),tab,SLOT(DrawLine()));
    connect(crea,SIGNAL(Line()),this,SLOT(ShowLine()));
    connect(crea,SIGNAL(Point()),tab,SLOT(DrawPoint()));
    connect(crea,SIGNAL(Point()),this,SLOT(ShowPoint()));
    connect(crea,SIGNAL(New()),tab,SLOT(Open()));
    connect(crea,SIGNAL(New()),this,SLOT(CreateCorrect()));
    crea->show();
}
void MainWindow::OpenXml(QString filename,Valori & v) throw(ErrorOpen)
try
{
    if(!filename.isEmpty())
    {
        QFile file(filename);
        QXmlStreamReader xmlreader(&file);
        if(file.open(QFile::ReadOnly)|| QFile::Text)
        {
            if(v.Size())
                v.DeleteAll();
        while(!xmlreader.atEnd() && !xmlreader.hasError())
        {
            QXmlStreamReader::TokenType token = xmlreader.readNext();
            if(token==QXmlStreamReader::StartDocument)
                                continue;
            if(xmlreader.isStartElement())
            {
                if(xmlreader.name()=="CdFisico")
                {
                    string titolo="";
                    string artista="";
                    int numcanzoni=0;
                    double prezzo=0;
                    while(!(xmlreader.tokenType()==xmlreader.EndElement))
                    {
                        if(xmlreader.name()=="Titolo")
                        {
                            QString stitolo=xmlreader.readElementText();
                            titolo=stitolo.toStdString();
                        }
                        if(xmlreader.name()=="Artista")
                        {
                             QString sartista=xmlreader.readElementText();
                             artista=sartista.toStdString();
                         }
                        if(xmlreader.name()=="Numero")
                        {
                            QString sname=xmlreader.readElementText();
                            numcanzoni=sname.toInt();
                        }
                        if(xmlreader.name()=="Costo")
                        {
                            QString scosto=xmlreader.readElementText();
                            prezzo=scosto.toDouble();
                        }
                        xmlreader.readNext();
                    }
                    CdFisico* fisico=new CdFisico(titolo,artista,numcanzoni,prezzo);
                    v.Aggiungi(*fisico);
                }
                else
                if(xmlreader.name()=="CdDigitale")
                {
                    string titolo="";
                    string artista="";
                    int numerocanzoni=0;
                    double prezzou=0;
                    while(!(xmlreader.tokenType()==xmlreader.EndElement))
                    {
                        if(xmlreader.name()=="Titolo")
                        {
                            QString stitolo=xmlreader.readElementText();
                            titolo=stitolo.toStdString();
                        }
                        if(xmlreader.name()=="Artista")
                        {
                            QString sartista=xmlreader.readElementText();
                            artista=sartista.toStdString();
                        }
                        if(xmlreader.name()=="Numero")
                        {
                            QString snumero=xmlreader.readElementText();
                            numerocanzoni=snumero.toInt();
                        }
                        if(xmlreader.name()=="CostoUnitario")
                        {
                            QString scostou=xmlreader.readElementText();
                            prezzou=scostou.toDouble();
                        }
                        xmlreader.readNext();
                    }
                    CdDigitale* digitale=new CdDigitale(titolo,artista,numerocanzoni,prezzou);
                    v.Aggiungi(*digitale);
                }
                if(xmlreader.name()=="CdCorriere")
                {
                    string titolo="";
                    string artista="";
                    int numerocanzoni=0;
                    double prezzo=0;
                    double prezzotrasp=0;
                    while(!(xmlreader.tokenType()==xmlreader.EndElement))
                    {
                        if(xmlreader.name()=="Titolo")
                        {
                            QString stitolo=xmlreader.readElementText();
                            titolo=stitolo.toStdString();
                        }
                        if(xmlreader.name()=="Artista")
                        {
                             QString sartista=xmlreader.readElementText();
                             artista=sartista.toStdString();
                         }
                        if(xmlreader.name()=="Numero")
                        {
                            QString sname=xmlreader.readElementText();
                            numerocanzoni=sname.toInt();
                        }
                        if(xmlreader.name()=="Costo")
                        {
                            QString scosto=xmlreader.readElementText();
                            prezzo=scosto.toDouble();
                        }
                        if(xmlreader.name()=="CostoTrasporto")
                        {
                            QString scostotrasp=xmlreader.readElementText();
                            prezzotrasp=scostotrasp.toDouble();
                        }
                        xmlreader.readNext();

                    }
                    CdCorriere* corriere=new CdCorriere(titolo,artista,numerocanzoni,prezzo,prezzotrasp);
                    v.Aggiungi(*corriere);
                }

        }
     }
        if(xmlreader.hasError()|| v.IsEmpty())
        {
            QString errore="";
            if(!v.IsEmpty())
            {
            errore=xmlreader.errorString();
            throw ErrorOpen(errore);
            }
            else
            {
                errore="I dati aperti non sono corretti!";
                throw ErrorOpen(errore);
            }
            file.close();
            v.DeleteAll();
            fileopen="";
        }
        else
        {
            fileopen=filename;
            file.close();
            barchart->setEnabled(true);
            linechart->setEnabled(true);
            pointchart->setEnabled(true);
            inserimento->setEnabled(false);
            remove->setEnabled(true);
            aggiungi->setEnabled(true);
            statusBar()->showMessage("Apertura del file",300);
            tab->Open();
        }
      }
   }
}
catch(ErrorOpen e)
{
    QMessageBox::critical(0,"Errore!",e.Error());

}
void MainWindow::OpenFile()
{
    QString filename;
    filename = QFileDialog::getOpenFileName(this,tr("Scigli un file da aprire"),QDir::currentPath(),"*.xml");
    if(!filename.isNull())
        tab->CloseAll();
    OpenXml(filename,val);

 }
void MainWindow::SaveXml(QFile& file) throw(ErrorSave)
try
{
        QXmlStreamWriter xmlWriter;
        xmlWriter.setDevice(&file);
        xmlWriter.setAutoFormatting(true);
        xmlWriter.writeStartDocument();
        xmlWriter.writeStartElement("QCharts");
        for(int i=0;i<val.Size() && !xmlWriter.hasError();i++)
        {
            CdMusicale* cd=val[i];
            QString stitolo=QString::fromStdString((cd->GetTitolo()));
            QString sartista=QString::fromStdString((cd->GetArtista()));
            int num=cd->GetNum();
            QString snum=QString::number(num);
            if(dynamic_cast<CdFisico*>(val[i]) && !dynamic_cast<CdCorriere*>(val[i]))
            {
                CdFisico* fisico=dynamic_cast<CdFisico*>(val[i]);
                double costo=fisico->GetCosto();
                QString scosto=QString::number(costo);
                xmlWriter.writeStartElement("CdFisico");
                xmlWriter.writeTextElement("Titolo",stitolo);
                xmlWriter.writeTextElement("Artista",sartista);
                xmlWriter.writeTextElement("Numero",snum);
                xmlWriter.writeTextElement("Costo",scosto);
                xmlWriter.writeEndElement();
            }
            else
            if(dynamic_cast<CdCorriere*>(val[i]))
            {
                CdCorriere* corriere=dynamic_cast<CdCorriere*>(val[i]);
                double costo=corriere->GetCosto();
                double ctrasp=corriere->GetAggiuntivo();
                QString scosto=QString::number(costo);
                QString strasp=QString::number(ctrasp);
                xmlWriter.writeStartElement("CdCorriere");
                xmlWriter.writeTextElement("Titolo",stitolo);
                xmlWriter.writeTextElement("Artista",sartista);
                xmlWriter.writeTextElement("Numero",snum);
                xmlWriter.writeTextElement("Costo",scosto);
                xmlWriter.writeTextElement("CostoTrasporto",strasp);
                xmlWriter.writeEndElement();
            }
            else
                if(dynamic_cast<CdDigitale*>(val[i]))
                {
                       CdDigitale* digitale=dynamic_cast<CdDigitale*>(val[i]);
                       double cunit=digitale->GetPrezzoUnitario();
                       QString sunit=QString::number(cunit);
                       xmlWriter.writeStartElement("CdDigitale");
                       xmlWriter.writeTextElement("Titolo",stitolo);
                       xmlWriter.writeTextElement("Artista",sartista);
                       xmlWriter.writeTextElement("Numero",snum);
                       xmlWriter.writeTextElement("CostoUnitario",sunit);
                       xmlWriter.writeEndElement();
                }
        }
        xmlWriter.writeEndElement();
        xmlWriter.writeEndDocument();
        if(xmlWriter.hasError())
        {
            file.close();
            throw ErrorSave();
        }
        else
        {
            statusBar()->showMessage("Salvataggio dei dati",300);
            file.close();
         }
}
catch(ErrorSave es)
{
    QMessageBox::warning(0,"Attenzione!", "Errore nel salvataggio dei dati!");
}
void MainWindow::SaveAs() throw(DatiVuoti,OnlyRead)
try
{
    if(val.Size())
    {
        tab->setCurrentIndex(0);
        QString filename = QFileDialog::getSaveFileName(this,tr("Salva come"),QDir::currentPath(),"*.xml");
        if(!filename.isEmpty())
            {
            QFile file(filename);
            if (file.open(QIODevice::WriteOnly))
            {
                SaveXml(file);
                file.close();
                fileopen=filename;     //mi salvo il percorso del file per eventuali sucessivi salvataggi
            }
             else
            {
                file.close();
                throw OnlyRead();
            }

            }
    }
    else
        throw(DatiVuoti(false));
}
catch(OnlyRead o)
{
    QMessageBox::warning(0,"Attenzione!", "Il file e aperto in mdoalità di sola lettura!");
}
catch(DatiVuoti d)
{
    if(!d.GetChiusura())
            QMessageBox::warning(0,"Attenzione!","Non ci sono dati da salvare!");
}
void MainWindow::Save() throw(DatiVuoti,OnlyRead)
try
{
    if(val.Size())
    {
        if(!fileopen.isEmpty())
        {
            QFile file(fileopen);
            if (file.open(QIODevice::WriteOnly))
                SaveXml(file);
            else
                QMessageBox::warning(0,"Attenzione!","Il file è aperto in modalità di sola lettura!");
            file.close();
        }
        else
        {
            tab->setCurrentIndex(0);
            QString filename = QFileDialog::getSaveFileName(this,tr("Salva come"),QDir::currentPath(),"*.xml");
            if(!filename.isEmpty())
            {
                QFile file(filename);
                if (file.open(QIODevice::WriteOnly))
                {
                    SaveXml(file);
                    fileopen=filename;
                    file.close();
                }
                else
                {
                    file.close();
                    throw OnlyRead();
                }
            }
        }
    }
    else
        throw DatiVuoti(false);
}
catch(OnlyRead o)
{
    QMessageBox::warning(0,"Attenzione!", "Il file e aperto in mdoalità di sola lettura!");

}
catch(DatiVuoti d)
{
    if(!d.GetChiusura())
        QMessageBox::warning(0,"Attenzione!","Non ci sono dati da salvare!");
}

void MainWindow::CloseFile() throw(DatiVuoti)
try
{
    if(val.Size())
    {
        val.DeleteAll();
        fileopen="";
        statusBar()->showMessage("Chiusura del file",300);
    }
    else
        throw DatiVuoti(true);
}
catch(DatiVuoti d)
{
    if(d.GetChiusura())
        QMessageBox::warning(0,"Attenzione!","Non ci sono dati da chiudere!");
}
void MainWindow::CloseAllAction()
{
    pointchart->setEnabled(false);
    barchart->setEnabled(false);
    linechart->setEnabled(false);
    inserimento->setEnabled(false);
    remove->setEnabled(false);
    aggiungi->setEnabled(false);
}
void MainWindow::CreateCorrect()
{
    aggiungi->setEnabled(true);
    remove->setEnabled(true);
    inserimento->setEnabled(false);
    pointchart->setEnabled(true);
    linechart->setEnabled(true);
    barchart->setEnabled(true);
    statusBar()->showMessage("Caricamento dati in corso..",400);
    fileopen="";
}
void MainWindow::NewElement()
{
    aggiungi->setEnabled(false);
    inserimento->setEnabled(true);
}
void MainWindow::InsertNew()
{
    aggiungi->setEnabled(true);
    inserimento->setEnabled(false);
}
void MainWindow::ShowBar()
{
    barchart->setEnabled(false);
    linechart->setEnabled(true);
    pointchart->setEnabled(true);
}
void MainWindow::ShowLine()
{
    barchart->setEnabled(true);
    linechart->setEnabled(false);
    pointchart->setEnabled(true);

}
void MainWindow::ShowPoint()
{
    barchart->setEnabled(true);
    linechart->setEnabled(true);
    pointchart->setEnabled(false);

}
void MainWindow::DeleteLast()
{
    aggiungi->setEnabled(true);
    remove->setEnabled(true);
    inserimento->setEnabled(false);
}
void MainWindow::closeEvent(QCloseEvent* event)
{
    if(val.Size())
    {
       bool diversi=false;
       if(!fileopen.isEmpty())//c'è qualche file aperto
       {
           Valori valt;
           OpenXml(fileopen,valt);
           if(valt!=val)
               diversi=true;
       }
       if(fileopen.isEmpty() || diversi)
       {
          QMessageBox msgBox;
          msgBox.setText("Il documento e' stato modificato.");
          msgBox.setInformativeText("Vuoi salvare le modifiche?");
          msgBox.setStandardButtons(QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);
          msgBox.setDefaultButton(QMessageBox::Save);
          int ret = msgBox.exec();
          if(fileopen.isEmpty())
          switch(ret){
                case QMessageBox::Save: SaveAsClose(event); break;
                case QMessageBox::Discard: event->accept(); break;
                case QMessageBox::Cancel: event->ignore(); break;
                default: break;
           }
          else
           switch(ret){
           case QMessageBox::Save: Save(); event->accept(); break;
           case QMessageBox::Discard: event->accept(); break;
           case QMessageBox::Cancel: event->ignore(); break;
           }
           }
       else
           event->accept();
        }
    else
    event->accept();
}
void MainWindow::SaveAsClose(QCloseEvent * event)throw(OnlyRead)
try
{
    tab->setCurrentIndex(0);
    QString filename = QFileDialog::getSaveFileName(this,tr("Salva come"),QDir::currentPath(),"*.xml");
    if(!filename.isEmpty())
        {
        QFile file(filename);
        if (file.open(QIODevice::WriteOnly))
        {
            SaveXml(file);
            file.close();
            event->accept();
        }
         else
        {
            file.close();
            event->ignore();
            throw OnlyRead();
        }
        }
    else
        event->ignore();
}
catch(OnlyRead)
{
    QMessageBox::warning(0,"Attenzione!", "Il file e aperto in mdoalità di sola lettura!");
}
