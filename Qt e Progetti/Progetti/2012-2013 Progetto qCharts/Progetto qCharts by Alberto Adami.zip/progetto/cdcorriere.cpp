//
//  cdcorriere.cpp
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#include "cdcorriere.h"
CdCorriere::CdCorriere():CdFisico(),aggiuntivo(0.0)
{
}
CdCorriere::CdCorriere(string t, string a,int n,double pb, double pa):CdFisico(t,a,n,pb),aggiuntivo(pa)
{
}
double CdCorriere::GetAggiuntivo() const
{
    return aggiuntivo;
}
void CdCorriere::SetAggiuntivo(double a)
{
    aggiuntivo=a;
}
double CdCorriere::prezzo() const
{
    return CdFisico::prezzo()+aggiuntivo;
}
bool CdCorriere::operator ==(const CdMusicale& c) const
{
    if(dynamic_cast<const CdCorriere*>(&c))
    {
        const CdCorriere& c1=dynamic_cast<const CdCorriere&>(c);
        return GetArtista()==c1.GetArtista() && GetTitolo()==c1.GetTitolo() && GetNum()==c1.GetNum() && GetCosto()==c1.GetCosto()
        && GetAggiuntivo()==c1.GetAggiuntivo();
    }
    return false;
}
bool CdCorriere::operator !=(const CdMusicale& c) const
{
    if(dynamic_cast<const CdCorriere*>(&c))
    {
        const CdCorriere& c1=dynamic_cast<const CdCorriere&>(c);
        return !(GetArtista()==c1.GetArtista() && GetTitolo()==c1.GetTitolo() && GetNum()==c1.GetNum() && GetCosto()==c1.GetCosto()
        && GetAggiuntivo()==c1.GetAggiuntivo());
    }
    return true;
}
