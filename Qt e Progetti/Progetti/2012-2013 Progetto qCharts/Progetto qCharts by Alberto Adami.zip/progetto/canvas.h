//
//  canvas.h
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#ifndef CANVAS_H
#define CANVAS_H
#include <QWidget>
#include <QPainter>
#include "valori.h"
#include "dati.h"
#include "datinorm.h"
#include "chart.h"
#include "linechart.h"
#include "barchart.h"
#include "pointchart.h"
class Canvas : public QWidget
{
    Q_OBJECT
private:
    Valori* val;
    Chart* chart;           //puntatore polimorfo a un chart
    QPointF origine;
    QPointF estremox;
    QPointF estremoy;
public:
     Canvas(Valori*,QWidget *parent = 0);
     void SetOrigine(const QPointF&);
     void SetEstremoX(const QPointF&);
     void SetEstremoY(const QPointF&);
     ~Canvas();
protected:
     void paintEvent(QPaintEvent *);
public slots:
     void CloseChart();
     void Aggiorna();
     void drawBar();
     void drawLine();
     void drawPoint();
};

#endif // CANVAS_H
