//
//  input.h
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#ifndef INPUT_H
#define INPUT_H
#include <QDialog>
#include <QList>
#include <QScrollArea>
#include "lineadato.h"
#include "valori.h"
#include "error.h"
class Input : public QDialog
{
Q_OBJECT
private:
    QScrollArea* area;
    Valori* val;
    int n;
    QList<LineaDato*> lista;
public:
     Input(QWidget *parent = 0,Valori* =0,int=0);
     bool Isok() const;
signals:
     void Ok();
private slots:
     void Create() throw(ErrorInput);
};
#endif // INPUT_H
/*
La classe input rappresenta un dialogo per l'inserimento dei dati nell'oggetto valori.
*/
