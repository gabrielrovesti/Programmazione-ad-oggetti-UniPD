//
//  dati.h
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#ifndef DATI_H
#define DATI_H
#include "valori.h"
#include<vector>
using std::vector;
class Dati
{
private:
    vector<double> d;
public:
    Dati(const Valori&);
    int Size() const;
    bool IsEmpty() const;
    double& operator[](int) const;
    double max() const;
};
#endif // DATI_H
/*
La classe Dati serve a rappresentare i dati grezzi contenuti nella classe Valori.
*/
