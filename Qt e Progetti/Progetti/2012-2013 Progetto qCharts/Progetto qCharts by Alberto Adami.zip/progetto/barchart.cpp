//
//  barchart.cpp
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#include "barchart.h"
BarChart::BarChart(const QPointF &o, double x,double w,const Dati &dn):Chart(QPoint(o.x(),o.y()-4),x+w,dn),width(w)
{
}
void BarChart::Draw(QPainter& p) const
{
    for(int i=0;i<Size();i++)
        {
            p.setPen(QPen(Qt::red,3));
            QSizeF size(width,GetOrigine().y()-points[i].y());
            QRectF rect(points[i],size);
            p.drawRect(rect);
            QRectF rect1(points[i]+QPointF(1,1),QSize(width-1,(GetOrigine().y()-points[i].y()-1)));
            p.fillRect(rect1, QBrush(QColor(Qt::darkBlue),Qt::SolidPattern));
            p.setPen(Qt::black);
            QString index;
            index.setNum(i+1);
            QPointF punto(points[i].x()+width/2-1 ,GetOrigine().y()+20);
            p.drawText(punto,index);
            QPointF py1(GetOrigine().x()+5,points[i].y());
            QPointF py2(GetOrigine().x()-5,points[i].y());
            p.drawLine(QLineF(py1,py2));
        }
        for(int i=0;i<Size();++i)
        {
            p.setFont(QFont("arial",7,Qt::black));
            QString value(QString::number(GetDati()[i]));
            p.drawText(QPointF(GetOrigine().x()-25,points[i].y()),value);
        }
}
double BarChart::GetWidth() const
{
    return width;
}
double BarChart::Spazio() const
{
        return points[points.size()-1].x()+width;
}
