//
//  cddigitale.cpp
//  Created by alberto adami.
//  Copyright (c) 2013 alberto adami. All rights reserved.
//
#include "cddigitale.h"
CdDigitale::CdDigitale():CdMusicale(),prezzocanzone(0.0)
{
}
CdDigitale::CdDigitale(string t, string a, int n,double p):CdMusicale(t,a,n),prezzocanzone(p)
{
}
double CdDigitale::GetPrezzoUnitario() const
{
    return prezzocanzone;
}
void CdDigitale::SetPrezzoUnitario(double p)
{
    prezzocanzone=p;
}
double CdDigitale::prezzo() const
{
    return GetNum()*prezzocanzone;
}
bool CdDigitale::operator ==(const CdMusicale& d) const
{
    if(dynamic_cast<const CdDigitale*>(&d))
    {
        const CdDigitale& d1=dynamic_cast<const CdDigitale&>(d);
        return GetArtista()==d1.GetArtista() && GetTitolo()==d1.GetTitolo() && GetNum()==d1.GetNum() && GetPrezzoUnitario()==d1.GetPrezzoUnitario();
    }
    return false;
}
bool CdDigitale::operator !=(const CdMusicale& d) const
{
    if(dynamic_cast<const CdDigitale*>(&d))
    {
        const CdDigitale& d1=dynamic_cast<const CdDigitale&>(d);
        return !(GetArtista()==d1.GetArtista() && GetTitolo()==d1.GetTitolo() && GetNum()==d1.GetNum() && GetPrezzoUnitario()==d1.GetPrezzoUnitario());
    }
    return true;
}
