#ifndef MODEL_H
#define MODEL_H

class Model
{
protected:
    explicit Model();
public:
    virtual ~Model() = default;
};

#endif // MODEL_H
