#ifndef BARCHARTOLDVIEW_H
#define BARCHARTOLDVIEW_H

#include <view/barchartview.h>

class BarChartOldView : public BarChartView
{
public:
    BarChartOldView(const QSize& size = QSize(800,500), View* parent = nullptr);
};

#endif // BARCHARTOLDVIEW_H
