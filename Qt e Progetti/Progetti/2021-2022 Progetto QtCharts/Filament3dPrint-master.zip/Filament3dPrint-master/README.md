Andrei Cristian Bobirica
- Progetto realizzazo per il corso di Programmazione Ad Oggetti
- Laurea triennale di Informatica Università degli studi di Padova
- [Repo GITHUB](https://github.com/andreibobirica/Filament3dPrint)

- [Relazione Del Progetto](https://github.com/andreibobirica/Filament3dPrint/blob/79e5bfe5a9772c35638af9dd67ae13ad940b804a/relazione.pdf)
