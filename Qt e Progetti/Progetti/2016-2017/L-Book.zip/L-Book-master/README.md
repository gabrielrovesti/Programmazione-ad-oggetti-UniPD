# L-Book
[![Codacy Badge](https://api.codacy.com/project/badge/Grade/0152f5bef44846c7a70bc41d74d89d27)](https://www.codacy.com/app/Giglium/L-Book?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=Giglium/L-Book&amp;utm_campaign=Badge_Grade) [![Build Status](https://travis-ci.org/Giglium/L-Book.svg?branch=master)](https://travis-ci.org/Giglium/L-Book)

The school's library manager program.

## Project for "*Programmazione ad Oggetti*"
A.A. 2016/2017 at *University of Padua*

Developed with Qt Framework using:
- Qt version: 5.5.1
- GCC: 5.4.0
- MinGW: 4.8.1 (32-bit)
- OS: Ubuntu 16.04.04 LTS / Windows 7 Professional N 64 bit
## License
* [GNU LESSER GENERAL PUBLIC LICENSE](https://www.gnu.org/licenses/lgpl-3.0.en.html)
