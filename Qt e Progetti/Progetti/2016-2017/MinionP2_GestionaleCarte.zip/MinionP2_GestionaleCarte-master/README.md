# MinionP2_GestionaleCarte
Programma C++ realizzato per il progetto didattico del corso "Programmazione ad oggetti" dell'università di Padova.

La repo contiene tutti i file h, cpp, xml e la relazione realizzata in LaTex contenente la descrizione del progetto.
