#include "partita.h"

Partita::Partita(Utente* ut, Campo c, Orario o): OradiTennis(ut,c,o){}

