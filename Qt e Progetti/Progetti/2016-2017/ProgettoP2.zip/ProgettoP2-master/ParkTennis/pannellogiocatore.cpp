#include "pannellogiocatore.h"

PannelloGiocatore::PannelloGiocatore(PannelloUtente *parent) : PannelloUtente(parent)
{

}

