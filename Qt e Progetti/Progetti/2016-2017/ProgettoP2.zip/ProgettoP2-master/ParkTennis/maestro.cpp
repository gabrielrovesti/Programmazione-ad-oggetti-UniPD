#include <maestro.h>

Maestro::~Maestro(){};

Maestro::Maestro(QString u,QString p):Utente(u,p){};
