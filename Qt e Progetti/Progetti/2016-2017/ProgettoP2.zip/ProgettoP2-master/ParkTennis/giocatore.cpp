#include <giocatore.h>

Giocatore::~Giocatore(){};

Giocatore::Giocatore(QString u, QString p):Utente(u,p){};
