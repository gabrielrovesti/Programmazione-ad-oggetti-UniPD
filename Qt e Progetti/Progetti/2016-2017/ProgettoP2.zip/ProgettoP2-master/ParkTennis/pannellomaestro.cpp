#include "pannellomaestro.h"

PannelloMaestro::PannelloMaestro(PannelloUtente *parent) : PannelloUtente(parent)
{

}

