# PAO16-17Fumetteria
Progetto di programmazione ad oggetti con uso di Qt 5.6.7 
