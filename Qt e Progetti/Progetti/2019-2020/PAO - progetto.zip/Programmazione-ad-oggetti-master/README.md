Programmazione-ad-oggetti
