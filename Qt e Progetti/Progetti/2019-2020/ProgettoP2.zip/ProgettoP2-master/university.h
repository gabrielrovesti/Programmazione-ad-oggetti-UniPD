#ifndef UNIVERSITY_H
#define UNIVERSITY_H

#include <QWidget>

class university : public QWidget
{
    Q_OBJECT

public:
    university(QWidget *parent = 0);
    ~university();
};

#endif // UNIVERSITY_H
