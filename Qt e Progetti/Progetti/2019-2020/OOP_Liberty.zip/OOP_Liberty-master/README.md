# Liberty

## Abstract

Applicazione per la gestione di progetti, ispirata alla web app trello.com, sviluppata per il progetto di Programmazione ad Oggetti 2019/2020

## Ambiente di sviluppo

L'applicazione é stata sviluppata sei seguenti sistemi:

> OS : MacOS 10.15.6
>
> Compilatore : Clang 11.0.3
>
> Qt : 5.9.5
