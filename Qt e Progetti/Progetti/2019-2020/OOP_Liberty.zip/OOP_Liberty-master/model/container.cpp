#include "container.h"

template <class T>
container<T>::container() {

}
