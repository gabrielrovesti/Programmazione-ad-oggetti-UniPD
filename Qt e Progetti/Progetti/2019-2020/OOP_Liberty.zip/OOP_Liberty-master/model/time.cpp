#include "time.h"

Time::Time() {

}
