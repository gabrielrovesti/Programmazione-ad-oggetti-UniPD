<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>addnewcontact</name>
    <message>
        <location filename="../gui/addnewcontact.cpp" line="13"/>
        <source>Username:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addnewcontact.cpp" line="15"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addnewcontact.cpp" line="19"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addnewcontact.cpp" line="29"/>
        <location filename="../gui/addnewcontact.cpp" line="37"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addnewcontact.cpp" line="29"/>
        <source>User not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addnewcontact.cpp" line="34"/>
        <source>Ok!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addnewcontact.cpp" line="34"/>
        <source>User succefully added to your contact list.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>addnewgroup</name>
    <message>
        <location filename="../gui/addnewgroup.cpp" line="14"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addnewgroup.cpp" line="17"/>
        <source>Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addnewgroup.cpp" line="21"/>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addnewgroup.cpp" line="25"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addnewgroup.cpp" line="44"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addnewgroup.cpp" line="44"/>
        <source>A group with the same name already exists.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>addrequestpayment</name>
    <message>
        <location filename="../gui/addrequestpayment.cpp" line="14"/>
        <source>Please read the description and select the request you want to make.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addrequestpayment.cpp" line="17"/>
        <source>Business Account:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addrequestpayment.cpp" line="18"/>
        <source>Executive Account:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addrequestpayment.cpp" line="21"/>
        <source>The business account allows the user to send message only to people who are in his connection list.
 Only one person per time can be insered in the addressee list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addrequestpayment.cpp" line="23"/>
        <source>Executive account can send a message to anyone who&apos;s registered to Legami.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addrequestpayment.cpp" line="26"/>
        <source>The business account can search users only by their username. 
 The number of results is restricted to 1 due to new creation user politics.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addrequestpayment.cpp" line="28"/>
        <source>Executive account can search users by username and a filter of the experience.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addrequestpayment.cpp" line="31"/>
        <source>Request Business Upgrade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addrequestpayment.cpp" line="33"/>
        <location filename="../gui/addrequestpayment.cpp" line="38"/>
        <source>Request Executive Upgrade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/addrequestpayment.cpp" line="62"/>
        <location filename="../gui/addrequestpayment.cpp" line="73"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>admingroups</name>
    <message>
        <location filename="../gui/admingroups.cpp" line="28"/>
        <source>Modify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/admingroups.cpp" line="61"/>
        <location filename="../gui/admingroups.cpp" line="65"/>
        <source>Done</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/admingroups.cpp" line="61"/>
        <source>Group deleted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/admingroups.cpp" line="65"/>
        <source>Group modified</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>adminpayments</name>
    <message>
        <location filename="../gui/adminpayments.cpp" line="53"/>
        <source>Business</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/adminpayments.cpp" line="54"/>
        <source>Executive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/adminpayments.cpp" line="59"/>
        <location filename="../gui/adminpayments.cpp" line="100"/>
        <source>Approved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/adminpayments.cpp" line="60"/>
        <source>Not Approved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/adminpayments.cpp" line="61"/>
        <location filename="../gui/adminpayments.cpp" line="110"/>
        <source>Rejected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/adminpayments.cpp" line="78"/>
        <source>Accept</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/adminpayments.cpp" line="79"/>
        <source>Reject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/adminpayments.cpp" line="100"/>
        <source>The selected payment has been approved.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/adminpayments.cpp" line="102"/>
        <location filename="../gui/adminpayments.cpp" line="112"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/adminpayments.cpp" line="102"/>
        <location filename="../gui/adminpayments.cpp" line="112"/>
        <source>Payment not selected.
 Please select a upgrade request</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/adminpayments.cpp" line="110"/>
        <source>The selected payment has been rejected.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>adminuser</name>
    <message>
        <location filename="../gui/adminuser.cpp" line="22"/>
        <source>Finish</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>adminusers</name>
    <message>
        <location filename="../gui/adminusers.cpp" line="14"/>
        <source>Modify</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>inboxMessages</name>
    <message>
        <location filename="../gui/inboxmessages.cpp" line="17"/>
        <source>Sender</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/inboxmessages.cpp" line="18"/>
        <source>Object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/inboxmessages.cpp" line="34"/>
        <source>Read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/inboxmessages.cpp" line="35"/>
        <source>Not Read</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>legamilogin</name>
    <message>
        <location filename="../gui/legamilogin.cpp" line="19"/>
        <source>Please enter your account data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamilogin.cpp" line="21"/>
        <source>Username:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamilogin.cpp" line="25"/>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamilogin.cpp" line="30"/>
        <source>Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamilogin.cpp" line="31"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>legamimainwindow</name>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="74"/>
        <source>Database not loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="75"/>
        <source>Would you like to try &lt;i&gt;another path&lt;/i&gt; rather than the normal one or to load the &lt;i&gt;example data?&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="78"/>
        <source>Another path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="79"/>
        <source>Example data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="97"/>
        <location filename="../gui/legamimainwindow.cpp" line="387"/>
        <location filename="../gui/legamimainwindow.cpp" line="418"/>
        <source>Error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="97"/>
        <source>Is not been possible to create the example account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="101"/>
        <source>Data example created!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="101"/>
        <source>A user account has been created.These are the login informations:
Username: root
Password: &apos;there is no password&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="598"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="599"/>
        <source>New User?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="600"/>
        <source>Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="601"/>
        <location filename="../gui/legamimainwindow.cpp" line="614"/>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="607"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="204"/>
        <location filename="../gui/legamimainwindow.cpp" line="608"/>
        <source>About Legami</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="211"/>
        <location filename="../gui/legamimainwindow.cpp" line="609"/>
        <source>About Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="191"/>
        <source>New Account Created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="191"/>
        <source>The new account requested has been created.
Please login with the new username and password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="193"/>
        <location filename="../gui/legamimainwindow.cpp" line="499"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="193"/>
        <source>It has not been possible to create a new account. Please try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="204"/>
        <source>Legami is a program made for the class &quot;Object Programming&quot;
Programmer name: Giorgio Maggiolo
Student Code: 610338
Email: maggiolo.giorgio@gmail.com</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="216"/>
        <source>Logged succefully!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="216"/>
        <source> logged in!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="220"/>
        <source>Login problem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="220"/>
        <source>You have provided wrong accessing data.
Please check username and password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="613"/>
        <source>Logout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="237"/>
        <location filename="../gui/legamimainwindow.cpp" line="603"/>
        <location filename="../gui/legamimainwindow.cpp" line="616"/>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="47"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="47"/>
        <source>Warning: italian file translation not found. 
 The only language available is English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="238"/>
        <location filename="../gui/legamimainwindow.cpp" line="604"/>
        <location filename="../gui/legamimainwindow.cpp" line="617"/>
        <source>Italian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="240"/>
        <location filename="../gui/legamimainwindow.cpp" line="605"/>
        <location filename="../gui/legamimainwindow.cpp" line="618"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="447"/>
        <source>The group requested has been created. 
 You are the admin.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="620"/>
        <source>Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="621"/>
        <source>View Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="622"/>
        <source>Modify Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="624"/>
        <source>Contacts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="625"/>
        <source>Show Contacts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="626"/>
        <source>Add new contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="627"/>
        <source>Delete Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="629"/>
        <source>Groups</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="630"/>
        <source>View Groups</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="631"/>
        <source>Register new group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="632"/>
        <source>Subscribe Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="634"/>
        <source>Messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="635"/>
        <source>Inbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="636"/>
        <source>Outbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="637"/>
        <source>New Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="639"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="641"/>
        <source>Upgrades</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="642"/>
        <source>Request Payments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="643"/>
        <source>Check Requests</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="647"/>
        <source>Administration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="648"/>
        <source>Admin Users</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="649"/>
        <source>Admin Groups</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="650"/>
        <source>Admin Payments Requested</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="345"/>
        <source>Successfully logged out!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="345"/>
        <source> successfully logged out.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="387"/>
        <source> asdasdasd successfully logged out.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="418"/>
        <source> There has been a error and the program could not recognize the type of the account.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="447"/>
        <source>Group Created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="457"/>
        <source>Group Subscrived</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/legamimainwindow.cpp" line="457"/>
        <source>You have been added to the group requested.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>modifycompanyinfos</name>
    <message>
        <location filename="../gui/modifycompanyinfos.cpp" line="12"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifycompanyinfos.cpp" line="15"/>
        <source>Address:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifycompanyinfos.cpp" line="18"/>
        <source>Company types:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifycompanyinfos.cpp" line="20"/>
        <source>Modify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifycompanyinfos.cpp" line="22"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>modifycompanyprofile</name>
    <message>
        <location filename="../gui/modifycompanyprofile.cpp" line="23"/>
        <source>Data Modified!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifycompanyprofile.cpp" line="23"/>
        <source>The data has been modified successfully.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>modifygroup</name>
    <message>
        <location filename="../gui/modifygroup.cpp" line="23"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifygroup.cpp" line="25"/>
        <source>Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifygroup.cpp" line="28"/>
        <source>Add new user:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifygroup.cpp" line="70"/>
        <source>New admin:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifygroup.cpp" line="71"/>
        <source>Remove user:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifygroup.cpp" line="72"/>
        <source>Remove admin:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifygroup.cpp" line="74"/>
        <source>Modify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifygroup.cpp" line="76"/>
        <source>Delete group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifygroup.cpp" line="78"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifygroup.cpp" line="96"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifygroup.cpp" line="96"/>
        <source>User not found</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>modifyuserexperience</name>
    <message>
        <location filename="../gui/modifyuserexperience.cpp" line="7"/>
        <source>Work Experience</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifyuserexperience.cpp" line="8"/>
        <source>Formative Experience</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifyuserexperience.cpp" line="13"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifyuserexperience.cpp" line="17"/>
        <source>Date exp:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifyuserexperience.cpp" line="20"/>
        <source>Descr:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifyuserexperience.cpp" line="22"/>
        <source>Modify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifyuserexperience.cpp" line="25"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifyuserexperience.cpp" line="28"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>modifyuserexperiences</name>
    <message>
        <location filename="../gui/modifyuserexperiences.cpp" line="4"/>
        <source>Experiences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifyuserexperiences.cpp" line="9"/>
        <source>Add Formative Exp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifyuserexperiences.cpp" line="13"/>
        <source>Add Working Exp</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>modifyuserinfos</name>
    <message>
        <location filename="../gui/modifyuserinfos.cpp" line="7"/>
        <source>User Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifyuserinfos.cpp" line="13"/>
        <source>First Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifyuserinfos.cpp" line="16"/>
        <source>Last Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifyuserinfos.cpp" line="19"/>
        <source>Birth Date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifyuserinfos.cpp" line="22"/>
        <source>Birth Place:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifyuserinfos.cpp" line="25"/>
        <source>Tel. Num.:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifyuserinfos.cpp" line="28"/>
        <source>Email:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifyuserinfos.cpp" line="30"/>
        <source>Modify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifyuserinfos.cpp" line="33"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>modifyusern</name>
    <message>
        <location filename="../gui/modifyusern.cpp" line="6"/>
        <source>Account Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifyusern.cpp" line="13"/>
        <source>Username:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifyusern.cpp" line="17"/>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifyusern.cpp" line="20"/>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifyusern.cpp" line="21"/>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifyusern.cpp" line="22"/>
        <source>Admin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifyusern.cpp" line="28"/>
        <source>Modify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifyusern.cpp" line="31"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>modifyuserprofile</name>
    <message>
        <location filename="../gui/modifyuserprofile.cpp" line="24"/>
        <source>Legami - Modify Profile Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifyuserprofile.cpp" line="29"/>
        <source>Data Modified!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifyuserprofile.cpp" line="29"/>
        <source>The data has been modified successfully.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifyuserprofile.cpp" line="32"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/modifyuserprofile.cpp" line="32"/>
        <source>Are you sure you are enabled to modify those data?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>newmessage</name>
    <message>
        <location filename="../gui/newmessage.cpp" line="23"/>
        <source>Select addressee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/newmessage.cpp" line="27"/>
        <source>Addressee:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/newmessage.cpp" line="34"/>
        <source>Object:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/newmessage.cpp" line="39"/>
        <source>Text:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/newmessage.cpp" line="44"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/newmessage.cpp" line="48"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/newmessage.cpp" line="57"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/newmessage.cpp" line="57"/>
        <source>Addressee not found!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/newmessage.cpp" line="63"/>
        <source>Sended!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/newmessage.cpp" line="63"/>
        <source>The message has been sent succefully.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>outboxMessages</name>
    <message>
        <location filename="../gui/outboxmessages.cpp" line="19"/>
        <source>Sender</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/outboxmessages.cpp" line="19"/>
        <source>Object</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>reguser</name>
    <message>
        <location filename="../gui/reguser.cpp" line="25"/>
        <source>Register</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/reguser.cpp" line="26"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/reguser.cpp" line="36"/>
        <source>User Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/reguser.cpp" line="37"/>
        <source>Company Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/reguser.cpp" line="40"/>
        <source>Username:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/reguser.cpp" line="41"/>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/reguser.cpp" line="65"/>
        <source>Duplicate account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/reguser.cpp" line="65"/>
        <source>Error! There is an already existing account with the same username.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>removecontact</name>
    <message>
        <location filename="../gui/removecontact.cpp" line="10"/>
        <source>Select the account to remove from your connection list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/removecontact.cpp" line="16"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/removecontact.cpp" line="20"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/removecontact.cpp" line="30"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/removecontact.cpp" line="30"/>
        <source>Account not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/removecontact.cpp" line="34"/>
        <source>Done</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/removecontact.cpp" line="34"/>
        <source>Account remove from your connection list.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>searchwidget</name>
    <message>
        <location filename="../gui/searchwidget.cpp" line="25"/>
        <source>Username Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/searchwidget.cpp" line="28"/>
        <source>Username:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/searchwidget.cpp" line="36"/>
        <source>Company Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/searchwidget.cpp" line="38"/>
        <source>User Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/searchwidget.cpp" line="166"/>
        <source>User info Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/searchwidget.cpp" line="172"/>
        <source>Surname:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/searchwidget.cpp" line="175"/>
        <source>Birth Date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/searchwidget.cpp" line="178"/>
        <source>Birth Place:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/searchwidget.cpp" line="181"/>
        <source>Tel number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/searchwidget.cpp" line="184"/>
        <source>Email:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/searchwidget.cpp" line="201"/>
        <source>Experience Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/searchwidget.cpp" line="204"/>
        <source>Formative Experience</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/searchwidget.cpp" line="205"/>
        <source>Working Experience</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/searchwidget.cpp" line="260"/>
        <source>Company info Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/searchwidget.cpp" line="266"/>
        <source>Address:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/searchwidget.cpp" line="269"/>
        <source>Company types:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/searchwidget.cpp" line="169"/>
        <location filename="../gui/searchwidget.cpp" line="206"/>
        <location filename="../gui/searchwidget.cpp" line="263"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/searchwidget.cpp" line="209"/>
        <source>Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/searchwidget.cpp" line="45"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/searchwidget.cpp" line="117"/>
        <source>Show profile selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/searchwidget.cpp" line="53"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/searchwidget.cpp" line="53"/>
        <source>Company basic account are not allowed to perform any search.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>showMessage</name>
    <message>
        <location filename="../gui/showmessage.cpp" line="4"/>
        <source>Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showmessage.cpp" line="9"/>
        <source>Sender:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showmessage.cpp" line="12"/>
        <source>Addressee:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showmessage.cpp" line="15"/>
        <source>Object:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showmessage.cpp" line="18"/>
        <source>Message:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>showcompanyinfo</name>
    <message>
        <location filename="../gui/showcompanyinfo.cpp" line="5"/>
        <source>Company info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showcompanyinfo.cpp" line="15"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showcompanyinfo.cpp" line="19"/>
        <source>Address:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showcompanyinfo.cpp" line="23"/>
        <source>Company type(s):</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>showcontacts</name>
    <message>
        <location filename="../gui/showcontacts.cpp" line="12"/>
        <source>Contats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showcontacts.cpp" line="32"/>
        <source>Show profile</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>showcontactsmessage</name>
    <message>
        <location filename="../gui/showcontactsmessage.cpp" line="11"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showcontactsmessage.cpp" line="15"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>showgroup</name>
    <message>
        <location filename="../gui/showgroup.cpp" line="28"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showgroup.cpp" line="31"/>
        <source>Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showgroup.cpp" line="67"/>
        <source>Admins:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showgroup.cpp" line="68"/>
        <source>Users:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showgroup.cpp" line="76"/>
        <source>Admin Group</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>showlistpayments</name>
    <message>
        <location filename="../gui/showlistpayments.cpp" line="28"/>
        <source>Business</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showlistpayments.cpp" line="29"/>
        <source>Executive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showlistpayments.cpp" line="32"/>
        <source>Approved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showlistpayments.cpp" line="33"/>
        <source>Rejected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showlistpayments.cpp" line="34"/>
        <source>Not Approved</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>showuserexperieces</name>
    <message>
        <location filename="../gui/showuserexperieces.cpp" line="5"/>
        <source>Experiences</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>showuserexperience</name>
    <message>
        <location filename="../gui/showuserexperience.cpp" line="13"/>
        <source>Working Experience</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showuserexperience.cpp" line="17"/>
        <source>Formative Experience</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showuserexperience.cpp" line="21"/>
        <source>Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showuserexperience.cpp" line="24"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showuserexperience.cpp" line="27"/>
        <source>Experience date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showuserexperience.cpp" line="30"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>showuserinfo</name>
    <message>
        <location filename="../gui/showuserinfo.cpp" line="6"/>
        <source>User Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showuserinfo.cpp" line="31"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showuserinfo.cpp" line="32"/>
        <source>Surname:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showuserinfo.cpp" line="33"/>
        <source>Birth Date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showuserinfo.cpp" line="34"/>
        <source>Birth place:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showuserinfo.cpp" line="35"/>
        <source>Tel Num:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showuserinfo.cpp" line="36"/>
        <source>Email:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>showusern</name>
    <message>
        <location filename="../gui/showusern.cpp" line="6"/>
        <source>Account Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showusern.cpp" line="18"/>
        <source>Username:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showusern.cpp" line="19"/>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showusern.cpp" line="21"/>
        <source>Basic Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showusern.cpp" line="22"/>
        <source>Business Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showusern.cpp" line="23"/>
        <source>Executive Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/showusern.cpp" line="25"/>
        <source>Account type:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>showuserprofile</name>
    <message>
        <location filename="../gui/showuserprofile.cpp" line="24"/>
        <source>Legami - Profile Page</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>subscribegroup</name>
    <message>
        <location filename="../gui/subscribegroup.cpp" line="29"/>
        <source>Select the group with you want to subscrive.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/subscribegroup.cpp" line="31"/>
        <source>Subscribe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/subscribegroup.cpp" line="34"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>viewGroupIscrived</name>
    <message>
        <location filename="../gui/viewgroupiscrived.cpp" line="76"/>
        <source>Done</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/viewgroupiscrived.cpp" line="76"/>
        <source>Group deleted.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>viewotheruser</name>
    <message>
        <location filename="../gui/viewotheruser.cpp" line="18"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
