#include "messaggio.h"
#include "user.h"

Messaggio::Messaggio(User* _l,pstring _ogg, pstring _text,dataora _d):oggetto(_ogg),testo(_text),autore(_l),t_post(_d){}

pstring Messaggio::getogg() const{return oggetto;}

pstring Messaggio::gettesto() const{return testo;}

pstring Messaggio::getTimePost() const{return t_post.getdataora();}

User* Messaggio::getautore() const{return autore;}

pstring Messaggio::tostring()const{
    pstring out;
    out+=autore->getinfo()->getusername();out+="##";
    out+=oggetto;out+="##";
    out+=testo;out+="##";
    out+=t_post.stamp();
    return out;

}

bool Messaggio::operator<(const Messaggio& m) const{return t_post<m.t_post ? true : false;}

bool Messaggio::operator>(const Messaggio& m) const{return t_post>m.t_post ? true : false;}
