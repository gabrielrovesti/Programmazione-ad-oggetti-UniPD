#ifndef OFFERTAWINDOW_H
#define OFFERTAWINDOW_H

#include <QWidget>
#include <QScrollArea>
#include <QVBoxLayout>
#include <QLineEdit>
#include "findofferte.h"
#include "offinfowidget.h"
#include "newoffwindow.h"

/*Implementa la ricerca delle offerte. Dal risultato della ricerca, carica dei offWidgets che, se cliccati,
 *causano l'apertura di un offInfoWidget con le informazioni relative al gruppo selezionata. Un pulsante
 *permette di candidarsi, e per gli utenti EXECUTIVE o superiori viene mostrato un pulsante che permette la creazione di nuove oferte.
 *Il tutto è contenuto in una QScrollArea per permettere una visualizzazione più compatta in caso di liste molto lunghe.
 *Ogni volta che si visualizzano i dettagli di un'offerta, viene creato un oggetto offInfoWidget. Questo viene
 *distrutto se si vuole vederne un'altra, e quindi ricreato.
 *La finestra di ricerca viene distrutta nel distruttore, la finestra di nuova offerta e di info si autodistruggono alla chiusura,
 *gli offWidgets dell'ultima ricerca vengono cancellati nel distruttore anch'essi con un ciclo che itera sul layout
 */

class offertaWindow:public QWidget{
Q_OBJECT
public:
    offertaWindow(Account* acc,QWidget *parent=0);
    ~offertaWindow();
signals:
    void offertaAggiunta(Offerta*,int);
private slots:
    void loadOff(QString,QString,QString,QString,QString,bool,int);
    void createOff(QString,QString,QString,QString,QString,QString,QString,Azienda*,QString);
    void loadInfo(Offerta*);
    void addofferta();
    void newOffClicked();

private:
    Account* account;
    findOfferte* findoff;
    offInfoWidget *info;
    newOffWindow *now;
    QScrollArea *searchArea,*infoArea;
    QPushButton *add,*newoff;
    QVBoxLayout *vertical;


};

#endif // OFFERTAWINDOW_H
