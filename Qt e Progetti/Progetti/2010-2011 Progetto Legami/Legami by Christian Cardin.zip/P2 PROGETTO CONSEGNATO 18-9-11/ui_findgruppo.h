/********************************************************************************
** Form generated from reading UI file 'findgruppo.ui'
**
** Created: Sun Sep 18 16:34:32 2011
**      by: Qt User Interface Compiler version 4.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FINDGRUPPO_H
#define UI_FINDGRUPPO_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QGridLayout>
#include <QtGui/QGroupBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpinBox>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_findGruppo
{
public:
    QPushButton *cerca;
    QGroupBox *groupBox;
    QCheckBox *simili;
    QWidget *layoutWidget_2;
    QHBoxLayout *horizontalLayout;
    QSpinBox *soglia;
    QLabel *label_6;
    QWidget *widget;
    QGridLayout *gridLayout;
    QLabel *label;
    QLineEdit *nome;
    QLabel *label_2;
    QLineEdit *sett;

    void setupUi(QWidget *findGruppo)
    {
        if (findGruppo->objectName().isEmpty())
            findGruppo->setObjectName(QString::fromUtf8("findGruppo"));
        findGruppo->resize(512, 171);
        cerca = new QPushButton(findGruppo);
        cerca->setObjectName(QString::fromUtf8("cerca"));
        cerca->setGeometry(QRect(20, 110, 461, 51));
        groupBox = new QGroupBox(findGruppo);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(280, 0, 221, 101));
        simili = new QCheckBox(groupBox);
        simili->setObjectName(QString::fromUtf8("simili"));
        simili->setGeometry(QRect(0, 40, 121, 22));
        layoutWidget_2 = new QWidget(groupBox);
        layoutWidget_2->setObjectName(QString::fromUtf8("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(0, 70, 218, 29));
        horizontalLayout = new QHBoxLayout(layoutWidget_2);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        soglia = new QSpinBox(layoutWidget_2);
        soglia->setObjectName(QString::fromUtf8("soglia"));
        soglia->setMinimum(0);
        soglia->setMaximum(100);
        soglia->setSingleStep(10);
        soglia->setValue(60);

        horizontalLayout->addWidget(soglia);

        label_6 = new QLabel(layoutWidget_2);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout->addWidget(label_6);

        widget = new QWidget(findGruppo);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(20, 0, 251, 101));
        gridLayout = new QGridLayout(widget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        nome = new QLineEdit(widget);
        nome->setObjectName(QString::fromUtf8("nome"));

        gridLayout->addWidget(nome, 0, 1, 1, 1);

        label_2 = new QLabel(widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        sett = new QLineEdit(widget);
        sett->setObjectName(QString::fromUtf8("sett"));

        gridLayout->addWidget(sett, 1, 1, 1, 1);


        retranslateUi(findGruppo);

        QMetaObject::connectSlotsByName(findGruppo);
    } // setupUi

    void retranslateUi(QWidget *findGruppo)
    {
        findGruppo->setWindowTitle(QApplication::translate("findGruppo", "Form", 0, QApplication::UnicodeUTF8));
        cerca->setText(QApplication::translate("findGruppo", "Cliccami! :D", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QApplication::translate("findGruppo", "Opzioni di rierca", 0, QApplication::UnicodeUTF8));
        simili->setText(QApplication::translate("findGruppo", "Ricerca Simili", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("findGruppo", "% Somiglianza Minima", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("findGruppo", "Nome", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("findGruppo", "Settore", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class findGruppo: public Ui_findGruppo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FINDGRUPPO_H
