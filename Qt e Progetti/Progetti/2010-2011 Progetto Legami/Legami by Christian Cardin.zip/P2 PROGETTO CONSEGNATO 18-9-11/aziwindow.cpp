#include "aziwindow.h"
#include "azwidget.h"
#include "errormex.h"
#include <QLayout>
aziWindow::aziWindow(Account *acc, QWidget *parent):QWidget(parent),account(acc){

    QPushButton* find=new QPushButton("Ricerca Aziende");
    newaz=new QPushButton("Crea nuova Azienda");
    add=new QPushButton();
    connect(add,SIGNAL(clicked()),this,SLOT(addazienda()));
    add->hide();
    newaz->hide();
    info=0;
    naw=0;

    tipoAcc tipo=account->checktipoaccount();
    if(tipo != BASIC){           // se è un account qualificato, può creare aziende
        newaz->setVisible(true);
        naw=new newAzWindow();
        connect(newaz,SIGNAL(clicked()),naw,SLOT(show()));
        connect(naw,SIGNAL(createAz(QString,QString,QString,QString,QString,QString,QString,QString,QString,QString)),
                this,SLOT(createAz(QString,QString,QString,QString,QString,QString,QString,QString,QString,QString)));
    }

    searchArea=new QScrollArea();
    searchArea->setSizePolicy(QSizePolicy::Fixed,QSizePolicy::Minimum);
    vertical=new QVBoxLayout();  //layout della searchArea
    searchArea->setLayout(vertical);

    infoArea=new QScrollArea();
    infoArea->setWidgetResizable(true);

    findaz=new findAziende(account);
    connect(find,SIGNAL(clicked()),findaz,SLOT(show()));
    connect(findaz,SIGNAL(findclicked(QString,QString,QString,QString,bool,int)),
            this,SLOT(loadAzi(QString,QString,QString,QString,bool,int)));


    QHBoxLayout *hbutt=new QHBoxLayout(); //layout pulsanti
    hbutt->addWidget(find);
    hbutt->addSpacing(82);
    hbutt->addWidget(newaz);
    hbutt->addWidget(add);
    hbutt->addStretch();
    QHBoxLayout *hmain=new QHBoxLayout(); //layout widgets
    hmain->addWidget(searchArea);
    hmain->addWidget(infoArea);
    hmain->setSizeConstraint(QLayout::SetNoConstraint);
    QVBoxLayout *vmain=new QVBoxLayout();  //layout principale
    vmain->addLayout(hbutt);
    vmain->addLayout(hmain);
    setLayout(vmain);
}

void aziWindow::loadAzi(QString no,QString sett,QString tip,QString loc,bool si,int so){
    vector<Azienda*> aziende=account->findaziende(no.toStdString(),sett.toStdString(),tip.toStdString(),loc.toStdString(),si,so);

    QLayoutItem *child;         //svuota completamente il layout della searchArea e pulisce la memoria dai vecchi dati
     while ((child = vertical->takeAt(0)) != 0) {
         if(child->widget())
             delete child->widget();
         else if(child->spacerItem())
             delete child->spacerItem();
         else if(child->layout())
             delete child->layout();
     }
     //numero risultati
    QLabel *resoult=new QLabel(QString::number(aziende.size())+" risultati");
    QFrame *line=new QFrame();
    line->setFrameShape(QFrame::HLine);
    vertical->addWidget(resoult);
    vertical->addWidget(line);
    azWidget *temp;

    for(int i=aziende.size()-1;i>=0;i--){       //scorre il vettore in ordine inverso e crea gli aztWidgets
        temp=new azWidget(aziende[i]);
        temp->disablebuttons();
        temp->setEnabled(true);
        connect(temp,SIGNAL(clicked(Azienda*)),this,SLOT(loadInfo(Azienda*)));
        vertical->addWidget(temp);
    }
    vertical->addStretch();
    if(info)
        info->hide();
    if(add->isVisible())
        add->hide();
}

void aziWindow::loadInfo(Azienda* az){
    add->setVisible(true);
    if(info){
        if(info->getazienda()==az){   //se ho cliccato lo stesso pulsante di prima, non faccio nulla
            if(info->isHidden())
                info->setVisible(true);//ma se la finestra di info non è attiva, la mostra
            return;
        }
        delete infoArea->takeWidget();     //rimuove ed elimina il widget con le informazioni precedenti
   }
    info=new azinfoWidget(az);
    infoArea->setWidget(info);           //setta le nuove info
    add->setText("Aggiungi "+QString::fromStdString(az->getinfo()->getnome())); 
    info->setVisible(true);
}

void aziWindow::addazienda(){
    Azienda* az=info->getazienda();
    try{
        account->addazienda(az);
    }
    catch(ErrState e){
        ErrorMex *werr=new ErrorMex(e);
        werr->show();
        return;
    }
    OkMex *ok=new OkMex("Inserimento avvenuto.","L'Azieda e' stata inserita correttamente nella tua lista delle aziende");
    ok->show();
    emit aziendaAggiunta(az);
}

void aziWindow::createAz(QString no, QString lo, QString ind, QString sett, QString desc, QString tip, QString dim,
                         QString web, QString tel, QString email){
    Azienda *az;
    try{
        az=account->newazienda(no.toStdString(),lo.toStdString(),ind.toStdString(),sett.toStdString(),
                               desc.toStdString(),tip.toStdString(),dim.toStdString(),web.toStdString(),
                               tel.toStdString(),email.toStdString());
    }
    catch(ErrState e){
        ErrorMex *werr=new ErrorMex(e);
        werr->show();
        return;
    }
    OkMex *ok=new OkMex("Creazione avvenuta!","L'Azieda e' stata inserita correttamente nella tua lista delle aziende");
    ok->show();
    emit aziendaAggiunta(az);
}

aziWindow::~aziWindow(){
    if(info)
        delete info;
    if(naw)
        delete naw;
    delete findaz;

    QLayoutItem *child;         //svuota completamente il layout della searchArea e pulisce la memoria dai vecchi dati
     while ((child = vertical->takeAt(0)) != 0) {
         if(child->widget())
             delete child->widget();
         else if(child->spacerItem())
             delete child->spacerItem();
         else if(child->layout())
             delete child->layout();
     }

}







