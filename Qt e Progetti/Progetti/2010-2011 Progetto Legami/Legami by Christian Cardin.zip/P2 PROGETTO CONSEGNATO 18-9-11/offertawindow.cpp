#include "offertawindow.h"
#include "errormex.h"

offertaWindow::offertaWindow(Account *acc, QWidget *parent):QWidget(parent),account(acc){

    QPushButton* find=new QPushButton("Ricerca Offerta");
    newoff=new QPushButton("Crea nuova Offerta");
    add=new QPushButton("Candidati a questa Offerta");
    connect(add,SIGNAL(clicked()),this,SLOT(addofferta()));
    add->hide();
    newoff->hide();

    info=0;
    tipoAcc tipo=account->checktipoaccount();
    if(tipo != BASIC && tipo!=BUSINESS){           // se è un account qualificato, può creare offerte
        newoff->setVisible(true);
        connect(newoff,SIGNAL(clicked()),this,SLOT(newOffClicked()));
    }

    searchArea=new QScrollArea();
    searchArea->setSizePolicy(QSizePolicy::Fixed,QSizePolicy::Minimum);
    vertical=new QVBoxLayout();  //layout della searchArea
    searchArea->setLayout(vertical);

    infoArea=new QScrollArea();
    infoArea->setWidgetResizable(true);

    findoff=new findOfferte(account);
    connect(find,SIGNAL(clicked()),findoff,SLOT(show()));
    connect(findoff,SIGNAL(findclicked(QString,QString,QString,QString,QString,bool,int)),
            this,SLOT(loadOff(QString,QString,QString,QString,QString,bool,int)));


    QHBoxLayout *hbutt=new QHBoxLayout(); //layout pulsanti
    hbutt->addWidget(find);
    hbutt->addSpacing(82);
    hbutt->addWidget(newoff);
    hbutt->addWidget(add);
    hbutt->addStretch();
    QHBoxLayout *hmain=new QHBoxLayout(); //layout widgets
    hmain->addWidget(searchArea);
    hmain->addWidget(infoArea);
    hmain->setSizeConstraint(QLayout::SetNoConstraint);
    QVBoxLayout *vmain=new QVBoxLayout();  //layout principale
    vmain->addLayout(hbutt);
    vmain->addLayout(hmain);
    setLayout(vmain);
}


void offertaWindow::loadOff(QString no,QString sett,QString tip,QString loc,QString se,bool si,int so){
    vector<Offerta*> offerte=account->findofferte(no.toStdString(),sett.toStdString(),tip.toStdString(),loc.toStdString(),se.toStdString(),si,so);

    QLayoutItem *child;         //svuota completamente il layout della searchArea e pulisce la memoria dai vecchi dati
     while ((child = vertical->takeAt(0)) != 0) {
         if(child->widget())
             delete child->widget();
         else if(child->spacerItem())
             delete child->spacerItem();
         else if(child->layout())
             delete child->layout();
     }
     //numero risultati
    QLabel *resoult=new QLabel(QString::number(offerte.size())+" risultati");
    QFrame *line=new QFrame();
    line->setFrameShape(QFrame::HLine);
    vertical->addWidget(resoult);
    vertical->addWidget(line);
    offWidget *temp;

    for(int i=offerte.size()-1;i>=0;i--){       //scorre il vettore in ordine inverso e crea gli offWidgets
        temp=new offWidget(offerte[i]);
        temp->disablebuttons();
        temp->hidedesc();
        vertical->addWidget(temp);
        connect(temp,SIGNAL(clicked(Offerta*)),this,SLOT(loadInfo(Offerta*)));
    }
    vertical->addStretch();
    if(info)
        info->hide();
    if(add->isVisible())
        add->hide();
}

void offertaWindow::newOffClicked(){
    now=new newOffWindow(account);
    connect(now,SIGNAL(createOff(QString,QString,QString,QString,QString,QString,QString,Azienda*,QString)),
            this,SLOT(createOff(QString,QString,QString,QString,QString,QString,QString,Azienda*,QString)));
    now->show();
}

void offertaWindow::loadInfo(Offerta* off){
    add->setVisible(true);
    if(info){
        if(info->getofferta()==off){   //se ho cliccato lo stesso pulsante di prima, non faccio nulla
            if(info->isHidden())
                info->setVisible(true);//ma se la finestra di info non è attiva, la mostra
            return;
        }
        delete infoArea->takeWidget();     //rimuove ed elimina il widget con le informazioni precedenti
   }
    info=new offInfoWidget(off,account);
    infoArea->setWidget(info);           //setta le nuove info
    info->setVisible(true);
}

void offertaWindow::addofferta(){
    Offerta* off=info->getofferta();
    try{
        account->candidatiaofferta(off);
    }
    catch(ErrState e){
        ErrorMex *werr=new ErrorMex(e);
        werr->show();
        return;
    }
    OkMex *ok=new OkMex("Candidatura avvenuta.","L'offerta' e' stata inserita correttamente nella tua lista delle candidature");
    ok->show();
    emit offertaAggiunta(off,0); //0: significa che deve aggiugere l'offerta nella lista delle candidature
}

void offertaWindow::createOff(QString tit,QString loc,QString ind,QString sett,QString desc,
                              QString gio,QString esp,Azienda* az,QString spec){
    Offerta* off;
    try{
        off=account->newofferta(tit.toStdString(),loc.toStdString(),ind.toStdString(),sett.toStdString(),
                                desc.toStdString(),gio.toStdString(),esp.toStdString(),az,spec.toStdString());
    }
    catch(ErrState e){
        ErrorMex *werr=new ErrorMex(e);
        werr->show();
        return;
    }
    OkMex *ok=new OkMex("Creazione avvenuta!","L'Offerta e' stata inserita correttamente nella tua lista delle offerte");
    ok->show();
    emit offertaAggiunta(off,1); //1: significa che deve aggiugere l'offerta nella lista delle offerte personali
}

offertaWindow::~offertaWindow(){
    delete findoff;

    QLayoutItem *child;         //svuota completamente il layout della searchArea e pulisce la memoria dai vecchi dati
     while ((child = vertical->takeAt(0)) != 0) {
         if(child->widget())
             delete child->widget();
         else if(child->spacerItem())
             delete child->spacerItem();
         else if(child->layout())
             delete child->layout();
     }
}
