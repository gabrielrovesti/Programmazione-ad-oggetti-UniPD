/********************************************************************************
** Form generated from reading UI file 'newaccountwindow.ui'
**
** Created: Sun Sep 18 16:34:32 2011
**      by: Qt User Interface Compiler version 4.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEWACCOUNTWINDOW_H
#define UI_NEWACCOUNTWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QDateEdit>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QTextEdit>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_newAccountWindow
{
public:
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_17;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLineEdit *nome;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QLineEdit *cogn;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_3;
    QLineEdit *user;
    QHBoxLayout *horizontalLayout_8;
    QLabel *label_8;
    QLineEdit *email;
    QHBoxLayout *horizontalLayout_18;
    QLabel *label_17;
    QComboBox *acc;
    QHBoxLayout *horizontalLayout_10;
    QLabel *label_10;
    QLineEdit *telefono;
    QHBoxLayout *horizontalLayout_12;
    QLabel *label_12;
    QLineEdit *web;
    QHBoxLayout *horizontalLayout_14;
    QVBoxLayout *verticalLayout;
    QLabel *label_11;
    QSpacerItem *verticalSpacer;
    QTextEdit *inter;
    QVBoxLayout *verticalLayout_4;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_4;
    QLineEdit *ind;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_6;
    QLineEdit *loc;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_5;
    QLineEdit *spec;
    QHBoxLayout *horizontalLayout_7;
    QLabel *label_7;
    QLineEdit *passw;
    QHBoxLayout *horizontalLayout_9;
    QLabel *label_9;
    QLineEdit *cpassw;
    QHBoxLayout *horizontalLayout_11;
    QLabel *label_13;
    QComboBox *sex;
    QHBoxLayout *horizontalLayout_13;
    QLabel *label_14;
    QDateEdit *nascita;
    QHBoxLayout *horizontalLayout_15;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_15;
    QSpacerItem *verticalSpacer_2;
    QTextEdit *obiet;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout_16;
    QPushButton *cancel;
    QSpacerItem *horizontalSpacer;
    QPushButton *ok;

    void setupUi(QWidget *newAccountWindow)
    {
        if (newAccountWindow->objectName().isEmpty())
            newAccountWindow->setObjectName(QString::fromUtf8("newAccountWindow"));
        newAccountWindow->resize(708, 421);
        layoutWidget = new QWidget(newAccountWindow);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 10, 684, 364));
        horizontalLayout_17 = new QHBoxLayout(layoutWidget);
        horizontalLayout_17->setObjectName(QString::fromUtf8("horizontalLayout_17"));
        horizontalLayout_17->setContentsMargins(0, 0, 0, 0);
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        nome = new QLineEdit(layoutWidget);
        nome->setObjectName(QString::fromUtf8("nome"));

        horizontalLayout->addWidget(nome);


        verticalLayout_3->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_2->addWidget(label_2);

        cogn = new QLineEdit(layoutWidget);
        cogn->setObjectName(QString::fromUtf8("cogn"));

        horizontalLayout_2->addWidget(cogn);


        verticalLayout_3->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_3->addWidget(label_3);

        user = new QLineEdit(layoutWidget);
        user->setObjectName(QString::fromUtf8("user"));

        horizontalLayout_3->addWidget(user);


        verticalLayout_3->addLayout(horizontalLayout_3);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        label_8 = new QLabel(layoutWidget);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        horizontalLayout_8->addWidget(label_8);

        email = new QLineEdit(layoutWidget);
        email->setObjectName(QString::fromUtf8("email"));

        horizontalLayout_8->addWidget(email);


        verticalLayout_3->addLayout(horizontalLayout_8);

        horizontalLayout_18 = new QHBoxLayout();
        horizontalLayout_18->setObjectName(QString::fromUtf8("horizontalLayout_18"));
        label_17 = new QLabel(layoutWidget);
        label_17->setObjectName(QString::fromUtf8("label_17"));

        horizontalLayout_18->addWidget(label_17);

        acc = new QComboBox(layoutWidget);
        acc->setObjectName(QString::fromUtf8("acc"));

        horizontalLayout_18->addWidget(acc);


        verticalLayout_3->addLayout(horizontalLayout_18);

        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        label_10 = new QLabel(layoutWidget);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        horizontalLayout_10->addWidget(label_10);

        telefono = new QLineEdit(layoutWidget);
        telefono->setObjectName(QString::fromUtf8("telefono"));

        horizontalLayout_10->addWidget(telefono);


        verticalLayout_3->addLayout(horizontalLayout_10);

        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setObjectName(QString::fromUtf8("horizontalLayout_12"));
        label_12 = new QLabel(layoutWidget);
        label_12->setObjectName(QString::fromUtf8("label_12"));

        horizontalLayout_12->addWidget(label_12);

        web = new QLineEdit(layoutWidget);
        web->setObjectName(QString::fromUtf8("web"));

        horizontalLayout_12->addWidget(web);


        verticalLayout_3->addLayout(horizontalLayout_12);

        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setObjectName(QString::fromUtf8("horizontalLayout_14"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label_11 = new QLabel(layoutWidget);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        verticalLayout->addWidget(label_11);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);


        horizontalLayout_14->addLayout(verticalLayout);

        inter = new QTextEdit(layoutWidget);
        inter->setObjectName(QString::fromUtf8("inter"));

        horizontalLayout_14->addWidget(inter);


        verticalLayout_3->addLayout(horizontalLayout_14);


        horizontalLayout_17->addLayout(verticalLayout_3);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_4->addWidget(label_4);

        ind = new QLineEdit(layoutWidget);
        ind->setObjectName(QString::fromUtf8("ind"));

        horizontalLayout_4->addWidget(ind);


        verticalLayout_4->addLayout(horizontalLayout_4);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        label_6 = new QLabel(layoutWidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout_6->addWidget(label_6);

        loc = new QLineEdit(layoutWidget);
        loc->setObjectName(QString::fromUtf8("loc"));

        horizontalLayout_6->addWidget(loc);


        verticalLayout_4->addLayout(horizontalLayout_6);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        label_5 = new QLabel(layoutWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        horizontalLayout_5->addWidget(label_5);

        spec = new QLineEdit(layoutWidget);
        spec->setObjectName(QString::fromUtf8("spec"));

        horizontalLayout_5->addWidget(spec);


        verticalLayout_4->addLayout(horizontalLayout_5);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        label_7 = new QLabel(layoutWidget);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        horizontalLayout_7->addWidget(label_7);

        passw = new QLineEdit(layoutWidget);
        passw->setObjectName(QString::fromUtf8("passw"));
        passw->setInputMethodHints(Qt::ImhHiddenText|Qt::ImhNoAutoUppercase|Qt::ImhNoPredictiveText);
        passw->setEchoMode(QLineEdit::Password);

        horizontalLayout_7->addWidget(passw);


        verticalLayout_4->addLayout(horizontalLayout_7);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        label_9 = new QLabel(layoutWidget);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        horizontalLayout_9->addWidget(label_9);

        cpassw = new QLineEdit(layoutWidget);
        cpassw->setObjectName(QString::fromUtf8("cpassw"));
        cpassw->setEchoMode(QLineEdit::Password);

        horizontalLayout_9->addWidget(cpassw);


        verticalLayout_4->addLayout(horizontalLayout_9);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setObjectName(QString::fromUtf8("horizontalLayout_11"));
        label_13 = new QLabel(layoutWidget);
        label_13->setObjectName(QString::fromUtf8("label_13"));

        horizontalLayout_11->addWidget(label_13);

        sex = new QComboBox(layoutWidget);
        sex->setObjectName(QString::fromUtf8("sex"));

        horizontalLayout_11->addWidget(sex);


        verticalLayout_4->addLayout(horizontalLayout_11);

        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setObjectName(QString::fromUtf8("horizontalLayout_13"));
        label_14 = new QLabel(layoutWidget);
        label_14->setObjectName(QString::fromUtf8("label_14"));

        horizontalLayout_13->addWidget(label_14);

        nascita = new QDateEdit(layoutWidget);
        nascita->setObjectName(QString::fromUtf8("nascita"));

        horizontalLayout_13->addWidget(nascita);


        verticalLayout_4->addLayout(horizontalLayout_13);

        horizontalLayout_15 = new QHBoxLayout();
        horizontalLayout_15->setObjectName(QString::fromUtf8("horizontalLayout_15"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        label_15 = new QLabel(layoutWidget);
        label_15->setObjectName(QString::fromUtf8("label_15"));

        verticalLayout_2->addWidget(label_15);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer_2);


        horizontalLayout_15->addLayout(verticalLayout_2);

        obiet = new QTextEdit(layoutWidget);
        obiet->setObjectName(QString::fromUtf8("obiet"));

        horizontalLayout_15->addWidget(obiet);


        verticalLayout_4->addLayout(horizontalLayout_15);


        horizontalLayout_17->addLayout(verticalLayout_4);

        layoutWidget1 = new QWidget(newAccountWindow);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(230, 380, 250, 29));
        horizontalLayout_16 = new QHBoxLayout(layoutWidget1);
        horizontalLayout_16->setObjectName(QString::fromUtf8("horizontalLayout_16"));
        horizontalLayout_16->setContentsMargins(0, 0, 0, 0);
        cancel = new QPushButton(layoutWidget1);
        cancel->setObjectName(QString::fromUtf8("cancel"));

        horizontalLayout_16->addWidget(cancel);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_16->addItem(horizontalSpacer);

        ok = new QPushButton(layoutWidget1);
        ok->setObjectName(QString::fromUtf8("ok"));

        horizontalLayout_16->addWidget(ok);


        retranslateUi(newAccountWindow);

        QMetaObject::connectSlotsByName(newAccountWindow);
    } // setupUi

    void retranslateUi(QWidget *newAccountWindow)
    {
        newAccountWindow->setWindowTitle(QApplication::translate("newAccountWindow", "Form", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("newAccountWindow", "* Nome         ", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("newAccountWindow", "* Cognome ", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("newAccountWindow", "* Username", 0, QApplication::UnicodeUTF8));
        label_8->setText(QApplication::translate("newAccountWindow", "* Email    ", 0, QApplication::UnicodeUTF8));
        label_17->setText(QApplication::translate("newAccountWindow", "Tipo Account", 0, QApplication::UnicodeUTF8));
        label_10->setText(QApplication::translate("newAccountWindow", "Telefono", 0, QApplication::UnicodeUTF8));
        label_12->setText(QApplication::translate("newAccountWindow", "Web         ", 0, QApplication::UnicodeUTF8));
        label_11->setText(QApplication::translate("newAccountWindow", " Interessi", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("newAccountWindow", "* Indirizzo", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("newAccountWindow", "* Localita'", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("newAccountWindow", "* Specializzazioni         ", 0, QApplication::UnicodeUTF8));
        label_7->setText(QApplication::translate("newAccountWindow", "* Password                       ", 0, QApplication::UnicodeUTF8));
        label_9->setText(QApplication::translate("newAccountWindow", "* Conferma Password", 0, QApplication::UnicodeUTF8));
        label_13->setText(QApplication::translate("newAccountWindow", "* Sesso", 0, QApplication::UnicodeUTF8));
        label_14->setText(QApplication::translate("newAccountWindow", "* Nascita", 0, QApplication::UnicodeUTF8));
        label_15->setText(QApplication::translate("newAccountWindow", "* Obiettivi", 0, QApplication::UnicodeUTF8));
        cancel->setText(QApplication::translate("newAccountWindow", "Chiudi", 0, QApplication::UnicodeUTF8));
        ok->setText(QApplication::translate("newAccountWindow", "Ok", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class newAccountWindow: public Ui_newAccountWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEWACCOUNTWINDOW_H
