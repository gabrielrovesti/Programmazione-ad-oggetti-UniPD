#ifndef DISCUSSWIDGET_H
#define DISCUSSWIDGET_H

#include <QWidget>
#include <QPushButton>
#include <QPlainTextEdit>
#include <QLabel>
#include <QLayout>
#include "discussione.h"
#include "account.h"
#include "gruppo.h"


/*Widget che rappresenta una discussione. Come primo parametro viene passato al costruttore un puntatore a Gruppo,
 *a Discussione e ad Account. Sono tutti necessari per il corretto funzionamento della classe (per creare il post
 *serve il gruppo a cui appartiene, l'indirizzo della discussione e naturalmente il mittente). Si vuole dare la possibilità
 *a chi è iscritto di scrivere messaggi, e all'amministratore di cancellare la discussione. E' previsto un pulsante di elimina
 *che se cliccato emette un apposito segnale indicando qual'è la discussione interessata e il widget che la ospita.
 *Tutti gli elementi contenuti in questa classe vengono distrutti con essa automaticamente.
*/

class discussWidget:public QWidget{
    Q_OBJECT
public:
    discussWidget(Gruppo* g,Discussione* d,Account* acc,QWidget* parent=0);
signals:
    void deleteClicked(Discussione*,discussWidget*);
public slots:
    void disablebuttons();
private slots:
    void addMex();
    void deldisc();
private:
    Gruppo* gruppo;
    Discussione* disc;
    Account* account;
    QLabel *discNumber;
    QVBoxLayout *vlay;
    QHBoxLayout *lineedit;
    QPlainTextEdit *edit;
    QPushButton *cancella,*insert;
    void buildIntestaz();
    void buildMex();
    void buildLineedit();
};

#endif // DISCUSSWIDGET_H
