/********************************************************************************
** Form generated from reading UI file 'modazinfowindow.ui'
**
** Created: Sun Sep 18 16:34:32 2011
**      by: Qt User Interface Compiler version 4.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MODAZINFOWINDOW_H
#define UI_MODAZINFOWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QFormLayout>
#include <QtGui/QGridLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPlainTextEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_modAzinfowindow
{
public:
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_2;
    QGridLayout *gridLayout;
    QFormLayout *formLayout;
    QLabel *label;
    QLineEdit *loc;
    QFormLayout *formLayout_4;
    QLabel *label_4;
    QLineEdit *ind;
    QFormLayout *formLayout_5;
    QLabel *label_5;
    QLineEdit *email;
    QFormLayout *formLayout_3;
    QLabel *label_3;
    QLineEdit *web;
    QFormLayout *formLayout_6;
    QLabel *label_6;
    QLineEdit *tel;
    QFormLayout *formLayout_2;
    QLabel *label_2;
    QComboBox *dim;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout;
    QLabel *label_7;
    QSpacerItem *verticalSpacer;
    QPlainTextEdit *desc;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer;
    QPushButton *chiudi;
    QPushButton *ok;
    QSpacerItem *horizontalSpacer_2;

    void setupUi(QWidget *modAzinfowindow)
    {
        if (modAzinfowindow->objectName().isEmpty())
            modAzinfowindow->setObjectName(QString::fromUtf8("modAzinfowindow"));
        modAzinfowindow->resize(473, 282);
        layoutWidget = new QWidget(modAzinfowindow);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 10, 452, 265));
        verticalLayout_2 = new QVBoxLayout(layoutWidget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        formLayout = new QFormLayout();
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label);

        loc = new QLineEdit(layoutWidget);
        loc->setObjectName(QString::fromUtf8("loc"));

        formLayout->setWidget(0, QFormLayout::FieldRole, loc);


        gridLayout->addLayout(formLayout, 0, 0, 1, 1);

        formLayout_4 = new QFormLayout();
        formLayout_4->setObjectName(QString::fromUtf8("formLayout_4"));
        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        formLayout_4->setWidget(0, QFormLayout::LabelRole, label_4);

        ind = new QLineEdit(layoutWidget);
        ind->setObjectName(QString::fromUtf8("ind"));

        formLayout_4->setWidget(0, QFormLayout::FieldRole, ind);


        gridLayout->addLayout(formLayout_4, 0, 1, 1, 1);

        formLayout_5 = new QFormLayout();
        formLayout_5->setObjectName(QString::fromUtf8("formLayout_5"));
        formLayout_5->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
        label_5 = new QLabel(layoutWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        formLayout_5->setWidget(0, QFormLayout::LabelRole, label_5);

        email = new QLineEdit(layoutWidget);
        email->setObjectName(QString::fromUtf8("email"));

        formLayout_5->setWidget(0, QFormLayout::FieldRole, email);


        gridLayout->addLayout(formLayout_5, 1, 1, 1, 1);

        formLayout_3 = new QFormLayout();
        formLayout_3->setObjectName(QString::fromUtf8("formLayout_3"));
        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        formLayout_3->setWidget(0, QFormLayout::LabelRole, label_3);

        web = new QLineEdit(layoutWidget);
        web->setObjectName(QString::fromUtf8("web"));

        formLayout_3->setWidget(0, QFormLayout::FieldRole, web);


        gridLayout->addLayout(formLayout_3, 2, 0, 1, 1);

        formLayout_6 = new QFormLayout();
        formLayout_6->setObjectName(QString::fromUtf8("formLayout_6"));
        label_6 = new QLabel(layoutWidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        formLayout_6->setWidget(0, QFormLayout::LabelRole, label_6);

        tel = new QLineEdit(layoutWidget);
        tel->setObjectName(QString::fromUtf8("tel"));

        formLayout_6->setWidget(0, QFormLayout::FieldRole, tel);


        gridLayout->addLayout(formLayout_6, 2, 1, 1, 1);

        formLayout_2 = new QFormLayout();
        formLayout_2->setObjectName(QString::fromUtf8("formLayout_2"));
        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        formLayout_2->setWidget(0, QFormLayout::LabelRole, label_2);

        dim = new QComboBox(layoutWidget);
        dim->setObjectName(QString::fromUtf8("dim"));

        formLayout_2->setWidget(0, QFormLayout::FieldRole, dim);


        gridLayout->addLayout(formLayout_2, 1, 0, 1, 1);


        verticalLayout_2->addLayout(gridLayout);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label_7 = new QLabel(layoutWidget);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        verticalLayout->addWidget(label_7);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);


        horizontalLayout->addLayout(verticalLayout);

        desc = new QPlainTextEdit(layoutWidget);
        desc->setObjectName(QString::fromUtf8("desc"));

        horizontalLayout->addWidget(desc);


        verticalLayout_2->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        chiudi = new QPushButton(layoutWidget);
        chiudi->setObjectName(QString::fromUtf8("chiudi"));

        horizontalLayout_2->addWidget(chiudi);

        ok = new QPushButton(layoutWidget);
        ok->setObjectName(QString::fromUtf8("ok"));

        horizontalLayout_2->addWidget(ok);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);


        verticalLayout_2->addLayout(horizontalLayout_2);


        retranslateUi(modAzinfowindow);

        QMetaObject::connectSlotsByName(modAzinfowindow);
    } // setupUi

    void retranslateUi(QWidget *modAzinfowindow)
    {
        modAzinfowindow->setWindowTitle(QApplication::translate("modAzinfowindow", "Form", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("modAzinfowindow", "Localita", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("modAzinfowindow", "Indirizzo", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("modAzinfowindow", "Email", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("modAzinfowindow", "Web", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("modAzinfowindow", "Telefono", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("modAzinfowindow", "Dimensione", 0, QApplication::UnicodeUTF8));
        label_7->setText(QApplication::translate("modAzinfowindow", "Descrizione", 0, QApplication::UnicodeUTF8));
        chiudi->setText(QApplication::translate("modAzinfowindow", "Chiudi", 0, QApplication::UnicodeUTF8));
        ok->setText(QApplication::translate("modAzinfowindow", "Ok", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class modAzinfowindow: public Ui_modAzinfowindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MODAZINFOWINDOW_H
