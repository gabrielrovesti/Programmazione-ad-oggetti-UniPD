#ifndef NEWAZWINDOW_H
#define NEWAZWINDOW_H

#include <QWidget>
namespace Ui {
    class newAzWindow;
}

/*Finestra per la creazione di una nuova azienda. L'utente inserisce i dati e questa li trasmette
 *per mezzo di un segnale. Il metodo close() è stato ridefinito in modo che tutti i campi vengano
 *svuotati dal loro precedente contenuto.
 *Gli oggetti vengono distrutti automaticamente alla distruzione della finestra.
 */
class newAzWindow : public QWidget{
    Q_OBJECT
public:
    explicit newAzWindow(QWidget *parent = 0);
    ~newAzWindow();
signals:
    void createAz(QString,QString,QString,QString,QString,
                   QString,QString,QString,QString,QString);
private slots:
    void newAzienda();

public slots:
    bool close();
private:
    void clearFields();
    Ui::newAzWindow *ui;
};

#endif // NEWAZWINDOW_H
