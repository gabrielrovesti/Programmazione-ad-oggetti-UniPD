#ifndef NEWOFFWINDOW_H
#define NEWOFFWINDOW_H

#include <QWidget>
#include "account.h"
#include "offerta.h"
namespace Ui {
    class newOffWindow;
}

/*Finestra per la creazione di una nuova offerta. L'utente inserisce i dati e questa li trasmette
 *per mezzo di un segnale. Il metodo close() è stato ridefinito in modo che tutti i campi vengano
 *svuotati dal loro precedente contenuto.
 *Gli oggetti vengono distrutti automaticamente alla distruzione della finestra.
 *In questa classe troviamo un vector di Aziende che serve come supporto per popolare la QComboBox
 *di selezione.
 */

class newOffWindow : public QWidget
{
    Q_OBJECT
public:
    explicit newOffWindow(Account* acc,QWidget *parent = 0);
    ~newOffWindow();
signals:
    void createOff(QString,QString,QString,QString,QString,
                   QString,QString,Azienda*,QString);
private slots:
    void newOfferta();

public slots:
    bool close();
private:
    void clearFields();
    vector<Azienda*> voff;
    Ui::newOffWindow *ui;
};

#endif // NEWOFFWINDOW_H
