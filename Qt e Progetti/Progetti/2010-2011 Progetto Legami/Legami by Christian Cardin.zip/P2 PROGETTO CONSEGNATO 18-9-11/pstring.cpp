#include "pstring.h"
#include <ctype.h>
#include <sstream>
using std::stringstream;

pstring::pstring(string s):string(s){}
pstring::pstring(const char* s):string(s){}
pstring::pstring(int number){
    stringstream buff;
    buff<<number;
    *this=buff.str();
}

pstring pstring::operator=(const int& number){
    stringstream buff;
    buff<<number;
    *this=buff.str();
    return *this;
}

pstring pstring::operator+=(const int& number){
    stringstream buff;
    buff<<number;
    *this+=buff.str();
    return *this;
}

pstring pstring::operator=(const string& s){
    return string::operator=(s);
}

pstring pstring::operator+=(const string& s){
    return string::operator+=(s);
}

pstring pstring::operator=(const char* s){
    return string::operator=(s);
}

pstring pstring::operator+=(const char* s){
    return string::operator+=(s);
}

bool pstring::isEmpty() const{
    return empty();
}

pstring pstring::trimmed() const{
    string totrim=*this;
    while(totrim.size()!=0 && totrim[0]==' ') //rimuove spazi all'inizio
        totrim.erase(0,1);

    if(totrim.size()!=0)
        while(totrim.size()!=0 && totrim[totrim.size()-1]==' ')   //rimuove spazi alle fine
            totrim.erase(totrim.size()-1);
    return totrim;
}

pstring pstring::toLower() const{
    string lower=*this;
    for(unsigned int i=0;i<lower.size();i++)
        lower[i]=std::tolower(lower[i]);
    return lower;
}

bool pstring::contains(pstring s, bool caseSensitive) const{
    size_type pos;
    if(caseSensitive)
        pos=(*this).find(s);
    else{
        string base=toLower();
        string tofind=s.toLower();
        pos=base.find(tofind);
    }
    if(pos==npos)
        return false;
    return true;
}
