#include "dataora.h"

dataora::dataora(){
    //inizializza il timestamp con quello corrente
    time(&timestamp);
    //controla se è in vigore l'ora legale
    tm *legale=gmtime(&timestamp);
    ctime(&timestamp);
    if(legale->tm_isdst)
        timestamp+=3600;
    //genera la struttura contenente le informazioni sul timestamp
    formattedTime = *gmtime (&timestamp);
}

dataora::dataora(time_t t):timestamp(t){
    formattedTime = *gmtime (&timestamp);
}

int dataora::secondi() const{return formattedTime.tm_sec;}
int dataora::minuti() const{return formattedTime.tm_min;}
int dataora::ore() const{return formattedTime.tm_hour+1;} //+1 perchè siamo in Italia!
int dataora::giorno() const{return formattedTime.tm_mday;}
int dataora::mese() const{return 1+formattedTime.tm_mon;} //+1 perchè tm_mon rappresenta i mesi da 0 a 11
int dataora::anno() const{return 1900+formattedTime.tm_year;} //tm_year: anni trascorsi dal 1900
int dataora::stamp() const{return timestamp;}


string dataora::getdata() const{
    stringstream buff;
    buff<<giorno()<<"/"<<mese()<<"/"<<anno();
    return buff.str();
}

string dataora::getora() const{
    stringstream buff;
    buff<<ore()<<":"<<minuti()<<":";
    if(secondi()<10) buff<<"0";
    buff<<secondi();
    return buff.str();
}

string dataora::getdataora() const{
    return getdata()+" "+getora();
}


bool dataora::operator<(const dataora& d)const{
    return timestamp<d.timestamp;
}
bool dataora::operator<=(const dataora& d)const{
    return timestamp<=d.timestamp;
}
bool dataora::operator>(const dataora& d)const{
    return timestamp>=d.timestamp;
}
bool dataora::operator==(const dataora& d)const{
    return timestamp==d.timestamp;
}
bool dataora::operator!=(const dataora& d)const{
    return timestamp!=d.timestamp;
}


