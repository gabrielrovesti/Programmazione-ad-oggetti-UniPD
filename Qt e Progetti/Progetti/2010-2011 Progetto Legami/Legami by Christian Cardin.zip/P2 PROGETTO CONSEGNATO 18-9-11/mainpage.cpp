#include "mainpage.h"
#include "ui_mainpage.h"
#include "errormex.h"
MainPage::MainPage(QWidget *parent):QMainWindow(parent),ui(new Ui::MainPage){
    ui->setupUi(this);
    try{
        gestore=new Legami();                //instanzia Legami
    }
    catch(ErrState e){
        ErrorMex* werr=new ErrorMex(e);              //DB error
        werr->show();
        connect(werr,SIGNAL(destroyed()),qApp,SLOT(quit()));
        return;
    }
    buildWidgets();
    setActions();
    setImage();  //quando costruisco l'interfaccia utente, l'immagine viene deallocata.
}

void MainPage::closeEvent(QCloseEvent *event){
    gestore->WriteOnDb();
    event->accept();
}

void MainPage::buildWidgets(){
    logform=new Loginform(gestore);
    newAccW=new newAccountWindow(gestore);
    upgrade=new UpgradeForm(gestore);
}

void MainPage::setImage(){
    QLabel *image=new QLabel();
    image->setPixmap(QPixmap("Immagini/legami2.png"));
    image->setAlignment(Qt::AlignRight);
    this->setCentralWidget(image);
}

void MainPage::setActions(){
    ui->actionLogout->setDisabled(true);
    connect(ui->actionChiudi,SIGNAL(triggered()),qApp,SLOT(quit()));    //CHIUDE Legami
    connect(ui->actionNuovo,SIGNAL(triggered()),newAccW,SLOT(show()));  //apre finestra registrazione
    connect(ui->actionLogin,SIGNAL(triggered()),logform,SLOT(show()));  //apre finestra login
    connect(ui->actionUpGrade,SIGNAL(triggered()),upgrade,SLOT(show())); //apre finestra upgrade
    connect(logform,SIGNAL(loginaccount(Account*)),this,SLOT(openAccountWindow(Account*))); //apre nuova Tab
    connect(ui->actionLogout,SIGNAL(triggered()),this,SLOT(closeAccountWindow()));
}

void MainPage::openAccountWindow(Account *acc){
    ui->actionLogin->setEnabled(false);
    ui->actionLogout->setEnabled(true);
    ui->actionNuovo->setEnabled(false);
    ui->actionUpGrade->setEnabled(false);
    interface=new UserInterface(acc),acc->getinfo()->getusername();
    this->setCentralWidget(interface);
    image=0;

}

void MainPage::closeAccountWindow(){
    interface->hide();
    delete interface;
    interface=0;
    ui->actionLogin->setEnabled(true);
    ui->actionLogout->setEnabled(false);
    ui->actionNuovo->setEnabled(true);
    ui->actionUpGrade->setEnabled(true);
    setImage();
}

MainPage::~MainPage(){
    delete ui;
    if(image)
        delete image;
    if(interface)
        delete interface;
    delete logform;
    delete upgrade;
    delete newAccW;
    delete gestore;
}
