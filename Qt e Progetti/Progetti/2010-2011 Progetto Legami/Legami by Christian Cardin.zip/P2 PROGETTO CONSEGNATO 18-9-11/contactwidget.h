#ifndef CONTACTWIDGET_H
#define CONTACTWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QPushButton>
#include <QPlainTextEdit>
#include "account.h"
 
#include "segnform.h"

/*Pulsante contatto: Derivato da QPushButton, contiene brevi informazioni riepilogative sul contatto che rappresenta.
 *Se cliccato, emette un segnale apposito specificando il contatto a cui il widget si riferisce.
 *presenta degli slots dai quali è possibile visualizzare o meno pulsanti per accedere alle funzionalità.
 *Questa classe viene usata in più ambiti del programma, per questo ha dei metodi che permettono una differente visualizzazione
 *della stessa a seconda delle esigenze, nascondendo di volta in volta gli elementi superflui.
 *Se abilitato, il pulsante di segnalazione apre una finestra, dalla quale è possibile scrivere una "lettera di referenze"
 *per il contatto. Essa viene cancellata dal distruttore ridefinito, mentre gli altri widgets vengono deallocati
 *automaticamente insieme al padre
 */

class contactWidget:public QPushButton{
    Q_OBJECT
public:
    contactWidget(Contatto contatto,Account* acc=0,QWidget* parent=0);
signals:
    void clicked(Contatto);
    void deleteClicked(Account*,contactWidget*);
public slots:
    void disablebuttons();

private slots:
    void del();
    void cliccato();
    void makesegnalazione(QString,QString);
private:
    Account* account;
    Contatto contatto;
    segnForm *segn;
    QPlainTextEdit *desc;
    QLabel *nome,*user,*spec,*loc,*tag;
    QPushButton *vedi,*cancella,*segnala;
    void buildLayers();
    void buildLabels();
    void buildButtons();
};

#endif // CONTACTWIDGET_H
