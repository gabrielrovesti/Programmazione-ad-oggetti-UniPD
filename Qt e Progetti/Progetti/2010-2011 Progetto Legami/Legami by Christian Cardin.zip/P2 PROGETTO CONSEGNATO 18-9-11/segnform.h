#ifndef SEGNFORM_H
#define SEGNFORM_H

#include <QWidget>

namespace Ui {
    class segnForm;
}

/*Finestra per la creazione di una nuova segnalazione. L'utente inserisce i dati e questa li trasmette.
 *tramite un segnale. Il metodo close() è stato ridefinito in modo che tutti i campi vengano
 *svuotati dal loro precedente contenuto.
 *Gli oggetti vengono distrutti automaticamente alla distruzione della finestra.
 */

class segnForm : public QWidget{
    Q_OBJECT

public:
    explicit segnForm(QString soggetto,QWidget *parent = 0);
    ~segnForm();
signals:
    void okpressed(QString,QString);
private slots:
    void enableok();
    void accept();
public slots:
    bool close();
private:
    void clearFields();
    Ui::segnForm *ui;
};

#endif // SEGNFORM_H
