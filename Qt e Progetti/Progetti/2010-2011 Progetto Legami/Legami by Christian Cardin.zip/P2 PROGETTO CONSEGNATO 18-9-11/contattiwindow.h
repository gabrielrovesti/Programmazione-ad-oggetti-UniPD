#ifndef CONTATTIWINDOW_H
#define CONTATTIWINDOW_H
#include <QWidget>
#include <QScrollArea>
#include <QVBoxLayout>
#include <QLineEdit>
#include "contactwidget.h"
 
#include "findcontatti.h"
#include "infowidget.h"

/*Implementa la ricerca dei contatti. Dal risultato della ricerca, carica dei contactWidgets che, se cliccati,
 *causano l'apertura di un infoWidget con le informazioni relative al contatto selezionato. Un pulsante
 *permette di aggiungere il contatto selezionato tra gli "amici". Il tutto è contenuto in ScrollArea
 *per permettere una visualizzazione più compatta in caso di liste molto lunghe.
 *In seguito all'azione di click, è possibile aggiungere il contatto selezionato impostando un tag nella relativa lineEdit.
 *Ogni volta che si visualizzano i dettagli di un contatto, viene creato un oggetto infoWidget. Questo viene
 *distrutto se si vuole vedere un altro contatto, e quindi ricreato. Alla fine viene distrutto nel distruttore insieme
 *alla finestra di ricerca e ai contactWidgets dell'ultima ricerca.
 */

class contattiWindow:public QWidget{
Q_OBJECT
public:    
    contattiWindow(Account* acc,QWidget *parent=0);
    ~contattiWindow();
signals:
    void contattoAggiunto(Contatto);
private slots:
    void loadContact(QString,QString,QString,QString,QString,bool,int);
    void loadInfo(Contatto);
    void addcontatto();
    void entercontatto();
private:
    Account* account;
    findContatti* findwind;
    QLabel *ltag;
    QLineEdit *tag;
    QScrollArea *searchArea,*infoArea;
    QPushButton *add,*hack;
    QVBoxLayout *vertical;
    infoWidget *info;


};

#endif // CONTATTIWINDOW_H
