#ifndef AZIENDA_H
#define	AZIENDA_H
#include "info.h"
#include "offerta.h"
#include "exp.h"
#include <vector>
#include "pstring.h"
using std::vector;
 

class Azienda{
private:
    AzInfo* quickinfo;
    User* amministratore;
    vector<Offerta*>* linked_offerte;
public:
    Azienda(AzInfo* _info,User* _resp);

    AzInfo* getinfo() const;
    User* getadmin() const;
    void setadmin(User*);
    void link(Offerta* _l);
    vector<Offerta*>* getlinked() const;

    virtual ~Azienda();
};

#endif	/* AZIENDA_H */

