#ifndef MAINPAGE_H
#define MAINPAGE_H
#include <QMainWindow>
#include "loginform.h"
#include "newaccountwindow.h"
#include "upgradeform.h"
#include "userinterface.h"
#include "legami.h"

namespace Ui {
    class MainPage;}

/* La mainwindow del programma. Qui viene instanziata la parte logica, tramite la costruzione di un oggetto Legami.
 * All'apertura compare un'immagine di sfondo.
 * La finestra è connessa con alcuni widget, tra i quali:
 *   Form di Iscrizione utente
 *   Form di login
 *   Form di upgrade
 *   Interfaccia utente.
 *
 * Una volta effettuato il login, viene allocata una interfaccia utente e caricata con l'account ritornato dalla
 * procedura. Dopo aver settato l'UserInterface come centralWidget, l'immagine viene deallocata. Per questo è necessario ricrearla
 * quando l'utente si slogga. Alla fine, i widget principali vengono deallocati nel distruttore. Gli altri widget figli
 * vengono deallocati automaticamente alla distruzione della classe.
 */

class MainPage : public QMainWindow{
    Q_OBJECT

public:
    explicit MainPage(QWidget *parent = 0);
    Legami* gestore;
    ~MainPage();
protected:
    void closeEvent(QCloseEvent *event);
private slots:
    void openAccountWindow(Account* acc);
    void closeAccountWindow();

private:
    QLabel *image;
    Loginform* logform;
    newAccountWindow* newAccW;
    UpgradeForm* upgrade;
    UserInterface *interface;

    void setActions();
    void buildWidgets();
    void setImage();

    Ui::MainPage *ui;
};

#endif // MAINPAGE_H
