#include "newgroupwindow.h"
#include "ui_newgroupwindow.h"

newGroupWindow::newGroupWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::newGroupWindow){
    ui->setupUi(this);
    connect(ui->ok,SIGNAL(clicked()),this,SLOT(newGroup()));
    connect(ui->chiudi,SIGNAL(clicked()),this,SLOT(close()));

}

void newGroupWindow::newGroup(){
    emit createGroup(ui->nome->text().trimmed(),ui->desc->toPlainText().trimmed(),ui->sett->text().trimmed(),ui->web->text().trimmed());
    close();
}

bool newGroupWindow::close(){
    clearFields();
    return QWidget::close();
}

void newGroupWindow::clearFields(){
    ui->nome->setText("");
    ui->sett->setText("");
    ui->desc->setPlainText("");
    ui->web->setText("");
}

newGroupWindow::~newGroupWindow(){
    delete ui;
}
