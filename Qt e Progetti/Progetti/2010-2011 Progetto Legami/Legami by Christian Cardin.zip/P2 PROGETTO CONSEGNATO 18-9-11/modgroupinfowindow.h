#ifndef MODGROUPINFOWINDOW_H
#define MODGROUPINFOWINDOW_H

#include <QWidget>
#include "gruppo.h"
#include "account.h"
namespace Ui {
    class modGroupinfowindow;
}

/*Finestra che consente di modificare i campi dati di un gruppo.
 *Emette un segnale una volta effettuate le modifiche.
 *Tutti i widget ivi contenuti vengono distrutti automaticamente alla chiusura
 */

class modGroupinfowindow : public QWidget{
    Q_OBJECT

public:
    explicit modGroupinfowindow(Gruppo* a,Account* acc,QWidget *parent = 0);
    ~modGroupinfowindow();
signals:
    void infoChanged();
private slots:
    void modify();
private:
    void loadLabels();
    Gruppo* gruppo;
    Account* account;
    Ui::modGroupinfowindow *ui;
};

#endif // MODGROUPINFOWINDOW_H
