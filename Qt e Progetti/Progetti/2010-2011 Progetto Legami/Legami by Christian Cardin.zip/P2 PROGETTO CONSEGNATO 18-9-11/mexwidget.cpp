#include "mexwidget.h"
#include <QBoxLayout>

mexWidget::mexWidget(Messaggio *e,QWidget *parent):QWidget(parent),mex(e){
    buildButtons();
    buildLabels();
    buildLayers();
}

void mexWidget::buildButtons(){
    cancella=new QPushButton("Cancella");      
    connect(cancella,SIGNAL(clicked()),this,SLOT(del()));
}

void mexWidget::buildLabels(){
    autore=new QLabel("<b>Mittente "+QString::fromStdString(mex->getautore()->getinfo()->getusername())+"</b>");
    oggetto=new QLabel("Oggetto: "+QString::fromStdString(mex->getogg()));
    ltesto=new QLabel("Testo:");
    testo=new QPlainTextEdit(QString::fromStdString(mex->gettesto()));
    testo->setReadOnly(true);
    testo->setTextInteractionFlags(0);
    data=new QLabel("Inviato il: "+QString::fromStdString(mex->getTimePost()));
    testo->setMaximumSize(550,100);
    testo->setSizePolicy(QSizePolicy::Preferred,QSizePolicy::Preferred);
}

void mexWidget::buildLayers(){
    //layout del testo
    QHBoxLayout *hltesto=new QHBoxLayout(); //label
    hltesto->addWidget(ltesto);
    hltesto->addStretch();
    QVBoxLayout *vtesto=new QVBoxLayout(); //generale
    vtesto->addLayout(hltesto);
    vtesto->addWidget(testo);

    //layout generale
    QVBoxLayout *v1=new QVBoxLayout();
    QVBoxLayout *v2=new QVBoxLayout();
    QHBoxLayout *h1=new QHBoxLayout();
    v1->addWidget(autore);
    v1->addWidget(data);
    v1->addWidget(oggetto);
    h1->addLayout(v1);
    h1->addStretch();
    h1->addWidget(cancella);
    v2->addLayout(h1);
    v2->addLayout(vtesto);
    setLayout(v2);
    v2->setSizeConstraint(QLayout::SetMinimumSize);
    setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);

}

void mexWidget::disablebuttons(){
    cancella->setVisible(false);
}

void mexWidget::del(){
    emit deleteClicked(mex,this);
}
