#include <QObject>
#include <map>
#include <algorithm>
#include <QTextStream>
#include "discussione.h"
#include "dbmanager.h"
#include "utils.h"
#include "exp.h"
#include "azienda.h"
#include "info.h"
#include "legami.h"
#include "offerta.h"

DBmanager::DBmanager(Legami* gest,const pstring &filename):gestore(gest),file(QString::fromStdString(filename)){
    treeAcc=new QTreeWidget();
    treeCon=new QTreeWidget();
    treeAzi=new QTreeWidget();
    treeExp=new QTreeWidget();
    treeSegn=new QTreeWidget();
    treeOff=new QTreeWidget();
    treeGro=new QTreeWidget();
    DBLocked=false;
    dirtBit=false;
}

void DBmanager::clearmemory(){
    treeAcc->clear();
    treeCon->clear();
    treeAzi->clear();
    treeExp->clear();
    treeSegn->clear();
    treeOff->clear();
    treeGro->clear();
}


QTreeWidgetItem* DBmanager::findInTree(QTreeWidget* tree,QString first,QString second,QString third){
    QTreeWidgetItemIterator it(tree);
    if(third!="")
        while (*it) {
            if ((*it)->text(0)  == first && (*it)->text(1)  == second && (*it)->text(2)  == third)
                return *it;
            ++it;
        }
    else if(second!="")
        while (*it) {
            if ((*it)->text(0)  == first && (*it)->text(1)  == second)
                return *it;
            ++it;
        }
    else
        while (*it) {
            if ((*it)->text(0)  == first)
                return *it;
            ++it;
        }
    return 0;
}

bool DBmanager::readfile() throw(ErrStateDb){
    if(!file.open(QFile::ReadOnly|QFile::Text)){
        file.open( QFile::WriteOnly|QFile::Text);
        QTextStream out(&file);
            out << "<legami>\n";
            out<<"<ACCOUNT username=\"admin\">\n";
                    out<<"<quickinfo>admin</quickinfo>\n";
                    out<<"<quickinfo>admin</quickinfo>\n";
                    out<<"<quickinfo>admin</quickinfo>\n";
                    out<<"<quickinfo>admin</quickinfo>\n";
                    out<<"<quickinfo>0</quickinfo>\n";
                    out<<"<quickinfo>------</quickinfo>\n";
                    out<<"<quickinfo>------</quickinfo>\n";
                    out<<"<quickinfo>admin@admin.it</quickinfo>\n";
                    out<<"<quickinfo>amministratore sistema</quickinfo>\n";
                    out<<"<quickinfo>amministrare il sistema</quickinfo>\n";
                    out<<"<quickinfo>0</quickinfo>\n";
                    out<<"<quickinfo>0</quickinfo>\n";
                    out<<"<quickinfo></quickinfo>\n";
                    out<<"<quickinfo></quickinfo>\n";
                    out<<"<quickinfo></quickinfo>\n";
            out<<"</ACCOUNT>";
            out<<"</legami>";
            file.close();
            file.open(QFile::ReadOnly|QFile::Text);
    }
    QString err="";
    int errline,errcol;
    QDomDocument doc;
    if(!doc.setContent(&file,false,&err,&errline,&errcol)){

        throw ErrStateDb(errline,errcol,err.toStdString());
        return false;
    }
    QDomElement root=doc.documentElement();
    if(root.tagName()!="legami"){
        throw ErrStateDb(-1,0,"");  //lancia messaggio di errore predefinito
        return false;
    }
    parseLegami(root);
    file.close();
    return true;
}
//*************SAVE***************
void DBmanager::saveAccount(UserInfo *info,tipoAcc tacc,bool del){
    if(DBLocked) return;       //controlla il lock, se ' settato non fa nulla
    DBLocked=true;             //setta il lock del database
    QTreeWidgetItem* item;
    item=findInTree(treeAcc,QString::fromStdString(info->getusername()));
    if(del){
        int index=treeAcc->indexOfTopLevelItem(item);
        treeAcc->takeTopLevelItem(index);
        delete item;
    }
    else{
        QString tipo="";
        if(tacc==BASIC)
            tipo="basic";
        else if(tacc==BUSINESS)
            tipo="business";
        else if(tacc==EXECUTIVE)
            tipo="executive";
        else if(tacc==ADMIN)
            tipo="admin";

        if(item!=0){
            item->setText(1,tipo+"##"+QString::fromStdString(info->tostring()));
        }
        else{
            item=new QTreeWidgetItem(treeAcc->invisibleRootItem());
            item->setText(0, QString::fromStdString(info->getusername()));
            item->setText(1, tipo+"##"+QString::fromStdString(info->tostring()));
        }
    }
    if(!dirtBit)
        dirtBit=true;
    DBLocked=false;
}

void DBmanager::saveContatto(User* prop){
    if(DBLocked) return;       //controlla il lock, se ' settato non fa nulla
    DBLocked=true;             //setta il lock del database

    QTreeWidgetItem* item;
    QString username=QString::fromStdString(prop->getinfo()->getusername());
    item=findInTree(treeCon,username);  //preleva il nodo dei contatti appartenente all'account
    //se la lista dei contatti e quella delle aziende sono vuote rimuove la voce dalla struttura dati
    if(prop->getaziende()->empty() && prop->getcontatti()->empty()){
        int index=treeCon->indexOfTopLevelItem(item);
        treeCon->takeTopLevelItem(index);
        delete item;
    }
    else{
        if(item==0){       //se l'account non aveva ancora una lista nel db, la crea
            item=new QTreeWidgetItem(treeCon->invisibleRootItem());
            item->setText(0, (username));
        }
        vector<Contatto>* clist=prop->getcontatti();
        vector<Azienda*>* alist=prop->getaziende();
        vector<Contatto>::const_iterator it=clist->begin();
        vector<Azienda*>::const_iterator ita=alist->begin();
        QString info="";
        while(it<clist->end()){        //itera tutti i contatti e salva le informazioni dei contatti in formato stringa
            if(!info.isEmpty())
                info+="|";
            info+=QString::fromStdString((*it)->getinfo()->getusername())+"##"+QString::fromStdString((*it).gettag());
            it++;
        }
        if(info!="")            //se i dati non sono vuoti, crea la voce nella struttura
            item->setText(1, (info));
        info.clear();
        while(ita<alist->end()){ //itera tutte le aziende e salva i nomi
            if(!info.isEmpty())
                info+="##";
            info+=QString::fromStdString((*ita)->getinfo()->getnome());
            ita++;
        }
        if(info!="")            //se i dati non sono vuoti, crea la voce nella struttura
            item->setText(2, (info));
    }
    if(!dirtBit)
        dirtBit=true;
    DBLocked=false;
}

void DBmanager::saveAzienda(AzInfo* info,pstring adm,bool del){
    if(DBLocked) return;       //controlla il lock, se ' settato non fa nulla
    DBLocked=true;             //setta il lock del database
    QString admin=QString::fromStdString(adm);
    QTreeWidgetItem* item;
    QString nome=QString::fromStdString(info->getnome());
    item=findInTree(treeAzi,nome);
    if(del){
        int index=treeAzi->indexOfTopLevelItem(item);
        treeAzi->takeTopLevelItem(index);
        delete item;
    }
    else{
        if(item!=0){
            item->setText(2, QString::fromStdString(info->tostring()));
        }
        else{
            if(admin=="") return;
            item=new QTreeWidgetItem(treeAzi->invisibleRootItem());
            item->setText(0, QString::fromStdString(info->getnome()));
            item->setText(1, (admin));
            item->setText(2, QString::fromStdString(info->tostring()));
        }
    }
    if(!dirtBit)
        dirtBit=true;
    DBLocked=false;
}

void DBmanager::saveExp(pstring user,vector<Exp*>* exp){
    if(DBLocked) return;       //controlla il lock, se ' settato non fa nulla
    DBLocked=true;             //setta il lock del database
    QString prop=QString::fromStdString(user);
    QTreeWidgetItem* item;
    item=findInTree(treeExp,prop);
    if(exp->empty()) //se la lista delle esperienze è vuota rimuove la voce dalla struttura dati
        delete item;
    else{
        if(item==0){
            item=new QTreeWidgetItem(treeExp->invisibleRootItem());
            item->setText(0, (prop));
        }
        vector<Exp*>::const_iterator it=exp->begin();
        QString info="";
        for(;it!=exp->end();it++){
            if(!info.isEmpty())
                info+="|";
            info+=QString::fromStdString((*it)->tostring());
        }
        item->setText(1, (info));
    }
    if(!dirtBit)
        dirtBit=true;
    DBLocked=false;
}

void DBmanager::saveSegn(pstring user,vector<Messaggio*>* mex){
    if(DBLocked) return;       //controlla il lock, se ' settato non fa nulla
    DBLocked=true;             //setta il lock del database
    QString prop=QString::fromStdString(user);
    QTreeWidgetItem* item;
    item=findInTree(treeSegn,prop);
    if(mex->empty()) //se la lista delle esperienze è vuota rimuove la voce dalla struttura dati
        delete item;
    else{
        if(item==0){
            item=new QTreeWidgetItem(treeSegn->invisibleRootItem());
            item->setText(0, (prop));
        }
        vector<Messaggio*>::const_iterator it=mex->begin();
        QString info="";
        for(;it!=mex->end();it++){
            if(!info.isEmpty())
                info+="|";
            info+=QString::fromStdString((*it)->tostring());
        }
        item->setText(1, (info));
    }
    if(!dirtBit)
        dirtBit=true;
    DBLocked=false;
}

void DBmanager::saveOff(Offerta* off,bool del){
    if(DBLocked) return;       //controlla il lock, se ' settato non fa nulla
    DBLocked=true;             //setta il lock del database
    QTreeWidgetItem* item;
    item=findInTree(treeOff,QString::number(off->getid()) );
    if(del){
        int index=treeOff->indexOfTopLevelItem(item);
        treeOff->takeTopLevelItem(index);
        delete item;
    }
    else{
        if(item==0){
            item=new QTreeWidgetItem(treeOff->invisibleRootItem());
            item->setText(0,QString::number(off->getid()));
        }
        item->setText(1, QString::fromStdString(off->tostring()));
        vector<User*>* utenti=off->getcandidati();
        vector<User*>::const_iterator it=utenti->begin();
        QString allut="";
        for(;it!=utenti->end();it++){
            if(!allut.isEmpty()) allut+="##";
            allut+=QString::fromStdString((*it)->getinfo()->getusername());
        }
        item->setText(2, (allut));
    }
    if(!dirtBit)
        dirtBit=true;
    DBLocked=false;
}

void DBmanager::saveGro(Gruppo* gru,bool del){
    if(DBLocked) return;       //controlla il lock, se ' settato non fa nulla
    DBLocked=true;             //setta il lock del database
    QTreeWidgetItem* item;
    item=findInTree(treeGro,QString::fromStdString(gru->getinfo()->getnome()));
    if(del){
        int index=treeGro->indexOfTopLevelItem(item);
        treeGro->takeTopLevelItem(index);
        delete item;
    }
    else{
        if(item==0){
            item=new QTreeWidgetItem(treeGro->invisibleRootItem());
            item->setText(0, QString::fromStdString(gru->getinfo()->getnome())); //salva nome gruppo
        }
        item->setText(1, QString::fromStdString(gru->getadmin()->getinfo()->getusername())); //salva username dell'adnmin
        item->setText(2, QString::fromStdString(gru->getinfo()->tostring()));  //salva le info
        vector<User*>* utenti=gru->getiscritti();
        vector<User*>::const_iterator it=utenti->begin();
        QString allut="";
        for(;it!=utenti->end();it++){
            if(!allut.isEmpty()) allut+="##";
            allut+=QString::fromStdString((*it)->getinfo()->getusername());
        }
        item->setText(3, (allut));   //salva gli iscritti

        vector<Discussione*>* disc=gru->getdiscussioni();
        vector<Discussione*>::const_iterator itd=disc->begin();
        QString alldisc="";
        for(;itd!=disc->end();itd++){
            if(!alldisc.isEmpty()) alldisc+="$";
            alldisc+=QString::fromStdString((*itd)->tostring());
        }
        item->setText(4, (alldisc));
    }
    if(!dirtBit)
        dirtBit=true;
    DBLocked=false;
}
//*************WRITE***************
void DBmanager::writexml(){
    if(!dirtBit) return;     //se non sono state applicate modifiche non fa nulla
    file.open(QFile::WriteOnly|QFile::Text);
    QXmlStreamWriter xwriter(&file);
    xwriter.setAutoFormatting(true);
    xwriter.writeStartDocument();
    xwriter.writeStartElement("legami");

    for(int i=0;i<treeAcc->topLevelItemCount();i++){
        QTreeWidgetItem* item=treeAcc->topLevelItem(i);
        writeAccount(&xwriter,item);
    }
    for(int i=0;i<treeAzi->topLevelItemCount();i++){
        QTreeWidgetItem* item=treeAzi->topLevelItem(i);
        writeAzienda(&xwriter,item);
    }
    for(int i=0;i<treeExp->topLevelItemCount();i++){
        QTreeWidgetItem* item=treeExp->topLevelItem(i);
        writeExp(&xwriter,item);
    }
    for(int i=0;i<treeSegn->topLevelItemCount();i++){
        QTreeWidgetItem* item=treeSegn->topLevelItem(i);
        writeSegn(&xwriter,item);
    }
    for(int i=0;i<treeOff->topLevelItemCount();i++){
        QTreeWidgetItem* item=treeOff->topLevelItem(i);
        writeOff(&xwriter,item);
    }
    for(int i=0;i<treeGro->topLevelItemCount();i++){
        QTreeWidgetItem* item=treeGro->topLevelItem(i);
        writeGro(&xwriter,item);
    }
    for(int i=0;i<treeCon->topLevelItemCount();i++){
        QTreeWidgetItem* item=treeCon->topLevelItem(i);
        writeContatto(&xwriter,item);
    }

    xwriter.writeEndDocument();
    dirtBit=false;
    file.close();
}

void DBmanager::writeAccount(QXmlStreamWriter *xwriter, QTreeWidgetItem *item){
    xwriter->writeStartElement("ACCOUNT");
    xwriter->writeAttribute("username",item->text(0));
    QString rawinf=item->text(1);

    QStringList infos=rawinf.split("##");
    foreach(QString i,infos)
        xwriter->writeTextElement("quickinfo",i);
    xwriter->writeEndElement();
}

void DBmanager::writeContatto(QXmlStreamWriter *xwriter, QTreeWidgetItem *item){
    xwriter->writeStartElement("COLLEGAMENTO");
    xwriter->writeAttribute("proprietario",item->text(0));
    QStringList infos;
    QString rawinf=item->text(1);    //Raccoglie le info sui contatti, le splitta e le scrive
    if(!rawinf.isEmpty()){           //ma solo se le informazioni non sono vuote
        infos=rawinf.split("|");
        foreach(QString i,infos){
            QStringList a=i.split("##");
            xwriter->writeStartElement("utente");
            xwriter->writeAttribute("tag",a[1]);
            xwriter->writeCharacters(a[0]);
            xwriter->writeEndElement();
        }
    }
    rawinf=item->text(2);   //raccoglie le aziende e le scrive (se ce ne sono)
    if(!rawinf.isEmpty()){
        infos=rawinf.split("##");
        foreach(QString i,infos)
            xwriter->writeTextElement("azienda",i); //stampa aziende
    }
    xwriter->writeEndElement();
}

void DBmanager::writeAzienda(QXmlStreamWriter *xwriter, QTreeWidgetItem *item){
    xwriter->writeStartElement("AZIENDA");
    xwriter->writeAttribute("nome",item->text(0));
    xwriter->writeAttribute("admin",item->text(1));
    QString rawinf=item->text(2);
    QStringList infos=rawinf.split("##");
    foreach(QString i,infos)
        xwriter->writeTextElement("azinfo",i);
    xwriter->writeEndElement();
}

void DBmanager::writeExp(QXmlStreamWriter *xwriter, QTreeWidgetItem *item){
    xwriter->writeStartElement("EXP");
    xwriter->writeAttribute("utente",item->text(0));
    QString rawinf=item->text(1);
    QStringList infos=rawinf.split("|");
    foreach(QString i,infos){
        QStringList a=i.split("##");
        xwriter->writeEmptyElement("azienda");
        xwriter->writeAttribute("inizio",a[0]);
        xwriter->writeAttribute("fine",a[1]);
        xwriter->writeAttribute("descrizione",a[2]);
        xwriter->writeAttribute("nomeente",a[3]);
        xwriter->writeAttribute("titolo",a[4]);
        xwriter->writeAttribute("ruolo",a[5]);
    }

    xwriter->writeEndElement();
}

void DBmanager::writeSegn(QXmlStreamWriter *xwriter, QTreeWidgetItem *item){
    xwriter->writeStartElement("SEGN");
    xwriter->writeAttribute("utente",item->text(0));
    QString rawinf=item->text(1);
    QStringList infos=rawinf.split("|");
    foreach(QString i,infos){
        QStringList a=i.split("##");
        xwriter->writeEmptyElement("messaggio");
        xwriter->writeAttribute("autore",a[0]);
        xwriter->writeAttribute("oggetto",a[1]);
        xwriter->writeAttribute("testo",a[2]);
        xwriter->writeAttribute("data",a[3]);
    }
    xwriter->writeEndElement();
}

void DBmanager::writeOff(QXmlStreamWriter *xwriter, QTreeWidgetItem *item){
    xwriter->writeStartElement("OFFERTA");
    xwriter->writeAttribute("id",item->text(0));
    QString rawinf=item->text(1);
    QStringList info=rawinf.split("##");
    xwriter->writeEmptyElement("info");
    xwriter->writeAttribute("proprietario",info[0]);
    xwriter->writeAttribute("azienda",info[1]);
    xwriter->writeAttribute("tit",info[2]);
    xwriter->writeAttribute("reg",info[3]);
    xwriter->writeAttribute("ind",info[4]);
    xwriter->writeAttribute("sett",info[5]);
    xwriter->writeAttribute("desc",info[6]);
    xwriter->writeAttribute("gio",info[7]);
    xwriter->writeAttribute("esp",info[8]);
    xwriter->writeAttribute("creaz",info[9]);
    xwriter->writeAttribute("spec",info[10]);
    rawinf=item->text(2);
    if(!rawinf.isEmpty()){
        info=rawinf.split("##");
        foreach(QString i,info)
            xwriter->writeTextElement("candidato",i);
    }
    xwriter->writeEndElement();
}

void DBmanager::writeGro(QXmlStreamWriter *xwriter, QTreeWidgetItem *item){
    xwriter->writeStartElement("GRUPPO");
    xwriter->writeAttribute("nome",item->text(0));
    xwriter->writeAttribute("admin",item->text(1));
    QStringList list=item->text(2).split("##");
    foreach(QString i,list)
        xwriter->writeTextElement("groupinfo",i);
    list=item->text(3).split("##");
    foreach(QString i,list)
        xwriter->writeTextElement("iscritto",i);
    QStringList discussioni=item->text(4).split("$");    //separa le diverse discussioni

    if(discussioni.size()>1 || !discussioni[0].isEmpty())//se ci sono delle discussioni esegue il foreach
        foreach(QString whole,discussioni){
            QStringList separa=whole.split("@");         //separa informazioni delle discussioni dai messaggi
            QStringList discinfo=separa[0].split("##");   //info delle discussioni
            QStringList mexinfo=separa[1].split("|");    //separa i messaggi
            xwriter->writeStartElement("DISCUSSIONE");   //stampa info discussione
            xwriter->writeAttribute("creatore",discinfo[0]);
            xwriter->writeAttribute("titolo",discinfo[1]);
            xwriter->writeAttribute("data",discinfo[2]);

            if(mexinfo.size()>1 || !mexinfo[0].isEmpty())     //se ci sono messaggi esegue il foreach
                foreach(QString particle,mexinfo){            //per ogni discussione, crea le righe dei messaggi

                    QStringList last=particle.split("##");     //finalmente le informazioni sul messaggio
                    xwriter->writeStartElement("messaggio");
                    xwriter->writeAttribute("autore",last[0]);
                    xwriter->writeAttribute("oggetto",last[1]);
                    xwriter->writeAttribute("data",last[3]);
                    xwriter->writeCharacters(last[2]);
                    xwriter->writeEndElement();              //chiude messaggio
                }
            xwriter->writeEndElement();                  //chiude discussione
        }
    xwriter->writeEndElement();                      //chiude gruppo
}
//**************PARSE**************

void DBmanager::parseLegami(const QDomElement &element){
    QDomNode child=element.firstChild();

    while(!child.isNull()){
        if(child.toElement().tagName()=="ACCOUNT")
            parseAccount(child.toElement(),treeAcc->invisibleRootItem());
        else if(child.toElement().tagName()=="AZIENDA")
            parseAzienda(child.toElement(),treeAzi->invisibleRootItem());
        else if(child.toElement().tagName()=="EXP")
           parseExp(child.toElement(),treeExp->invisibleRootItem());
        else if(child.toElement().tagName()=="SEGN")
           parseSegn(child.toElement(),treeSegn->invisibleRootItem());
        else if(child.toElement().tagName()=="OFFERTA")
           parseOff(child.toElement(),treeOff->invisibleRootItem());
        else if(child.toElement().tagName()=="GRUPPO")
           parseGro(child.toElement(),treeGro->invisibleRootItem());
        else if(child.toElement().tagName()=="COLLEGAMENTO")
           parseContatto(child.toElement(),treeCon->invisibleRootItem());

        child=child.nextSibling();
    }

}

void DBmanager::parseAccount(const QDomElement &element, QTreeWidgetItem *parent){
    QTreeWidgetItem* item=new QTreeWidgetItem(parent);
    QString username=element.attribute("username");
    item->setText(0,username);
    QDomNode child=element.firstChild();
    QString allInfo="";
    while(!child.isNull()){
        if(child.toElement().tagName()=="quickinfo"){
            QString info=child.toElement().text();
            if(!allInfo.isEmpty()) allInfo += "##";
            allInfo += info;
        }
        child=child.nextSibling();
    }
    item->setText(1,allInfo);
    QStringList quickinfo=allInfo.split("##");
    QString tipoAcc=quickinfo.takeAt(0);
    UserInfo* uinfo=new UserInfo(username.toStdString() ,quickinfo.takeFirst().toStdString(),quickinfo.takeFirst().toStdString(),
                              quickinfo.takeFirst().toStdString(),quickinfo.takeFirst().toInt(),quickinfo.takeFirst().toStdString(),
                              quickinfo.takeFirst().toStdString(),quickinfo.takeFirst().toStdString() ,
                              quickinfo.takeFirst().toStdString(),quickinfo.takeFirst().toStdString(),quickinfo.takeFirst().toInt(),
                              quickinfo.takeFirst().toInt(),quickinfo.takeFirst().toStdString(),quickinfo.takeFirst().toStdString(),
                              quickinfo.takeFirst().toStdString());

    Account* a=0;
    if(tipoAcc=="basic")
        a=new Account(uinfo,gestore);
    else if(tipoAcc=="business")
        a=new Business(uinfo,gestore);
    else if(tipoAcc=="executive")
        a=new Executive(uinfo,gestore);
    else if(tipoAcc=="admin")
        a=new Admin(uinfo,gestore);
    (*(gestore->usermap))[username.toStdString()]=a;
}

void DBmanager::parseAzienda(const QDomElement &element, QTreeWidgetItem *parent){
    QTreeWidgetItem* item=new QTreeWidgetItem(parent);
    QString admin=element.attribute("admin"),allInfo="";
    item->setText(0,element.attribute("nome"));
    item->setText(1,admin);

    QDomNode child=element.firstChild();
    while(!child.isNull()){

        if(child.toElement().tagName()=="azinfo"){
            QString info=child.toElement().text();
            if(!allInfo.isEmpty()) allInfo += "##";
            allInfo = allInfo+info;
        }
        child=child.nextSibling();
    }
    item->setText(2,allInfo);
    QStringList azinfo=allInfo.split("##");


    AzInfo* ai=new AzInfo(item->text(0).toStdString() ,azinfo[0].toStdString(),azinfo[1].toStdString(),azinfo[2].toStdString(),azinfo[3].toStdString(),
                             azinfo[4].toStdString(),azinfo[5].toStdString(),azinfo[6].toStdString(),azinfo[7].toStdString(),
                             azinfo[8].toStdString());
    User* ad=(*(gestore->usermap))[admin.toStdString()];
    Azienda* az=new Azienda(ai,ad);
    (*(gestore->azmap))[item->text(0).toStdString()]=az;
}


void DBmanager::parseExp(const QDomElement &element, QTreeWidgetItem *parent){
    QTreeWidgetItem* item=new QTreeWidgetItem(parent);
    QString utente=element.attribute("utente");
    item->setText(0,utente);
    QDomNode child=element.firstChild();
    QString allInfo="",out;
    QDomElement node;
    while(!child.isNull()){
        node=child.toElement();
        if(node.tagName()=="azienda"){

            out=node.attribute("inizio")+"##";
            out+=node.attribute("fine")+"##";
            out+=node.attribute("descrizione")+"##";
            out+=node.attribute("nomeente")+"##";
            out+=node.attribute("titolo")+"##";
            out+=node.attribute("ruolo");
        }
        QStringList expinfo=out.split("##");
        Azienda* az=0;
        if(gestore->azmap->find(expinfo[3].toStdString())!=gestore->azmap->end())
            az=gestore->azmap->find(expinfo[3].toStdString())->second;
        Account* acc=(*(gestore->usermap))[utente.toStdString()];

        //crea e aggiunge l'esperienza
        acc->newlavoro(expinfo[0].toInt(),expinfo[1].toInt(),expinfo[2].toStdString(),az,expinfo[3].toStdString(),
                       expinfo[4].toStdString(),expinfo[5].toStdString());
        if(!allInfo.isEmpty()) allInfo+="|";
        allInfo+=out;
        child=child.nextSibling();
    }
    item->setText(1,allInfo);
}

void DBmanager::parseSegn(const QDomElement &element, QTreeWidgetItem *parent){
    QTreeWidgetItem* item=new QTreeWidgetItem(parent);
    QString utente=element.attribute("utente");
    item->setText(0,utente);
    QDomNode child=element.firstChild();
    QString allInfo="",out;
    QDomElement node;
    while(!child.isNull()){
        node=child.toElement();
        if(node.tagName()=="messaggio"){
            out=node.attribute("autore")+"##";
            out+=node.attribute("oggetto")+"##";
            out+=node.attribute("testo")+"##";
            out+=node.attribute("data");
        }
        QStringList info=out.split("##");
        Account* destinatario=(*(gestore->usermap))[utente.toStdString()];
        Account* autore=(*(gestore->usermap))[info[0].toStdString()];
        Messaggio* m=new Messaggio(autore,info[1].toStdString(),info[2].toStdString(),info[3].toInt());
        destinatario->addSegnalazione(m);

        if(!allInfo.isEmpty()) allInfo+="|";
        allInfo+=out;
        child=child.nextSibling();
    }
    item->setText(1,allInfo);
}

void DBmanager::parseOff(const QDomElement &element, QTreeWidgetItem *parent){
    QTreeWidgetItem* item=new QTreeWidgetItem(parent);
    QString id=element.attribute("id");
    item->setText(0,id);
    QDomNode child=element.firstChild();
    QString allusers="",out,user;
    QDomElement node=child.toElement();
    if(node.tagName()=="info"){
            out=node.attribute("proprietario")+"##";
            out+=node.attribute("azienda")+"##";
            out+=node.attribute("tit")+"##";
            out+=node.attribute("reg")+"##";
            out+=node.attribute("ind")+"##";
            out+=node.attribute("sett")+"##";
            out+=node.attribute("desc")+"##";
            out+=node.attribute("gio")+"##";
            out+=node.attribute("esp")+"##";
            out+=node.attribute("creaz")+"##";
            out+=node.attribute("spec");
    }
    item->setText(1,out);
    child=child.nextSibling();
    vector<User*>* acc=new vector<User*>;
    while(!child.isNull()){
        node=child.toElement();
        if(node.tagName()=="candidato"){
            user=node.text();
            if(!allusers.isEmpty()) allusers+="##";
            allusers+=user;
            acc->push_back(gestore->usermap->find(user.toStdString())->second);
        }
        child=child.nextSibling();
    }
    item->setText(2,allusers);
    QStringList info=out.split("##");
    Executive* prop=dynamic_cast<Executive*>((*(gestore->usermap))[info[0].toStdString()]);
    Azienda* az=0;
    map<pstring,Azienda*>::const_iterator ita=gestore->azmap->find(info[1].toStdString());
    if(ita!=gestore->azmap->end())
        az=ita->second;
    Offerta* off=new Offerta(id.toInt(),info[2].toStdString(),info[3].toStdString(),
             info[4].toStdString(),info[5].toStdString(),info[6].toStdString(),info[7].toStdString(),
             info[8].toStdString(),prop,az,info[9].toInt(),info[10].toStdString(),acc);
    prop->get_poff()->push_back(off);
    if(az)
        az->link(off);
    (*gestore->offertemap)[id.toInt()]=off;
    vector<User*>::const_iterator it=acc->begin();
    for(;it!=acc->end();it++){
        User* a=(*it);
        a->getcandidature()->push_back(off);
        sort(a->getcandidature()->begin(),a->getcandidature()->end());
    }
}

void DBmanager::parseGro(const QDomElement &element, QTreeWidgetItem *parent){
    QTreeWidgetItem* item=new QTreeWidgetItem(parent);
    QString nome=element.attribute("nome");
    QString adminname=element.attribute("admin");
    item->setText(0,nome);      //imposta il nome come primo parametro
    item->setText(1,adminname); //imposta l'amministratore come secondo parametro
    QDomNode child=element.firstChild();
    QString out="",username="";

    while(child.toElement().tagName()=="groupinfo"){    //raccoglie le GroupInfo
        if(!out.isEmpty()) out+="##";
        out+=child.toElement().text();
        child=child.nextSibling();
    }

    QStringList info=out.split("##");         //prepara le info per inizializzare il Gruppo
    GroupInfo* ginfo=new GroupInfo(nome.toStdString() ,info[0].toStdString(),info[1].toStdString(),info[2].toInt(),info[3].toStdString());
    item->setText(2,out);   //salva le info
    out="";
    vector<Account*> iscritti;
    while(child.toElement().tagName()=="iscritto"){    //raccoglie gli iscritti
        username=child.toElement().text();
        iscritti.push_back(gestore->usermap->find(username.toStdString())->second); //cerca l'utente nella map e lo aggiunge agli iscritti
        if(!out.isEmpty()) out+="##";
        out+=username;
        child=child.nextSibling();   
    }
    item->setText(3,out);  //salva i nomi degli iscritti
    QDomElement node;
    QDomNode discelement;
    QString discinfo="",titolo;
    User* creatoreDisc,*autoreMex;
    int data;
    vector<Discussione*>* discussioni=new vector<Discussione*>;

    while(child.toElement().tagName()=="DISCUSSIONE"){    //cicla tutte le discussioni
        vector<Messaggio*>* messaggi=new vector<Messaggio*>;
        node=child.toElement();

        username=node.attribute("creatore");              //salva l'username del creatore della discussione
        creatoreDisc=gestore->usermap->find(username.toStdString())->second; //preleva il creatore della discussione dalla map
        titolo=node.attribute("titolo");
        data=node.attribute("data").toInt();
        discelement=child.firstChild();

        while(discelement.toElement().tagName()=="messaggio"){  //cicla tutti i messaggi della discussione
            node=discelement.toElement();
            autoreMex=gestore->usermap->find(node.attribute("autore").toStdString())->second; //preleva l'autore del messaggio
            //crea e inserisce il messaggio
            messaggi->push_back(new Messaggio(autoreMex,node.attribute("oggetto").toStdString(),
                                              node.text().toStdString(),node.attribute("data").toInt()));
            discelement=discelement.nextSibling();
        }

        Discussione *temp=new Discussione(creatoreDisc,titolo.toStdString() ,data,messaggi);
        discussioni->push_back(temp);
        if(!discinfo.isEmpty()) discinfo+="$";
        discinfo+=QString::fromStdString(temp->tostring());
        child=child.nextSibling();
    }

    item->setText(4,discinfo);
    User* admin=gestore->usermap->find(adminname.toStdString())->second;
    Gruppo* gruppo=new Gruppo(ginfo,admin,0,discussioni);    //non inserisco ora gli iscritti.. verrà fatto automaticamente poi
    (*gestore->groupmap)[nome.toStdString()]=gruppo;
    vector<Account*>::iterator it=iscritti.begin();
    while(it!=iscritti.end()){
        (*it)->addgruppo(gruppo);    //itero gli iscritti del gruppo e invoco addGruppo: in questo modo
        it++;                       //avviene il collegamento del gruppo in automatico
    }
}

void DBmanager::parseContatto(const QDomElement &element, QTreeWidgetItem *parent){
    QTreeWidgetItem* item=new QTreeWidgetItem(parent);
    item->setText(0,element.attribute("proprietario"));            //salva il possessore dei contatti
    map<pstring,Account*>::const_iterator it;
    it=gestore->usermap->find(element.attribute("proprietario").toStdString());  //lo estrae dalla mappa degli utenti
    Account* prop=it->second;
    Account* acc;
    Azienda* azi;

    QDomNode child=element.firstChild();
    QString allcontact="",allazi="";
    while(!child.isNull()){
        if(child.toElement().tagName()=="utente"){            //itera i contatti
            QString info=child.toElement().text()+"##"+child.toElement().attribute("tag");  //raccoglie attributi
            if(!allcontact.isEmpty())
                allcontact += "|";
            allcontact += info;                     //raggruppa tutte le info dei contatti in un'unica stringa e la salva
            it=gestore->usermap->find(child.toElement().text().toStdString());
            acc=it->second;
            gestore->addcontatto(prop,acc,child.toElement().attribute("tag").toStdString());
        }
        if(child.toElement().tagName()=="azienda"){     //itera le aziende
            QString info=child.toElement().text();
            if(!allazi.isEmpty())
                allazi += "##";
            allazi += info;

            azi=gestore->azmap->find(child.toElement().text().toStdString())->second;
            prop->addazienda(azi);    //aggiunge l'azienda alla lista dell'utente
        }
        child=child.nextSibling();
    }
    item->setText(1,allcontact);
    item->setText(2,allazi);
}
DBmanager::~DBmanager(){
    clearmemory();
        delete treeAcc;
        delete treeCon;
        delete treeAzi;
        delete treeExp;
        delete treeSegn;
        delete treeOff;
        delete treeGro;
}
