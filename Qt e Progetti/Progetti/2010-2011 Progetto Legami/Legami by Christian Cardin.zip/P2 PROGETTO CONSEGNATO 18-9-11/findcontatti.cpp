#include "findcontatti.h"
#include "ui_findcontatti.h"

findContatti::findContatti(Account* acc,QWidget *parent):QWidget(parent),account(acc),ui(new Ui::findContatti){
    ui->setupUi(this);
    tipoAcc tipo=acc->checktipoaccount();
    ui->soglia->setDisabled(true);
    connect(ui->cerca,SIGNAL(clicked()),this,SLOT(findpressed()));
    if(tipo==ADMIN || tipo==EXECUTIVE)
        connect(ui->simili,SIGNAL(toggled(bool)),ui->soglia,SLOT(setEnabled(bool)));
    else if(tipo==BUSINESS)
        ui->soglia->setValue(50);
    else if(tipo==BASIC){
        ui->simili->setDisabled(true);
        ui->soglia->setValue(100);
    }
    this->setWindowTitle("Ricerca contatti");

}

void findContatti::findpressed(){
    emit findclicked(ui->user->text().trimmed(),ui->nome->text().trimmed(),ui->cogn->text().trimmed(),
                     ui->spec->text().trimmed(),ui->loc->text().trimmed(),ui->simili->isChecked(),
                     ui->soglia->value());
    close();
}

bool findContatti::close(){
    clearFields();
    return QWidget::close();
}

void findContatti::clearFields(){
    ui->user->setText("");
    ui->nome->setText("");
    ui->cogn->setText("");
    ui->spec->setText("");
    ui->loc->setText("");
}


findContatti::~findContatti(){
    delete ui;
}
