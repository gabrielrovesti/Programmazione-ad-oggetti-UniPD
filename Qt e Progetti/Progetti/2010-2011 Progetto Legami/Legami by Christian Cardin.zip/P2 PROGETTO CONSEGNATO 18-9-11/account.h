#ifndef ACCOUNT_H
#define	ACCOUNT_H
#include "user.h"
#include "errstate.h"
#include "utils.h"
#include "pstring.h"

class Discussione;
class Legami;
//Un account si può costruire solo a partire da un utente completo!
//per creare un nuovo gruppo, azienda, offerta, candidatura
//l'account fa riferimento al puntatore gestore per richiamare i suddetti metodi

class Account:public User{
protected:
    tipoAcc acc;
    Legami* gestore;
public:
    int max_risultati;
    Account(UserInfo* _info,Legami* _l);
    tipoAcc checktipoaccount();
    Legami* getgestore() const;
//******************************CONTATTO****************************************
    //i contatti sono inseriti in ordine alfabetico
    //se si inserisce un tag che non c'è su personal_tag, lo aggiunge!
    void addcontatto(User* _con,pstring _tag)throw(ErrStateContact);

    //ritorna false se il contatto non è presente nella lista.
    void deletecontatto(User* _con)throw(ErrStateContact);
    
    //ritorna la lista dei contatti che soddisfano le carateristiche indicate in info
    //simili=0 restituisce solo quei contatti che matchano al 100%
    //simili=1 include i contatti che hanno una percentuale di somiglianza p, calcolata
    //facendo una media pesata sul numero di campi ricercati (ad es: un contatto che ha un match solo
    //sull'username, ha una percentuale di somiglianza maggiore che un contatto con match in nome e cognome)
    //p sarà 100 < p <= soglia
    //i contatti sono memorizzati in ordine crescente, alla fine i più simili (tirare fuori con pop back)
    virtual vector<User*> findutenti(pstring user="",pstring nome="",pstring cogn="",pstring spec="",
           pstring loc="",bool simili=0,int soglia=100);

    //restituisce un vettore di interi, contenente gli indici dei contatti corrispondenti ai parametri voluti
    vector<int> filtracontatti(pstring dato);


//********************************INFO******************************************
    /* Modifica i dati in blocco perchè risulta più facile modificare più campi insieme.
     * tra i parametri formali compaiono i campi che possono essere modificati dall'utente.
     * Lancia un'eccezione nel caso in cui un campo obbligatorio sia nullo*/
    void modifyinfo(pstring _psw,pstring _nome, pstring _cognome,
        pstring _localita, pstring _indirizzo, pstring _spec, pstring _obiet,
        pstring _tel="", pstring _web="", pstring _interessi="")throw(ErrStateInfo);

    /* L'utente non modifica direttamente i campi propri del gruppo, lo fa il gestore.
     * l'utente si limita a indicare i nuovi campi
     * Lancia un'eccezione se l'utente che tenta di modificare le informazioni
     * non è l'amministratore del gruppo*/
    void modifygroupinfo(Gruppo* _g, pstring desc,pstring sett,pstring web="")throw(ErrStateInfo);

//*****************************CURRICULUM***************************************
    /*lancia un'eccezione se:
     * Il link di riferimento e il nome sono entrambi nulli
     * la data di inizio supera quella attuale
     * la data di inizio supera quella di fine
     * la descrizione è nulla*/
    Exp* newlavoro(dataora _inizio,dataora _fin,pstring _descr,Azienda* _l=0,pstring _nome="",
        pstring _tit="",pstring _ruolo="")throw(ErrStateExp);

    /*lancia un'eccezione se:
     * Il link di riferimento è nullo
     * l'esperienza non è nel curriculum
     * la data di inizio supera quella attuale
     * la data di inizio supera quella di fine
     * la descrizione è nulla*/
    void modifyesperienza(Exp* _exp,dataora _inizio,dataora _fin,pstring _descr,
                          pstring _tit="",pstring _ruolo="")throw(ErrStateExp);
    
    /*lancia un'eccezione se:
     * Il link di riferimento è nullo
     * l'esperienza non è nel curriculum*/
    void deletelavoro(Exp* _exp)throw(ErrStateExp);

     /*lancia un'eccezione se:
     * L'oggetto o il testo sono vuoti
     * il link all'utente non è valido o non esiste*/
    void segnala(User* _destinatario,pstring _oggetto,pstring _testo)throw(ErrStateExp);

    /*lancia un'eccezione se:
     * la Messaggio non è nel curriculum*/
    void deleteSegnalazione(Messaggio* _seg)throw(ErrStateExp);

    void addSegnalazione(Messaggio* _seg)throw(ErrStateExp);

//*******************************GRUPPI*****************************************

    
    /* lancia un'eccezione se:
     * link al gruppo==0
     * l'utente è già iscritto
     * gruppo non esiste*/
    void addgruppo(Gruppo* _g)throw(ErrStateGroup);

    /* lancia un'eccezione se:
     * link al gruppo==0
     * l'utente è già iscritto
     * gruppo non esiste*/
    void removegruppo(Gruppo* _g)throw(ErrStateGroup);

    /* lancia un'eccezione se:
     * un campo pstring è vuoto
     * esiste gruppo con lo stesso nome*/
    Gruppo* newgruppo(pstring _nome, pstring _desc,pstring _settore,
                   pstring _web="")throw(ErrStateGroup);

    /* lancia un'eccezione se:
     * gruppo non esiste o link non valido
     * non sei amministratore del sito che vuoi rimuovere*/
    void deletegruppo(Gruppo* _g)throw(ErrStateGroup);

    /* lancia un'eccezione se:
     * gruppo non esiste o link non valido
     * non si è iscritti al gruppo
     * campo titolo, o testo, vuoti*/
    Discussione* makediscussione(Gruppo* _g,pstring tit)throw(ErrStateGroup);
    void deletediscussione(Gruppo* g,Discussione* disc) throw(ErrStateGroup);
    Messaggio* makepost(Gruppo* _g,Discussione* _d,pstring text,pstring ogg="")throw(ErrStateGroup);

    virtual vector<Gruppo*> findgruppi(pstring nome="",pstring sett="",bool simili=0,int soglia=100);
//*******************************AZIENDE****************************************
    void addazienda(Azienda* _a)throw(ErrStateAz);
    void removeazienda(Azienda* _a)throw(ErrStateAz);
    virtual vector<Azienda*> findaziende(pstring nome="",pstring sett="",pstring tipo="",
                   pstring loc="",bool simili=false,int soglia=100);
    virtual Azienda* newazienda(pstring nome, pstring localita,pstring indirizzo,pstring settore,pstring descrizione,
    pstring t,pstring dimensione,pstring web,pstring telefono,pstring email)throw (ErrStateAz);
    virtual void modifyazinfo(Azienda* a, pstring localita,pstring indirizzo,pstring descrizione,
                      pstring dimensione,pstring web,pstring telefono,pstring email)throw(ErrStateInfo);
    virtual void deleteazienda(Azienda* a)throw(ErrStateAz);
    virtual vector<Azienda*> get_paziende() const;

//*******************************OFFERTE****************************************
    void candidatiaofferta(Offerta* _o)throw(ErrStateOff);
    void toglidaofferta(Offerta* _o)throw(ErrStateOff);
    virtual vector<Offerta*> findofferte(pstring tit="",pstring sett="",pstring gior="",
                   pstring loc="",pstring desc="",bool simili=0,int soglia=100);
    virtual vector<Offerta*>* get_poff() const;
    virtual void deleteofferta(Offerta* o)throw(ErrStateOff);
    virtual Offerta* newofferta(pstring tit,pstring loc,pstring ind, pstring sett, pstring desc,pstring gior,
                            pstring esp,Azienda* az=0,pstring spec="");
    virtual ~Account(){}
};

class Business: public Account{
public:
    Business(UserInfo* _info,Legami* _l);
    virtual Azienda* newazienda(pstring nome, pstring localita,pstring indirizzo,pstring settore,pstring descrizione,
    pstring t,pstring dimensione,pstring web,pstring telefono,pstring email)throw (ErrStateAz);
    virtual void modifyazinfo(Azienda* a, pstring localita,pstring indirizzo,pstring descrizione,
                      pstring dimensione,pstring web,pstring telefono,pstring email)throw(ErrStateInfo);
    virtual void deleteazienda(Azienda* a)throw(ErrStateAz);
    virtual vector<Azienda*> get_paziende() const;

    //**ricerche**
    virtual vector<User*> findutenti(pstring user="",pstring nome="",pstring cogn="",pstring spec="",
           pstring loc="",bool simili=0,int soglia=60);
    virtual vector<Offerta*> findofferte(pstring tit="",pstring sett="",pstring gior="",
                   pstring loc="",pstring desc="",bool simili=0,int soglia=50);
    virtual vector<Azienda*> findaziende(pstring nome="",pstring sett="",pstring tipo="",
                   pstring loc="",bool simili=0,int soglia=50);
    virtual vector<Gruppo*> findgruppi(pstring nome="",pstring sett="",bool simili=0,int soglia=50);
    virtual ~Business(){}
};

class Executive: public Business{
protected:
    vector<Offerta*>* off_proposte;
public:
    Executive(UserInfo* _info,Legami* _l);
    virtual Offerta* newofferta(pstring tit,pstring loc,pstring ind, pstring sett, pstring desc,pstring gior,
    pstring esp,Azienda* az=0,pstring spec="");
    virtual void deleteofferta(Offerta* o)throw(ErrStateOff);
    virtual vector<Offerta*>* get_poff() const;

    //ricerche
    virtual vector<User*> findutenti(pstring user="",pstring nome="",pstring cogn="",pstring spec="",
           pstring loc="",bool simili=1,int soglia=40);
    virtual vector<Offerta*> findofferte(pstring tit="",pstring sett="",pstring gior="",
                   pstring loc="",pstring desc="",bool simili=1,int soglia=40);
    virtual vector<Azienda*> findaziende(pstring nome="",pstring sett="",pstring tipo="",
                   pstring loc="",bool simili=1,int soglia=40);
    virtual vector<Gruppo*> findgruppi(pstring nome="",pstring sett="",bool simili=1,int soglia=40);
    virtual ~Executive();
};

class Admin:public Executive{
public:
    Admin(UserInfo* _info,Legami* _l);
    virtual ~Admin(){}
};




#endif	/* ACCOUNT_H */

