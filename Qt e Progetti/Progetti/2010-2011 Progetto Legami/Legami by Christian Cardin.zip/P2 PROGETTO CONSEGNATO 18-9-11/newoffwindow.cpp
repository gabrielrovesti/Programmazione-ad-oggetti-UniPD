#include "newoffwindow.h"
#include "azienda.h"
#include "ui_newoffwindow.h"

newOffWindow::newOffWindow(Account* acc,QWidget *parent) :
    QWidget(parent),
    ui(new Ui::newOffWindow){
    ui->setupUi(this);
    this->setAttribute(Qt::WA_DeleteOnClose);  //dealloca automaticamente il widget alla chiusura
    connect(ui->ok,SIGNAL(clicked()),this,SLOT(newOfferta()));
    connect(ui->chiudi,SIGNAL(clicked()),this,SLOT(close()));
    this->setWindowTitle("Nuova Offerta di lavoro");
    ui->gio->addItem("Part Time");
    ui->gio->addItem("Completa");
    ui->gio->addItem("Indifferente");
    ui->az->addItem("");
    voff=acc->get_paziende();
    unsigned int it=0;
    while(it<voff.size()){             //prende le aziende personali e le trascrive nella comboBox
        ui->az->addItem(QString::fromStdString(voff[it]->getinfo()->getnome()));
        it++;
    }
}

void newOffWindow::newOfferta(){
    int index=ui->az->currentIndex();
    Azienda* az=0;
    if(index>0)
        az=voff[index-1];
    emit createOff(ui->tit->text(),ui->loc->text(),ui->ind->text(),ui->sett->text(),ui->desc->toPlainText(),
                  ui->gio->currentText(),ui->esp->toPlainText(),az,ui->spec->toPlainText());
    close();
}

bool newOffWindow::close(){
    clearFields();
    return QWidget::close();
}

void newOffWindow::clearFields(){
    ui->tit->setText("");
    ui->sett->setText("");
    ui->loc->setText("");
    ui->ind->setText("");
    ui->desc->setPlainText("");
    ui->esp->setPlainText("");
    ui->spec->setPlainText("");
    ui->gio->setCurrentIndex(0);
    ui->az->setCurrentIndex(0);

}

newOffWindow::~newOffWindow(){
    delete ui;
}
