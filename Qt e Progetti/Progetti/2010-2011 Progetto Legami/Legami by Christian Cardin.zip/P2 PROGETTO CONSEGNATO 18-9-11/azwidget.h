#ifndef AZWIDGET_H
#define AZWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QPushButton>
#include <QPlainTextEdit>
#include "azienda.h"
#include "account.h"

/*Pulsante azienda: Derivato da QPushButton, contiene brevi informazioni riepilogative sull'azienda che rappresenta.
 *Se cliccato, emette un segnale apposito specificando l'azienda a cui il widget si riferisce.
 *presenta degli slots dai quali è possibile visualizzare o meno pulsanti per accedere alle funzionalità.
 *Gli oggetti contenuti vengono distrutti automaticamente alla distruzione del Widget.
*/
class azWidget:public QPushButton{
    Q_OBJECT
public:
    azWidget(Azienda* a,QWidget* parent=0);
    void showelimina();
signals:
    void deleteClicked(Azienda*,azWidget*,int);
    void clicked(Azienda*);
public slots:
    void clickedthis();
    void del();
    void canc();
    void disablebuttons();
private:
    Azienda* azi;
    QLabel *nome,*tipo,*settore;
    QPushButton *cancella,*elimina;
    void buildLayers();
    void buildLabels();
};

#endif // AZWIDGET_H
