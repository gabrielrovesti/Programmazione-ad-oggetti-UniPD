#ifndef OFFWIDGET_H
#define OFFWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QPushButton>
#include <QPlainTextEdit>
#include "account.h"
#include "offerta.h"

/*Pulsante offerta: Derivato da QPushButton, contiene brevi informazioni riepilogative sull'offerta che rappresenta.
 *Se cliccato, emette un segnale apposito specificando l'offerta a cui il widget si riferisce.
 *presenta degli slots dai quali è possibile visualizzare o meno pulsanti per accedere alle funzionalità.
 *Questa classe viene usata in più ambiti del programma, per questo ha dei metodi che permettono una differente visualizzazione
 *della stessa a seconda delle esigenze, nascondendo di volta in volta gli elementi superflui.
 *Se abilitati, i pulsante di elimina e rimuovi cono connessi a dei segnali atti ad eseguire determinate operazioni.
 *Tutti gli elementi appartenenti a questa classe vengono automaticamente distrutti insieme ad essa.
 */

class offWidget:public QPushButton{
    Q_OBJECT
public:
    offWidget(Offerta* a,QWidget* parent=0);
    void enableadmin();
    void hidedesc();
signals:
    void deleteClicked(Offerta*,offWidget*);
    void vedidettagli(Offerta*);
    void clicked(Offerta*);
public slots:
    void del();
    void vedidett();
    void disablebuttons();
private slots:
    void click();
private:
    Offerta* off;
    QLabel *nome,*nomeaz,*ldesc;
    QPlainTextEdit *desc;
    QPushButton *cancella,*dettagli,*elimina;
    void buildLayers();
    void buildLabels();
    void buildWidgets();
};

#endif // OFFWIDGET_H
