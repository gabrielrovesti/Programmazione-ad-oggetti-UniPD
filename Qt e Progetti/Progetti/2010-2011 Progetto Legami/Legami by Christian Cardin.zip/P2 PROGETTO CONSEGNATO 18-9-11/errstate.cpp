#include "errstate.h"

ErrState::ErrState(int _a, int _n, pstring _t, pstring amb, pstring wh):num_ambito(_a),num_errore(_n),title(_t),ambito(amb),what(wh){}
int ErrState::getnumambito() const{return num_ambito;}
int ErrState::getnumerr() const{return num_errore;}
pstring ErrState::err_title() const{return title;}
pstring ErrState::err_ambito()const {return ambito;}
pstring ErrState::err_descr() const{return what;}


//********************************CONTATTI**************************************

ErrStateContact::ErrStateContact(int _a, int _n):ErrState(_a,_n,"Errore nella gestione degli Utenti"){
    switch(num_ambito){
        case 1:ambito="Impossibile inserire un nuovo contatto.";break;
        case 2:ambito="Impossibile eliminare il contatto.";break;
        case 3:ambito="Impossibile iscrivere l'utente.";break;
        case 4:ambito="Impossibile effettuare il login.";break;
        case 5:ambito="Impossibile effettuare l'upgrade";break;
        default: ambito="Ambito sconosciuto.";break;
    }

    switch(num_errore){
        case 1:what="L'utente gia' presente tra la propria lista dei contatti";break;
        case 2:what="L'utente non presente nella propria lista dei contatti";break;
        case 3:what="Username gia' presente";break;
        case 4:what="Campo username vuoto";break;
        case 5:what="Campo nome vuoto";break;
        case 10:what="Campo cognome vuoto";break;
        case 6:what="Campo indirizzo vuoto";break;
        case 7:what="Campo email vuoto";break;
        case 8:what="Campo specializzazione vuoto";break;
        case 9:what="Campo obiettivi vuoto";break;
        case 11:what="Data di nascita invalida";break;
        case 12:what="Username non trovato";break;
        case 13:what="Password Errata";break;
        case 14:what="Downgrade non consentito";break;
        case 15:what="Campo Localita' vuoto";break;
        case 16:what="Campo Password vuoto";break;
        case 17:what="Passwords non coincidenti";break;
        default: what="Errore sconosciuto";break;
    }
}


//********************************INFO******************************************

ErrStateInfo::ErrStateInfo(int _a, int _n):ErrState(_a,_n,"Errore nella modifica delle informazioni"){
    switch(num_ambito){
        case 1:ambito="Prego inserire un valore valido per il campo:";break;
        case 2:ambito="Impossibile modificare i dati.";break;
        default: ambito=ErrState::err_title();break;
    }
    switch(num_errore){
        case 0:what="Non si dispongono dei privilegi necessari.";break;
        case 1:what="Password";break;
        case 2:what="Nome";break;
        case 3:what="Cognome";break;
        case 4:what="Logo";break;
        case 5:what="localita";break;
        case 6:what="Indirizzo";break;
        case 7:what="Specializzazione";break;
        case 8:what="Obiettivi";break;
        default: what=ErrState::err_descr();break;
    }
}

//********************************EXP*******************************************

ErrStateExp::ErrStateExp(int _a, int _n):ErrState(_a,_n,"Errore nella modifica del curriculum"){
    switch(num_ambito){
        case 1:ambito="Impossibile inserire una nuova esperienza";break;
        case 3:ambito="Impossibile modificare l'esperienza.";break;
        case 4:ambito="Impossibile cancellare l'esperienza.";break;
        case 5:ambito="Impossibile inserire la Segnalazione";break;
        case 6:ambito="Impossibile cancellare la Segnalazione.";break;
        default: ambito=ErrState::err_title();break;
    }
    switch(num_errore){
        case 1:what="Inserire un collegamento all'ente di riferimento o un nome non nullo";break;
        case 2:what="La data di fine e' antecedente a quella di inizio";break;
        case 3:what="Il campo descrizione deve essere non nullo";break;
        case 4:what="La data di inizio e' superiore a quella attuale!";break;
        case 5:what="Il link di riferimento deve essere una Scuola";break;
        case 6:what="Inserire un riferimento all'esperienza valido";break;
        case 7:what="L'esperienza indicata non esiste.";break;
        case 8:what="La Messaggio indicata non esiste.";break;
        case 9:what="I campi Intestazione e Testo devono essere non nulli.";break;
        case 10:what="Destinatario sconosciuto.";break;
        case 11:what="La scuola indicata non esiste.";break;
        case 12:what="L'azienda indicata non esiste";break;
        case 13:what="L'utente figura gia' nell'elenco.";break;
        case 14:what="L'utente non figura nell'elenco.";break;
        default: what=ErrState::err_descr();break;
    }
}


//********************************GROUP*****************************************

ErrStateGroup::ErrStateGroup(int _a, int _n):ErrState(_a,_n,"Errore nella gestione del gruppo"){
    switch(num_ambito){
        case 1:ambito="Impossibile inserire il link al gruppo";break;
        case 2:ambito="Impossibile rimuovere il link al gruppo";break;
        case 3:ambito="Impossibile creare un nuovo gruppo.";break;
        case 4:ambito="Impossibile cancellare il gruppo.";break;
        case 5:ambito="Impossibile creare una nuova discussione.";break;
        case 6:ambito="Impossibile inserire il messaggio.";break;
        case 7:ambito="Impossibile rimuovere la discussione.";break;
        default: ambito=ErrState::err_title();break;
    }
    switch(num_errore){
        case 1:what="Link non valido";break;
        case 2:what="Sei gia' iscritto a questo gruppo.";break;
        case 3:what="Non sei iscritto a questo gruppo";break;
        case 4:what="Campo Nome vuoto";break;
        case 5:what="Campo Logo vuoto";break;
        case 6:what="Campo Descrizione vuoto";break;
        case 7:what="Campo Settore vuoto";break;
        case 8:what="Link al responsabile non valido.";break;
        case 9:what="Il gruppo specificato non esiste.";break;
        case 10:what="L'utente specificato non esiste";break;
        case 11:what="L'utente specificato e' tra gli iscritti del gruppo.";break;
        case 12:what="Esiste gia' un altro gruppo con lo stesso nome.";break;
        case 13:what="Non si hanno i privilegi necessari.";break;
        case 14:what="Campo titolo vuoto";break;
        case 15:what="Campo testo vuoto";break;
        case 16:what="Discussione non presente.";break;
        case 17:what="Sei amministratore di questo gruppo. Designare un altro amministratore prima di rimuoversi.";break;
        default: what=ErrState::err_descr();break;
    }
}

//********************************AZIENDE***************************************

ErrStateAz::ErrStateAz(int _a, int _n):ErrState(_a,_n,"Errore nella gestione dell'Azienda"){
    switch(num_ambito){
        case 1:ambito="Impossibile inserire il link all'azienda";break;
        case 2:ambito="Impossibile rimuovere il link all'azienda";break;
        case 3:ambito="Impossibile creare una nuova azienda.";break;
        case 4:ambito="Impossibile cancellare l'azienda.";break;
        default: ambito=ErrState::err_title();break;
    }
    switch(num_errore){
        case 1:what="Link non valido";break;
        case 2:what="Sei gia' iscritto a questa azienda.";break;
        case 3:what="Non sei iscritto a questa azienda";break;
        case 4:what="Campo Nome vuoto";break;
        case 5:what="Campo Localita' vuoto";break;
        case 6:what="Campo Indirizzo vuoto";break;
        case 7:what="Campo Settore vuoto";break;
        case 8:what="Campo descrizione vuoto";break;
        case 9:what="Campo tipo vuoto";break;
        case 10:what="Campo dimensione vuoto";break;
        case 11:what="Link al responsabile non valido.";break;
        case 12:what="Esiste gia' un'altra azienda con lo stesso nome.";break;
        case 13:what="Non si hanno i privilegi necessari.";break;
        case 14:what="L'azienda specificata non esiste.";break;
        case 15:what="Sei amministratore di questa azienda.";break;
        default: what=ErrState::err_descr();break;
    }
}

//********************************OFFERTE***************************************

ErrStateOff::ErrStateOff(int _a, int _n):ErrState(_a,_n,"Errore nella gestione dell'Offerta"){
    switch(num_ambito){
        case 1:ambito="Impossibile inserire il link all'offerta";break;
        case 2:ambito="Impossibile rimuovere il link all'offerta";break;
        case 3:ambito="Impossibile creare una nuova offerta.";break;
        case 4:ambito="Impossibile cancellare l'offerta.";break;
        default: ambito=ErrState::err_title();break;
    }
    switch(num_errore){
        case 1:what="Campo titolo vuoto";break;
        case 2:what="Campo localita' vuoto";break;
        case 3:what="Campo indirizzo vuoto";break;
        case 4:what="Campo settore vuoto";break;
        case 5:what="Campo descrizione vuoto";break;
        case 6:what="Campo giornata vuoto";break;
        case 7:what="Campo rivolto a vuoto";break;
        case 8:what="Campo esperienze vuoto";break;
        case 9:what="Non sei iscritto a questa offerta";break;
        case 10:what="Sei gia' iscritto a questa offerta.";break;
        case 11:what="Link al responsabile non valido.";break;
        case 13:what="Non si hanno i privilegi necessari.";break;
        case 14:what="L'offerta specificata non esiste.";break;
        case 15:what="Link non valido";break;
        case 16:what="Sei il creatore dell'offerta, non puoi iscriverti!";break;
        default: what=ErrState::err_descr();break;
        }
}

ErrStateDb::ErrStateDb(int row, int col, pstring mex):ErrState(0,0,"Errore nella lettura del database"){
    if(row==-1){
        ambito="Impossibile caricare il database.";
        what="Il file selezionato non e' un database per Legami!";
    }
    else{
        ambito="Riga: ";ambito+=row+"\nColonna: "+col;
        what="Messaggio: "+mex+"\n\nLettura fallita, contattare l'amministratore del sistema.";
    }
}
