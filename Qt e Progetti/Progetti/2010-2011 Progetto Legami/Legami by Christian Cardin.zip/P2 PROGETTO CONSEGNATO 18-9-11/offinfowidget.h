#ifndef OFFINFOWIDGET_H
#define OFFINFOWIDGET_H

#include <QGroupBox>
#include <QLabel>
#include <QTabWidget>
#include <QPushButton>
#include <QScrollArea>
#include <QPlainTextEdit>
#include "userinfowindow.h"
#include "account.h"
#include "offerta.h"

/*Finestra che raccoglie tutti i dettagli su un'offerta. Deriva da QTabWidget per facilitare una visualizzazione
 *"a cartelle". La prima tab ospita informazioni testuali atte a descrivere l'offerta; non è prevista la
 *modifica delle informazioni di un'offerta.
 *Se il creatore dell'offerta ha legato una specifica azienda, viene mostrato il link che, se cliccato, apre la finestra dei
 *dettagi dell'azienda.
 *
 *La seconda tab indica il numero dei candidati all'offerta, ma solo il creatore o l'admin possono vedere i nomi e
 *i dettagli dei candidati.
 *
 *Cliccando un contactWidget, si apre una finestra con tutte le informazioni sul suo profilo, opportunamente filtrate
 *a seconda del grado di account del richiedente.
 *
 *I widget degli iscritti sono connessi all'evento destroyed() della classe in modo che, quando viene
 *lanciato, si deallochino automaticamente.La finestra delle info dei contatti si auto-cancella alla chiusura.
 *Se presente, l'azWidget e l'azInfoWidget si deallocano automaticamente alla distruzione del padre, non appena
 *questo lancia il segnale destroyed()
*/

class offInfoWidget:public QTabWidget{
    Q_OBJECT
public:
    offInfoWidget(Offerta* a,Account* acc,QWidget* parent=0);
    Offerta* getofferta() const;
private slots:
    void loadCandInfo(Contatto);

private:
    Offerta *offerta;
    Account *account;
    QLabel *tit,*loc,*ind,*sett,*gio,*admin,*creaz;
    QPlainTextEdit *desc,*spec,*esp;
    QGroupBox *discBox;
    azWidget *azwid;
    UserInfoWindow *info;

    void buildLayersInfo();
    void buildLabelsInfo();
    void buildCandidati();
};

#endif // OFFINFOWIDGET_H
