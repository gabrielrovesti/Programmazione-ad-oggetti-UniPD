#include "groupwidget.h"

#include <QMessageBox>
#include <QBoxLayout>

groupWidget::groupWidget(Gruppo *a,QWidget *parent):QPushButton(parent),group(a){
    cancella=new QPushButton("Rimuovi");
    elimina=new QPushButton("Elimina");
    elimina->hide();
    connect(elimina,SIGNAL(clicked()),this,SLOT(canc()));
    connect(cancella,SIGNAL(clicked()),this,SLOT(del()));
    connect(this,SIGNAL(clicked()),this,SLOT(clickedthis()));
    buildLabels();
    buildLayers();
    setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
    setMaximumHeight(90);
}

void groupWidget::buildLabels(){
    GroupInfo *info=group->getinfo();
    nome=new QLabel("<b>"+QString::fromStdString(info->getnome())+"</b>");
    prop=new QLabel("Admin: "+QString::fromStdString(group->getadmin()->getinfo()->getusername()));
    data=new QLabel("Creato il "+QString::fromStdString(info->getcreazione()));

}

void groupWidget::buildLayers(){
    QVBoxLayout *v1=new QVBoxLayout();
    QVBoxLayout *v2=new QVBoxLayout();
    QHBoxLayout *h1=new QHBoxLayout();

    v1->addWidget(nome);
    v1->addWidget(prop);
    v1->addWidget(data);
    v1->addStretch();
    //pulsante
    v2->addWidget(cancella);
    v2->addWidget(elimina);
    v2->addStretch();
    //main layout
    h1->addLayout(v1);
    h1->addStretch();
    h1->addLayout(v2);
    h1->setSizeConstraint(QLayout::SetMinimumSize);
    setLayout(h1);
}

void groupWidget::del(){
    emit deleteClicked(group,this,1);
}

void groupWidget::canc(){
    emit deleteClicked(group,this,2);
}

void groupWidget::clickedthis(){
    emit clicked(group);
}

void groupWidget::showelimina(){
    elimina->setVisible(true);
    cancella->setVisible(false);
}

void groupWidget::disablebuttons(){
    cancella->setVisible(false);
    elimina->setVisible(false);
    this->setDisabled(true);
}
