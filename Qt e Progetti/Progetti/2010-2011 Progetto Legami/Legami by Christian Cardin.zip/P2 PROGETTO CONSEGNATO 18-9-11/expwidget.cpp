#include "expwidget.h"
#include "azinfowidget.h"
#include "errormex.h"
#include <QMessageBox>
#include <QBoxLayout>

expWidget::expWidget(Account* acc,Exp *e,QWidget *parent):QWidget(parent),account(acc),exp(e){
    azwid=0;
    buildButtons();
    buildLabels();
    buildLayers();
    modexp=new modExpWindow(account);
    connect(modexp,SIGNAL(expChanged()),this,SLOT(reloadLabels()));
}

void expWidget::buildButtons(){
    modifica=new QPushButton("Modifica");
    cancella=new QPushButton("Cancella");
    connect(modifica,SIGNAL(clicked()),this,SLOT(mod()));
    connect(cancella,SIGNAL(clicked()),this,SLOT(del()));

}

void expWidget::buildLabels(){
    if(exp->getente()){
        azwid=new azWidget(exp->getente());
        azwid->disablebuttons();
        azwid->setEnabled(true);
        connect(azwid,SIGNAL(clicked(Azienda*)),this,SLOT(showazinfo(Azienda*)));
    }
    else
        nomeaz=new QLabel("<b>Nome azienda: "+QString::fromStdString(exp->getnomeente())+"</b>");
    durata=new QLabel("da "+QString::fromStdString(exp->getinizio())+" a "+QString::fromStdString(exp->getfine()));
    ldesc=new QLabel("Descrizione");
    desc=new QPlainTextEdit(QString::fromStdString(exp->getdesc()));
    desc->setReadOnly(true);
    desc->setTextInteractionFlags(0);
    ruolo=new QLabel("Ruolo: "+QString::fromStdString(exp->getruolo()));
    tit=new QLabel("Titolo conseguito: "+QString::fromStdString(exp->gettitolo()));
    desc->setMaximumSize(550,100);
    desc->setSizePolicy(QSizePolicy::Preferred,QSizePolicy::Preferred);
    desc->setReadOnly(true);
    desc->setTextInteractionFlags(Qt::NoTextInteraction);
}

void expWidget::buildLayers(){
    //layout descrizione
    QHBoxLayout *hdesc=new QHBoxLayout(); //label
    hdesc->addWidget(ldesc);
    hdesc->addStretch();
    QVBoxLayout *vdesc=new QVBoxLayout(); //generale
    vdesc->addLayout(hdesc);
    vdesc->addWidget(desc);

    //layout generale
    QVBoxLayout *v1=new QVBoxLayout();
    QVBoxLayout *v2=new QVBoxLayout();
    QVBoxLayout *v3=new QVBoxLayout();
    QHBoxLayout *h1=new QHBoxLayout();
    if(azwid==0)
        v1->addWidget(nomeaz);
    else
        v1->addWidget(azwid);
    v1->addWidget(durata);
    v1->addWidget(ruolo);
    v1->addWidget(tit);
    v2->addWidget(modifica);
    v2->addWidget(cancella);
    v2->addStretch();
    h1->addLayout(v1);
    h1->addStretch();
    h1->addLayout(v2);
    v3->addLayout(h1);
    v3->addLayout(vdesc);
    v3->setSizeConstraint(QLayout::SetMinimumSize);
    setLayout(v3);
    setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);

}

void expWidget::reloadLabels(){
    durata->setText("da "+QString::fromStdString(exp->getinizio())+" a "+QString::fromStdString(exp->getfine()));
    desc->setPlainText(QString::fromStdString(exp->getdesc()));
    ruolo->setText("Ruolo: "+QString::fromStdString(exp->getruolo()));
    tit->setText("Titolo conseguito: "+QString::fromStdString(exp->gettitolo()));
}

void expWidget::del(){
    emit deleteClicked(exp,this);
}

void expWidget::disablebuttons(){
    modifica->setVisible(false);
    cancella->setVisible(false);
}

void expWidget::showazinfo(Azienda *az){
    if(exp->getente()){       //L'azienda potrebbe essere stata cancellata. Se esiste ancora visualizza i dettagli
        azinfoWidget *info=new azinfoWidget(az);
        info->show();
    }
    else{
        ErrorMex* err=new ErrorMex("Azienda eliminata","A quanto pare l'azienda e' stata rimossa!",
                                   "Pertanto, il pulsante verra' disabilitato e non sara' piu' possibile accedere ai dettagli.");
        err->show();
        azwid->disconnect();
        azwid->setDisabled(true);

    }
}

void expWidget::mod(){
    modexp->load(exp);
    modexp->show();
}

expWidget::~expWidget(){
    delete modexp;
    if(azwid)
        delete azwid;
}
