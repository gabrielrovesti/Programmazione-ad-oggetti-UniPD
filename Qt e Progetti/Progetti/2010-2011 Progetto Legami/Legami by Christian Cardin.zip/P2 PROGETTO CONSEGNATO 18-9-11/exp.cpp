#include "pstring.h"
#include "exp.h"
#include "azienda.h"
#include "utils.h"
#include "errstate.h"


Exp::Exp(dataora _inizio, dataora _fin, pstring _descr, Azienda* _l, pstring _nome,
         pstring _tit, pstring _ruolo):ente(_l),inizio(_inizio),fine(_fin),descrizione(_descr),
         nome_ente(_nome),ruolo(_ruolo),titolo_conseguito(_tit){
    if(ente!=0) nome_ente=ente->getinfo()->getnome();
}

pstring Exp::getinizio() const{return inizio.getdata();}

pstring Exp::getfine() const{
    if(fine==0) return "*In Attivita*";
    return fine.getdata();
}

pstring Exp::getdesc() const{return descrizione;}

pstring Exp::getnomeente() const{
        return nome_ente;
}

pstring Exp::gettitolo() const{return titolo_conseguito;}

pstring Exp::getruolo() const{return ruolo;}

bool Exp::modify(dataora _inizio, dataora _fin, pstring _descr, pstring _tit, pstring _ruolo){
    if(_descr.trimmed()=="") throw ErrStateExp(3,3);
    inizio=_inizio;
    fine=_fin;
    descrizione=_descr;
    titolo_conseguito=_tit;
    ruolo=_ruolo;
    return true;
}

int Exp::durata() const{
    if(fine!=0)
        return difftime(fine.stamp(),inizio.stamp())/86400;
    time_t t;
    time(&t);
    return difftime(t,inizio.stamp())/86400;
}

Azienda* Exp::getente() const{return ente;}

pstring Exp::tostring() const{
    pstring out;
    out+=inizio.stamp();out+="##";
    out+=fine.stamp();out+="##";
    out+=descrizione;out+="##";
    out+=nome_ente;out+="##";
    out+=titolo_conseguito;out+="##";
    out+=ruolo;
    return out;
}

void Exp::modifydeleted_ente(){
    if(!ente)
        return;
    nome_ente=ente->getinfo()->getnome();
    ente=0;
}

bool Exp::in_attivita() const{
    if(fine==0)return true;
    return false;
}

bool Exp::operator>(const Exp& e) const{return inizio>e.inizio;}
bool Exp::operator<(const Exp& e) const{return inizio<e.inizio;}
bool Exp::operator==(const Exp& e) const{return (inizio==e.inizio)&&(fine==e.fine);}


