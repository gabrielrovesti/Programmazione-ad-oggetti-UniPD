#include "user.h"

User::User(UserInfo* _info): quickinfo(_info){
    curriculum=new Curriculum;
    contatti=new vector<Contatto>;
    gruppi=new vector<Gruppo*>;
    aziende=new vector<Azienda*>;
    candidature=new vector<Offerta*>;
    personal_tag=new vector< Tag >;
}

UserInfo* User::getinfo() const{return quickinfo;}
Curriculum* User::getcurriculum() const{return curriculum;}
vector<Contatto>* User::getcontatti() const{return contatti;}
vector<Gruppo*>* User::getgruppi() const{return gruppi;}
vector<Azienda*>* User::getaziende() const{return aziende;}
vector<Offerta*>* User::getcandidature() const{return candidature;}


vector< Tag >* User::get_ptag() const{return personal_tag;}

vector<Gruppo*>::iterator User::is_presente(Gruppo* _g) const{
    vector<Gruppo*>::iterator it=gruppi->begin();
    while(it!=gruppi->end() && (*it)!=_g)
        it++;
    return it;
}

vector<Azienda*>::iterator User::is_presente(Azienda* a) const{
    vector<Azienda*>::iterator it=aziende->begin();
    while(it!=aziende->end() && (*it)!=a)
        it++;
    return it;
}

User::~User(){
    delete quickinfo;
    delete personal_tag;
    delete contatti;
    delete curriculum;
    delete gruppi;
    delete aziende;
    delete candidature;
}
