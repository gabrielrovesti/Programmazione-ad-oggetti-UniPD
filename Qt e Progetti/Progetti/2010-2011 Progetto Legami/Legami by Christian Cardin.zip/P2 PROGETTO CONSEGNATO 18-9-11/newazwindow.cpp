#include "newazwindow.h"
#include "ui_newazwindow.h"

newAzWindow::newAzWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::newAzWindow){
    ui->setupUi(this);
    connect(ui->ok,SIGNAL(clicked()),this,SLOT(newAzienda()));
    connect(ui->chiudi,SIGNAL(clicked()),this,SLOT(close()));

    ui->dim->addItem("< 10");
    ui->dim->addItem("Da 10 a 30");
    ui->dim->addItem("Da 30 a 100");
    ui->dim->addItem("Da 100 a 500");
    ui->dim->addItem("500 +");


}

void newAzWindow::newAzienda(){
    emit createAz(ui->nome->text(),ui->loc->text(),ui->ind->text(),ui->sett->text(),ui->desc->toPlainText(),
                  ui->tip->text(),ui->dim->currentText(),ui->web->text(),ui->tel->text(),ui->email->text());
    close();
}

bool newAzWindow::close(){
    clearFields();
    return QWidget::close();
}

void newAzWindow::clearFields(){
    ui->nome->setText("");
    ui->tip->setText("");
    ui->sett->setText("");
    ui->loc->setText("");
    ui->ind->setText("");
    ui->desc->setPlainText("");
    ui->email->setText("");
    ui->web->setText("");
    ui->tel->setText("");
    ui->dim->setCurrentIndex(0);
}

newAzWindow::~newAzWindow(){
    delete ui;
}
