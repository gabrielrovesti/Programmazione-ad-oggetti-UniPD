/********************************************************************************
** Form generated from reading UI file 'mainpage.ui'
**
** Created: Sun Sep 18 16:34:32 2011
**      by: Qt User Interface Compiler version 4.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINPAGE_H
#define UI_MAINPAGE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QStatusBar>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainPage
{
public:
    QAction *actionNuovo;
    QAction *actionLogin;
    QAction *actionUpGrade;
    QAction *actionAccedi;
    QAction *actionChiudi;
    QAction *actionLogout;
    QWidget *centralwidget;
    QMenuBar *menubar;
    QMenu *menuAccount;
    QMenu *menuLegami;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainPage)
    {
        if (MainPage->objectName().isEmpty())
            MainPage->setObjectName(QString::fromUtf8("MainPage"));
        MainPage->resize(800, 600);
        actionNuovo = new QAction(MainPage);
        actionNuovo->setObjectName(QString::fromUtf8("actionNuovo"));
        actionLogin = new QAction(MainPage);
        actionLogin->setObjectName(QString::fromUtf8("actionLogin"));
        actionUpGrade = new QAction(MainPage);
        actionUpGrade->setObjectName(QString::fromUtf8("actionUpGrade"));
        actionAccedi = new QAction(MainPage);
        actionAccedi->setObjectName(QString::fromUtf8("actionAccedi"));
        actionChiudi = new QAction(MainPage);
        actionChiudi->setObjectName(QString::fromUtf8("actionChiudi"));
        actionLogout = new QAction(MainPage);
        actionLogout->setObjectName(QString::fromUtf8("actionLogout"));
        centralwidget = new QWidget(MainPage);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        MainPage->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainPage);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 25));
        menuAccount = new QMenu(menubar);
        menuAccount->setObjectName(QString::fromUtf8("menuAccount"));
        menuLegami = new QMenu(menubar);
        menuLegami->setObjectName(QString::fromUtf8("menuLegami"));
        MainPage->setMenuBar(menubar);
        statusbar = new QStatusBar(MainPage);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainPage->setStatusBar(statusbar);

        menubar->addAction(menuLegami->menuAction());
        menubar->addAction(menuAccount->menuAction());
        menuAccount->addAction(actionLogin);
        menuAccount->addAction(actionLogout);
        menuAccount->addAction(actionNuovo);
        menuAccount->addAction(actionUpGrade);
        menuLegami->addAction(actionChiudi);

        retranslateUi(MainPage);

        QMetaObject::connectSlotsByName(MainPage);
    } // setupUi

    void retranslateUi(QMainWindow *MainPage)
    {
        MainPage->setWindowTitle(QApplication::translate("MainPage", "Legami \342\230\272", 0, QApplication::UnicodeUTF8));
        actionNuovo->setText(QApplication::translate("MainPage", "Iscrizione", 0, QApplication::UnicodeUTF8));
        actionLogin->setText(QApplication::translate("MainPage", "Login", 0, QApplication::UnicodeUTF8));
        actionUpGrade->setText(QApplication::translate("MainPage", "UpGrade", 0, QApplication::UnicodeUTF8));
        actionAccedi->setText(QApplication::translate("MainPage", "Database", 0, QApplication::UnicodeUTF8));
        actionChiudi->setText(QApplication::translate("MainPage", "Chiudi", 0, QApplication::UnicodeUTF8));
        actionLogout->setText(QApplication::translate("MainPage", "Logout", 0, QApplication::UnicodeUTF8));
        menuAccount->setTitle(QApplication::translate("MainPage", "Account", 0, QApplication::UnicodeUTF8));
        menuLegami->setTitle(QApplication::translate("MainPage", "Legami", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainPage: public Ui_MainPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINPAGE_H
