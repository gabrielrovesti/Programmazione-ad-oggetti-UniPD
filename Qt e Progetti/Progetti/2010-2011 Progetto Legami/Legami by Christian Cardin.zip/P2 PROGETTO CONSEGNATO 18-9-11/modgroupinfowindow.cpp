#include "modgroupinfowindow.h"
#include "ui_modgroupinfowindow.h"
#include "errormex.h"

modGroupinfowindow::modGroupinfowindow(Gruppo* a,Account* acc,QWidget *parent):QWidget(parent),gruppo(a),account(acc),
                                       ui(new Ui::modGroupinfowindow){
    ui->setupUi(this);
    loadLabels();
    connect(ui->chiudi,SIGNAL(clicked()),this,SLOT(close()));
    connect(ui->ok,SIGNAL(clicked()),this,SLOT(modify()));

}

void modGroupinfowindow::loadLabels(){
    GroupInfo *info=gruppo->getinfo();
    ui->web->setText(QString::fromStdString(info->getweb()));
    ui->sett->setText(QString::fromStdString(info->getsettore()));
    ui->desc->setPlainText(QString::fromStdString(info->getdesc()));
}

void modGroupinfowindow::modify(){
    try{
        account->modifygroupinfo(gruppo,ui->sett->text().toStdString(),ui->desc->toPlainText().toStdString(),ui->web->text().toStdString());
    }catch(ErrState e){
        ErrorMex* werr=new ErrorMex(e);
        werr->show();
        return;
    }
    OkMex* kmex=new OkMex("Modifica Gruppo","Modifiche avvenute con successo");
    kmex->show();
    emit infoChanged();
    close();
}

modGroupinfowindow::~modGroupinfowindow(){
    delete ui;
}

