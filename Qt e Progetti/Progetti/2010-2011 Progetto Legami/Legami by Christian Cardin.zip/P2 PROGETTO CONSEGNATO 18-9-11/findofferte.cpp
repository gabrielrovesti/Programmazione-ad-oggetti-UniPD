#include "findofferte.h"
#include "ui_findofferte.h"

findOfferte::findOfferte(Account* acc,QWidget *parent):QWidget(parent),account(acc),ui(new Ui::findOfferte){
    ui->setupUi(this);
    tipoAcc tipo=acc->checktipoaccount();
    ui->soglia->setDisabled(true);
    connect(ui->cerca,SIGNAL(clicked()),this,SLOT(findpressed()));
    if(tipo==ADMIN || tipo==EXECUTIVE)
        connect(ui->simili,SIGNAL(toggled(bool)),ui->soglia,SLOT(setEnabled(bool)));
    else if(tipo==BUSINESS)
        ui->soglia->setValue(50);
    else if(tipo==BASIC){
        ui->simili->setDisabled(true);
        ui->soglia->setValue(100);
    }
    ui->gio->addItem("");
    ui->gio->addItem("Part Time");
    ui->gio->addItem("Completa");
    ui->gio->addItem("Indifferente");
    this->setWindowTitle("Ricerca Offerte");

}

void findOfferte::findpressed(){
    emit findclicked(ui->tit->text(),ui->sett->text(),ui->gio->currentText(),ui->loc->text(),ui->key->text(),
                     ui->simili->isChecked(),ui->soglia->value());
    close();
}

bool findOfferte::close(){
    clearFields();
    return QWidget::close();
}

void findOfferte::clearFields(){
    ui->tit->setText("");
    ui->sett->setText("");
    ui->loc->setText("");
    ui->key->setText("");
    ui->gio->setCurrentIndex(0);
}


findOfferte::~findOfferte(){
    delete ui;
}
