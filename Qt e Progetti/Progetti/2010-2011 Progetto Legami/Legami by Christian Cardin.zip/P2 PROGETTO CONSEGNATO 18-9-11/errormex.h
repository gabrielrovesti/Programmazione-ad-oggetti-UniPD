#ifndef ERRORMEX_H
#define ERRORMEX_H
#include "errstate.h"
#include <QMessageBox>

/*Classi che ereditano da QMessageBox:
 *  - OkMex si occupa di stampare messaggi informativi, il costruttore accetta il testo da mostrare
 *    (titolo finestra, messaggio, eventuali dettagli).
 *  - ErrorMex si occupa di mostrare i messaggi di errore. Ha il costruttore sovraccaricato in modo da gestire due modalità:
 *    La prima è manuale: come OkMex, viene impostato manualmente il testo da visualizzare.
 *    La seconda accetta come parametro un oggetto ErrState, il quale contiene un messaggio specifico dell'errore riscontrato
 *    causato dal throw di un'eccezione.
 *
 *Sono programmate per autodistruggersi alla chiusura.
*/

class OkMex:public QMessageBox{
public:
    OkMex(QString tit,QString mex,QString dettagli="",QWidget *parent=0);
};

class ErrorMex:public QMessageBox{
public:
    ErrorMex(ErrState err,QWidget *parent=0);
    ErrorMex(QString tit,QString ambito,QString err,QWidget *parent=0);
};

#endif // ERRORMEX_H
