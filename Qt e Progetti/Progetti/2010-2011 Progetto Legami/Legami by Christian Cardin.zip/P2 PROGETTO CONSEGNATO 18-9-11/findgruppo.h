#ifndef FINDGRUPPO_H
#define FINDGRUPPO_H

#include <QWidget>
#include "account.h"

namespace Ui {
    class findGruppo;
}

/*Finestra di ricerca dei gruppi. Viene richiesto di specificare alcuni campi e di impstare le opzioni di ricerca:
 *viene fatto un controllo sul tipo dell'account e vengono abilitate di conseguenza delle funzionalità.
 *Gli oggetti vengono distrutti automaticamente alla distruzione della finestra.
*/

class findGruppo : public QWidget{
    Q_OBJECT

public:
    explicit findGruppo(Account* acc,QWidget *parent = 0);
    ~findGruppo();

signals:
    void findclicked(QString,QString,bool,int);
private slots:
    void findPressed();
public slots:
    bool close();
private:
    void clearFields();
    Ui::findGruppo *ui;
};

#endif // FINDGRUPPO_H
