#ifndef EXP_H
#define	EXP_H
#include "pstring.h"
#include <time.h>
#include "dataora.h"
 using std::string;

//DA FARE: nei costruttori di esperienza scolastica e lavorativa, se il link non è vuoto
//bisogna inizializzare il nome con quello della scuola-azienda corrispondente
class Azienda;

//rappresenta un'esperienza caratterizzata dalla data di inizio e, eventualmente, di fine.
class Exp{
private:
    Azienda* ente;
    dataora inizio,fine;
    pstring descrizione,nome_ente,ruolo,titolo_conseguito;
public:
    //si assume che la data con timestamp 0 (1/1/1900) indica un'esperienza non ancora conclusa
    Exp(dataora _inizio,dataora _fin,pstring _descr,Azienda* _l=0,pstring _nome="",
        pstring _tit="",pstring _ruolo="");
    pstring getinizio() const;
    pstring getfine() const;
    pstring getdesc() const;
    pstring getnomeente() const;
    pstring gettitolo() const;
    pstring getruolo() const;
    Azienda* getente() const;
    pstring tostring() const;
    bool modify(dataora _inizio,dataora _fin,pstring _descr,pstring _tit="",pstring _ruolo="");
    void modifydeleted_ente();
    int durata() const; //la durata in giorni dell'esperienza. Se è ancora in corso,
                        //restituisce i giorni fino alla data attuale.
    bool in_attivita() const;
    //un'esperienza A è maggiore (minore) di B se è iniziata dopo (prima)
    bool operator>(const Exp&) const;
    bool operator<(const Exp&) const;
    bool operator==(const Exp&) const;
};
#endif	/* EXP_H */

