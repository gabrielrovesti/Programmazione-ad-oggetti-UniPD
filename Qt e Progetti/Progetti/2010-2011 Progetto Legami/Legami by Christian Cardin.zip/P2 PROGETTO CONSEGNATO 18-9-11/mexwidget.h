#ifndef MEXWIDGET_H
#define MEXWIDGET_H
#include <QWidget>
#include <QLabel>
#include <QPushButton>
#include <QPlainTextEdit>
#include "messaggio.h"

/*Widget messaggio: contiene informazioni riepilogative sulla segnalazione che rappresenta.
 *Il proprietario può decidere di rimuovere la segnalaazione (in tal caso verrà emesso un segnale per far
 *partire l'operazione) ma non è in grado di modificarla.
 *Gli oggetti contenuti vengono distrutti automaticamente alla distruzione del Widget.
*/

class mexWidget:public QWidget{
    Q_OBJECT
public:
    mexWidget(Messaggio* e,QWidget* parent=0);
signals:
    void deleteClicked(Messaggio*,mexWidget*);

public slots:
    void del();
    void disablebuttons();
private:
    Messaggio* mex;
    QLabel *autore,*oggetto,*ltesto,*data;
    QPlainTextEdit *testo;
    QPushButton *cancella;
    void buildLabels();
    void buildLayers();
    void buildButtons();
};
#endif // MEXWIDGET_H
