#include "infowidget.h"
#include <QMessageBox>
#include <QBoxLayout>
#include "errormex.h"
infoWidget::infoWidget(User *a,QWidget *parent):QGroupBox(parent),utente(a){
    acc=dynamic_cast<Account*>(utente);
    modifica=new QPushButton("Modifica Info");
    modiw=new moduserinfowindow(acc);
    connect(modifica,SIGNAL(clicked()),modiw,SLOT(show()));
    connect(modiw,SIGNAL(infoChanged()),this,SLOT(loadLabels()));
    buildLabels();
    loadLabels();
    buildLayers();
}

User* infoWidget::getutente() const{
    return utente;
}

void infoWidget::buildLabels(){
    user=new QLabel();
    nome=new QLabel();
    tipo=new QLabel();
    email=new QLabel();
    ind=new QLabel();
    spec=new QLabel();
    loc=new QLabel();
    web=new QLabel();
    tel=new QLabel();
    nas=new QLabel();
    ob=new QPlainTextEdit();
    ob->setMaximumSize(700,100);
    ob->setMinimumWidth(400);
    ob->setReadOnly(true);
    ob->setTextInteractionFlags(Qt::NoTextInteraction);
    inter=new QPlainTextEdit();
    inter->setMaximumSize(700,100);
    inter->setMinimumWidth(400);
    inter->setReadOnly(true);
    inter->setTextInteractionFlags(Qt::NoTextInteraction);

}

void infoWidget::loadLabels(){
    if(acc){
        tipoAcc tip=acc->checktipoaccount();
        QString temp;
        if(tip==BASIC)
            temp="BASIC";
        else if(tip==BUSINESS)
            temp="BUSINESS";
        else if(tip==EXECUTIVE)
            temp="EXECUTIVE";
        else if(tip==ADMIN)
            temp="ADMIN";
        tipo->setText("Tipo Account: "+temp);
    }
    UserInfo* infos=utente->getinfo();
    user->setText("<b>Username: "+QString::fromStdString(infos->getusername())+"</b>");
    nome->setText("Nome: "+QString::fromStdString(infos->getcognome())+" "+QString::fromStdString(infos->getnome()));
    email->setText("Email: "+QString::fromStdString(infos->getemail()));
    spec->setText("Specializzazione: "+QString::fromStdString(infos->getspec()));
    ind->setText("Indirizzo: "+QString::fromStdString(infos->getindirizzo()));
    loc->setText("Localita: "+QString::fromStdString(infos->getlocalita()));
    web->setText("Web: "+QString::fromStdString(infos->getweb()));
    tel->setText("Telefono: "+QString::fromStdString(infos->gettelefono()));
    nas->setText("Nascita: "+QString::fromStdString(infos->getnascita()));
    ob->setPlainText(QString::fromStdString(infos->getobiettivi()));
    inter->setPlainText(QString::fromStdString(infos->getinteressi()));
}

void infoWidget::buildLayers(){
    //layout degli obiettivi
    QHBoxLayout *hlob=new QHBoxLayout(); //label
    hlob->addWidget(new QLabel("Obiettivi"));
    hlob->addStretch();
    QVBoxLayout *vob=new QVBoxLayout(); //generale
    vob->addLayout(hlob);
    vob->addWidget(ob);
    //layout degli interessi
    QHBoxLayout *hlint=new QHBoxLayout(); //label
    hlint->addWidget(new QLabel("Interessi"));
    hlint->addStretch();
    QVBoxLayout *vint=new QVBoxLayout(); //generale
    vint->addLayout(hlint);
    vint->addWidget(inter);
    //layout totale info
    QVBoxLayout *lay=new QVBoxLayout();
    lay->addWidget(user);
    if(acc) lay->addWidget(tipo);
    lay->addWidget(nome);
    lay->addWidget(email);
    lay->addWidget(ind);
    lay->addWidget(loc);
    lay->addWidget(spec);
    lay->addWidget(web);
    lay->addWidget(tel);
    lay->addWidget(nas);

    QVBoxLayout *v3=new QVBoxLayout();
    QHBoxLayout *hinfo=new QHBoxLayout();
    hinfo->addLayout(lay);
    hinfo->addStretch();
    hinfo->addWidget(modifica);
    v3->addLayout(hinfo);
    v3->addLayout(vob);
    v3->addLayout(vint);
    v3->addStretch();
    setLayout(v3);
}

void infoWidget::disablebuttons(){
    modifica->setVisible(false);
    tipo->setVisible(false);
}

infoWidget::~infoWidget(){
    delete modiw;
}

