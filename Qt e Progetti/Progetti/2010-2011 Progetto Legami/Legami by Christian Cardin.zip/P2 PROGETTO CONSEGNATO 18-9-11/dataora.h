#ifndef DATAORA_H
#define	DATAORA_H
#include <time.h>
#include <sstream>
#include <string>
using std::string;
using std::stringstream;

class dataora{
public:
    dataora();       //inizializza con il timestamp corrente
    dataora(time_t); //inizializza con un timestamp predefinito (es: dal database)
    int ore() const;
    int minuti() const;
    int secondi() const;
    int giorno() const;
    int mese() const;
    int anno() const;
    int stamp() const;
    string getdata() const; //ritorna la data in formato gg/mm/aaaa
    string getora() const;  //ritorna l'ora in formato h:min:sec
    string getdataora() const; //ritorna gg/mm/aaa h:min:sec
    bool operator<(const dataora&) const;
    bool operator>(const dataora&) const;
    bool operator<=(const dataora&) const;
    bool operator>=(const dataora&) const;
    bool operator==(const dataora&) const;
    bool operator!=(const dataora&) const;

private:
    time_t timestamp;
    tm formattedTime;  //puntatore alla struttura contenente le info sul timestamp
                        //utile per non doverla generare ad ogni occorrenza
};


#endif	/* DATAORA_H */

