#ifndef GROUPINFOWIDGET_H
#define GROUPINFOWIDGET_H

#include <QGroupBox>
#include <QLabel>
#include <QTabWidget>
#include <QPushButton>
#include <QScrollArea>
#include <QPlainTextEdit>
#include "modgroupinfowindow.h"
#include "discusswidget.h"
#include "account.h"
#include "gruppo.h"

/*Finestra che raccoglie tutti i dettagli su un gruppo. Deriva da QTabWidget per facilitare una visualizzazione
 * "a cartelle". La prima tab ospita informazioni testuali atte a descrivere il gruppo; l'amministratore può decidere
 * di modificarle attraverso una finestra di modifica che compare premendo il pulsante apposito.
 *La seconda tab crea una lista di contactWidget, che sono gli iscritti al gruppo. Solo gli iscritti al gruppo
 *sono autorizzati a vedere i nomi degli altri iscritti, ma solo l'amministratore o l'admin possono vederne i dettagli.
 *La terza tab mostra una dopo l'altra tutte le discussioni inserendo oggetti discussWidget all'interno di una ScrollArea.
 *
 *Gli iscritti e l'admin possono scrivere messaggi e pubblicare nuove discussioni.
 *Cliccando un contactWidget, si apre una finestra con tutte le informazioni sul suo profilo, opportunamente filtrate
 *a seconda del grado di account del richiedente.
 *
 *La finestra di modifica viene deallocata nel distruttore (se è stata definita).
 *I widget degli iscritti e delle discussioni sono connesse all'evento destroyed() della classe in modo che, quando viene
 *lanciato, si deallochino automaticamente.
 *Tutti gli altri elementi sono distrutti automaticamente.
*/

class groupInfoWidget:public QTabWidget{
    Q_OBJECT
public:
    groupInfoWidget(Gruppo* a,Account* acc,QWidget* parent=0);
    ~groupInfoWidget();
    Gruppo* getgruppo() const;
    void hidetabs();
private slots:
    void removedisc(Discussione*,discussWidget*);
    void loadIscrInfo(Contatto);
    void loadLabels();
    void addDisc();

private:
    Gruppo *gruppo;
    Account *account;
    QLabel *nome,*sett,*creaz,*web;
    QPlainTextEdit *desc,*edit;
    QScrollArea *area;
    QPushButton *modifica;
    QVBoxLayout *vertical;
    modGroupinfowindow *modgiw;

    void buildLayersInfo();
    void buildLabelsInfo();
    void buildIscritti();
    void buildDiscussioni();
};

#endif // GROUPINFOWIDGET_H
