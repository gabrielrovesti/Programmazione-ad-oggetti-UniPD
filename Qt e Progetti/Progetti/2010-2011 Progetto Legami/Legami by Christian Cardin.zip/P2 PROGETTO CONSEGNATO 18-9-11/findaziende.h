#ifndef FINDAZIENDE_H
#define FINDAZIENDE_H

#include <QWidget>
#include "account.h"
namespace Ui {
    class findAziende;
}

/*Finestra di ricerca delle aziende. Viene richiesto di specificare alcuni campi e di impstare le opzioni di ricerca:
 *viene fatto un controllo sul tipo dell'account e vengono abilitate di conseguenza delle funzionalità.
 *Gli oggetti vengono distrutti automaticamente alla distruzione della finestra.
*/
class findAziende : public QWidget{
    Q_OBJECT
public:
    explicit findAziende(Account* acc,QWidget *parent = 0);
    ~findAziende();
signals:
    void findclicked(QString,QString,QString,QString,bool,int);
private slots:
    void findpressed();
public slots:
    bool close();
private:
    void clearFields();
    Account* account;
    Ui::findAziende *ui;
};

#endif // FINDAZIENDE_H
