#ifndef AZIWINDOW_H
#define AZIWINDOW_H

#include <QWidget>
#include <QScrollArea>
#include <QVBoxLayout>
#include <QLineEdit>
#include "findaziende.h"
#include "azinfowidget.h"
#include "newazwindow.h"

/*Implementa la ricerca delle aziende. Dal risultato della ricerca, carica degli azWidgets che, se cliccati,
 *causano l'apertura di un azInfoWidget con le informazioni relative all'azienda selezionata. Un pulsante
 *permette di aggiungere l'azienda selezionata tra le "preferite", e per gli utenti BUSINESS o superiori
 *viene mostrato un pulsante che permette la creazione di nuove aziende. Il tutto è contenuto in ScrollArea
 *per permettere una visualizzazione più compatta in caso di liste molto lunghe.
 *Ogni volta che si visualizzano i dettagli di un'azienda, viene creato un oggetto azinfoWidget. Questo viene
 *distrutto se si vuole vedere un'altra azienda, e quindi ricreato. Alla fine viene distrutto nel distruttore insieme
 *alla finestra di ricerca e di nuova azienda. gli azwidget vengono deallocati nel distruttore con un ciclo.
 */
class aziWindow:public QWidget{
Q_OBJECT
public:
    aziWindow(Account* acc,QWidget *parent=0);
    ~aziWindow();
signals:
    void aziendaAggiunta(Azienda*);
private slots:
    void loadAzi(QString,QString,QString,QString,bool si,int so);
    void createAz(QString,QString,QString,QString,QString,QString,QString,QString,QString,QString);
    void loadInfo(Azienda*);
    void addazienda();

private:
    Account* account;
    findAziende* findaz;
    azinfoWidget *info;
    newAzWindow *naw;
    QScrollArea *searchArea,*infoArea;
    QPushButton *add,*newaz;
    QVBoxLayout *vertical;



};

#endif // AZIWINDOW_H
