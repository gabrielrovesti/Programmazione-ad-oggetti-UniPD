#ifndef FINDCONTATTI_H
#define FINDCONTATTI_H

#include <QWidget>
#include "account.h"
namespace Ui {
    class findContatti;
}

/*Finestra di ricerca dei contatti. Viene richiesto di specificare alcuni campi e di impstare le opzioni di ricerca:
 *viene fatto un controllo sul tipo dell'account e vengono abilitate di conseguenza delle funzionalità.
 *Gli oggetti vengono distrutti automaticamente alla distruzione della finestra.
*/

class findContatti : public QWidget{
    Q_OBJECT
public:
    explicit findContatti(Account* acc,QWidget *parent = 0);
    ~findContatti();
signals:
    void findclicked(QString,QString,QString,QString,QString,bool,int);
private slots:
    void findpressed();
public slots:
    bool close();
private:
    void clearFields();
    Account* account;
    Ui::findContatti *ui;
};

#endif // FINDCONTATTI_H
