/********************************************************************************
** Form generated from reading UI file 'newazwindow.ui'
**
** Created: Sun Sep 18 16:34:32 2011
**      by: Qt User Interface Compiler version 4.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEWAZWINDOW_H
#define UI_NEWAZWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QGridLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPlainTextEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_newAzWindow
{
public:
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_3;
    QVBoxLayout *verticalLayout_2;
    QGridLayout *gridLayout;
    QLabel *label;
    QLineEdit *nome;
    QLabel *label_6;
    QLineEdit *sett;
    QLabel *label_4;
    QLineEdit *tip;
    QLabel *label_2;
    QLineEdit *tel;
    QLabel *label_5;
    QLineEdit *loc;
    QLabel *label_3;
    QLineEdit *web;
    QLabel *label_7;
    QLineEdit *ind;
    QLabel *label_8;
    QLineEdit *email;
    QLabel *label_9;
    QComboBox *dim;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout;
    QLabel *label_10;
    QSpacerItem *verticalSpacer;
    QPlainTextEdit *desc;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer;
    QPushButton *chiudi;
    QPushButton *ok;
    QSpacerItem *horizontalSpacer_2;

    void setupUi(QWidget *newAzWindow)
    {
        if (newAzWindow->objectName().isEmpty())
            newAzWindow->setObjectName(QString::fromUtf8("newAzWindow"));
        newAzWindow->resize(481, 340);
        layoutWidget = new QWidget(newAzWindow);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 10, 462, 321));
        verticalLayout_3 = new QVBoxLayout(layoutWidget);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        nome = new QLineEdit(layoutWidget);
        nome->setObjectName(QString::fromUtf8("nome"));

        gridLayout->addWidget(nome, 0, 1, 1, 1);

        label_6 = new QLabel(layoutWidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        gridLayout->addWidget(label_6, 0, 2, 1, 2);

        sett = new QLineEdit(layoutWidget);
        sett->setObjectName(QString::fromUtf8("sett"));

        gridLayout->addWidget(sett, 0, 4, 1, 1);

        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout->addWidget(label_4, 1, 0, 1, 1);

        tip = new QLineEdit(layoutWidget);
        tip->setObjectName(QString::fromUtf8("tip"));

        gridLayout->addWidget(tip, 1, 1, 1, 1);

        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 1, 2, 1, 1);

        tel = new QLineEdit(layoutWidget);
        tel->setObjectName(QString::fromUtf8("tel"));

        gridLayout->addWidget(tel, 1, 3, 1, 2);

        label_5 = new QLabel(layoutWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout->addWidget(label_5, 2, 0, 1, 1);

        loc = new QLineEdit(layoutWidget);
        loc->setObjectName(QString::fromUtf8("loc"));

        gridLayout->addWidget(loc, 2, 1, 1, 1);

        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout->addWidget(label_3, 2, 2, 1, 1);

        web = new QLineEdit(layoutWidget);
        web->setObjectName(QString::fromUtf8("web"));

        gridLayout->addWidget(web, 2, 3, 1, 2);

        label_7 = new QLabel(layoutWidget);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        gridLayout->addWidget(label_7, 3, 0, 1, 1);

        ind = new QLineEdit(layoutWidget);
        ind->setObjectName(QString::fromUtf8("ind"));

        gridLayout->addWidget(ind, 3, 1, 1, 1);

        label_8 = new QLabel(layoutWidget);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        gridLayout->addWidget(label_8, 3, 2, 1, 1);

        email = new QLineEdit(layoutWidget);
        email->setObjectName(QString::fromUtf8("email"));

        gridLayout->addWidget(email, 3, 3, 1, 2);

        label_9 = new QLabel(layoutWidget);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        gridLayout->addWidget(label_9, 4, 0, 1, 1);

        dim = new QComboBox(layoutWidget);
        dim->setObjectName(QString::fromUtf8("dim"));

        gridLayout->addWidget(dim, 4, 1, 1, 1);


        verticalLayout_2->addLayout(gridLayout);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label_10 = new QLabel(layoutWidget);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        verticalLayout->addWidget(label_10);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);


        horizontalLayout->addLayout(verticalLayout);

        desc = new QPlainTextEdit(layoutWidget);
        desc->setObjectName(QString::fromUtf8("desc"));

        horizontalLayout->addWidget(desc);


        verticalLayout_2->addLayout(horizontalLayout);


        verticalLayout_3->addLayout(verticalLayout_2);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        chiudi = new QPushButton(layoutWidget);
        chiudi->setObjectName(QString::fromUtf8("chiudi"));

        horizontalLayout_2->addWidget(chiudi);

        ok = new QPushButton(layoutWidget);
        ok->setObjectName(QString::fromUtf8("ok"));

        horizontalLayout_2->addWidget(ok);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);


        verticalLayout_3->addLayout(horizontalLayout_2);


        retranslateUi(newAzWindow);

        QMetaObject::connectSlotsByName(newAzWindow);
    } // setupUi

    void retranslateUi(QWidget *newAzWindow)
    {
        newAzWindow->setWindowTitle(QApplication::translate("newAzWindow", "Nuova Azienda", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("newAzWindow", "Nome", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("newAzWindow", "Settore", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("newAzWindow", "Tipo", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("newAzWindow", "Telefono", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("newAzWindow", "Localit\303\240", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("newAzWindow", "Web", 0, QApplication::UnicodeUTF8));
        label_7->setText(QApplication::translate("newAzWindow", "Indirizzo", 0, QApplication::UnicodeUTF8));
        label_8->setText(QApplication::translate("newAzWindow", "Email", 0, QApplication::UnicodeUTF8));
        label_9->setText(QApplication::translate("newAzWindow", "Dimensione", 0, QApplication::UnicodeUTF8));
        label_10->setText(QApplication::translate("newAzWindow", "Descrizione", 0, QApplication::UnicodeUTF8));
        chiudi->setText(QApplication::translate("newAzWindow", "Chiudi", 0, QApplication::UnicodeUTF8));
        ok->setText(QApplication::translate("newAzWindow", "Ok", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class newAzWindow: public Ui_newAzWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEWAZWINDOW_H
