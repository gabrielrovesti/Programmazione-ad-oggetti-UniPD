#include "azwidget.h"
#include <QMessageBox>
#include <QBoxLayout>

azWidget::azWidget(Azienda *a,QWidget *parent):QPushButton(parent),azi(a){
    cancella=new QPushButton("Rimuovi");
    elimina=new QPushButton("Elimina");
    elimina->hide();
    buildLabels();
    buildLayers();

    connect(cancella,SIGNAL(clicked()),this,SLOT(del()));
    connect(elimina,SIGNAL(clicked()),this,SLOT(canc()));
    connect(this,SIGNAL(clicked()),this,SLOT(clickedthis()));
}

void azWidget::buildLabels(){
    AzInfo *info=azi->getinfo();
    nome=new QLabel("<b>"+QString::fromStdString(info->getnome())+"</b>");
    tipo=new QLabel("Tipo: "+QString::fromStdString(info->gettipo()));
    settore=new QLabel("Settore: "+QString::fromStdString(info->getsettore()));
}

void azWidget::buildLayers(){
    QVBoxLayout *v1=new QVBoxLayout();
    QVBoxLayout *v2=new QVBoxLayout();

    QHBoxLayout *h1=new QHBoxLayout();
    //labels
    v1->addWidget(nome);
    v1->addWidget(tipo);
    v1->addWidget(settore);
    v1->addStretch(0);
    //pulsante
    v2->addWidget(cancella);
    v2->addWidget(elimina);
    v2->addStretch(0);
    //main layout
    h1->addLayout(v1);
    h1->addStretch();
    h1->addLayout(v2);

    h1->setSizeConstraint(QLayout::SetMinimumSize);
    setLayout(h1);
    //this
    setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
    setMaximumHeight(90);
}

void azWidget::del(){
    emit deleteClicked(azi,this,1);
}

void azWidget::canc(){
    emit deleteClicked(azi,this,2);
}

void azWidget::clickedthis(){
    emit clicked(azi);
}

void azWidget::showelimina(){
    elimina->setVisible(true);
    cancella->hide();
}

void azWidget::disablebuttons(){
    cancella->setVisible(false);
    elimina->setVisible(false);
    this->setDisabled(true);
}
