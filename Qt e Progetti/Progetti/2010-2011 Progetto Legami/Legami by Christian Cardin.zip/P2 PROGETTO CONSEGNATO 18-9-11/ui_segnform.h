/********************************************************************************
** Form generated from reading UI file 'segnform.ui'
**
** Created: Sun Sep 18 16:34:32 2011
**      by: Qt User Interface Compiler version 4.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SEGNFORM_H
#define UI_SEGNFORM_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QFormLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPlainTextEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_segnForm
{
public:
    QWidget *widget;
    QVBoxLayout *verticalLayout_2;
    QFormLayout *formLayout;
    QLabel *logg;
    QLineEdit *ogg;
    QFormLayout *formLayout_2;
    QVBoxLayout *verticalLayout;
    QLabel *ltex;
    QSpacerItem *verticalSpacer;
    QPlainTextEdit *tex;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QPushButton *chiudi;
    QPushButton *ok;

    void setupUi(QWidget *segnForm)
    {
        if (segnForm->objectName().isEmpty())
            segnForm->setObjectName(QString::fromUtf8("segnForm"));
        segnForm->resize(326, 215);
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(segnForm->sizePolicy().hasHeightForWidth());
        segnForm->setSizePolicy(sizePolicy);
        widget = new QWidget(segnForm);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(10, 10, 305, 191));
        verticalLayout_2 = new QVBoxLayout(widget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        formLayout = new QFormLayout();
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        logg = new QLabel(widget);
        logg->setObjectName(QString::fromUtf8("logg"));

        formLayout->setWidget(0, QFormLayout::LabelRole, logg);

        ogg = new QLineEdit(widget);
        ogg->setObjectName(QString::fromUtf8("ogg"));

        formLayout->setWidget(0, QFormLayout::FieldRole, ogg);


        verticalLayout_2->addLayout(formLayout);

        formLayout_2 = new QFormLayout();
        formLayout_2->setObjectName(QString::fromUtf8("formLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        ltex = new QLabel(widget);
        ltex->setObjectName(QString::fromUtf8("ltex"));

        verticalLayout->addWidget(ltex);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);


        formLayout_2->setLayout(0, QFormLayout::LabelRole, verticalLayout);

        tex = new QPlainTextEdit(widget);
        tex->setObjectName(QString::fromUtf8("tex"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(tex->sizePolicy().hasHeightForWidth());
        tex->setSizePolicy(sizePolicy1);

        formLayout_2->setWidget(0, QFormLayout::FieldRole, tex);


        verticalLayout_2->addLayout(formLayout_2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        chiudi = new QPushButton(widget);
        chiudi->setObjectName(QString::fromUtf8("chiudi"));

        horizontalLayout->addWidget(chiudi);

        ok = new QPushButton(widget);
        ok->setObjectName(QString::fromUtf8("ok"));

        horizontalLayout->addWidget(ok);


        verticalLayout_2->addLayout(horizontalLayout);


        retranslateUi(segnForm);

        QMetaObject::connectSlotsByName(segnForm);
    } // setupUi

    void retranslateUi(QWidget *segnForm)
    {
        segnForm->setWindowTitle(QApplication::translate("segnForm", "Segnala Utente", 0, QApplication::UnicodeUTF8));
        logg->setText(QApplication::translate("segnForm", "Oggetto", 0, QApplication::UnicodeUTF8));
        ltex->setText(QApplication::translate("segnForm", "Testo", 0, QApplication::UnicodeUTF8));
        chiudi->setText(QApplication::translate("segnForm", "Chiudi", 0, QApplication::UnicodeUTF8));
        ok->setText(QApplication::translate("segnForm", "Ok", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class segnForm: public Ui_segnForm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SEGNFORM_H
