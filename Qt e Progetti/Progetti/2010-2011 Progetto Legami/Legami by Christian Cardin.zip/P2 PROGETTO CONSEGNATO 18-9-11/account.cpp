#include "account.h"
#include "gruppo.h"
#include "legami.h"
#include "offerta.h"
#include "azienda.h"

Account::Account(UserInfo* _info,Legami* _l):User(_info),gestore(_l){
    max_risultati=100;
    acc=BASIC;
}

tipoAcc Account::checktipoaccount(){
    return acc;
}

Legami* Account::getgestore() const{return gestore;}

void Account::addcontatto(User* _con, pstring _tag) throw(ErrStateContact){
    gestore->addcontatto(this,_con,_tag);
}

void Account::deletecontatto(User* _con)throw(ErrStateContact){
    vector<Contatto>::iterator it=contatti->begin();
    for(;it!=contatti->end();it++){
        //se trova l'utente lo rimuove dai contatti
        if(_con->getinfo()->getusername()==(*it)->getinfo()->getusername()){
            pstring tag=(*it).gettag();   //preleva il tag
            contatti->erase(it);          //cancella il contatto
            vector< Tag >::iterator ittag=personal_tag->begin();
            while(tag!=(*ittag).first)  //il tag DEVE avere corrispondenza in personal_tag
                ittag++;
            int occorrenze=--(*ittag).second; //decrementa il numero di occorrenze del tag
            if(occorrenze==0)
                personal_tag->erase(ittag);  //se le occorrenze sono 0, elimina il tag dalla lista
            gestore->Save(this);
            return;
        }
        //se il nome di _con è alfabeticamente maggiore del nome corrente, vuol dire
        //che sicuramente non è presente nel resto del vector
        if(_con->getinfo()->getusername()>(*it)->getinfo()->getusername())
            throw ErrStateContact(2,2);
    }
    throw ErrStateContact(2,2);
}

vector<User*> Account::findutenti(pstring user, pstring nome, pstring cogn,
        pstring spec, pstring loc,bool simili,int soglia){
    simili=0;
    soglia=100;
    UserInfo info(user.trimmed(),"",nome.trimmed(),cogn.trimmed(),1,loc.trimmed(),"","",spec.trimmed(),"",0);
    return gestore->findutenti(info,this,simili,soglia,max_risultati);
    
}

vector<int> Account::filtracontatti(pstring dato){
    vector<int> filtrati;
    vector<Contatto>::iterator it=contatti->begin();
    pstring par;
    unsigned int i=0;
    while(i<contatti->size()){
        par=(*it).gettag();
        if(par==dato)
            filtrati.push_back(i);
        i++;
        it++;
    }
    return filtrati;
}
//**************************************INFO************************************
void Account::modifyinfo(pstring _psw,pstring _nome, pstring _cognome,
        pstring _localita, pstring _indirizzo, pstring _spec, pstring _obiet,
        pstring _tel, pstring _web, pstring _interessi)throw(ErrStateInfo){
    quickinfo->modifyInfo(_psw,_nome,_cognome,_localita,_indirizzo,_spec,_obiet,_tel,_web,_interessi);
    gestore->Save(quickinfo,acc,0);
}

void Account::modifygroupinfo(Gruppo* _g, pstring desc, pstring sett, pstring web)throw(ErrStateInfo){
    if(this!=_g->getadmin() && acc!=ADMIN) throw ErrStateInfo(2,0);
    gestore->setgroupinfo(_g,0,desc,sett,web);
}

//*************************CURRICULUM******************************************
Exp* Account::newlavoro(dataora _inizio, dataora _fin, pstring _descr,
        Azienda* _l, pstring _nome, pstring _tit, pstring _ruolo)throw(ErrStateExp){
    if(_l==0){
        if(_nome.trimmed()=="")
            throw ErrStateExp(1,1);
    }else
        _nome=_l->getinfo()->getnome();
    if(_fin!=0)
       if(_inizio>_fin) throw ErrStateExp(2,2);
    if(_inizio>dataora()) throw ErrStateExp(2,4);
    if(_descr.trimmed()=="") throw ErrStateExp(2,3);
    Exp* newexp=curriculum->insertExp(_inizio,_fin,_descr.trimmed(),_l,_nome,_tit,_ruolo);
    gestore->Save(getinfo()->getusername(),curriculum->getexp());
    return newexp;
}

void Account::modifyesperienza(Exp* _exp,dataora _inizio, dataora _fin, pstring _descr,
        pstring _tit, pstring _ruolo)throw(ErrStateExp){
    if(_exp==0) throw ErrStateExp(3,6);
    if(!curriculum->is_presente(_exp))
        throw ErrStateExp(3,7);
    if(_fin!=0)
        if(_inizio>_fin) throw ErrStateExp(3,2);
    if(_inizio>dataora()) throw ErrStateExp(3,4);
    if(_descr.trimmed()=="") throw ErrStateExp(3,3);
    _exp->modify(_inizio,_fin,_descr,_tit,_ruolo);
    gestore->Save(getinfo()->getusername(),curriculum->getexp());
}

void Account::deletelavoro(Exp* _exp)throw(ErrStateExp){
    if(_exp==0) throw ErrStateExp(4,6);
    if(!curriculum->deleteExp(_exp))
        throw ErrStateExp(4,7);
    gestore->Save(getinfo()->getusername(),curriculum->getexp());
    
}

void Account::segnala(User* _destinatario, pstring _oggetto, pstring _testo)throw(ErrStateExp){
    if(_oggetto.trimmed()=="" || _testo.trimmed()=="")
        throw  ErrStateExp(5,6);
    gestore->sendsegn(this,_destinatario,_oggetto,_testo);

}

void Account::deleteSegnalazione(Messaggio* _seg)throw(ErrStateExp){
        if(!curriculum->deleteSeg(_seg))
            throw ErrStateExp(6,8);
        gestore->Save(getinfo()->getusername(),curriculum->getseg());
}

void Account::addSegnalazione(Messaggio* _seg)throw(ErrStateExp){
    curriculum->insertSeg(_seg);
}

//*******************************GRUPPI*****************************************



void Account::addgruppo(Gruppo* _g)throw(ErrStateGroup){
    if(!_g) throw ErrStateGroup(1,1);
    pstring actual;
    pstring g_name=_g->getinfo()->getnome();
    bool superato=false; //indica che non abbiamo ancora trovato un gruppo
                         //che viene dopo in ordine alfabetico di quello da inserire
    vector<Gruppo*>::iterator it=gruppi->begin();
    while(it!=gruppi->end() && !superato){
        actual=(*it)->getinfo()->getnome();
        if(g_name==actual) throw ErrStateGroup(1,2); //esiste già il collegamento con quel gruppo!
        if(g_name>actual) superato=true;
        else it++;
    }
    gestore->iscriviagruppo(this,_g);
    gruppi->insert(it,_g);
}

void Account::removegruppo(Gruppo* _g)throw(ErrStateGroup){
    if(!_g) throw ErrStateGroup(2,1);
    if(_g->getadmin()==this)
        throw ErrStateGroup(2,17);
    vector<Gruppo*>::iterator it=is_presente(_g);
    if(it==gruppi->end()) throw ErrStateGroup(2,3);
    gestore->removedagruppo(this,_g);
    gruppi->erase(it);

}

Gruppo* Account::newgruppo(pstring _nome,   pstring _desc, pstring _settore,
                        pstring _web)throw(ErrStateGroup){
    _nome=_nome.trimmed();_desc=_desc.trimmed();_settore=_settore.trimmed();
    if(_nome=="")throw ErrStateGroup(3,4);;
    if(_desc=="")throw ErrStateGroup(3,6);
    if(_settore=="")throw ErrStateGroup(3,7);
    Gruppo* g=gestore->creategroup(this,_nome, _desc,_settore,_web);
    addgruppo(g);
    return g;
}

void Account::deletegruppo(Gruppo* _g)throw(ErrStateGroup){
    if(!_g) throw ErrStateGroup(4,1);
    gestore->deletegroup(this,_g);
}

Discussione* Account::makediscussione(Gruppo* _g, pstring tit)throw(ErrStateGroup){
    if(!_g) throw ErrStateGroup(5,1);
    vector<Gruppo*>::const_iterator it=is_presente(_g);
    if(acc!= ADMIN && it==gruppi->end()) throw ErrStateGroup(5,3);
    pstring t=tit.trimmed();
    if(t=="")throw ErrStateGroup(5,14);
    return gestore->adddiscussione(_g,this,t);

}

void Account::deletediscussione(Gruppo *g, Discussione *disc)throw(ErrStateGroup){
    if(!g) throw ErrStateGroup(5,1);
    vector<Gruppo*>::const_iterator it=is_presente(g);
    if(it==gruppi->end()) throw ErrStateGroup(5,3);
    if(g->getadmin()!=this && acc!=ADMIN) throw ErrStateGroup(5,13);  //non è admin o amministratore
    gestore->deletediscussione(g,disc);
}

Messaggio* Account::makepost(Gruppo* _g, Discussione* _d, pstring text, pstring ogg)throw(ErrStateGroup){
    if(!_g) throw ErrStateGroup(6,1);
    vector<Gruppo*>::const_iterator it=is_presente(_g);
    if(it==gruppi->end()) throw ErrStateGroup(6,3);
    pstring t=text.trimmed();
    if(t=="")throw ErrStateGroup(5,14);
    return gestore->addpost(_g,_d,this,t,ogg);
}

vector<Gruppo*> Account::findgruppi(pstring nome, pstring sett, bool simili,int soglia){
    GroupInfo gr(nome.trimmed(),"",sett.trimmed(),0);
    simili=0;
    soglia=100;
    return gestore->findgruppi(gr,simili,soglia,max_risultati);
}

void Account::addazienda(Azienda* _a)throw(ErrStateAz){
    if(!_a) throw ErrStateAz(1,1);
    pstring actual;
    pstring a_name=_a->getinfo()->getnome();
    bool superato=false; 
    vector<Azienda*>::iterator it=aziende->begin();
    while(it!=aziende->end() && !superato){
        actual=(*it)->getinfo()->getnome();
        if(a_name==actual) throw ErrStateAz(1,2); //esiste già il collegamento con quell'azienda!
        if(a_name>actual) superato=true;
        else it++;
    }
    aziende->insert(it,_a);
    gestore->Save(this);
}

void Account::removeazienda(Azienda* _a)throw(ErrStateAz){
    if(!_a) throw ErrStateAz(2,1);                //link invalido
    if(_a->getadmin()==this) throw ErrStateAz(2,15);//è amministratore dell'azienda, non si può rimuovere
    bool superato=false;
    vector<Azienda*>::iterator it=aziende->begin();
    while(it!=aziende->end() && !superato){
        if(_a==(*it)) superato=true;
        else it++;
    }
    if(it==aziende->end()) throw ErrStateAz(2,3);
    aziende->erase(it);
    gestore->Save(this);
}

vector<Azienda*> Account::findaziende(pstring nome, pstring sett, pstring tipo, 
        pstring loc,bool simili,int soglia){
    simili=false;
    soglia=100;
    AzInfo az(nome.trimmed(),loc.trimmed(),"",sett.trimmed(),"",tipo.trimmed(),"");
    return gestore->findaziende(az,simili,soglia,max_risultati);
}

Azienda* Account::newazienda(pstring nome,pstring localita, pstring indirizzo, pstring settore, pstring descrizione,
                         pstring t, pstring dimensione, pstring web, pstring telefono, pstring email)throw (ErrStateAz){
    return 0;
}

void Account::modifyazinfo(Azienda *a, pstring localita, pstring indirizzo, pstring descrizione,
                           pstring dimensione, pstring web, pstring telefono, pstring email)throw (ErrStateInfo){
    return;
}

void Account::deleteazienda(Azienda *a)throw (ErrStateAz){
    return;
}

vector<Azienda*> Account::get_paziende() const{
    return vector<Azienda*>();
}


void Account::candidatiaofferta(Offerta* _o)throw(ErrStateOff){
    if(!_o) throw ErrStateOff(1,1);
    gestore->candidautente(this,_o);
}

void Account::toglidaofferta(Offerta* _o)throw(ErrStateOff){
    if(!_o) throw ErrStateOff(2,15);
    gestore->toglicandidatura(this,_o);
}

vector<Offerta*> Account::findofferte(pstring tit, pstring sett, pstring gior,
        pstring loc, pstring desc,bool simili,int soglia){
    simili=false;
    soglia=100;
    Offerta off(-1,tit.trimmed(),loc.trimmed(),"",sett.trimmed(),desc.trimmed(),gior.trimmed(),"",0);
    return gestore->findofferte(off,simili,soglia,max_risultati);
}

vector<Offerta*>* Account::get_poff() const{
    return NULL;
}

void Account::deleteofferta(Offerta *o)throw(ErrStateOff){
    return;
}

Offerta* Account::newofferta(pstring tit, pstring loc, pstring ind, pstring sett,
                         pstring desc, pstring gior, pstring esp, Azienda *az, pstring spec){
    return 0;
}

//*****************************BUSINESS****************************************

Business::Business(UserInfo* _info, Legami* _l):Account(_info,_l){
    max_risultati=400;
    acc=BUSINESS;
}

Azienda* Business::newazienda(pstring nome, pstring localita, pstring indirizzo,
         pstring settore,pstring descrizione,pstring t, pstring dimensione, pstring web,
        pstring telefono,pstring email)throw (ErrStateAz){
    localita=localita.trimmed();
    nome=nome.trimmed();
    indirizzo=indirizzo.trimmed();
    settore=settore.trimmed();
    descrizione=descrizione.trimmed();
    t=t.trimmed();
    dimensione=dimensione.trimmed();
    web=web.trimmed();
    telefono=telefono.trimmed();
    email=email.trimmed();
    if(nome=="")throw ErrStateAz(3,4);
    if(localita=="")throw ErrStateAz(3,5);
    if(indirizzo=="")throw ErrStateAz(3,6);
    if(settore=="")throw ErrStateAz(3,7);
    if(descrizione=="")throw ErrStateAz(3,8);
    if(t=="")throw ErrStateAz(3,9);
    if(dimensione=="")throw ErrStateAz(3,10);
    Azienda* a=gestore->createaz(this,nome,   localita,
            indirizzo, settore, descrizione, t,
            dimensione, web, telefono, email);
    addazienda(a);
    return a;
}

void Business::modifyazinfo(Azienda* a,  pstring localita,
        pstring indirizzo, pstring descrizione, pstring dimensione, pstring web,
        pstring telefono, pstring email)throw(ErrStateInfo){
    gestore->setazinfo(a,this, localita,indirizzo,descrizione,dimensione,web,telefono,email);
}

void Business::deleteazienda(Azienda* a)throw(ErrStateAz){
    if(!a) throw ErrStateAz(4,1);
    if(acc!=ADMIN && a->getadmin()!=this) throw ErrStateAz(4,13);
    gestore->deleteaz(this,a);
}

vector<Azienda*> Business::get_paziende() const{
    vector<Azienda*>::const_iterator it=aziende->begin();
    vector<Azienda*> p_az;
    while(it<aziende->end()){
        if((*it)->getadmin()==this)     //se è amministratore
            p_az.push_back(*it);
        it++;
    }
    return p_az;
}

vector<User*> Business::findutenti(pstring user, pstring nome, pstring cogn, pstring spec, pstring loc, bool simili,int soglia){
    soglia=50;
    UserInfo info(user.trimmed(),"",nome.trimmed(),cogn.trimmed(),1,loc.trimmed(),"","",spec.trimmed(),"",0);
    return gestore->findutenti(info,this,simili,soglia,max_risultati);
}
vector<Offerta*> Business::findofferte(pstring tit, pstring sett, pstring gior, pstring loc, pstring desc, bool simili,int soglia){
    soglia=50;
    Offerta off(-1,tit.trimmed(),loc.trimmed(),"",sett.trimmed(),desc.trimmed(),gior.trimmed(),"",0);
    return gestore->findofferte(off,simili,soglia,max_risultati);
}
vector<Azienda*> Business::findaziende(pstring nome, pstring sett, pstring tipo, pstring loc, bool simili,int soglia){
    AzInfo az(nome.trimmed(),loc.trimmed(),"","",sett.trimmed(),"",tipo.trimmed(),"");
    soglia=50;
    return gestore->findaziende(az,simili,soglia,max_risultati);
}
vector<Gruppo*> Business::findgruppi(pstring nome, pstring sett, bool simili,int soglia){
    GroupInfo gr(nome.trimmed(),"",sett.trimmed(),0);
    soglia=50;
    return gestore->findgruppi(gr,simili,soglia,max_risultati);
}



//*****************************EXECUTIVE****************************************


Executive::Executive(UserInfo* _info, Legami* _l):Business(_info,_l){
    max_risultati=800;
    off_proposte=new vector<Offerta*>;
    acc=EXECUTIVE;
}

vector<Offerta*>* Executive::get_poff() const{
    return off_proposte;
}

Offerta* Executive::newofferta(pstring tit, pstring loc, pstring ind, pstring sett,
            pstring desc, pstring gior, pstring esp, Azienda *az, pstring spec){
    tit=tit.trimmed();
    if(tit=="")throw ErrStateOff(3,1);
    loc=loc.trimmed();
    if(loc=="")throw ErrStateOff(3,2);
    ind=ind.trimmed();
    if(ind=="")throw ErrStateOff(3,3);
    sett=sett.trimmed();
    if(sett=="")throw ErrStateOff(3,4);
    desc=desc.trimmed();
    if(desc=="")throw ErrStateOff(3,5);
    gior=gior.trimmed();
    if(gior=="")throw ErrStateOff(3,6);
    esp=esp.trimmed();
    if(esp=="")throw ErrStateOff(3,8);

    Offerta* o=gestore->createoffer(this,tit,loc,ind,sett,desc,gior,esp,az,spec);
    off_proposte->push_back(o);
    return o;
}

void Executive::deleteofferta(Offerta* o)throw(ErrStateOff){
    if(!o) throw ErrStateOff(4,15);
    gestore->deleteoff(this,o);
}

Executive::~Executive(){
off_proposte->clear();
delete off_proposte;
}

vector<User*> Executive::findutenti(pstring user, pstring nome, pstring cogn, pstring spec, pstring loc, bool simili,int soglia){
    UserInfo info(user.trimmed(),"",nome.trimmed(),cogn.trimmed(),1,loc.trimmed(),"","",spec.trimmed(),"",0);
    return gestore->findutenti(info,this,simili,soglia,max_risultati);
}
vector<Offerta*> Executive::findofferte(pstring tit, pstring sett, pstring gior, pstring loc, pstring desc, bool simili,int soglia){
    Offerta off(-1,tit.trimmed(),loc.trimmed(),"",sett.trimmed(),desc.trimmed(),gior.trimmed(),"",0);
    return gestore->findofferte(off,simili,soglia,max_risultati);
}
vector<Azienda*> Executive::findaziende(pstring nome, pstring sett, pstring tipo, pstring loc, bool simili,int soglia){
    AzInfo az(nome.trimmed(),loc.trimmed(),"","",sett.trimmed(),"",tipo.trimmed(),"");
    return gestore->findaziende(az,simili,soglia,max_risultati);
}
vector<Gruppo*> Executive::findgruppi(pstring nome, pstring sett, bool simili,int soglia){
    GroupInfo gr(nome.trimmed(),"",sett.trimmed(),0);
    return gestore->findgruppi(gr,simili,soglia,max_risultati);
}
Admin::Admin(UserInfo* _info, Legami* _l):Executive(_info,_l){
    acc=ADMIN;
    max_risultati=1000000;
}
