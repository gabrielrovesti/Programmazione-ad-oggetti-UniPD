#ifndef GRUPPO_H
#define	GRUPPO_H
#include "info.h"
#include "discussione.h"
#include "link.h"
#include <vector>
using std::vector;
class Offerta;

class Gruppo{
private:
    GroupInfo* quickinfo;
    User* amministratore;
    vector<User*> *iscritti;
    vector<Discussione*> *discussioni;
    vector<User*>::iterator position(User*) const;
public:
    Gruppo(GroupInfo* _info,User* admin,vector<User*>* _iscr=new vector<User*>,
            vector<Discussione*>* _disc=new vector<Discussione*>);

    GroupInfo* getinfo() const;
    User* getadmin() const;
    bool is_iscritto(User*) const;
    vector<User*>* getiscritti() const;
    vector<Discussione*>* getdiscussioni() const;

    //l'inserimento avviene sempre in coda: infatti i nuovi iscritti vengono visualizzati per ultimi
    void setadmin(User*);
    bool addUtente(User*);
    bool removeutente(User*);
    void newdiscussione(Discussione*);
    bool removediscussione(Discussione*);

    ~Gruppo();

};


#endif	/* GRUPPO_H */

