#include "groupinfowidget.h"
#include "userinfowindow.h"
#include "groupwidget.h"
#include "errormex.h"
#include <QMessageBox>
#include <QBoxLayout>

groupInfoWidget::groupInfoWidget(Gruppo *a,Account* acc,QWidget *parent):QTabWidget(parent),gruppo(a),account(acc){

    modifica=new QPushButton("Modifica Info");
    modifica->setVisible(false);
    modgiw=0;
    if(gruppo->getadmin()==account || account->checktipoaccount()==ADMIN){    //se è admin, visualizza il pulsante di modifica
        modgiw=new modGroupinfowindow(a,acc);
        connect(modifica,SIGNAL(clicked()),modgiw,SLOT(show()));
        modifica->setVisible(true);
        connect(modgiw,SIGNAL(infoChanged()),this,SLOT(loadLabels()));
    }
    buildLabelsInfo();
    buildLayersInfo();
    if(gruppo->is_iscritto(account) || account->checktipoaccount()==ADMIN){ //solo gli iscritti i gli admin possono vedere le discussioni
        buildIscritti();
        buildDiscussioni();
    }

    this->setMaximumHeight(500);
    this->setMinimumHeight(500);
    this->setWindowTitle("Dettaglio Gruppo");
    this->setAttribute(Qt::WA_DeleteOnClose);
}

void groupInfoWidget::buildLabelsInfo(){
    nome=new QLabel();
    sett=new QLabel();
    creaz=new QLabel();
    web=new QLabel();
    desc=new QPlainTextEdit();
    desc->setReadOnly(true);
    desc->setTextInteractionFlags(Qt::NoTextInteraction);
    desc->setMaximumSize(700,70);
    desc->setMinimumWidth(400);
    loadLabels();
}

void groupInfoWidget::loadLabels(){
    GroupInfo* info=gruppo->getinfo();
    nome->setText("<b>Nome Gruppo: "+QString::fromStdString(info->getnome())+"</b>");
    sett->setText("Settore: "+QString::fromStdString(info->getsettore()));
    web->setText("Sito Web: "+QString::fromStdString(info->getweb()));
    creaz->setText("Data Creazione: "+QString::fromStdString(info->getcreazione()));
    desc->setPlainText(QString::fromStdString(info->getdesc()));
}

void groupInfoWidget::buildLayersInfo(){
    //layout descrizione
    QHBoxLayout *hldesc=new QHBoxLayout(); //label
    hldesc->addWidget(new QLabel("Descrizione"));
    hldesc->addStretch();
    QVBoxLayout *vdesc=new QVBoxLayout(); //generale
    vdesc->addLayout(hldesc);
    vdesc->addWidget(desc);

    //layout totale info
    QVBoxLayout *lay=new QVBoxLayout();
    lay->addWidget(nome);
    lay->addWidget(sett);
    lay->addWidget(web);
    lay->addWidget(creaz);


    QVBoxLayout *v3=new QVBoxLayout();
    QHBoxLayout *hinfo=new QHBoxLayout();
    hinfo->addLayout(lay);
    hinfo->addStretch();
    hinfo->addWidget(modifica);
    v3->addLayout(hinfo);
    v3->addLayout(vdesc);
    v3->addStretch();
    QGroupBox *infobox=new QGroupBox("");      //imposta il widget da inserire nella tab
    infobox->setLayout(v3);
    this->addTab(infobox,"Informazioni");

}

void groupInfoWidget::buildIscritti(){
    vector<User*>* contacts=gruppo->getiscritti();
    QVBoxLayout *vertical= new QVBoxLayout();
    tipoAcc tipo=account->checktipoaccount();
     //numero risultati
    QLabel *resoult=new QLabel(QString::number(contacts->size())+" Iscritti");
    QFrame *line=new QFrame();
    line->setFrameShape(QFrame::HLine);
    vertical->addWidget(resoult);
    vertical->addWidget(line);
    if(gruppo->is_iscritto(account) || tipo==ADMIN){   //se ha i requisiti necessari per vedere gli iscritti
        contactWidget *temp;
        bool disabilita=false;
        if(account!= gruppo->getadmin() && tipo !=ADMIN)  //solo l'admin e l'amministratore possono vedere i dettagli
            disabilita=true;                              //degli iscritti direttamente
        for(int i=contacts->size()-1;i>=0;i--){       //scorre il vettore in ordine inverso e crea i Widgets
            temp=new contactWidget((*contacts)[i]);
            connect(temp,SIGNAL(clicked(Contatto)),this,SLOT(loadIscrInfo(Contatto)));
            connect(this,SIGNAL(destroyed()),temp,SLOT(deleteLater()));   //distrugge il widget alla distruzione di questa finestra
            if(disabilita)
                temp->setDisabled(true);
            vertical->addWidget(temp);
        }
    }
    vertical->addStretch();
    QGroupBox *cbox=new QGroupBox("");
    cbox->setLayout(vertical);
    this->addTab(cbox,"Iscritti");
}

void groupInfoWidget::buildDiscussioni(){
    vertical= new QVBoxLayout();
    edit=new QPlainTextEdit();         //costruisce per prima la lineedit
    edit->setMaximumSize(700,80);
    edit->setMinimumWidth(350);

    QVBoxLayout *v1=new QVBoxLayout();
    QPushButton *insert=new QPushButton("Scrivi Discussione");
    connect(insert,SIGNAL(clicked()),this,SLOT(addDisc()));
    v1->addWidget(insert);
    //v1->addStretch();
    QHBoxLayout *lineedit=new QHBoxLayout();
    lineedit->addWidget(edit);
    lineedit->addLayout(v1);
    vertical->addLayout(lineedit);

    QFrame *line=new QFrame();
    line->setFrameShape(QFrame::HLine);
    vertical->addWidget(line);              //fine lineedit

    vector<Discussione*>* disc=gruppo->getdiscussioni();
    tipoAcc tipo=account->checktipoaccount();
    bool disabilita=true;
    if(tipo==ADMIN || gruppo->getadmin()==account)  //se è admin o amministratore, tiene attivo il pulsante cancellazione;
        disabilita=false;
    discussWidget *temp;
    for(unsigned int i=0;i<disc->size();i++){       //scorre il vettore e crea i discussWidgets
        temp=new discussWidget(gruppo,(*disc)[i],account);
        if(disabilita) temp->disablebuttons();   //se non ha i requisiti disabilita il pulsante di elimina
        connect(temp,SIGNAL(deleteClicked(Discussione*,discussWidget*)),this,SLOT(removedisc(Discussione*,discussWidget*)));
        connect(this,SIGNAL(destroyed()),temp,SLOT(deleteLater()));
        vertical->addWidget(temp);
    }

    vertical->addStretch();
    QGroupBox *dBox=new QGroupBox("");
    dBox->setLayout(vertical);
    QScrollArea *area3=new QScrollArea();
    area3->setWidgetResizable(true);      //permette di rimodellare il widget se cambia le dimensioni
    area3->setWidget(dBox);
    area3->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
    this->addTab(area3,"Discussioni");
}

void groupInfoWidget::removedisc(Discussione *disc, discussWidget *wid){
    int r=QMessageBox::warning(this,"Richiesta di conferma","Sei sicuro di voler cancellare la discussione e tutti i commenti?",
                               QMessageBox::Yes,QMessageBox::No);
    if(r==QMessageBox::Yes){
        try{
            account->deletediscussione(gruppo,disc);
        }
        catch(ErrState e){
            ErrorMex *err=new ErrorMex(e);
            err->show();
            return;
        }
        wid->disconnect();
        delete wid;
    }
}

void groupInfoWidget::addDisc(){
    QString contenuto=edit->toPlainText().trimmed();
    edit->setPlainText("");
    Discussione* discussione;
    if(contenuto=="")             //se è vuoto non fa nulla
        return;
    try{
        discussione=account->makediscussione(gruppo,contenuto.toStdString());
    }
    catch(ErrState e){
        ErrorMex *err=new ErrorMex(e);
        err->show();
        return;
    }
    discussWidget *temp=new discussWidget(gruppo,discussione,account);
    if(account->checktipoaccount()!=ADMIN && gruppo->getadmin()!=account) temp->disablebuttons();   //se non ha i requisiti disabilita il pulsante di elimina
    connect(temp,SIGNAL(deleteClicked(Discussione*,discussWidget*)),this,SLOT(removedisc(Discussione*,discussWidget*)));
    delete vertical->takeAt(vertical->count()-1)->spacerItem();  //rimuove lo stretch finale
    vertical->addWidget(temp);
    vertical->addStretch();
}

void groupInfoWidget::loadIscrInfo(Contatto contact){
    UserInfoWindow *info=new UserInfoWindow(static_cast<Account*>(*contact));
    info->show(account);
}
Gruppo* groupInfoWidget::getgruppo() const{
    return gruppo;
}

void groupInfoWidget::hidetabs(){
    removeTab(2);
    removeTab(1);
}

groupInfoWidget::~groupInfoWidget(){
    if(modgiw)
        delete modgiw;
}
