#ifndef GROUPWIDGET_H
#define GROUPWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QPushButton>
#include <QPlainTextEdit>
#include "account.h"
#include "gruppo.h"

/*Pulsante gruppo: Derivato da QPushButton, contiene brevi informazioni riepilogative sul gruppo che rappresenta.
 *Se cliccato, emette un segnale apposito specificando il gruppo a cui il widget si riferisce.
 *presenta degli slots dai quali è possibile visualizzare o meno pulsanti per accedere alle funzionalità.
 *Gli oggetti contenuti vengono distrutti automaticamente alla distruzione del Widget.
*/

class groupWidget:public QPushButton{
    Q_OBJECT
public:
    groupWidget(Gruppo* a,QWidget* parent=0);
    void showelimina();
signals:
    void deleteClicked(Gruppo*,groupWidget*,int);
    void clicked(Gruppo*);
public slots:
    void clickedthis();
    void del();
    void canc();
    void disablebuttons();
private:

    Gruppo* group;
    QLabel *nome,*data,*prop;
    QPushButton *cancella,*elimina;
    void buildLayers();
    void buildLabels();
};

#endif // GROUPWIDGET_H
