#include "contactwidget.h"
#include "userinfowindow.h"
#include "errormex.h"
#include <QMessageBox>
#include <QBoxLayout>
contactWidget::contactWidget(Contatto c,Account* acc,QWidget *parent):QPushButton(parent),account(acc),contatto(c){
    if(account){
        segn=new segnForm(QString::fromStdString(contatto->getinfo()->getusername()));
        connect(segn,SIGNAL(okpressed(QString,QString)),this,SLOT(makesegnalazione(QString,QString)));
        buildButtons();
    }
    buildLabels();
    buildLayers();
    connect(this,SIGNAL(clicked()),this,SLOT(cliccato()));
    this->setMinimumHeight(70);
    this->setMaximumHeight(130);
}

void contactWidget::buildButtons(){
    cancella=new QPushButton("Cancella");
    segnala=new QPushButton("Segnala");
    connect(cancella,SIGNAL(clicked()),this,SLOT(del()));
    connect(segnala,SIGNAL(clicked()),segn,SLOT(show()));
}

void contactWidget::buildLabels(){
    UserInfo* info=contatto->getinfo();
    user=new QLabel("<b>Username: "+QString::fromStdString(info->getusername())+"</b>");
    nome=new QLabel("Nome: "+QString::fromStdString(info->getcognome())+" "+QString::fromStdString(info->getnome()));
    if(account){
        spec=new QLabel("Specializzazione: "+QString::fromStdString(info->getspec()));
        loc=new QLabel("Localita: "+QString::fromStdString(info->getlocalita()));
        tag=new QLabel("Tag: "+QString::fromStdString(contatto.gettag()));
    }
}

void contactWidget::buildLayers(){

    //layout generale
    QVBoxLayout *v1=new QVBoxLayout();
    QVBoxLayout *v2=new QVBoxLayout();
    QVBoxLayout *v3=new QVBoxLayout();
    QHBoxLayout *h1=new QHBoxLayout();
    v1->addWidget(user);
    if(account) v1->addWidget(tag);
    v1->addWidget(nome);
    if(account){
        v1->addWidget(spec);
        v1->addWidget(loc);
        v1->addStretch();
    }
    if(account){
        v2->addWidget(segnala);
        v2->addWidget(cancella);
        v2->addStretch();
        h1->addLayout(v1);
        h1->addStretch();
        h1->addLayout(v2);
        v3->setSizeConstraint(QLayout::SetMinimumSize);
        v3->addLayout(h1);
        v3->addStretch();
        setLayout(v3);
    }
    else
        setLayout(v1);
    setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
}

void contactWidget::del(){
    emit deleteClicked(dynamic_cast<Account*>(*contatto),this);
}

void contactWidget::cliccato(){
    emit clicked(contatto);
}

void contactWidget::makesegnalazione(QString ogg, QString text){
    try{
        account->segnala(*contatto,ogg.toStdString(),text.toStdString());
    }
    catch(ErrState e){
        ErrorMex *werr=new ErrorMex(e);
        werr->show();
        return;
    }
    OkMex* mex=new OkMex("Segnalazione effettuata","La segnalazione e' stata inviata correttamente!");
    mex->show();
}

void contactWidget::disablebuttons(){
    this->setDisabled(true);
    this->setFlat(true);
    cancella->setVisible(false);
    segnala->setVisible(false);
}
