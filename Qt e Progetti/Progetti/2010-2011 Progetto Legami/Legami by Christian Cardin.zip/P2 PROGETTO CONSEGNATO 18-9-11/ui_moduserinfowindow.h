/********************************************************************************
** Form generated from reading UI file 'moduserinfowindow.ui'
**
** Created: Sun Sep 18 16:34:32 2011
**      by: Qt User Interface Compiler version 4.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MODUSERINFOWINDOW_H
#define UI_MODUSERINFOWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QFormLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QTextEdit>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_moduserinfowindow
{
public:
    QWidget *widget;
    QVBoxLayout *verticalLayout_5;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout_3;
    QFormLayout *formLayout;
    QLabel *label;
    QLineEdit *lpass;
    QFormLayout *formLayout_2;
    QLabel *label_11;
    QLineEdit *lnome;
    QFormLayout *formLayout_3;
    QLabel *label_9;
    QLineEdit *lcogn;
    QFormLayout *formLayout_4;
    QLabel *label_2;
    QLineEdit *lspec;
    QFormLayout *formLayout_9;
    QVBoxLayout *verticalLayout;
    QLabel *label_5;
    QSpacerItem *verticalSpacer;
    QTextEdit *linter;
    QVBoxLayout *verticalLayout_4;
    QFormLayout *formLayout_5;
    QLabel *label_6;
    QLineEdit *lind;
    QFormLayout *formLayout_6;
    QLabel *label_7;
    QLineEdit *lloc;
    QFormLayout *formLayout_7;
    QLabel *label_8;
    QLineEdit *ltel;
    QFormLayout *formLayout_8;
    QLabel *label_3;
    QLineEdit *lweb;
    QFormLayout *formLayout_10;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_10;
    QSpacerItem *verticalSpacer_2;
    QTextEdit *lob;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer;
    QPushButton *chiudi;
    QPushButton *ok;
    QSpacerItem *horizontalSpacer_2;

    void setupUi(QWidget *moduserinfowindow)
    {
        if (moduserinfowindow->objectName().isEmpty())
            moduserinfowindow->setObjectName(QString::fromUtf8("moduserinfowindow"));
        moduserinfowindow->resize(694, 315);
        widget = new QWidget(moduserinfowindow);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(10, 10, 670, 291));
        verticalLayout_5 = new QVBoxLayout(widget);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(0, 0, 0, 0);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        formLayout = new QFormLayout();
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label);

        lpass = new QLineEdit(widget);
        lpass->setObjectName(QString::fromUtf8("lpass"));
        lpass->setEchoMode(QLineEdit::Password);

        formLayout->setWidget(0, QFormLayout::FieldRole, lpass);


        verticalLayout_3->addLayout(formLayout);

        formLayout_2 = new QFormLayout();
        formLayout_2->setObjectName(QString::fromUtf8("formLayout_2"));
        label_11 = new QLabel(widget);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        formLayout_2->setWidget(0, QFormLayout::LabelRole, label_11);

        lnome = new QLineEdit(widget);
        lnome->setObjectName(QString::fromUtf8("lnome"));

        formLayout_2->setWidget(0, QFormLayout::FieldRole, lnome);


        verticalLayout_3->addLayout(formLayout_2);

        formLayout_3 = new QFormLayout();
        formLayout_3->setObjectName(QString::fromUtf8("formLayout_3"));
        label_9 = new QLabel(widget);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        formLayout_3->setWidget(0, QFormLayout::LabelRole, label_9);

        lcogn = new QLineEdit(widget);
        lcogn->setObjectName(QString::fromUtf8("lcogn"));

        formLayout_3->setWidget(0, QFormLayout::FieldRole, lcogn);


        verticalLayout_3->addLayout(formLayout_3);

        formLayout_4 = new QFormLayout();
        formLayout_4->setObjectName(QString::fromUtf8("formLayout_4"));
        label_2 = new QLabel(widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        formLayout_4->setWidget(0, QFormLayout::LabelRole, label_2);

        lspec = new QLineEdit(widget);
        lspec->setObjectName(QString::fromUtf8("lspec"));

        formLayout_4->setWidget(0, QFormLayout::FieldRole, lspec);


        verticalLayout_3->addLayout(formLayout_4);

        formLayout_9 = new QFormLayout();
        formLayout_9->setObjectName(QString::fromUtf8("formLayout_9"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label_5 = new QLabel(widget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        verticalLayout->addWidget(label_5);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);


        formLayout_9->setLayout(0, QFormLayout::LabelRole, verticalLayout);

        linter = new QTextEdit(widget);
        linter->setObjectName(QString::fromUtf8("linter"));

        formLayout_9->setWidget(0, QFormLayout::FieldRole, linter);


        verticalLayout_3->addLayout(formLayout_9);


        horizontalLayout->addLayout(verticalLayout_3);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        formLayout_5 = new QFormLayout();
        formLayout_5->setObjectName(QString::fromUtf8("formLayout_5"));
        label_6 = new QLabel(widget);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        formLayout_5->setWidget(0, QFormLayout::LabelRole, label_6);

        lind = new QLineEdit(widget);
        lind->setObjectName(QString::fromUtf8("lind"));

        formLayout_5->setWidget(0, QFormLayout::FieldRole, lind);


        verticalLayout_4->addLayout(formLayout_5);

        formLayout_6 = new QFormLayout();
        formLayout_6->setObjectName(QString::fromUtf8("formLayout_6"));
        label_7 = new QLabel(widget);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        formLayout_6->setWidget(0, QFormLayout::LabelRole, label_7);

        lloc = new QLineEdit(widget);
        lloc->setObjectName(QString::fromUtf8("lloc"));

        formLayout_6->setWidget(0, QFormLayout::FieldRole, lloc);


        verticalLayout_4->addLayout(formLayout_6);

        formLayout_7 = new QFormLayout();
        formLayout_7->setObjectName(QString::fromUtf8("formLayout_7"));
        label_8 = new QLabel(widget);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        formLayout_7->setWidget(0, QFormLayout::LabelRole, label_8);

        ltel = new QLineEdit(widget);
        ltel->setObjectName(QString::fromUtf8("ltel"));

        formLayout_7->setWidget(0, QFormLayout::FieldRole, ltel);


        verticalLayout_4->addLayout(formLayout_7);

        formLayout_8 = new QFormLayout();
        formLayout_8->setObjectName(QString::fromUtf8("formLayout_8"));
        label_3 = new QLabel(widget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        formLayout_8->setWidget(0, QFormLayout::LabelRole, label_3);

        lweb = new QLineEdit(widget);
        lweb->setObjectName(QString::fromUtf8("lweb"));

        formLayout_8->setWidget(0, QFormLayout::FieldRole, lweb);


        verticalLayout_4->addLayout(formLayout_8);

        formLayout_10 = new QFormLayout();
        formLayout_10->setObjectName(QString::fromUtf8("formLayout_10"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        label_10 = new QLabel(widget);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        verticalLayout_2->addWidget(label_10);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer_2);


        formLayout_10->setLayout(0, QFormLayout::LabelRole, verticalLayout_2);

        lob = new QTextEdit(widget);
        lob->setObjectName(QString::fromUtf8("lob"));

        formLayout_10->setWidget(0, QFormLayout::FieldRole, lob);


        verticalLayout_4->addLayout(formLayout_10);


        horizontalLayout->addLayout(verticalLayout_4);


        verticalLayout_5->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        chiudi = new QPushButton(widget);
        chiudi->setObjectName(QString::fromUtf8("chiudi"));

        horizontalLayout_2->addWidget(chiudi);

        ok = new QPushButton(widget);
        ok->setObjectName(QString::fromUtf8("ok"));

        horizontalLayout_2->addWidget(ok);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);


        verticalLayout_5->addLayout(horizontalLayout_2);


        retranslateUi(moduserinfowindow);

        QMetaObject::connectSlotsByName(moduserinfowindow);
    } // setupUi

    void retranslateUi(QWidget *moduserinfowindow)
    {
        moduserinfowindow->setWindowTitle(QApplication::translate("moduserinfowindow", "Form", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("moduserinfowindow", "*Password", 0, QApplication::UnicodeUTF8));
        label_11->setText(QApplication::translate("moduserinfowindow", "*Nome", 0, QApplication::UnicodeUTF8));
        label_9->setText(QApplication::translate("moduserinfowindow", "*Cognome", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("moduserinfowindow", "*Specialita'", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("moduserinfowindow", "Interessi", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("moduserinfowindow", "*Indirizzo", 0, QApplication::UnicodeUTF8));
        label_7->setText(QApplication::translate("moduserinfowindow", "*Localita'", 0, QApplication::UnicodeUTF8));
        label_8->setText(QApplication::translate("moduserinfowindow", "Telefono", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("moduserinfowindow", "Web", 0, QApplication::UnicodeUTF8));
        label_10->setText(QApplication::translate("moduserinfowindow", "*Obiettivi", 0, QApplication::UnicodeUTF8));
        chiudi->setText(QApplication::translate("moduserinfowindow", "Chiudi", 0, QApplication::UnicodeUTF8));
        ok->setText(QApplication::translate("moduserinfowindow", "Ok", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class moduserinfowindow: public Ui_moduserinfowindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MODUSERINFOWINDOW_H
