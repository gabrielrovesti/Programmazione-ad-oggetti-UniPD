#include "userinterface.h"
#include <QLayout>
#include <QScrollArea>

UserInterface::UserInterface(Account *acc){
    buildMenu();
    buildStack(acc);

    QHBoxLayout *v=new QHBoxLayout();
    v->addWidget(menu);
    v->addWidget(stack,1);
    v->setSizeConstraint(QLayout::SetMinimumSize);
    setLayout(v);
    setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
    setAttribute( Qt::WA_DeleteOnClose ); //dealloca automaticamente il widget alla chiusura
}


void UserInterface::buildMenu(){
    //inizializza lista pulsanti menù
    menu = new QListWidget;
    menu->setViewMode(QListView::IconMode);
    menu->setIconSize(QSize(50,50));
    menu->setMovement(QListView::Static);
    menu->setMaximumWidth(128);

    menu->setSpacing(15);
    QListWidgetItem *profilo = new QListWidgetItem(menu);
    profilo->setText(tr("Profilo"));
    profilo->setIcon(QIcon("Immagini/profilo.png"));
    profilo->setTextAlignment(Qt::AlignHCenter);

    QListWidgetItem *contatti = new QListWidgetItem(menu);
    contatti->setText(tr("Contatti"));
    contatti->setIcon(QIcon("Immagini/contatti.png"));
    contatti->setTextAlignment(Qt::AlignHCenter);

    QListWidgetItem *aziende = new QListWidgetItem(menu);
    aziende->setText(tr("Aziende"));
    aziende->setIcon(QIcon("Immagini/aziende.png"));
    aziende->setTextAlignment(Qt::AlignHCenter);

    QListWidgetItem *candidature = new QListWidgetItem(menu);
    candidature->setText(tr("Offerte"));
    candidature->setIcon(QIcon("Immagini/candidature.png"));
    candidature->setTextAlignment(Qt::AlignHCenter);

    QListWidgetItem *gruppi = new QListWidgetItem(menu);
    gruppi->setText(tr("Gruppi"));
    gruppi->setIcon(QIcon("Immagini/gruppi.png"));
    gruppi->setTextAlignment(Qt::AlignHCenter);
}

void UserInterface::buildStack(Account *acc){
    stack=new QStackedWidget();
    uiw=new UserInfoWindow(acc);  //schermata riepilogo profilo
    cw=new contattiWindow(acc);   //cerca e aggiungi contatti
    az=new aziWindow(acc);             //cerca,aggiungi e crea aziende
    offw=new offertaWindow(acc);   //cerca,aggiungi e crea offerte
    grup=new gruppoWindow(acc);     //cerca,aggiungi e crea gruppi

    //quando viene aggiunto un'offerta, viene aggiornata la schermata del profilo
    connect(cw,SIGNAL(contattoAggiunto(Contatto)),uiw,SLOT(updateContact(Contatto)));
    connect(az,SIGNAL(aziendaAggiunta(Azienda*)),uiw,SLOT(updateAziende(Azienda*)));
    connect(offw,SIGNAL(offertaAggiunta(Offerta*,int)),uiw,SLOT(updateOfferta(Offerta*,int)));
    connect(grup,SIGNAL(GruppoAggiunto(Gruppo*)),uiw,SLOT(updateGruppo(Gruppo*)));

    stack->addWidget(uiw);
    stack->addWidget(cw);
    stack->addWidget(az);
    stack->addWidget(offw);
    stack->addWidget(grup);
    connect(menu,SIGNAL(currentItemChanged(QListWidgetItem*,QListWidgetItem*)),this,SLOT(changePage(QListWidgetItem*,QListWidgetItem*)));
}

void UserInterface::changePage(QListWidgetItem *current, QListWidgetItem *previous){
    if(current==previous)   //se ho cliccato lo stesso di prima non fa nulla
        return;
    if (!current)
        current = previous;
    stack->setCurrentIndex(menu->row(current));
}
UserInterface::~UserInterface(){
    QListWidgetItem *item=menu->takeItem(0);
    while(item !=0){   //distrugge le icone
        delete item;
        item=menu->takeItem(0);
    }
    delete uiw;
    delete cw;
    delete az;
    delete offw;
    delete grup;
}
