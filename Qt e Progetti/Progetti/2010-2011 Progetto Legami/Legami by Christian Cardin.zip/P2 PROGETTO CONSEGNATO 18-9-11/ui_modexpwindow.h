/********************************************************************************
** Form generated from reading UI file 'modexpwindow.ui'
**
** Created: Sun Sep 18 16:34:32 2011
**      by: Qt User Interface Compiler version 4.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MODEXPWINDOW_H
#define UI_MODEXPWINDOW_H

#include <QtCore/QDate>
#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QDateEdit>
#include <QtGui/QDialog>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QTextEdit>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_modExpWindow
{
public:
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_6;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QDateEdit *inizio;
    QSpacerItem *horizontalSpacer;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QDateEdit *fine;
    QCheckBox *activity;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_3;
    QLineEdit *tit;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_4;
    QLineEdit *ru;
    QHBoxLayout *horizontalLayout_5;
    QVBoxLayout *verticalLayout;
    QLabel *label_5;
    QSpacerItem *verticalSpacer;
    QTextEdit *desc;
    QHBoxLayout *horizontalLayout_7;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *chiudi;
    QPushButton *ok;
    QSpacerItem *horizontalSpacer_3;

    void setupUi(QDialog *modExpWindow)
    {
        if (modExpWindow->objectName().isEmpty())
            modExpWindow->setObjectName(QString::fromUtf8("modExpWindow"));
        modExpWindow->resize(451, 403);
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(modExpWindow->sizePolicy().hasHeightForWidth());
        modExpWindow->setSizePolicy(sizePolicy);
        layoutWidget = new QWidget(modExpWindow);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(20, 32, 423, 338));
        verticalLayout_2 = new QVBoxLayout(layoutWidget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        inizio = new QDateEdit(layoutWidget);
        inizio->setObjectName(QString::fromUtf8("inizio"));

        horizontalLayout->addWidget(inizio);


        horizontalLayout_6->addLayout(horizontalLayout);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_2->addWidget(label_2);

        fine = new QDateEdit(layoutWidget);
        fine->setObjectName(QString::fromUtf8("fine"));
        fine->setMinimumDate(QDate(1770, 1, 1));

        horizontalLayout_2->addWidget(fine);


        horizontalLayout_6->addLayout(horizontalLayout_2);

        activity = new QCheckBox(layoutWidget);
        activity->setObjectName(QString::fromUtf8("activity"));

        horizontalLayout_6->addWidget(activity);


        verticalLayout_2->addLayout(horizontalLayout_6);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_3->addWidget(label_3);

        tit = new QLineEdit(layoutWidget);
        tit->setObjectName(QString::fromUtf8("tit"));

        horizontalLayout_3->addWidget(tit);


        verticalLayout_2->addLayout(horizontalLayout_3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_4->addWidget(label_4);

        ru = new QLineEdit(layoutWidget);
        ru->setObjectName(QString::fromUtf8("ru"));

        horizontalLayout_4->addWidget(ru);


        verticalLayout_2->addLayout(horizontalLayout_4);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label_5 = new QLabel(layoutWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        verticalLayout->addWidget(label_5);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);


        horizontalLayout_5->addLayout(verticalLayout);

        desc = new QTextEdit(layoutWidget);
        desc->setObjectName(QString::fromUtf8("desc"));

        horizontalLayout_5->addWidget(desc);


        verticalLayout_2->addLayout(horizontalLayout_5);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_7->addItem(horizontalSpacer_2);

        chiudi = new QPushButton(layoutWidget);
        chiudi->setObjectName(QString::fromUtf8("chiudi"));

        horizontalLayout_7->addWidget(chiudi);

        ok = new QPushButton(layoutWidget);
        ok->setObjectName(QString::fromUtf8("ok"));
        ok->setDefault(true);
        ok->setFlat(false);

        horizontalLayout_7->addWidget(ok);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_7->addItem(horizontalSpacer_3);


        verticalLayout_2->addLayout(horizontalLayout_7);


        retranslateUi(modExpWindow);

        QMetaObject::connectSlotsByName(modExpWindow);
    } // setupUi

    void retranslateUi(QDialog *modExpWindow)
    {
        modExpWindow->setWindowTitle(QApplication::translate("modExpWindow", "Dialog", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("modExpWindow", "Inizio", 0, QApplication::UnicodeUTF8));
        inizio->setDisplayFormat(QApplication::translate("modExpWindow", "dd/MM/yyyy", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("modExpWindow", "Fine", 0, QApplication::UnicodeUTF8));
        fine->setDisplayFormat(QApplication::translate("modExpWindow", "dd/MM/yyyy", 0, QApplication::UnicodeUTF8));
        activity->setText(QApplication::translate("modExpWindow", "In Attivita", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("modExpWindow", "Titolo: ", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("modExpWindow", "Ruolo: ", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("modExpWindow", "Descrizione", 0, QApplication::UnicodeUTF8));
        chiudi->setText(QApplication::translate("modExpWindow", "Chiudi", 0, QApplication::UnicodeUTF8));
        ok->setText(QApplication::translate("modExpWindow", "Ok", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class modExpWindow: public Ui_modExpWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MODEXPWINDOW_H
