#include "contattiwindow.h"
#include "userinfowindow.h"
#include "errormex.h"
#include <QLayout>
contattiWindow::contattiWindow(Account *acc, QWidget *parent):QWidget(parent),account(acc){

    tag=new QLineEdit();
    ltag=new QLabel("Tag:");
    QPushButton* find=new QPushButton("Ricerca Utenti");
    hack=0;
    if(account->checktipoaccount()==ADMIN){
        hack=new QPushButton("Modifica Utente");   //Se è admin attiva la funzionalità di modifica utenti
        connect(hack,SIGNAL(clicked()),this,SLOT(entercontatto()));
        hack->hide();
    }
    add=new QPushButton();
    connect(add,SIGNAL(clicked()),this,SLOT(addcontatto()));
    add->hide();
    tag->hide();
    ltag->hide();

    info=0;
    searchArea=new QScrollArea();
    searchArea->setSizePolicy(QSizePolicy::Fixed,QSizePolicy::Minimum);
    vertical=new QVBoxLayout();  //layout della searchArea
    searchArea->setLayout(vertical);

    infoArea=new QScrollArea();
    infoArea->setWidgetResizable(true);
    //infoArea->setWidget();

    findwind=new findContatti(account);
    connect(find,SIGNAL(clicked()),findwind,SLOT(show()));
    connect(findwind,SIGNAL(findclicked(QString,QString,QString,QString,QString,bool,int)),
            this,SLOT(loadContact(QString,QString,QString,QString,QString,bool,int)));


    QHBoxLayout *hbutt=new QHBoxLayout(); //layout pulsanti
    hbutt->addWidget(find);
    hbutt->addSpacing(95);
    if(hack)
        hbutt->addWidget(hack);
    hbutt->addWidget(add);
    hbutt->addWidget(ltag);
    hbutt->addWidget(tag);
    hbutt->addStretch();
    QHBoxLayout *hmain=new QHBoxLayout(); //layout widgets
    hmain->addWidget(searchArea);
    hmain->addWidget(infoArea);
    hmain->setSizeConstraint(QLayout::SetNoConstraint);
    QVBoxLayout *vmain=new QVBoxLayout();  //layout principale
    vmain->addLayout(hbutt);
    vmain->addLayout(hmain);
    setLayout(vmain);
}


void contattiWindow::loadContact(QString us,QString no,QString co,QString sp,QString lo,bool si,int so){
    vector<User*> contacts=account->findutenti(us.toStdString(),no.toStdString(),co.toStdString(),sp.toStdString(),lo.toStdString(),si,so);

    QLayoutItem *child;         //svuota completamente il layout della searchArea e pulisce la memoria dai vecchi dati
     while ((child = vertical->takeAt(0)) != 0) {
         if(child->widget())
             delete child->widget();
         else if(child->spacerItem())
             delete child->spacerItem();
         else if(child->layout())
             delete child->layout();
     }
     //numero risultati
    QLabel *resoult=new QLabel(QString::number(contacts.size())+" risultati");
    QFrame *line=new QFrame();
    line->setFrameShape(QFrame::HLine);
    vertical->addWidget(resoult);
    vertical->addWidget(line);
    contactWidget *temp;

    for(int i=contacts.size()-1;i>=0;i--){       //scorre il vettore in ordine inverso e crea i contactWidgets
        temp=new contactWidget(contacts[i]);
        connect(temp,SIGNAL(clicked(Contatto)),this,SLOT(loadInfo(Contatto)));
        vertical->addWidget(temp);
    }
    vertical->addStretch();
    if(info)
        info->hide();
    if(add->isVisible()){
        add->hide();
        ltag->hide();
        tag->hide();
    }
    if(hack && hack->isVisible())
        hack->hide();
}

void contattiWindow::loadInfo(Contatto contact){
    add->setVisible(true);
    if(hack)
        hack->setVisible(true);
    if(info){
        if(info->getutente()==*contact){   //se ho cliccato lo stesso pulsante di prima, non faccio nulla
            if(info->isHidden())
                info->setVisible(true);//ma se la finestra di info non è attiva, la mostra
            return;
        }
        delete infoArea->takeWidget();     //rimuove ed elimina il widget con le informazioni precedenti
   }
    info=new infoWidget(*contact);
    info->disablebuttons();
    infoArea->setWidget(info);           //setta le nuove info
    add->setText("Aggiungi "+QString::fromStdString((*contact)->getinfo()->getusername()));
    ltag->setVisible(true);
    tag->setText("");
    tag->setVisible(true);
    info->setVisible(true);
}

void contattiWindow::addcontatto(){
    QString tagcontatto=tag->text().trimmed();
    if(tagcontatto.isEmpty())
        tagcontatto="-Senza Tag-";
    User* ut=info->getutente();
    try{
        account->addcontatto(ut,tagcontatto.toStdString());
    }
    catch(ErrState e){
        ErrorMex *werr=new ErrorMex(e);
        werr->show();
        return;
    }
    OkMex *ok=new OkMex("Inserimento avvenuto.","L'utente e' stato inserito correttamente nella tua lista dei contatti");
    ok->show();
    emit contattoAggiunto(Contatto(ut,tagcontatto.toStdString()));
}

void contattiWindow::entercontatto(){
    if(account->checktipoaccount() != ADMIN)
        return;
    UserInfoWindow *hack= new UserInfoWindow(dynamic_cast<Account*>(info->getutente()));
    hack->show(account);
}

contattiWindow::~contattiWindow(){
    if(info) delete info;
    delete findwind;

    QLayoutItem *child;         //svuota completamente il layout della searchArea e pulisce la memoria dai vecchi dati
     while ((child = vertical->takeAt(0)) != 0) {
         if(child->widget())
             delete child->widget();
         else if(child->spacerItem())
             delete child->spacerItem();
         else if(child->layout())
             delete child->layout();
     }
}

