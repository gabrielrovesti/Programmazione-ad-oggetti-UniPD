#include "contatto.h"
#include "user.h"


Contatto::Contatto(User* _u,pstring _tag):collegamento(_u),tag(_tag){}

User* Contatto::operator*()const{return dynamic_cast<User*>(collegamento);}
User* Contatto::operator->()const{return dynamic_cast<User*>(collegamento);}

bool Contatto::operator==(const Contatto& l) const{return collegamento==l.collegamento;}
bool Contatto::operator!=(const Contatto& l) const{return collegamento!=l.collegamento;}


pstring Contatto::gettag() const{return tag;}
