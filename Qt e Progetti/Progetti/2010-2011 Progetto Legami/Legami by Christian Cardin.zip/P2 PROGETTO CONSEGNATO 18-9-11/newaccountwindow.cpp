#include "newaccountwindow.h"
#include "ui_newaccountwindow.h"
#include "legami.h"
#include "errstate.h"
#include "errormex.h"

newAccountWindow::newAccountWindow(Legami* _gestore,QWidget *parent):QWidget(parent),gestore(_gestore),ui(new Ui::newAccountWindow){
    ui->setupUi(this);
    ui->sex->addItem("Maschio");
    ui->sex->addItem("Femmina");
    ui->acc->addItem("BASIC");
    ui->acc->addItem("BUSINESS");
    ui->acc->addItem("EXECUTIVE");
    ui->nascita->setDisplayFormat("d/MM/yyyy");
    QDate date=QDate::currentDate();
    ui->nascita->setMaximumDate(date.addYears(-18));
    ui->nascita->setMinimumDate(date.addYears(-100));
    connect(ui->cancel,SIGNAL(clicked()),this,SLOT(close()));
    connect(ui->ok,SIGNAL(clicked()),this,SLOT(Accepted()));
    this->setWindowTitle("Iscrizione Nuovo Utente");

    ui->ok->setDefault(true);
    raise();
}

void newAccountWindow::Accepted(){
    QDateTime datetime(ui->nascita->date());
    try{
        gestore->iscriviutente(ui->acc->currentText().toStdString(),ui->user->text().toStdString(),ui->passw->text().toStdString(),ui->cpassw->text().toStdString(),ui->nome->text().toStdString(),
                                           ui->cogn->text().toStdString(),ui->sex->currentIndex(),ui->loc->text().toStdString(),ui->ind->text().toStdString(),
                                           ui->email->text().toStdString(),ui->spec->text().toStdString(),ui->obiet->toPlainText().toStdString(),datetime.toTime_t()+8600,
                                           ui->telefono->text().toStdString(),ui->web->text().toStdString(),ui->inter->toPlainText().toStdString());
    }catch(ErrState e){
        ErrorMex* wmess=new ErrorMex(e);
        wmess->show();
        return;
    }
    OkMex* kmex=new OkMex("Utente Iscritto!","Iscrizione avvenuta correttamente\nOra potrai accedere attraverso l'apposita schermata di login");
    kmex->show();
    close();
}

bool newAccountWindow::close(){
    clearFields();
    return QWidget::close();
}

void newAccountWindow::clearFields(){
    ui->user->setText("");
    ui->passw->setText("");
    ui->nome->setText("");
    ui->cogn->setText("");
    ui->loc->setText("");
    ui->ind->setText("");
    ui->email->setText("");
    ui->spec->setText("");
    ui->obiet->setText("");
    ui->telefono->setText("");
    ui->web->setText("");
    ui->inter->setText("");
    ui->cpassw->setText("");
    ui->acc->setCurrentIndex(0);
    ui->sex->setCurrentIndex(0);
    QDate date=QDate::currentDate();
    ui->nascita->setDate(date.addYears(-18));
}


newAccountWindow::~newAccountWindow(){
    delete ui;
}
