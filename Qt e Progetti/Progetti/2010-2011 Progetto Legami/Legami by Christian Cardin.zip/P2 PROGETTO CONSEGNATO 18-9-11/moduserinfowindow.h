#ifndef MODUSERINFOWINDOW_H
#define MODUSERINFOWINDOW_H
#include "account.h"
#include <QWidget>

namespace Ui {
    class moduserinfowindow;
}

/*Finestra che consente di modificare i campi dati del proprio utente.
 *Emette un segnale una volta effettuate le modifiche.
 *Tutti i widget ivi contenuti vengono distrutti automaticamente alla chiusura
 */

class moduserinfowindow : public QWidget{
    Q_OBJECT

public:
    explicit moduserinfowindow(Account* acc,QWidget *parent = 0);
    ~moduserinfowindow();

public slots:
    void buildLabels();

private slots:
    void changes();

signals:
    void infoChanged();

private:
    Account* account;

    Ui::moduserinfowindow *ui;
};

#endif // MODUSERINFOWINDOW_H
