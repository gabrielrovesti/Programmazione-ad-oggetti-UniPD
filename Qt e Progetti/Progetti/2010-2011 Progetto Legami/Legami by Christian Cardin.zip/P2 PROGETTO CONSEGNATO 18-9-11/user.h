#ifndef USER_H
#define	USER_H
#include "contatto.h"
#include "curriculum.h"
#include "info.h"
#include <utility>


class Azienda;
class Offerta;
class Gruppo;
using namespace std;

typedef pair<pstring,int> Tag;

class User{
protected:
    UserInfo* quickinfo;
    Curriculum *curriculum;
    vector<Contatto>* contatti;
    vector<Gruppo*>* gruppi;
    vector<Azienda*>* aziende;
    vector<Offerta*> *candidature;
    vector<Tag>* personal_tag;
public:
    User(UserInfo* _info);
    UserInfo* getinfo() const;
    Curriculum* getcurriculum() const;
    vector<Contatto>* getcontatti() const;
    vector<Gruppo*>* getgruppi() const;
    vector<Azienda*>* getaziende() const;
    vector<Offerta*>* getcandidature() const;
    vector<Tag>* get_ptag() const;
    vector<Gruppo*>::iterator is_presente(Gruppo* _g) const;
    vector<Azienda*>::iterator is_presente(Azienda* a) const;
    virtual ~User();
};

#endif	/* USER_H */

