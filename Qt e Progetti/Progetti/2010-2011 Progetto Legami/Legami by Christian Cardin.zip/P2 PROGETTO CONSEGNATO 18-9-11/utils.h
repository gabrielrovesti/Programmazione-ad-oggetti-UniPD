#ifndef UTILS_H
#define	UTILS_H

typedef enum{SEGNALAZIONE,MESSAGGIO} tipoMex;
typedef enum{BASIC,BUSINESS,EXECUTIVE,ADMIN} tipoAcc;

#endif	/* UTILS_H */

