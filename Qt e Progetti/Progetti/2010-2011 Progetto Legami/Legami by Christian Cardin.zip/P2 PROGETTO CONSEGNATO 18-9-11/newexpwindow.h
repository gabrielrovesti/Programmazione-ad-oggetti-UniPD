#ifndef NEWEXPWINDOW_H
#define NEWEXPWINDOW_H
#include <QWidget>
#include "legami.h"

namespace Ui {
    class newExpWindow;
}

/*Finestra per la creazione di una nuova esperienza. L'utente inserisce i dati e questa trasmette
 *l'esperienza creata per mezzo di un segnale. Il metodo close() è stato ridefinito in modo che tutti i campi vengano
 *svuotati dal loro precedente contenuto.
 *Gli oggetti vengono distrutti automaticamente alla distruzione della finestra.
 */

class newExpWindow : public QWidget
{
    Q_OBJECT

public:
    explicit newExpWindow(Account* acc,QWidget *parent = 0);
    ~newExpWindow();

signals:
    void expCreated(Exp*);
public slots:
    bool close();
private slots:
    void newexp();
private:
    void clearFields();
    Legami* gestore;
    Account* account;
    Ui::newExpWindow *ui;
};

#endif // NEWEXPWINDOW_H
