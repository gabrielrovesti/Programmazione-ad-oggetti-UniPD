#include "discusswidget.h"
#include <QBoxLayout>
#include <QScrollArea>
#include <QPlainTextEdit>
#include "errormex.h"

discussWidget::discussWidget(Gruppo* g,Discussione *e,Account* acc,QWidget *parent):QWidget(parent),
                             gruppo(g),disc(e),account(acc){

    cancella=new QPushButton("Cancella");
    discNumber=new QLabel();
    connect(cancella,SIGNAL(clicked()),this,SLOT(deldisc()));
    vlay=new QVBoxLayout();
    buildIntestaz();
    buildMex();
    buildLineedit();


}

void discussWidget::buildIntestaz(){
    QVBoxLayout *v1=new QVBoxLayout();
    QLabel *inf=new QLabel("Inviato il:\n"+QString::fromStdString(disc->getdata())+"\n"+QString::fromStdString(disc->getora())); //data discussione
    v1->addWidget(inf);
    v1->addWidget(cancella);
    v1->addStretch();

    QString contenuto="<font color=blue><b>"+QString::fromStdString(disc->getcreatore()->getinfo()->getusername())+
                      ": </b></font>"+QString::fromStdString(disc->getargomento());
    QTextEdit *arg= new QTextEdit(contenuto);
    arg->setReadOnly(true);
    arg->setTextInteractionFlags(Qt::NoTextInteraction);
    arg->setMaximumSize(700,80);
    arg->setMinimumWidth(350);

    QHBoxLayout *h2=new QHBoxLayout();
    discNumber->setText("Messaggi: "+QString::number(disc->getNumMex()));
    h2->addWidget(discNumber);
    h2->addStretch();


    QFrame *line=new QFrame();
    line->setFrameShape(QFrame::HLine);
    QVBoxLayout *v2=new QVBoxLayout();
    v2->addWidget(arg);
    v2->addLayout(h2);
    v2->addWidget(line);

    vlay->addLayout(v2);
    QHBoxLayout *h3=new QHBoxLayout();
    h3->addLayout(v1);   //layout intestazione
    h3->addLayout(vlay);

    this->setLayout(h3);

}

void discussWidget::buildMex(){
    vector<Messaggio*>* messaggi=disc->getmessaggi();
    for(unsigned int i=0;i<messaggi->size();i++){
        Messaggio* mex=(*messaggi)[i];
        QLabel *data=new QLabel(QString::fromStdString(mex->getTimePost()));
        QHBoxLayout *h1=new QHBoxLayout();
        h1->addWidget(data);
        h1->addStretch();
        QString contenuto="<font color=blue><b>"+QString::fromStdString(mex->getautore()->getinfo()->getusername())+
                          ": </b></font>"+QString::fromStdString(mex->gettesto());
        QTextEdit *text=new QTextEdit(contenuto);
        text->setTextInteractionFlags(Qt::NoTextInteraction);
        text->setMaximumSize(700,80);
        text->setMinimumWidth(350);

        QVBoxLayout *v1=new QVBoxLayout();
        v1->addLayout(h1);
        v1->addWidget(text);

        vlay->addLayout(v1);
    }
}

void discussWidget::buildLineedit(){
    if(!gruppo->is_iscritto(account)){       //se non è iscritto, non dà all'utente la possiblità di scrivere messaggi
        this->disablebuttons();
        return;
    }
    edit=new QPlainTextEdit();
    edit->setMaximumSize(700,80);
    edit->setMinimumWidth(350);

    QVBoxLayout *v1=new QVBoxLayout();
    insert=new QPushButton("Aggiungi");
    connect(insert,SIGNAL(clicked()),this,SLOT(addMex()));
    v1->addWidget(insert);
    v1->addStretch();

    lineedit=new QHBoxLayout();
    lineedit->addWidget(edit);
    lineedit->addLayout(v1);
    vlay->addLayout(lineedit);

    connect(lineedit,SIGNAL(destroyed()),edit,SLOT(hide()));
    connect(lineedit,SIGNAL(destroyed()),insert,SLOT(hide()));
    connect(lineedit,SIGNAL(destroyed()),edit,SLOT(deleteLater()));
    connect(lineedit,SIGNAL(destroyed()),insert,SLOT(deleteLater()));
    connect(lineedit,SIGNAL(destroyed()),v1,SLOT(deleteLater()));
}

void discussWidget::addMex(){
    if(edit->toPlainText().trimmed()=="")
        return;
    Messaggio* mex;
    try{
        mex=account->makepost(gruppo,disc,edit->toPlainText().trimmed().toStdString());
    }
    catch(ErrState e){
        ErrorMex *err=new ErrorMex(e);
        err->show();
        return;
    }
    insert->disconnect();             //rimuove i collegamenti con il pulsante di invio
    delete vlay->takeAt(vlay->count()-1)->layout();  //rimuove l'ultimo layout (quello del text edit d'inserimento)

    QLabel *data=new QLabel(QString::fromStdString(mex->getTimePost()));
    QHBoxLayout *h1=new QHBoxLayout();
    h1->addWidget(data);
    h1->addStretch();
    QString contenuto="<font color=blue><b>"+QString::fromStdString(mex->getautore()->getinfo()->getusername())+": </b></font>"+QString::fromStdString(mex->gettesto());
    QTextEdit *text=new QTextEdit(contenuto);
    text->setTextInteractionFlags(Qt::NoTextInteraction);
    text->setMaximumSize(700,80);
    text->setMinimumWidth(350);

    QVBoxLayout *v1=new QVBoxLayout();
    v1->addLayout(h1);
    v1->addWidget(text);

    vlay->addLayout(v1);
    buildLineedit();   //ricostruisce la lineedit*/
    discNumber->setText("Messaggi:"+QString::number(disc->getNumMex()));   //aggiorna la label con il numero messaggi
}

void discussWidget::disablebuttons(){
    cancella->setVisible(false);
}

void discussWidget::deldisc(){
    emit deleteClicked(disc,this);
}
