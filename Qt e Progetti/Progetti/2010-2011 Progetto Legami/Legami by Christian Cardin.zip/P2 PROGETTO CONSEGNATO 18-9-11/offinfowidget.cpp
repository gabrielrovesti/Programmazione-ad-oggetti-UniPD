#include "offinfowidget.h"
#include "azienda.h"
#include "contactwidget.h"
#include "azinfowidget.h"
#include <QMessageBox>
#include <QBoxLayout>

offInfoWidget::offInfoWidget(Offerta *a,Account* acc,QWidget *parent):QTabWidget(parent),offerta(a),account(acc){
    buildLabelsInfo();
    buildLayersInfo();
    buildCandidati();
    this->setWindowTitle("Dettaglio Offerta");

    this->setAttribute(Qt::WA_DeleteOnClose);
}

Offerta* offInfoWidget::getofferta() const{
    return offerta;
}

void offInfoWidget::buildLabelsInfo(){
    tit=new QLabel("Titolo: "+QString::fromStdString(offerta->gettitolo()));
    loc=new QLabel("Località: "+QString::fromStdString(offerta->getlocalita()));
    ind=new QLabel("Indirizzo: "+QString::fromStdString(offerta->getindirizzo()));
    sett=new QLabel("Settore: "+QString::fromStdString(offerta->getsettore()));
    gio=new QLabel("Giornata lavorativa: "+QString::fromStdString(offerta->getgiornata()));

    admin=new QLabel("<b>Proprietario: "+QString::fromStdString(offerta->getcreatore()->getinfo()->getusername())+"</b>");
    if(offerta->getazienda()){
        azwid=new azWidget(offerta->getazienda());
        azwid->disablebuttons();
        azwid->setEnabled(true);
        azinfoWidget *azinfo=new azinfoWidget(offerta->getazienda(),account);
        connect(azwid,SIGNAL(clicked()),azinfo,SLOT(show()));
        connect(this,SIGNAL(destroyed()),azinfo,SLOT(deleteLater()));
        connect(this,SIGNAL(destroyed()),azwid,SLOT(deleteLater()));
    }
    else azwid=0;
    creaz=new QLabel("Creazione: "+QString::fromStdString(offerta->getcreazione()));

    spec=new QPlainTextEdit(QString::fromStdString(offerta->getspecifiche()));
    esp=new QPlainTextEdit(QString::fromStdString(offerta->getexp()));
    desc=new QPlainTextEdit(QString::fromStdString(offerta->getdescrizione()));
    spec->setReadOnly(true);
    spec->setTextInteractionFlags(Qt::NoTextInteraction);
    spec->setMaximumSize(700,70);
    spec->setMinimumWidth(400);
    esp->setReadOnly(true);
    esp->setTextInteractionFlags(Qt::NoTextInteraction);
    esp->setMaximumSize(700,70);
    esp->setMinimumWidth(400);
    desc->setReadOnly(true);
    desc->setTextInteractionFlags(Qt::NoTextInteraction);
    desc->setMaximumSize(700,70);
    desc->setMinimumWidth(400);
}


void offInfoWidget::buildLayersInfo(){
    //layout dell'esperienza
    QHBoxLayout *hlexp=new QHBoxLayout(); //label
    hlexp->addWidget(new QLabel("Esperienza Richiesta"));
    hlexp->addStretch();
    QVBoxLayout *vesp=new QVBoxLayout(); //generale
    vesp->addLayout(hlexp);
    vesp->addWidget(esp);
    //layout delle specifiche
    QHBoxLayout *hlspec=new QHBoxLayout(); //label
    hlspec->addWidget(new QLabel("Specifiche Aggiuntive"));
    hlspec->addStretch();
    QVBoxLayout *vspec=new QVBoxLayout(); //generale
    vspec->addLayout(hlspec);
    vspec->addWidget(spec);
    //layout degli obiettivi
    QHBoxLayout *hldesc=new QHBoxLayout(); //label
    hldesc->addWidget(new QLabel("Descrizione"));
    hldesc->addStretch();
    QVBoxLayout *vdesc=new QVBoxLayout(); //generale
    vdesc->addLayout(hldesc);
    vdesc->addWidget(desc);

    //layout totale info
    QVBoxLayout *lay=new QVBoxLayout();
    lay->addWidget(admin);
    lay->addWidget(tit);
    if(azwid)lay->addWidget(azwid);
    lay->addWidget(ind);
    lay->addWidget(loc);
    lay->addWidget(sett);
    lay->addWidget(gio);
    lay->addWidget(creaz);


    QVBoxLayout *v3=new QVBoxLayout();
    QHBoxLayout *hinfo=new QHBoxLayout();
    hinfo->addLayout(lay);
    hinfo->addStretch();
    v3->addLayout(hinfo);
    v3->addLayout(vdesc);
    v3->addLayout(vesp);
    v3->addLayout(vspec);
    v3->addStretch();
    QGroupBox *infobox=new QGroupBox("");      //imposta il widget da inserire nella tab
    infobox->setLayout(v3);

    infobox->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
    QScrollArea *area=new QScrollArea();  //crea la scroll per visualizzare i contenuti dei widget
    area->setWidgetResizable(true);      //permette di rimodellare il widget se cambia le dimensioni
    area->setWidget(infobox);
    area->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
    this->addTab(area,"Informazioni");
}

void offInfoWidget::buildCandidati(){
    vector<User*>* contacts=offerta->getcandidati();
    QVBoxLayout *vertical= new QVBoxLayout();
    tipoAcc tipo=account->checktipoaccount();
     //numero risultati
    info=0;
    QLabel *resoult=new QLabel(QString::number(contacts->size())+" candidati");
    QFrame *line=new QFrame();
    line->setFrameShape(QFrame::HLine);
    vertical->addWidget(resoult);
    vertical->addWidget(line);

    if(account==offerta->getcreatore() || tipo==ADMIN){   //se ha i requisiti necessari per vedere i candidati
        contactWidget *temp;
        for(int i=contacts->size()-1;i>=0;i--){       //scorre il vettore in ordine inverso e crea i contactWidgets
            temp=new contactWidget((*contacts)[i]);
            connect(temp,SIGNAL(clicked(Contatto)),this,SLOT(loadCandInfo(Contatto)));
            connect(this,SIGNAL(destroyed()),temp,SLOT(deleteLater())); //distrugge automaticamente il widget insieme al padre
            vertical->addWidget(temp);
        }
    }
    vertical->addStretch();
    QGroupBox *cbox=new QGroupBox("");
    cbox->setLayout(vertical);
    this->addTab(cbox,"Candidati");
}

void offInfoWidget::loadCandInfo(Contatto contact){
    info=new UserInfoWindow(dynamic_cast<Account*>(*contact));
    info->show(account);
}

