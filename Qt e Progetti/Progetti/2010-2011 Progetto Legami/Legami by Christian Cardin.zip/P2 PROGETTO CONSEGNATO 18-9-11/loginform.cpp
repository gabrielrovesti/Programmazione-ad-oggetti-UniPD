#include "loginform.h"
#include "legami.h"
#include "errormex.h"

Loginform::Loginform(Legami* gest,QWidget *parent):QWidget(parent),gestore(gest){
    QLabel* us=new QLabel(tr("&Username:"));
    QLabel* ps=new QLabel(tr("&Password:"));
    login= new QPushButton("Login");
    login->setDefault(true);
    bclose= new QPushButton("Chiudi");
    luser=new QLineEdit();
    lpass=new QLineEdit();
    lock=new QLabel();
    lock->setPixmap(QPixmap("Immagini/lock.png"));
    QHBoxLayout *l1=new QHBoxLayout();
    QHBoxLayout *l2=new QHBoxLayout();
    QHBoxLayout *l3=new QHBoxLayout();
    QHBoxLayout *l4=new QHBoxLayout();
    QVBoxLayout *v1=new QVBoxLayout();
    lpass->setEchoMode(QLineEdit::Password);
    this->setWindowTitle("Login");


    connect(luser,SIGNAL(textChanged(QString)),this,SLOT(EnableButtonLogin()));
    connect(lpass,SIGNAL(textChanged(QString)),this,SLOT(EnableButtonLogin()));
    connect(login,SIGNAL(clicked()),this,SLOT(loginClicked()));          //emette il segnale di login che la mainwindow dovrà catturare
    connect(bclose,SIGNAL(clicked()),this,SLOT(close()));


    login->setEnabled(false);
    us->setBuddy(luser);
    ps->setBuddy(lpass);
    l1->addWidget(us);
    l1->addWidget(luser);
    l2->addWidget(ps);
    l2->addWidget(lpass);
    l3->addStretch();
    l3->addWidget(bclose);
    l3->addWidget(login);
    l3->addStretch();
    v1->addLayout(l1);
    v1->addLayout(l2);
    v1->addLayout(l3);
    l4->addLayout(v1);
    l4->addWidget(lock);
    setLayout(l4);
    raise();
    layout()->setSizeConstraint(QLayout::SetFixedSize);
}

void Loginform::EnableButtonLogin(){
    if(luser->text().trimmed().isEmpty() || lpass->text().isEmpty())
        login->setEnabled(false);
    else
        login->setEnabled(true);
}

void Loginform::loginClicked(){
    Account* acc;
    try{
        acc=gestore->login(luser->text().trimmed().toStdString(),lpass->text().toStdString());
    }
    catch(ErrState err){
        ErrorMex* werr=new ErrorMex(err);
        werr->show();
        return;
    }
    emit loginaccount(acc);
    close();
}

bool Loginform::close(){
    clearFields();
    return QWidget::close();
}

void Loginform::clearFields(){
    luser->setText("");
    lpass->setText("");
}

