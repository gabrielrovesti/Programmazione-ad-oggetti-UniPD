#ifndef LEGAMI_H
#define	LEGAMI_H
#include <map>
#include "pstring.h"
#include "account.h"
#include "gruppo.h"
#include "errstate.h"
#include "dbmanager.h"
#include "utils.h"
using std::map;


/*
**********NOTE*********
L'iscrizione di un utente ad un gruppo avviene in modo sincrono: se c'è un collegamento all'utente
sulla lista degli iscritti al gruppo, anche l'utente avrà un collegamento al gruppo

Stessa cosa vale per le offerte: un utente quando si candida ottiene un collegamento all'offerta e
contemporaneamente compare tra i candidati dell'offerta.

I collegamenti con i contatti e le aziende non sono sincronizzati.

Le aziende comprese nelle esperienze non vengono sincronizzate
*/

class Legami{
private:

    //map di tutte le entita <id_entita,indirizzo_mem>
    map<pstring,Account*>* usermap; //comprende account, business ed executive
    map<pstring,Gruppo*>* groupmap;
    map<pstring,Azienda*>* azmap;
    map<int,Offerta*>* offertemap;
    void clear();
    DBmanager *db;
public:
    friend class DBmanager;
    Legami();
    void WriteOnDb();
    //************RICERCHE*****************
    vector<User*> findutenti(const UserInfo& info,User* richiedente,bool simili=0,int soglia=40,int limite=5000) const;
    vector<Offerta*> findofferte(const Offerta& off,bool simili=0,int soglia=40,int limite=5000) const;
    vector<Gruppo*> findgruppi(const GroupInfo& info,bool simili=0,int soglia=40,int limite=5000)const;
    vector<Azienda*> findaziende(const AzInfo& info,bool simili=0,int soglia=40,int limite=5000)const;
    
    //************ACCOUNT-CONTATTI*****************
    void iscriviutente(pstring tipo,pstring _username,pstring _psw,pstring _cpsw,pstring _nome,pstring _cognome,bool _sex,pstring _localita,
                       pstring _indirizzo,pstring _email,pstring _spec,pstring _obiet,dataora _nascita,pstring _tel="",
                       pstring _web="",pstring _interessi="");

    Account* login(pstring user,pstring psw) const;
    void addcontatto(User* prop,User* con,pstring tag)throw(ErrStateContact);
    Account* upgrade(Account* a,tipoAcc tipo);


    //*************CURRICULUM****************
    void addlav(Account* _u,Exp* newexp)throw (ErrStateExp); //aggiunge un lavoratore all'azienda designata
    void removelav(Azienda* _a,Account* _u)throw (ErrStateExp); //rimuove un lavoratore all'azienda designata
    void sendsegn(User* mit,User* dest,pstring _ogg,pstring _mex,dataora date=dataora())throw (ErrStateExp);

    //***************GRUPPI-DISCUSSIONI****************
    void iscriviagruppo(User* _u,Gruppo* _g)throw(ErrStateGroup); //aggiunge un utente tra la lista degli iscritti di un gruppo
    void removedagruppo(User* _u,Gruppo* _g)throw(ErrStateGroup); //contrario di iscriviagruppo()
    Gruppo* creategroup(User* admin,pstring _nome, pstring _desc,
                        pstring _settore,pstring _web="")throw (ErrStateGroup); //crea un nuovo gruppo

    void deletegroup(User* admin,Gruppo* _g)throw(ErrStateGroup);
    void setgroupinfo(Gruppo* _g,User* newadmin=0,pstring desc="",pstring sett="",pstring web="")throw(ErrStateInfo);

    Discussione* adddiscussione(Gruppo* _g,User* autore,pstring tit)throw(ErrStateGroup);
    void deletediscussione(Gruppo* g,Discussione* disc) throw(ErrStateGroup);
    Messaggio* addpost(Gruppo* _g,Discussione* _d,User* autore,pstring text,pstring ogg="")throw(ErrStateGroup);

    //*************AZIENDE****************
    Azienda* createaz(User* admin,pstring nome, pstring localita, pstring indirizzo,pstring settore,
                      pstring descrizione,pstring t, pstring dimensione, pstring web,pstring telefono,pstring email)throw (ErrStateAz);
    void setazinfo(Azienda* _g,User* admin, pstring localita="", pstring indirizzo="",
                   pstring descrizione="", pstring dimensione="", pstring web="", pstring telefono="", pstring email="")throw(ErrStateInfo);
    void deleteaz(User* admin,Azienda* a)throw(ErrStateAz);

    //*************OFFERTE****************
    void candidautente(User* u,Offerta* off)throw(ErrStateOff);
    void toglicandidatura(User* u,Offerta* off)throw(ErrStateOff);
    Offerta* createoffer(User* admin,pstring tit,pstring loc,pstring ind, pstring sett, pstring desc,
                         pstring gior,pstring esp,Azienda* az=0,pstring spec="");
    void deleteoff(Executive* admin,Offerta* o)throw(ErrStateOff);

    //*************SALVATAGGIO****************
    void Save(UserInfo* info,tipoAcc tacc=BASIC,bool del=0);
    void Save(User* prop);
    void Save(AzInfo* info,pstring admin="",bool del=0);
    void Save(pstring prop,vector<Exp*>* exp);
    void Save(pstring prop,vector<Messaggio*>* segn);

    ~Legami();
};


#endif	/* LEGAMI_H */

