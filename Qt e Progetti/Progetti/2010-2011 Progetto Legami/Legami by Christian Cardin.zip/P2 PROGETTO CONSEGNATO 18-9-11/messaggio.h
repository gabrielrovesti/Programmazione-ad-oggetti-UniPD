#ifndef MESSAGGIO_H
#define	MESSAGGIO_H
#include "dataora.h"
#include "user.h"
#include "pstring.h"
 

class Messaggio{
private:
    pstring oggetto,testo;
    User* autore;
    dataora t_post;
public:
    Messaggio(User*,pstring _ogg,pstring _text,dataora _d=dataora());
    pstring getogg() const;
    pstring gettesto() const;
    pstring getTimePost() const;
    User* getautore() const;
    pstring tostring()const;
    bool operator<(const Messaggio&) const;
    bool operator>(const Messaggio&) const;
};


#endif	/* MESSAGGIO_H */

