/********************************************************************************
** Form generated from reading UI file 'findofferte.ui'
**
** Created: Sun Sep 18 16:34:32 2011
**      by: Qt User Interface Compiler version 4.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FINDOFFERTE_H
#define UI_FINDOFFERTE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QComboBox>
#include <QtGui/QGridLayout>
#include <QtGui/QGroupBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpinBox>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_findOfferte
{
public:
    QGroupBox *groupBox;
    QCheckBox *simili;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QSpinBox *soglia;
    QLabel *label_6;
    QPushButton *cerca;
    QWidget *layoutWidget_2;
    QGridLayout *gridLayout;
    QLabel *label;
    QLineEdit *tit;
    QLabel *label_2;
    QLineEdit *sett;
    QLabel *label_3;
    QLabel *label_4;
    QLineEdit *loc;
    QLabel *label_5;
    QLineEdit *key;
    QComboBox *gio;

    void setupUi(QWidget *findOfferte)
    {
        if (findOfferte->objectName().isEmpty())
            findOfferte->setObjectName(QString::fromUtf8("findOfferte"));
        findOfferte->resize(545, 182);
        groupBox = new QGroupBox(findOfferte);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(320, 10, 221, 101));
        simili = new QCheckBox(groupBox);
        simili->setObjectName(QString::fromUtf8("simili"));
        simili->setGeometry(QRect(0, 40, 121, 22));
        layoutWidget = new QWidget(groupBox);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(0, 70, 218, 29));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        soglia = new QSpinBox(layoutWidget);
        soglia->setObjectName(QString::fromUtf8("soglia"));
        soglia->setMinimum(0);
        soglia->setMaximum(100);
        soglia->setSingleStep(10);
        soglia->setValue(60);

        horizontalLayout->addWidget(soglia);

        label_6 = new QLabel(layoutWidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout->addWidget(label_6);

        cerca = new QPushButton(findOfferte);
        cerca->setObjectName(QString::fromUtf8("cerca"));
        cerca->setGeometry(QRect(330, 120, 201, 51));
        layoutWidget_2 = new QWidget(findOfferte);
        layoutWidget_2->setObjectName(QString::fromUtf8("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(10, 10, 301, 161));
        gridLayout = new QGridLayout(layoutWidget_2);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(layoutWidget_2);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 2);

        tit = new QLineEdit(layoutWidget_2);
        tit->setObjectName(QString::fromUtf8("tit"));

        gridLayout->addWidget(tit, 0, 3, 1, 1);

        label_2 = new QLabel(layoutWidget_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        sett = new QLineEdit(layoutWidget_2);
        sett->setObjectName(QString::fromUtf8("sett"));

        gridLayout->addWidget(sett, 1, 3, 1, 1);

        label_3 = new QLabel(layoutWidget_2);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout->addWidget(label_3, 2, 0, 1, 2);

        label_4 = new QLabel(layoutWidget_2);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout->addWidget(label_4, 3, 0, 1, 3);

        loc = new QLineEdit(layoutWidget_2);
        loc->setObjectName(QString::fromUtf8("loc"));

        gridLayout->addWidget(loc, 3, 3, 1, 1);

        label_5 = new QLabel(layoutWidget_2);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout->addWidget(label_5, 4, 0, 1, 2);

        key = new QLineEdit(layoutWidget_2);
        key->setObjectName(QString::fromUtf8("key"));

        gridLayout->addWidget(key, 4, 3, 1, 1);

        gio = new QComboBox(layoutWidget_2);
        gio->setObjectName(QString::fromUtf8("gio"));

        gridLayout->addWidget(gio, 2, 3, 1, 1);


        retranslateUi(findOfferte);

        QMetaObject::connectSlotsByName(findOfferte);
    } // setupUi

    void retranslateUi(QWidget *findOfferte)
    {
        findOfferte->setWindowTitle(QApplication::translate("findOfferte", "Form", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QApplication::translate("findOfferte", "Opzioni di rierca", 0, QApplication::UnicodeUTF8));
        simili->setText(QApplication::translate("findOfferte", "Ricerca Simili", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("findOfferte", "% Somiglianza Minima", 0, QApplication::UnicodeUTF8));
        cerca->setText(QApplication::translate("findOfferte", "Cliccami! :D", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("findOfferte", "Titolo", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("findOfferte", "Settore", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("findOfferte", "Giornata", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("findOfferte", "Localit\303\240", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("findOfferte", "Parola chiave", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class findOfferte: public Ui_findOfferte {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FINDOFFERTE_H
