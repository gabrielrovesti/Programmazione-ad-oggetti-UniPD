#ifndef USERINTERFACE_H
#define USERINTERFACE_H
#include <QWidget>
#include <QStackedWidget>
#include <QListWidget>
#include "userinfowindow.h"
#include "contattiwindow.h"
#include "aziwindow.h"
#include "offertawindow.h"
#include "gruppowindow.h"
#include "account.h"


/*Questa classe costituisce il cuore dell'interfaccia grafica. La combinazione QListWidget-QStackedWidget
 *permette una agevole azione di rollover tra vari widget, che offrono la maggior parte delle funzionalità
 *del programma. Viene creato un menù laterale con delle icone, che se cliccate visualizzano le rispettive
 *schermate. Esse sono:
 * UserInfoWindow: informazioni generali dell'utente e riepilogo profilo
 * contattiWindow: cerca e aggiungi contatti
 * aziWindow: cerca,aggiungi e crea aziende
 * offertaWindow: cerca,aggiungi e crea offerte di lavoro
 * gruppoWindow: cerca,aggiungi e crea gruppi
 *
 *Tutti questi elementi vengono distrutti nel distruttore. Altri widget sono deallocati automaticamente.
 */

class UserInterface:public QWidget{
    Q_OBJECT
public:
    UserInterface(Account* acc);
    ~UserInterface();
private slots:
    void changePage(QListWidgetItem *current, QListWidgetItem *previous);

private:
    QListWidget *menu;
    QStackedWidget *stack;
    void buildMenu();
    void buildStack(Account* acc);
    UserInfoWindow *uiw;
    contattiWindow *cw;
    aziWindow *az;
    offertaWindow *offw;
    gruppoWindow *grup;
};

#endif // USERINTERFACE_H
