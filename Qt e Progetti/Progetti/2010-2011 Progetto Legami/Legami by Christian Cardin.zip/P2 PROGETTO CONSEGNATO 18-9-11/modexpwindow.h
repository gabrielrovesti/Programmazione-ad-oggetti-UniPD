#ifndef MODEXPWINDOW_H
#define MODEXPWINDOW_H

#include "account.h"
#include <QDialog>

namespace Ui {
    class modExpWindow;
}

/*Finestra che consente di modificare i campi dati di un'esperienza.
 *Emette un segnale una volta effettuate le modifiche.
 *Tutti i widget ivi contenuti vengono distrutti automaticamente alla chiusura
 */

class modExpWindow : public QDialog{
    Q_OBJECT

public:
    explicit modExpWindow(Account* acc,QWidget *parent = 0);
    void load(Exp* e);
    ~modExpWindow();

signals:
    void expChanged();

private slots:
    void changes();

private:
    Account* account;
    Exp *exp;
    Ui::modExpWindow *ui;
};

#endif // MODEXPWINDOW_H
