#ifndef CONTATTO_H
#define	CONTATTO_H
#include "dataora.h"
#include "pstring.h"

class User;

class Contatto{
private:
    User* collegamento;
    pstring tag;
public:
    User* operator*() const;
    Contatto(User* _u,pstring _tag="");
    User* operator->() const;
    pstring gettag() const;
    bool operator==(const Contatto&) const;
    bool operator!=(const Contatto&) const;
};


#endif	/* CONTATTO_H */

