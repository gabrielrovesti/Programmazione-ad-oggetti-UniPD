#include "azinfowidget.h"
#include <QMessageBox>
#include <QBoxLayout>

azinfoWidget::azinfoWidget(Azienda *a,Account* richiedente,QWidget *parent):QGroupBox(parent),azienda(a){
    modifica=new QPushButton("Modifica Info",this);
    modifica->setVisible(false);
    modaiw=0;
    if(richiedente!=0 && a->getadmin()==richiedente){
        modaiw=new modAzinfowindow(a,richiedente);
        connect(modifica,SIGNAL(clicked()),modaiw,SLOT(show()));
        modifica->setVisible(true);
        connect(modaiw,SIGNAL(infoChanged()),this,SLOT(loadLabels()));
    }

    buildLabels();
    loadLabels();
    buildLayers();
    this->setWindowTitle("Informazioni su "+QString::fromStdString(azienda->getinfo()->getnome()));
    this->setAttribute(Qt::WA_DeleteOnClose);
}

Azienda* azinfoWidget::getazienda() const{
    return azienda;
}

void azinfoWidget::buildLabels(){
    admin=new QLabel(this);
    dim=new QLabel(this);
    nome=new QLabel(this);
    email=new QLabel(this);
    ind=new QLabel(this);
    tipo=new QLabel(this);
    sett=new QLabel(this);
    loc=new QLabel(this);
    web=new QLabel(this);
    tel=new QLabel(this);
    desc=new QPlainTextEdit(this);
    desc->setReadOnly(true);
    desc->setTextInteractionFlags(Qt::NoTextInteraction);
    desc->setMaximumSize(700,100);
    desc->setMinimumWidth(400);
}

void azinfoWidget::loadLabels(){

    AzInfo* infos=azienda->getinfo();
    admin->setText("<b>Proprietario: "+QString::fromStdString(azienda->getadmin()->getinfo()->getusername())+"</b>");
    nome->setText(QString::fromStdString(infos->getnome()));
    email->setText("Email: "+QString::fromStdString(infos->getemail()));
    sett->setText("Specializzazione: "+QString::fromStdString(infos->getsettore()));
    dim->setText("Dimensione: "+QString::fromStdString(infos->getdim()));
    tipo->setText("Tipo: "+QString::fromStdString(infos->gettipo()));
    ind->setText("Indirizzo: "+QString::fromStdString(infos->getindirizzo()));
    loc->setText("Localita: "+QString::fromStdString(infos->getlocalita()));
    web->setText("Web: "+QString::fromStdString(infos->getweb()));
    tel->setText("Telefono: "+QString::fromStdString(infos->gettelefono()));
    desc->setPlainText(QString::fromStdString(infos->getdesc()));

}

void azinfoWidget::buildLayers(){
    //layout degli obiettivi
    QHBoxLayout *hldesc=new QHBoxLayout(); //label
    hldesc->addWidget(new QLabel("Descrizione"));
    hldesc->addStretch();
    QVBoxLayout *vdesc=new QVBoxLayout(); //generale
    vdesc->addLayout(hldesc);
    vdesc->addWidget(desc);

    //layout totale info
    QVBoxLayout *lay=new QVBoxLayout();
    lay->addWidget(admin);
    lay->addWidget(nome);
    lay->addWidget(tipo);
    lay->addWidget(sett);
    lay->addWidget(dim);
    lay->addWidget(email);
    lay->addWidget(ind);
    lay->addWidget(loc);
    lay->addWidget(web);
    lay->addWidget(tel);

    QVBoxLayout *v3=new QVBoxLayout();
    QHBoxLayout *hinfo=new QHBoxLayout();
    hinfo->addLayout(lay);
    hinfo->addStretch();
    hinfo->addWidget(modifica);
    v3->addLayout(hinfo);
    v3->addLayout(vdesc);
    v3->addStretch();
    setLayout(v3);
}

azinfoWidget::~azinfoWidget(){
    if(modaiw)
       delete modaiw;
}


