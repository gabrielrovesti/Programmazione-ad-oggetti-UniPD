#include "upgradeform.h"
#include "legami.h"
#include "errormex.h"
#include <QtGui>

UpgradeForm::UpgradeForm(Legami* gest,QWidget *parent):QWidget(parent),gestore(gest){
    QLabel* us=new QLabel(tr("&Username:"));
    QLabel* ps=new QLabel(tr("&Password:"));
    QLabel* ty=new QLabel(tr("&Tipo:"));
    up= new QPushButton("Upgrade");
    up->setDefault(true);
    bclose= new QPushButton("Chiudi");
    luser=new QLineEdit();
    lpass=new QLineEdit();
    type=new QComboBox();
    type->addItem("BUSINESS");
    type->addItem("EXECUTIVE");
    QHBoxLayout *l1=new QHBoxLayout();
    QHBoxLayout *l2=new QHBoxLayout();
    QHBoxLayout *l3=new QHBoxLayout();
    QHBoxLayout *l4=new QHBoxLayout();
    QVBoxLayout *v1=new QVBoxLayout();
    lpass->setEchoMode(QLineEdit::Password);
    this->setWindowTitle("Upgrade Account");


    connect(luser,SIGNAL(textChanged(QString)),this,SLOT(EnableButtonUp()));
    connect(lpass,SIGNAL(textChanged(QString)),this,SLOT(EnableButtonUp()));
    connect(up,SIGNAL(clicked()),this,SLOT(upgradeClicked()));          //emette il segnale di login che la mainwindow dovrà catturare
    connect(bclose,SIGNAL(clicked()),this,SLOT(close()));

    up->setEnabled(false);
    us->setBuddy(luser);
    ps->setBuddy(lpass);
    ty->setBuddy(type);
    l1->addWidget(us);
    l1->addWidget(luser);
    l2->addWidget(ps);
    l2->addWidget(lpass);
    l3->addWidget(ty);
    l3->addWidget(type);
    l4->addStretch();
    l4->addWidget(bclose);
    l4->addWidget(up);
    l4->addStretch();
    v1->addLayout(l1);
    v1->addLayout(l2);
    v1->addLayout(l3);
    v1->addLayout(l4);
    setLayout(v1);
    raise();
    layout()->setSizeConstraint(QLayout::SetFixedSize);
}

void UpgradeForm::EnableButtonUp(){
    if(luser->text().trimmed().isEmpty() || lpass->text().isEmpty())
        up->setEnabled(false);
    else
        up->setEnabled(true);
}

void UpgradeForm::upgradeClicked(){
    tipoAcc t;
    if(type->currentIndex()==0)
        t=BUSINESS;
    else
        t=EXECUTIVE;
    try{
        Account* acc=gestore->login(luser->text().trimmed().toStdString(),lpass->text().toStdString());
        gestore->upgrade(acc,t);
    }
    catch(ErrState err){
        ErrorMex* werr=new ErrorMex(err);
        werr->show();
        return;
    }
    OkMex* kmex=new OkMex("Account Aggiornato!","Upgrade avvenuto correttamente\nOra potrai accedere attraverso l'apposita schermata di login");
    kmex->show();
    close();
}

bool UpgradeForm::close(){
    clearFields();
    return QWidget::close();
}

void UpgradeForm::clearFields(){
    luser->setText("");
    lpass->setText("");
}


