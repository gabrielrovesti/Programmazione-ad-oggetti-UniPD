#ifndef INFOWIDGET_H
#define INFOWIDGET_H

#include <QGroupBox>
#include <QLabel>
#include <QPushButton>
#include <QPlainTextEdit>
#include "account.h"
#include "moduserinfowindow.h"

/*Contiene le informazioni di un utente e le mostra tramite delle QLabel.
 *Questo widget serve sia per visualizzare informazioni sui contatti (quindi di User)
 *sia per le info personali (quindi per Account). In quest'ultimo caso, si ha bisogno di convertire
 *il tipo del parametro da User* ad Account* per permettere di accedere alla funzionalità di modifica informazioni.
 *La conversione è sicura perchè inizialmente tutti gli utenti presenti su Legami sono instanziati come Account o suoi derivati,
 *quindi il dynamic_cast sarà sempre possibile.
 *Tutti i widget definiti in questa classe vengono automaticamente distrutti alla chiusura.
 *tranne la finestra di modifica, che viene distrutta nel distruttore se è stata definita.
 */
class infoWidget:public QGroupBox{
    Q_OBJECT
public:
    infoWidget(User* a,QWidget* parent=0);
    ~infoWidget();
    User* getutente() const;
public slots:
    void disablebuttons();
private slots:
    void loadLabels();
private:
    User* utente;
    Account* acc;
    moduserinfowindow *modiw;
    QLabel *user,*nome,*tipo,*email,*spec,*ind,*loc,*web,*tel,*nas;
    QPlainTextEdit *ob,*inter;
    QPushButton *modifica;
    void buildLayers();
    void buildLabels();
    void buildWidgets();
};

#endif // INFOWIDGET_H
