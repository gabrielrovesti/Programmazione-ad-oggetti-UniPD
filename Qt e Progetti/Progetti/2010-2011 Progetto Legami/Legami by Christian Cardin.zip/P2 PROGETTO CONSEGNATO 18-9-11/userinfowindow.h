#ifndef USERINFOWINDOW_H
#define USERINFOWINDOW_H
#include <QtGui>
#include "legami.h"
#include "expwidget.h"
#include "mexwidget.h"
#include "newexpwindow.h"
#include "azwidget.h"
#include "groupwidget.h"
#include "offwidget.h"
#include "contactwidget.h"

namespace Ui {
    class UserInfoWindow;
}

/*La classe utente per eccellenza. Rappresenta il Profilo di un utente, tutte le sue informazioni e le sue
 * attività in Legami sono presenti qui dentro. La classe è organizzata in cartelle, ognuna contenente
 *informazioni diverse. Per facilitare la suddivisione, eredita le caratteristiche da QTabWidget.
 *
 *La prima tab mostra le informazioni personali attraverso un infoWidget.
 *
 *La seconda tab mostra il curriculum dell'utente: le esperienze personali (expWidget) e le segnalazioni
 *dagli altri utenti (mexWidget). E' inoltre presente un pulsante per la creazione di nuove esperienze.
 *
 *La terza tab raccoglie i contatti. Tramite la QComboBox è possibile filtrare i contatti per tag:
 *scegliendo un tag si attiva una funzione che nasconde i contatti non voluti e tiene solo i selezionati
 *
 *La quarta ospita la lista dei gruppi ai quali l'utente si è iscritto. Se ne è l'amministratore sarà
 *contornato di rosso.
 *
 *La quarta ospita la lista delle aziende seguite. Se ne è l'amministratore sarà contornata di rosso.
 *Solo gli account BUSINESS o superiori hanno questa tab
 *
 *La quinta mostra le candidature dell'utente. Cliccando nell'offWidget si apre la finestra delle informazioni.
 *Si può vedere il numero degli iscritti, ma non i loro nomi. Solo il proprietario dell'azienda e l'admin possono.
 *
 *La sesta tab possono averla solo gli utenti EXECUTIVE o superiori. Vengono salvate le offerte create
 *+++++++++++++++++
 *Tutti i widget contenuti nelle tab sono collegati in modo tale che quando la classe emette destroyed(),
 *automaticamente tutti questi widget si deallocano. La schermata di nuova esperienza viene distrutta dal
 *distruttore. I restanti vengono distrutti automaticamente.
 *+++++++++++++++++
 *Questa classe ha il metodo show() sovraccaricato in modo da filtrare le informazioni a seconda della tipologia
 *di utente che le richiede; inoltre imposta il flag di autodistruzione alla chiusura.
 */

class UserInfoWindow : public QTabWidget{
    Q_OBJECT

public:
    explicit UserInfoWindow(Account* acc,QTabWidget *parent = 0);
    ~UserInfoWindow();
signals:
    void disablebuttons();
public slots:
    void show(Account*);
    void updateContact(Contatto);
    void updateAziende(Azienda*);
    void updateOfferta(Offerta*,int);
    void updateGruppo(Gruppo*);
    void updatefilter();

private slots:
    void deleteExp(Exp* e,expWidget *wid);
    void deleteMex(Messaggio* m,mexWidget *wid);
    void deleteAzi(Azienda* a,azWidget *wid,int mod);
    void deleteGroup(Gruppo* a,groupWidget *wid,int mod);
    void deleteOff(Offerta* a,offWidget *wid);
    void delete_Poff(Offerta* a,offWidget *wid);
    void deleteContacts(Account* a,contactWidget *wid);
    void filtracontact(QString);
    void vedicontatto(Contatto);
    void vediazienda(Azienda*);
    void vediofferta(Offerta*);
    void vedigruppo(Gruppo*);
    void updateExp(Exp* e);

private:
    //fare print_Poff e build_PofferteTab
    Account* account;
    void buildInfoTab();
    void buildCurriculumTab();
    void buildContactsTab();
    void buildAziendeTab();
    void buildGruppiTab();
    void buildOfferteTab();
    void build_PofferteTab();
    void buildButtons();
    void printExp();
    void printContacts();
    void printMex();
    void printAzi();
    void printGroup();
    void printOff();
    void print_Poff();
    void disableActions(Account*);

    newExpWindow *expwin;
    QVector<contactWidget*>* vcontact;
    QComboBox *filter;
    QPushButton *newexp;
    QGroupBox *expBox,*segnBox,*azBox,*gBox,*offBox,*conBox,*poffBox;
    QVBoxLayout *vlexp,*vlmex,*vlcon,*vlazi,*vlo,*vl_po,*vlg;
};

#endif // USERINFOWINDOW_H
