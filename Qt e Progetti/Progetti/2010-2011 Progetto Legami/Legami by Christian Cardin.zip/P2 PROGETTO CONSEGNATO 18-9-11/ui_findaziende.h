/********************************************************************************
** Form generated from reading UI file 'findaziende.ui'
**
** Created: Sun Sep 18 16:34:32 2011
**      by: Qt User Interface Compiler version 4.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FINDAZIENDE_H
#define UI_FINDAZIENDE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QGridLayout>
#include <QtGui/QGroupBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpinBox>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_findAziende
{
public:
    QGroupBox *groupBox;
    QCheckBox *simili;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QSpinBox *soglia;
    QLabel *label_6;
    QPushButton *cerca;
    QWidget *widget;
    QGridLayout *gridLayout;
    QLabel *label;
    QLineEdit *nome;
    QLabel *label_2;
    QLineEdit *sett;
    QLabel *label_3;
    QLineEdit *tip;
    QLabel *label_4;
    QLineEdit *loc;

    void setupUi(QWidget *findAziende)
    {
        if (findAziende->objectName().isEmpty())
            findAziende->setObjectName(QString::fromUtf8("findAziende"));
        findAziende->resize(545, 184);
        groupBox = new QGroupBox(findAziende);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(320, 10, 221, 101));
        simili = new QCheckBox(groupBox);
        simili->setObjectName(QString::fromUtf8("simili"));
        simili->setGeometry(QRect(0, 40, 121, 22));
        layoutWidget = new QWidget(groupBox);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(0, 70, 218, 29));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        soglia = new QSpinBox(layoutWidget);
        soglia->setObjectName(QString::fromUtf8("soglia"));
        soglia->setMinimum(0);
        soglia->setMaximum(100);
        soglia->setSingleStep(10);
        soglia->setValue(60);

        horizontalLayout->addWidget(soglia);

        label_6 = new QLabel(layoutWidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout->addWidget(label_6);

        cerca = new QPushButton(findAziende);
        cerca->setObjectName(QString::fromUtf8("cerca"));
        cerca->setGeometry(QRect(320, 120, 201, 51));
        widget = new QWidget(findAziende);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(11, 13, 281, 161));
        gridLayout = new QGridLayout(widget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        nome = new QLineEdit(widget);
        nome->setObjectName(QString::fromUtf8("nome"));

        gridLayout->addWidget(nome, 0, 1, 1, 1);

        label_2 = new QLabel(widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        sett = new QLineEdit(widget);
        sett->setObjectName(QString::fromUtf8("sett"));

        gridLayout->addWidget(sett, 1, 1, 1, 1);

        label_3 = new QLabel(widget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout->addWidget(label_3, 2, 0, 1, 1);

        tip = new QLineEdit(widget);
        tip->setObjectName(QString::fromUtf8("tip"));

        gridLayout->addWidget(tip, 2, 1, 1, 1);

        label_4 = new QLabel(widget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout->addWidget(label_4, 3, 0, 1, 1);

        loc = new QLineEdit(widget);
        loc->setObjectName(QString::fromUtf8("loc"));

        gridLayout->addWidget(loc, 3, 1, 1, 1);


        retranslateUi(findAziende);

        QMetaObject::connectSlotsByName(findAziende);
    } // setupUi

    void retranslateUi(QWidget *findAziende)
    {
        findAziende->setWindowTitle(QApplication::translate("findAziende", "Form", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QApplication::translate("findAziende", "Opzioni di rierca", 0, QApplication::UnicodeUTF8));
        simili->setText(QApplication::translate("findAziende", "Ricerca Simili", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("findAziende", "% Somiglianza Minima", 0, QApplication::UnicodeUTF8));
        cerca->setText(QApplication::translate("findAziende", "Cliccami! :D", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("findAziende", "Nome", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("findAziende", "Settore", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("findAziende", "Tipo", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("findAziende", "Localit\303\240", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class findAziende: public Ui_findAziende {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FINDAZIENDE_H
