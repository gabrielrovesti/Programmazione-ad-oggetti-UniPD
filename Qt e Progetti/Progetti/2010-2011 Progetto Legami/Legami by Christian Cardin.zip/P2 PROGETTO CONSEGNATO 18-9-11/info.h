#ifndef INFO_H
#define	INFO_H
#include "dataora.h"
#include "utils.h"
#include "errstate.h"
#include "pstring.h"
 

class Info{           //classe astratta con tostring() metodo virtuale puro
public:
   virtual pstring tostring() const =0;
   virtual ~Info(){}
};

class UserInfo:public Info{
    friend class Account;
private:
    pstring username,password,nome,cognome,localita,indirizzo,email,specializzazioni,obiettivi;
    pstring telefono,web,interessi;
    dataora nascita,iscrizione;
    bool sex; //0: maschio, 1 femmina
    
public:
    UserInfo(pstring _username,pstring _psw,pstring _nome,pstring _cognome,bool _sex, pstring _localita,pstring _indirizzo,pstring _email,
            pstring _spec,pstring _obiet,dataora _nascita,dataora _iscriz=dataora(),pstring _tel="",
            pstring _web="",pstring _interessi="");
    bool checkpsw(pstring _psw) const;
    pstring getusername() const;
    pstring getpassword() const;
    pstring getnome() const;
    pstring getcognome() const;
    pstring getlocalita() const;
    pstring getindirizzo() const;
    pstring gettelefono() const;
    pstring getemail() const;
    pstring getweb() const;
    pstring getinteressi() const;
    pstring getspec() const;
    pstring getobiettivi() const;
    pstring getnascita() const;
    pstring getiscrizione() const;
    bool getsex() const;
    /*restituisce la percentuale di "somiglianza":
     * (campi che hanno un match/campi richiesti) * 100
     * naturalmente, più è alto questo numero più un utente risponde alle caratteristiche
     * volute. Sarà poi a discrezione dell'utente se vuole vedere solo i contatti
     * con somiglianza totale (100%) oppure anche gli altri.*/
    double somiglia(const UserInfo& info) const;
    void modifyInfo(pstring _psw,pstring _nome, pstring _cognome,
                                       pstring _localita, pstring _indirizzo, pstring _spec, pstring _obiet,
                                       pstring _tel, pstring _web, pstring _interessi)throw(ErrStateInfo);
    virtual pstring tostring() const;
    virtual ~UserInfo(){}
};

class User;

class AzInfo:public Info{
private:
    pstring nome,localita,indirizzo,settore,descrizione,tipo,dimensione;
    pstring web,telefono,email;
    int visite;
public:
    AzInfo(pstring _nome,pstring _localita,pstring _indirizzo, pstring _settore,pstring _desc,
            pstring _tipo,pstring _dim,pstring _web="",pstring _telefono="",pstring _email="");

    pstring getnome() const;
    pstring getlocalita() const;
    pstring getindirizzo() const;
    pstring gettipo() const;
    pstring getdesc() const;
    pstring getdim() const;
    pstring getsettore() const;
    pstring getweb() const;
    pstring gettelefono() const;
    pstring getemail() const;
    void modifyInfo(pstring localita,pstring indirizzo, pstring descrizione,
                    pstring dimensione, pstring web, pstring telefono,pstring email);

    double somiglia(const AzInfo& info) const;
    virtual pstring tostring() const;
    virtual ~AzInfo(){}
};


class GroupInfo:public Info{
private:
    pstring nome,descrizione,settore,web;
    dataora creazione;

public:
    GroupInfo(pstring _nome, pstring _desc,pstring _settore,
              dataora _creaz=dataora(),pstring _web="");
    pstring getnome() const;
    pstring getdesc() const;
    pstring getsettore() const;
    pstring getweb() const;
    pstring getcreazione() const;
    void modifyInfo(pstring sett,pstring desc,pstring web);
    void setsettore(pstring);
    void setdescr(pstring);
    void setweb(pstring);
    void setnome(pstring);
    double somiglia(const GroupInfo& info) const;
    virtual pstring tostring() const;
    virtual ~GroupInfo(){}
};


#endif	/* INFO_H */

