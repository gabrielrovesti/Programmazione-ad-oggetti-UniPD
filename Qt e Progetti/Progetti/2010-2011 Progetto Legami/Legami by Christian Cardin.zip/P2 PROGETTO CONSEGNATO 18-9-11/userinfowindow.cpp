#include "userinfowindow.h"
#include "errormex.h"
#include "infowidget.h"
#include "azinfowidget.h"
#include "offinfowidget.h"
#include "groupinfowidget.h"
#include <QFormLayout>
#include <QMessageBox>
#include <QScrollArea>

UserInfoWindow::UserInfoWindow(Account* acc,QTabWidget *parent):QTabWidget(parent),account(acc){
    expwin=new newExpWindow(account);
    connect(expwin,SIGNAL(expCreated(Exp*)),this,SLOT(updateExp(Exp*)));
    printExp();
    printMex();
    printContacts();
    printGroup();
    printAzi();
    printOff();
    buildButtons();
    buildInfoTab();
    buildCurriculumTab();
    buildContactsTab();
    buildGruppiTab();
    buildAziendeTab();
    buildOfferteTab();
    if(account->checktipoaccount()==EXECUTIVE || account->checktipoaccount()==ADMIN){
        print_Poff();
        build_PofferteTab();
    }
    this->setWindowTitle("Scheda di "+QString::fromStdString(account->getinfo()->getusername()));
    setSizePolicy(QSizePolicy::Maximum,QSizePolicy::Minimum);
    setAttribute(Qt::WA_DeleteOnClose);
}

void UserInfoWindow::buildInfoTab(){
    infoWidget *info=new infoWidget(account);
    connect(this,SIGNAL(disablebuttons()),info,SLOT(disablebuttons()));
    connect(this,SIGNAL(destroyed()),info,SLOT(deleteLater()));  //distruzione automatica alla chiusura
    QScrollArea *area1=new QScrollArea();  //crea la scroll per visualizzare i contenuti dei widget
    area1->setWidgetResizable(true);      //permete di rimodellare il widget se cambia le dimensioni
    area1->setWidget(info);
    area1->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
    addTab(area1,"Informazioni");
}

void UserInfoWindow::buildCurriculumTab(){
    //exp e segn groupbox
    expBox->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
    segnBox->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);

    //layout curriculum
    QVBoxLayout *v1=new QVBoxLayout();
    QHBoxLayout *hbuttonexp=new QHBoxLayout();
    hbuttonexp->addWidget(newexp);    //pulsante nuova esperienza
    hbuttonexp->addStretch();
    v1->addLayout(hbuttonexp);
    QFrame *line=new QFrame();
    line->setFrameShape(QFrame::HLine);
    v1->addWidget(expBox);           //expBox
    v1->addWidget(line);
    v1->addWidget(segnBox);          //segnBox
    v1->addStretch();
    v1->setSizeConstraint(QLayout::SetMinimumSize);  //impedisce alle textedit di diventare enormi

    //curriculum groupbox
    QGroupBox *curriculumBox=new QGroupBox("");
    curriculumBox->setLayout(v1);
    curriculumBox->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);

    //SCROLLAREA
    QScrollArea *area2=new QScrollArea();  //crea la scroll per visualizzare i contenuti dei widget
    area2->setWidgetResizable(true);      //permette di rimodellare il widget se cambia le dimensioni
    area2->setWidget(curriculumBox);
    area2->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
    addTab(area2,"Curriculum");
}

void UserInfoWindow::buildAziendeTab(){
    azBox->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
    QScrollArea *area3=new QScrollArea();  //crea la scroll per visualizzare i contenuti dei widget
    area3->setWidgetResizable(true);      //permette di rimodellare il widget se cambia le dimensioni
    area3->setWidget(azBox);

    area3->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
    addTab(area3,"Aziende");
}

void UserInfoWindow::buildGruppiTab(){
    gBox->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
    QScrollArea *area3=new QScrollArea();  //crea la scroll per visualizzare i contenuti dei widget
    area3->setWidgetResizable(true);      //permette di rimodellare il widget se cambia le dimensioni
    area3->setWidget(gBox);

    area3->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
    addTab(area3,"Gruppi");
}

void UserInfoWindow::buildOfferteTab(){
    offBox->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
    QScrollArea *area3=new QScrollArea();  //crea la scroll per visualizzare i contenuti dei widget
    area3->setWidgetResizable(true);      //permette di rimodellare il widget se cambia le dimensioni
    area3->setWidget(offBox);
    area3->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
    addTab(area3,"Candidature");
}

void UserInfoWindow::build_PofferteTab(){
    poffBox->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
    QScrollArea *area3=new QScrollArea();  //crea la scroll per visualizzare i contenuti dei widget
    area3->setWidgetResizable(true);      //permette di rimodellare il widget se cambia le dimensioni
    area3->setWidget(poffBox);
    area3->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
    addTab(area3,"Offerte Personali");
}

void UserInfoWindow::buildContactsTab(){
    conBox->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
    QScrollArea *area3=new QScrollArea();  //crea la scroll per visualizzare i contenuti dei widget
    area3->setWidgetResizable(true);      //permette di rimodellare il widget se cambia le dimensioni
    area3->setWidget(conBox);

    area3->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
    addTab(area3,"Contatti");
}


void UserInfoWindow::buildButtons(){
    newexp=new QPushButton("Aggiungi Esperienza");
    connect(newexp,SIGNAL(clicked()),expwin,SLOT(show()));
    connect(this,SIGNAL(disablebuttons()),newexp,SLOT(hide()));
}

void UserInfoWindow::printExp(){
    vector<Exp*>* evect=account->getcurriculum()->getexp();  //prendo il vector delle esperienze
    expBox=new QGroupBox("Esperienze");                      //init del box
    vlexp=new QVBoxLayout();
    vlexp->setSizeConstraint(QLayout::SetMinimumSize);
    expWidget* temp;
    for(unsigned int i=0;i<evect->size();i++){                                //per ogni esperienza, crea il suo widget
        temp=new expWidget(account,(*evect)[i]);                //si intercettano i segnali di delete
        vlexp->addWidget(temp);
        connect(temp,SIGNAL(deleteClicked(Exp*,expWidget*)),this,SLOT(deleteExp(Exp*,expWidget*)));
        connect(this,SIGNAL(disablebuttons()),temp,SLOT(disablebuttons()));
        connect(this,SIGNAL(destroyed()),temp,SLOT(deleteLater()));  //distruzione automatica alla chiusura
    }
    expBox->setLayout(vlexp);
}

void UserInfoWindow::printContacts(){
    filter=new QComboBox();         //Inizializza il filtro con i tags
        updatefilter();
        connect(filter,SIGNAL(currentIndexChanged(QString)),this,SLOT(filtracontact(QString)));
        connect(this,SIGNAL(disablebuttons()),filter,SLOT(hide()));
        QLabel *lfil=new QLabel("Filtro TAG:");
        connect(this,SIGNAL(disablebuttons()),lfil,SLOT(hide()));
        QHBoxLayout *hfil=new QHBoxLayout();
        hfil->addWidget(lfil);
        hfil->addWidget(filter);
        hfil->addStretch();
        vcontact=new QVector<contactWidget*>();
        vector<Contatto>* evect=account->getcontatti();       //prendo il vector dei contatti
        conBox=new QGroupBox("");                      //init del box
        vlcon=new QVBoxLayout();
        vlcon->addLayout(hfil);
        vlcon->setSizeConstraint(QLayout::SetMinimumSize);
        contactWidget* temp;
        for(unsigned int i=0;i<evect->size();i++){                                //per ogni contatto, crea il suo widget
            temp=new contactWidget((*evect)[i],account);
            vlcon->addWidget(temp);
            vcontact->push_back(temp);
            connect(temp,SIGNAL(deleteClicked(Account*,contactWidget*)),this,SLOT(deleteContacts(Account*,contactWidget*)));
            connect(temp,SIGNAL(clicked(Contatto)),this,SLOT(vedicontatto(Contatto)));
            connect(this,SIGNAL(disablebuttons()),temp,SLOT(disablebuttons()));
            connect(this,SIGNAL(destroyed()),temp,SLOT(deleteLater()));  //distrugge automaticamente insieme al padre

        }
        vlcon->addStretch();
        conBox->setLayout(vlcon);
}

void UserInfoWindow::printMex(){
    vector<Messaggio*>* mvect=account->getcurriculum()->getseg();  //prendo il vector delle segnalazioni
    segnBox=new QGroupBox("Segnalazioni");                      //init del box
    vlmex=new QVBoxLayout();
    vlmex->setSizeConstraint(QLayout::SetMinimumSize);
    mexWidget* temp;
    for(unsigned int i=0;i<mvect->size();i++){                        //per ogni messaggio, crea il suo widget
        temp=new mexWidget((*mvect)[i]);                //si intercettano i segnali di modifica e delete
        vlmex->addWidget(temp);
        connect(temp,SIGNAL(deleteClicked(Messaggio*,mexWidget*)),this,SLOT(deleteMex(Messaggio*,mexWidget*)));
        connect(this,SIGNAL(disablebuttons()),temp,SLOT(disablebuttons()));
        connect(this,SIGNAL(destroyed()),temp,SLOT(deleteLater()));  //distrugge automaticamente insieme al padre
    }
    segnBox->setLayout(vlmex);
}

void UserInfoWindow::printAzi(){
    vector<Azienda*>* avect=account->getaziende();   //prendo il vector delle aziende
    azBox=new QGroupBox("");                      //init del box
    vlazi=new QVBoxLayout();
    vlazi->setSizeConstraint(QLayout::SetMinimumSize);
    azWidget* temp;
    Azienda* a;
    for(unsigned int i=0;i<avect->size();i++){
        a=(*avect)[i];
        temp=new azWidget(a);
        if(account==a->getadmin()){          // se è admin di qualche azienda, la contorna di rosso
            temp->setPalette(QPalette(Qt::red));
            temp->setAutoFillBackground(true);
            temp->showelimina();
        }
        vlazi->addWidget(temp);
        connect(temp,SIGNAL(deleteClicked(Azienda*,azWidget*,int)),this,SLOT(deleteAzi(Azienda*,azWidget*,int)));
        connect(this,SIGNAL(disablebuttons()),temp,SLOT(disablebuttons()));
        connect(temp,SIGNAL(clicked(Azienda*)),this,SLOT(vediazienda(Azienda*)));
        connect(this,SIGNAL(destroyed()),temp,SLOT(deleteLater()));  //distrugge automaticamente insieme al padre
    }
    vlazi->addStretch();
    azBox->setLayout(vlazi);
}

void UserInfoWindow::printGroup(){
    vector<Gruppo*>* avect=account->getgruppi();   //prendo il vector dei gruppi
    gBox=new QGroupBox("");                      //init del box
    vlg=new QVBoxLayout();
    vlg->setSizeConstraint(QLayout::SetMinimumSize);
    groupWidget* temp;
    for(unsigned int i=0;i<avect->size();i++){                        //per ogni messaggio, crea il suo widget
        Gruppo* g=(*avect)[i];
        temp=new groupWidget(g);                //si intercettano i segnali di modifica e delete
        if(account==g->getadmin()){          // se è admin di qualche gruppo, la contorna di rosso
            temp->setPalette(QPalette(Qt::red));
            temp->setAutoFillBackground(true);
            temp->showelimina();
        }
        vlg->addWidget(temp);
        connect(temp,SIGNAL(deleteClicked(Gruppo*,groupWidget*,int)),this,SLOT(deleteGroup(Gruppo*,groupWidget*,int)));
        connect(this,SIGNAL(disablebuttons()),temp,SLOT(disablebuttons()));
        connect(temp,SIGNAL(clicked(Gruppo*)),this,SLOT(vedigruppo(Gruppo*)));
        connect(this,SIGNAL(destroyed()),temp,SLOT(deleteLater()));  //distrugge automaticamente insieme al padre
    }
    vlg->addStretch();
    gBox->setLayout(vlg);
}

void UserInfoWindow::printOff(){
    vector<Offerta*>* avect=account->getcandidature();   //prendo il vector dei gruppi
    offBox=new QGroupBox("");                      //init del box
    vlo=new QVBoxLayout();
    vlo->setSizeConstraint(QLayout::SetMinimumSize);
    offWidget* temp;
    for(unsigned int i=0;i<avect->size();i++){                        //per ogni messaggio, crea il suo widget
        temp=new offWidget((*avect)[i]);                //si intercettano i segnali di modifica e delete
        vlo->addWidget(temp);
        connect(temp,SIGNAL(deleteClicked(Offerta*,offWidget*)),this,SLOT(deleteOff(Offerta*,offWidget*)));
        connect(this,SIGNAL(disablebuttons()),temp,SLOT(disablebuttons()));
        connect(temp,SIGNAL(vedidettagli(Offerta*)),this,SLOT(vediofferta(Offerta*)));
        connect(this,SIGNAL(destroyed()),temp,SLOT(deleteLater()));  //distrugge automaticamente insieme al padre
    }
    vlo->addStretch();
    offBox->setLayout(vlo);
}

void UserInfoWindow::print_Poff(){                 //SOLO EXECUTIVE E ADMIN POSSONO ACCEDERVI
    vector<Offerta*>* avect=account->get_poff();   //prendo il vector delle offerte personali
    poffBox=new QGroupBox("");                     //init del box
    vl_po=new QVBoxLayout();
    vl_po->setSizeConstraint(QLayout::SetMinimumSize);
    offWidget* temp;
    for(unsigned int i=0;i<avect->size();i++){                        //per ogni messaggio, crea il suo widget
        temp=new offWidget((*avect)[i]);                //si intercettano i segnali di modifica e delete
        vl_po->addWidget(temp);
        temp->enableadmin();    //attiva pulsanti admin
        connect(temp,SIGNAL(deleteClicked(Offerta*,offWidget*)),this,SLOT(delete_Poff(Offerta*,offWidget*)));
        connect(this,SIGNAL(disablebuttons()),temp,SLOT(disablebuttons()));
        connect(temp,SIGNAL(vedidettagli(Offerta*)),this,SLOT(vediofferta(Offerta*)));
        connect(this,SIGNAL(destroyed()),temp,SLOT(deleteLater()));  //distrugge automaticamente insieme al padre
    }
    vl_po->addStretch();
    poffBox->setLayout(vl_po);
}

void UserInfoWindow::updateExp(Exp *e){
    expWidget *temp=new expWidget(account,e);
    connect(this,SIGNAL(destroyed()),temp,SLOT(deleteLater()));  //distrugge automaticamente insieme al padre
    connect(temp,SIGNAL(deleteClicked(Exp*,expWidget*)),this,SLOT(deleteExp(Exp*,expWidget*)));
    vlexp->addWidget(temp);
}

void UserInfoWindow::updatefilter(){
    while(filter->count()!=0)    //cancella il contenuto della  combobox
        filter->removeItem(0);

    filter->addItem("Tutti i TAG");
    vector< Tag > *tags=account->get_ptag();
    unsigned int i=0;
    while(i<tags->size()){
        filter->addItem(QString::fromStdString((*tags)[i].first));
        i++;
    }
}

void UserInfoWindow::updateContact(Contatto contat){
    updatefilter();
    contactWidget *temp=new contactWidget(contat,account);
    delete vlcon->takeAt(vlcon->count()-1)->spacerItem();    //rimuove lo stretch finale di vlcon
    vlcon->addWidget(temp);
    vlcon->addStretch();
    vcontact->push_back(temp);
    connect(this,SIGNAL(destroyed()),temp,SLOT(deleteLater()));  //distrugge automaticamente insieme al padre
    connect(temp,SIGNAL(deleteClicked(Account*,contactWidget*)),this,SLOT(deleteContacts(Account*,contactWidget*)));
    connect(temp,SIGNAL(clicked(Contatto)),this,SLOT(vedicontatto(Contatto)));
    connect(this,SIGNAL(disablebuttons()),temp,SLOT(disablebuttons()));
}

void UserInfoWindow::updateAziende(Azienda * azienda){
    azWidget *temp=new azWidget(azienda);
    delete vlazi->takeAt(vlazi->count()-1)->spacerItem();    //rimuove lo stretch finale del layout della pagina delle aziende
    vlazi->addWidget(temp);
    vlazi->addStretch();
    if(account==azienda->getadmin()){          // se è admin di qualche azienda, la contorna di rosso
        temp->setPalette(QPalette(Qt::red));
        temp->setAutoFillBackground(true);
        temp->showelimina();
    }
    connect(this,SIGNAL(destroyed()),temp,SLOT(deleteLater()));  //distrugge automaticamente insieme al padre
    connect(temp,SIGNAL(deleteClicked(Azienda*,azWidget*,int)),this,SLOT(deleteAzi(Azienda*,azWidget*,int)));
    connect(this,SIGNAL(disablebuttons()),temp,SLOT(disablebuttons()));
    connect(temp,SIGNAL(clicked(Azienda*)),this,SLOT(vediazienda(Azienda*)));
}

void UserInfoWindow::updateOfferta(Offerta * offerta,int lay){
    offWidget *temp=new offWidget(offerta);
    QVBoxLayout *layout;   //a seconda del discriminante (0 o 1) inserisce ilnuovo widget nel layout delle candidature o delle
    if(lay==0){             //offerte personali
        connect(temp,SIGNAL(deleteClicked(Offerta*,offWidget*)),this,SLOT(deleteOff(Offerta*,offWidget*)));
        layout=vlo;
    }
    else{
        layout=vl_po;
        temp->enableadmin();
        connect(temp,SIGNAL(deleteClicked(Offerta*,offWidget*)),this,SLOT(delete_Poff(Offerta*,offWidget*)));
    }
    delete layout->takeAt(layout->count()-1)->spacerItem();    //rimuove lo stretch finale del layout della pagina delle offerte
    layout->addWidget(temp);
    layout->addStretch();

    connect(this,SIGNAL(destroyed()),temp,SLOT(deleteLater()));  //distrugge automaticamente insieme al padre
    connect(this,SIGNAL(disablebuttons()),temp,SLOT(disablebuttons()));
    connect(temp,SIGNAL(vedidettagli(Offerta*)),this,SLOT(vediofferta(Offerta*)));
}

void UserInfoWindow::updateGruppo(Gruppo* gruppo){
    groupWidget *temp=new groupWidget(gruppo);
    delete vlg->takeAt(vlg->count()-1)->spacerItem();    //rimuove lo stretch finale del layout della pagina dei gruppo
    vlg->addWidget(temp);
    vlg->addStretch();

    connect(temp,SIGNAL(deleteClicked(Gruppo*,groupWidget*,int)),this,SLOT(deleteGroup(Gruppo*,groupWidget*,int)));
    connect(this,SIGNAL(disablebuttons()),temp,SLOT(disablebuttons()));
    connect(temp,SIGNAL(clicked(Gruppo*)),this,SLOT(vedigruppo(Gruppo*)));
    connect(this,SIGNAL(destroyed()),temp,SLOT(deleteLater()));  //distrugge automaticamente insieme al padre
}

void UserInfoWindow::vedicontatto(Contatto contatto){
    UserInfoWindow *window=new UserInfoWindow(dynamic_cast<Account*>(*contatto));
    window->show(account);   //è già impostato nel costruttore la distruzione automatica
}

void UserInfoWindow::vediazienda(Azienda* azienda){
    azinfoWidget *info=new azinfoWidget(azienda,account);
    info->show();
    info->setAttribute(Qt::WA_DeleteOnClose);
}

void UserInfoWindow::vediofferta(Offerta* offerta){
    offInfoWidget *info=new offInfoWidget(offerta,account);
    info->show();
    info->setAttribute(Qt::WA_DeleteOnClose);
}
void UserInfoWindow::vedigruppo(Gruppo* gruppo){
    groupInfoWidget *info=new groupInfoWidget(gruppo,account);
    info->show();
    info->setAttribute(Qt::WA_DeleteOnClose);
}

void UserInfoWindow::deleteExp(Exp *e,expWidget *wid){
    int r=QMessageBox::warning(this,"Richiesta di conferma","Sei sicuro di voler cancellare l'esperienza?",
                               QMessageBox::Yes,QMessageBox::No);
    if(r==QMessageBox::Yes){
        wid->disconnect();
        delete wid;
        resize(sizeHint());
        try{account->deletelavoro(e);}
        catch(ErrStateExp e){
            ErrorMex *err=new ErrorMex(e);
            err->show();
            return;
        }
    }
}

void UserInfoWindow::deleteMex(Messaggio *m, mexWidget *wid){
    int r=QMessageBox::warning(this,"Richiesta di conferma","Sei sicuro di voler cancellare la segnalazione?",
                               QMessageBox::Yes,QMessageBox::No);
    if(r==QMessageBox::Yes){
        wid->disconnect();
        delete wid;
        resize(sizeHint());
        try{account->deleteSegnalazione(m);}
        catch(ErrStateExp e){
            ErrorMex *err=new ErrorMex(e);
            err->show();
            return;
        }
    }
}

void UserInfoWindow::deleteAzi(Azienda *a, azWidget *wid,int mod){
    int r=QMessageBox::warning(this,"Richiesta di conferma","Sei sicuro di voler rimuovere l'azienda dalla lista?",
                               QMessageBox::Yes,QMessageBox::No);
    if(r==QMessageBox::Yes){
        try{
            if(mod==1)               //se mod==1 allora rimuovi l'azienda dal profilo
                account->removeazienda(a);
            else                     //altrimenti la elimina del tutto
                account->deleteazienda(a);
        }
        catch(ErrState e){
            ErrorMex *err=new ErrorMex(e);
            err->show();
            return;
        }
        wid->disconnect();
        delete wid;
    }
}

void UserInfoWindow::deleteGroup(Gruppo *a, groupWidget *wid,int mod){
    int r=QMessageBox::warning(this,"Richiesta di conferma","Sei sicuro di voler rimuovere il gruppo dalla lista?",
                               QMessageBox::Yes,QMessageBox::No);
    if(r==QMessageBox::Yes){
        try{
            if(mod==1)               //se mod==1 allora rimuovi lil gruppo dal profilo
                account->removegruppo(a);
            else                     //altrimenti lo elimina del tutto
                account->deletegruppo(a);
        }
        catch(ErrState e){
            ErrorMex *err=new ErrorMex(e);
            err->show();
            return;
        }
        wid->disconnect();
        delete wid;
    }
}

void UserInfoWindow::deleteOff(Offerta *a, offWidget *wid){
    int r=QMessageBox::warning(this,"Richiesta di conferma","Sei sicuro di voler rimuovere l'offerta dalla lista delle candidature?",
                               QMessageBox::Yes,QMessageBox::No);
    if(r==QMessageBox::Yes){
        try{account->toglidaofferta(a);}
        catch(ErrState e){
            ErrorMex *err=new ErrorMex(e);
            err->show();
            return;
        }
        wid->disconnect();
        delete wid;
    }
}

void UserInfoWindow::delete_Poff(Offerta *a, offWidget *wid){
    int r=QMessageBox::warning(this,"Richiesta di conferma","Sei sicuro di voler rimuovere l'offerta permanentemente?",
                               QMessageBox::Yes,QMessageBox::No);
    if(r==QMessageBox::Yes){
        try{account->deleteofferta(a);}
        catch(ErrState e){
            ErrorMex *err=new ErrorMex(e);
            err->show();
            return;
        }
        wid->disconnect();
        delete wid;
    }
}

void UserInfoWindow::deleteContacts(Account *a, contactWidget *wid){
    int r=QMessageBox::warning(this,"Richiesta di conferma","Sei sicuro di voler rimuovere il Contatto",
                               QMessageBox::Yes,QMessageBox::No);
    if(r==QMessageBox::Yes){
        try{account->deletecontatto(a);
        }
        catch(ErrState e){
            ErrorMex *err=new ErrorMex(e);
            err->show();
            return;
        }
        int i=vcontact->indexOf(wid);   //rimuove il widget dal vector
        vcontact->remove(i);
        wid->disconnect();
        delete wid;
        updatefilter();
        resize(sizeHint());
    }
}

void UserInfoWindow::filtracontact(QString selectedtag){
    if(selectedtag=="Tutti i TAG"){                     //leva il filtro precedente mostrando tutti i contatti
        for(int i=0;i<vcontact->size();i++){
            if((*vcontact)[i]->isVisible()==false)
            (*vcontact)[i]->setVisible(true);
        }
    }
    else{
        vector<int> index=account->filtracontatti(selectedtag.toStdString());    //tag è l'enum "parametro"
        for(int i=0;i<vcontact->size();i++)
            (*vcontact)[i]->setVisible(false);          //nasconde tutti i contatti
        for(unsigned int i=0;i<index.size();i++)
            (*vcontact)[index[i]]->setVisible(true);   //index contiene gli indici dei contatti da mostrare
    }
}

void UserInfoWindow::disableActions(Account *acc){
    tipoAcc tipo=acc->checktipoaccount();
    if(tipo!=ADMIN){
        emit disablebuttons();//disabilita i pulsanti di modifica
        removeTab(6);         //rimuove tab delle offerte personali
        if(tipo!=EXECUTIVE){
            removeTab(5);         //rimuove tab delle offerte
            if(tipo!=BUSINESS){
                removeTab(4);     //rimuove tab delle aziende
            }
        }
    }
}

void UserInfoWindow::show(Account *ut){
    disableActions(ut);
    QTabWidget::show();
}

UserInfoWindow::~UserInfoWindow(){
    delete expwin;
}

