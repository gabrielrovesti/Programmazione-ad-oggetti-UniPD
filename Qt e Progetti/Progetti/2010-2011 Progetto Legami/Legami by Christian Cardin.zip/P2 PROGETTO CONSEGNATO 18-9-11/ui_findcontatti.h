/********************************************************************************
** Form generated from reading UI file 'findcontatti.ui'
**
** Created: Sun Sep 18 16:34:32 2011
**      by: Qt User Interface Compiler version 4.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FINDCONTATTI_H
#define UI_FINDCONTATTI_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QGridLayout>
#include <QtGui/QGroupBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpinBox>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_findContatti
{
public:
    QGroupBox *groupBox;
    QCheckBox *simili;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QSpinBox *soglia;
    QLabel *label_6;
    QPushButton *cerca;
    QWidget *layoutWidget1;
    QGridLayout *gridLayout;
    QLabel *label;
    QLineEdit *user;
    QLabel *label_2;
    QLineEdit *nome;
    QLabel *label_3;
    QLineEdit *cogn;
    QLabel *label_4;
    QLineEdit *spec;
    QLabel *label_5;
    QLineEdit *loc;

    void setupUi(QWidget *findContatti)
    {
        if (findContatti->objectName().isEmpty())
            findContatti->setObjectName(QString::fromUtf8("findContatti"));
        findContatti->resize(551, 190);
        groupBox = new QGroupBox(findContatti);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(320, 10, 221, 101));
        simili = new QCheckBox(groupBox);
        simili->setObjectName(QString::fromUtf8("simili"));
        simili->setGeometry(QRect(0, 40, 121, 22));
        layoutWidget = new QWidget(groupBox);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(0, 70, 218, 29));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        soglia = new QSpinBox(layoutWidget);
        soglia->setObjectName(QString::fromUtf8("soglia"));
        soglia->setMinimum(0);
        soglia->setMaximum(100);
        soglia->setSingleStep(10);
        soglia->setValue(60);

        horizontalLayout->addWidget(soglia);

        label_6 = new QLabel(layoutWidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout->addWidget(label_6);

        cerca = new QPushButton(findContatti);
        cerca->setObjectName(QString::fromUtf8("cerca"));
        cerca->setGeometry(QRect(330, 120, 201, 51));
        layoutWidget1 = new QWidget(findContatti);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(10, 10, 301, 161));
        gridLayout = new QGridLayout(layoutWidget1);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(layoutWidget1);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 2);

        user = new QLineEdit(layoutWidget1);
        user->setObjectName(QString::fromUtf8("user"));

        gridLayout->addWidget(user, 0, 3, 1, 1);

        label_2 = new QLabel(layoutWidget1);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        nome = new QLineEdit(layoutWidget1);
        nome->setObjectName(QString::fromUtf8("nome"));

        gridLayout->addWidget(nome, 1, 3, 1, 1);

        label_3 = new QLabel(layoutWidget1);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout->addWidget(label_3, 2, 0, 1, 2);

        cogn = new QLineEdit(layoutWidget1);
        cogn->setObjectName(QString::fromUtf8("cogn"));

        gridLayout->addWidget(cogn, 2, 3, 1, 1);

        label_4 = new QLabel(layoutWidget1);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout->addWidget(label_4, 3, 0, 1, 3);

        spec = new QLineEdit(layoutWidget1);
        spec->setObjectName(QString::fromUtf8("spec"));

        gridLayout->addWidget(spec, 3, 3, 1, 1);

        label_5 = new QLabel(layoutWidget1);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout->addWidget(label_5, 4, 0, 1, 2);

        loc = new QLineEdit(layoutWidget1);
        loc->setObjectName(QString::fromUtf8("loc"));

        gridLayout->addWidget(loc, 4, 3, 1, 1);


        retranslateUi(findContatti);

        QMetaObject::connectSlotsByName(findContatti);
    } // setupUi

    void retranslateUi(QWidget *findContatti)
    {
        findContatti->setWindowTitle(QApplication::translate("findContatti", "Cerca Utenti", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QApplication::translate("findContatti", "Opzioni di rierca", 0, QApplication::UnicodeUTF8));
        simili->setText(QApplication::translate("findContatti", "Ricerca Simili", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("findContatti", "% Somiglianza Minima", 0, QApplication::UnicodeUTF8));
        cerca->setText(QApplication::translate("findContatti", "Cliccami! :D", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("findContatti", "Username", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("findContatti", "Nome", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("findContatti", "Cognome", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("findContatti", "Specializzazione", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("findContatti", "Localit\303\240", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class findContatti: public Ui_findContatti {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FINDCONTATTI_H
