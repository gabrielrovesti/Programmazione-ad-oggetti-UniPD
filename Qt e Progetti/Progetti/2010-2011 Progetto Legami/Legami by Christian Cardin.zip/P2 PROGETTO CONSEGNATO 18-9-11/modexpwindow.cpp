#include "modexpwindow.h"
#include "errormex.h"
#include "ui_modexpwindow.h"

modExpWindow::modExpWindow(Account *acc, QWidget *parent):QDialog(parent),account(acc),ui(new Ui::modExpWindow){
    ui->setupUi(this);
    ui->verticalLayout_2->setMargin(10);
    setLayout(ui->verticalLayout_2);
    connect(ui->chiudi,SIGNAL(clicked()),this,SLOT(close()));
    connect(ui->ok,SIGNAL(clicked()),this,SLOT(changes()));
    connect(ui->activity,SIGNAL(toggled(bool)),ui->fine,SLOT(setDisabled(bool)));
    setWindowTitle("Modifica Esperienza");

}
void modExpWindow::load(Exp *e){
    exp=e;
    QDate d=QDate::fromString(QString::fromStdString(exp->getinizio()),"d/M/yyyy");
    ui->inizio->setDate(d);

    if(exp->getfine()=="*In Attivita*"){
        ui->fine->setDisabled(true);
        ui->activity->setChecked(true);
    }
    else{
        d=QDate::fromString(QString::fromStdString(exp->getfine()),"d/M/yyyy");
        ui->fine->setDate(d);
    }
    ui->desc->setText(QString::fromStdString(exp->getdesc()));
    ui->tit->setText(QString::fromStdString(exp->gettitolo()));
    ui->ru->setText(QString::fromStdString(exp->getruolo()));
}

void modExpWindow::changes(){
    QDateTime inizio(ui->inizio->date());
    QDateTime fine(ui->fine->date());
    int iniziostamp=inizio.toTime_t()+8600;
    int finestamp;
    if(ui->activity->isChecked())
        finestamp=0;
    else
        finestamp=fine.toTime_t()+8600;
    try{
        account->modifyesperienza(exp,iniziostamp,finestamp,ui->desc->toPlainText().toStdString(),ui->tit->text().toStdString(),ui->ru->text().toStdString());
    }
    catch(ErrState e){
        ErrorMex* wmess=new ErrorMex(e);
        wmess->show();
        return;
    }
    OkMex* kmex=new OkMex("Modifica Esperienza","Modifiche avvenute con successo");
    kmex->show();
    emit expChanged();
    close();

}

modExpWindow::~modExpWindow(){
    delete ui;
}
