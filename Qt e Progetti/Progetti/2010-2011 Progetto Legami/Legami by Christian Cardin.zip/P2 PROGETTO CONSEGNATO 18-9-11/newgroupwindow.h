#ifndef NEWGROUPWINDOW_H
#define NEWGROUPWINDOW_H

#include <QWidget>

namespace Ui {
    class newGroupWindow;
}

/*Finestra per la creazione di un nuov gruppo. L'utente inserisce i dati e questa li trasmette
 *per mezzo di un segnale. Il metodo close() è stato ridefinito in modo che tutti i campi vengano
 *svuotati dal loro precedente contenuto.
 *Gli oggetti vengono distrutti automaticamente alla distruzione della finestra.
 */

class newGroupWindow : public QWidget{
    Q_OBJECT

public:
    explicit newGroupWindow(QWidget *parent = 0);
    ~newGroupWindow();
signals:
    void createGroup(QString,QString,QString,QString);
private slots:
    void newGroup();
public slots:
    bool close();
private:
    void clearFields();
    Ui::newGroupWindow *ui;
};

#endif // NEWGROUPWINDOW_H
