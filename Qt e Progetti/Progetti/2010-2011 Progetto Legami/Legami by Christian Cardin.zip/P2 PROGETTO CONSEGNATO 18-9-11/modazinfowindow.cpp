#include "modazinfowindow.h"
#include "ui_modazinfowindow.h"
#include "errormex.h"
modAzinfowindow::modAzinfowindow(Azienda* a,Account* acc,QWidget *parent):QWidget(parent),azienda(a),account(acc),
ui(new Ui::modAzinfowindow){
    ui->setupUi(this);
    ui->dim->addItem("< 10");
    ui->dim->addItem("Da 10 a 30");
    ui->dim->addItem("Da 30 a 100");
    ui->dim->addItem("Da 100 a 500");
    ui->dim->addItem("500 +");
    loadLabels();
    connect(ui->chiudi,SIGNAL(clicked()),this,SLOT(close()));
    connect(ui->ok,SIGNAL(clicked()),this,SLOT(modify()));
}

void modAzinfowindow::loadLabels(){
    AzInfo *info=azienda->getinfo();
    ui->loc->setText(QString::fromStdString(info->getlocalita()));
    ui->ind->setText(QString::fromStdString(info->getindirizzo()));
    ui->email->setText(QString::fromStdString(info->getemail()));
    ui->web->setText(QString::fromStdString(info->getweb()));
    ui->tel->setText(QString::fromStdString(info->gettelefono()));
    ui->desc->setPlainText(QString::fromStdString(info->getdesc()));
    int index=0;
    QString azdim=QString::fromStdString(info->getdim());
    if(azdim=="Da 10 a 30")
        index=1;
    else if(azdim=="Da 30 a 100")
        index=2;
    else if(azdim=="Da 100 a 500")
        index=3;
    else if(azdim=="500 +")
        index=4;
    ui->dim->setCurrentIndex(index);
}

void modAzinfowindow::modify(){
    try{
        account->modifyazinfo(azienda,ui->loc->text().toStdString(),ui->ind->text().toStdString(),ui->desc->toPlainText().toStdString(),
                               ui->dim->currentText().toStdString(),ui->web->text().toStdString(),ui->tel->text().toStdString(),ui->email->text().toStdString());
    }catch(ErrState e){
        ErrorMex* werr=new ErrorMex(e);
        werr->show();
        return;
    }
    OkMex* kmex=new OkMex("Modifica Azienda","Modifiche avvenute con successo");
    kmex->show();
    emit infoChanged();
    close();
}

modAzinfowindow::~modAzinfowindow(){
    delete ui;
}
