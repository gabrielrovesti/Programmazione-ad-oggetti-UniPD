#ifndef PSTRING_H
#define PSTRING_H
#include <string>
using std::string;

class pstring:public string{
public:
    pstring(string s="");
    pstring(const char*);
    pstring(int);

    pstring operator=(const int&);
    pstring operator+=(const int&);
    pstring operator=(const char*);
    pstring operator+=(const char*);
    pstring operator=(const string&);
    pstring operator+=(const string&);

    bool isEmpty() const;
    pstring trimmed() const;
    pstring toLower() const;
    bool contains(const pstring,bool caseSensitive=false) const;
};

#endif // PSTRING_H
