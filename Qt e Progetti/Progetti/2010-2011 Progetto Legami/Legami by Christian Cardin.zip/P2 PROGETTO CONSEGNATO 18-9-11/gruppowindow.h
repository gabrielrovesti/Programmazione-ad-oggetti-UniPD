#ifndef GRUPPOWINDOW_H
#define GRUPPOWINDOW_H
#include <QWidget>
#include <QScrollArea>
#include <QVBoxLayout>
#include <QLineEdit>
 
#include "findgruppo.h"
#include "groupwidget.h"
#include "groupinfowidget.h"
#include "newgroupwindow.h"

/*Implementa la ricerca dei gruppi. Dal risultato della ricerca, carica dei groupWidgets che, se cliccati,
 *causano l'apertura di un groupInfoWidget con le informazioni relative al gruppo selezionata. Un pulsante
 *permette di iscriversi, e per tutti gli utenti viene mostrato un pulsante che permette la creazione di nuove aziende.
 *Il tutto è contenuto in una QScrollArea per permettere una visualizzazione più compatta in caso di liste molto lunghe.
 *Ogni volta che si visualizzano i dettagli di un grupo, viene creato un oggetto groupInfoWidget. Questo viene
 *distrutto se si vuole vedere un altro gruppo, e quindi ricreato. Alla fine viene distrutto nel distruttore insieme
 *alla finestra di ricerca e di nuovo gruppo, oltre che ai groupWidgets dell'ultima ricerca
 */

class gruppoWindow:public QWidget{
Q_OBJECT
public:
    gruppoWindow(Account* acc,QWidget *parent=0);
    ~gruppoWindow();
signals:
    void GruppoAggiunto(Gruppo*);
private slots:
    void loadGroup(QString,QString,bool,int);
    void createGroup(QString,QString,QString,QString);
    void loadInfo(Gruppo*);
    void addGruppo();

private:
    Account* account;
    findGruppo* findgroup;
    groupInfoWidget *info;
    newGroupWindow *ngw;
    QScrollArea *searchArea,*infoArea;
    QPushButton *add,*newgroup;
    QVBoxLayout *vertical;
};
#endif // GRUPPOWINDOW_H
