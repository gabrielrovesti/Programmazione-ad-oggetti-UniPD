#include "errormex.h"

OkMex::OkMex(QString tit, QString mex, QString dettagli, QWidget *parent):QMessageBox(parent){
    setWindowTitle(tit);
    setIcon(Information);
    setText(mex);
    if(dettagli!="")
        setDetailedText(dettagli);
    addButton("Ok",AcceptRole);
    this->setFixedSize(sizeHint());
    setAttribute( Qt::WA_DeleteOnClose ); //dealloca automaticamente il widget alla chiusura
}

ErrorMex::ErrorMex(ErrState err, QWidget *parent):QMessageBox(parent){
    setWindowTitle(QString::fromStdString(err.err_title()));
    setIcon(Critical);
    setText(QString::fromStdString(err.err_ambito())+"\n"+QString::fromStdString(err.err_descr()));
    addButton("Ok",AcceptRole);
    this->setFixedSize(sizeHint());
    setAttribute( Qt::WA_DeleteOnClose ); //dealloca automaticamente il widget alla chiusura
}

ErrorMex::ErrorMex(QString tit, QString ambito, QString descr, QWidget *parent):QMessageBox(parent){
    setWindowTitle(tit);
    setIcon(Critical);
    setText(ambito+"\n"+descr);
    addButton("Ok",AcceptRole);
    this->setFixedSize(sizeHint());
    setAttribute( Qt::WA_DeleteOnClose ); //dealloca automaticamente il widget alla chiusura
}

