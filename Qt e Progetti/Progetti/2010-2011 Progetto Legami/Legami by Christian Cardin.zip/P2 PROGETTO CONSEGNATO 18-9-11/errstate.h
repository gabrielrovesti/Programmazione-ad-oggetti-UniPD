#ifndef ERRSTATE_H
#define	ERRSTATE_H
#include "pstring.h"

/* state è una classe specifica per gestire le eccezioni.
 * ritorna un messaggio d'errore determinato dal tipo
 * un indicatore dell'ambito (cartelle utente, modifica info ecc..)
 * numero identificativo dell'errore
 * ogni sottoclasse gestisce eccezioni diverse, e restituisce messaggi specifici
 */
class ErrState{
protected:
    int num_ambito;
    int num_errore;
    pstring title,ambito,what;
    ErrState(int _a,int _n,pstring _t="Errore generico nell'applicativo.",pstring amb="",pstring wh="");
public:
    pstring err_title() const;
    pstring err_ambito() const;
    pstring err_descr() const;
    int getnumambito() const;
    int getnumerr() const;
};

//Errore nella modifica delle informazioni
class ErrStateInfo:public ErrState{
public:
    ErrStateInfo(int _a,int _n);
};

//Errore nella modifica del curriculum
class ErrStateExp:public ErrState{
public:
    ErrStateExp(int _a,int _n);
};

//Errore nella gestione dei Contatti
class ErrStateContact:public ErrState{
public:
    ErrStateContact(int _a,int _n);
};

class ErrStateGroup:public ErrState{
public:
    ErrStateGroup(int _a,int _n);
};

class ErrStateAz:public ErrState{
public:
    ErrStateAz(int _a,int _n);
};

class ErrStateOff:public ErrState{
public:
    ErrStateOff(int _a,int _n);
};
class ErrStateDb:public ErrState{
public:
    ErrStateDb(int row,int col,pstring mex);
};





#endif	/* STATE_H */

