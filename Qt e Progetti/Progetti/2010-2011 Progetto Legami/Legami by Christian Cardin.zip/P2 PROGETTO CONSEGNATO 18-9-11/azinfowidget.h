#ifndef AZINFOWIDGET_H
#define AZINFOWIDGET_H

#include <QGroupBox>
#include <QLabel>
#include <QPushButton>
#include <QPlainTextEdit>
#include "account.h"
#include "azienda.h"
#include "modazinfowindow.h"


/*Contiene le informazioni di un'azienda e le mostra tramite delle QLabel.
 *Se richiedente è definito (ed è effettivamente il creatore dell'azienda)
 *viene visualizzato un pulsante da cui è possibile modificare le informazioni.
 *Tutti i widget definiti in questa classe vengono automaticamente distrutti alla chiusura.
 *tranne la finestra di modifica, che viene distrutta nel distruttore se è stata definita.
 */
class azinfoWidget:public QGroupBox{
    Q_OBJECT
public:
    azinfoWidget(Azienda* a,Account* richiedente=0,QWidget* parent=0);
    Azienda* getazienda() const;
    ~azinfoWidget();
private slots:
    void loadLabels();
private:
    Azienda *azienda;
    modAzinfowindow *modaiw;
    QLabel *admin,*nome,*dim,*email,*sett,*ind,*loc,*web,*tel,*tipo;
    QPlainTextEdit *desc;
    QPushButton *modifica;
    void buildLayers();
    void buildLabels();

};

#endif // AZINFOWIDGET_H
