#ifndef MODAZINFOWINDOW_H
#define MODAZINFOWINDOW_H

#include <QWidget>
#include "account.h"
#include "azienda.h"

namespace Ui {
    class modAzinfowindow;
}

/*Finestra che consente di modificare i campi dati di un'azienda.
 *Emette un segnale una volta effettuate le modifiche.
 *Tutti i widget ivi contenuti vengono distrutti automaticamente alla chiusura
 */

class modAzinfowindow : public QWidget{
    Q_OBJECT

public:
    explicit modAzinfowindow(Azienda* a,Account* acc,QWidget *parent = 0);
    ~modAzinfowindow();
signals:
    void infoChanged();
private slots:
    void modify();
private:
    void loadLabels();
    Azienda* azienda;
    Account* account;
    Ui::modAzinfowindow *ui;
};

#endif // MODAZINFOWINDOW_H
