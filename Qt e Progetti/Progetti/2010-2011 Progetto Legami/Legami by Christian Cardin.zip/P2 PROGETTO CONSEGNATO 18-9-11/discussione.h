#ifndef DISCUSSIONE_H
#define	DISCUSSIONE_H
#include <vector>
#include "link.h"
#include "dataora.h"
#include "messaggio.h"
#include "pstring.h"
using std::vector;

class Discussione{
private:
    User* creatore;
    pstring argomento;
    dataora creazione;
    vector<Messaggio*>* messaggi;
public:
    //se il parametro dataora è settato a 0, inizializza la discussione con l'ora attuale
    Discussione(User* _creatore,pstring _argomento,dataora _creazione=dataora(),vector<Messaggio*>* _mex=new vector<Messaggio*>);
    
    void insertmex(Messaggio*);
    User* getcreatore() const;
    pstring getargomento() const;
    pstring getdata() const;
    pstring getora() const;
    pstring tostring() const;
    int getNumMex() const;
    vector<Messaggio*>* getmessaggi() const;
    ~Discussione();
};


#endif	/* DISCUSSIONE_H */

