#ifndef LOGINFORM_H
#define LOGINFORM_H
#include <QtGui>
class Legami;
class Account;


/*Finestra per il login degli utenti. Prende come parametro un riferimento al gestore, in modo da richiamare
 *la funzione di login. Una volta accertata l'identità dell'utente, trasmette per mezzo di un segnale
 *l'account ritornato e validato.
 *Il metodo close() è stato ridefinito in modo che tutti i campi vengano svuotati dal loro precedente contenuto.
 *Gli oggetti vengono distrutti automaticamente alla distruzione della finestra.
 */
class Loginform:public QWidget{
    Q_OBJECT
public:
    Loginform(Legami* gest,QWidget *parent=0);
signals:
    void loginaccount(Account*);
public slots:
    bool close();
private slots:
    void clearFields();
    void loginClicked();
    void EnableButtonLogin();
private:
    Legami* gestore;
    QLabel* lock;
    QPushButton *login;
    QPushButton *bclose;
    QLineEdit *luser;
    QLineEdit *lpass;
};

#endif // LOGINFORM_H
