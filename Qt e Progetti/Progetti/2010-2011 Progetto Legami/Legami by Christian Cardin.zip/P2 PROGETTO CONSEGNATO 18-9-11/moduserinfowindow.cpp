#include "moduserinfowindow.h"
#include "ui_moduserinfowindow.h"
#include "errormex.h"

moduserinfowindow::moduserinfowindow(Account* acc,QWidget *parent):
        QWidget(parent),account(acc),ui(new Ui::moduserinfowindow){
    ui->setupUi(this);
    buildLabels();
    connect(ui->chiudi,SIGNAL(clicked()),this,SLOT(close()));
    connect(ui->ok,SIGNAL(clicked()),this,SLOT(changes()));

}

void moduserinfowindow::buildLabels(){
    UserInfo* infos=account->getinfo();
    ui->lpass->setText(QString::fromStdString(infos->getpassword()));
    ui->lnome->setText(QString::fromStdString(infos->getnome()));
    ui->lcogn->setText(QString::fromStdString(infos->getcognome()));
    ui->lind->setText(QString::fromStdString(infos->getindirizzo()));
    ui->lob->setText(QString::fromStdString(infos->getobiettivi()));
    ui->lloc->setText(QString::fromStdString(infos->getlocalita()));
    ui->linter->setText(QString::fromStdString(infos->getinteressi()));
    ui->lweb->setText(QString::fromStdString(infos->getweb()));
    ui->ltel->setText(QString::fromStdString(infos->gettelefono()));
    ui->lspec->setText(QString::fromStdString(infos->getspec()));
}

void moduserinfowindow::changes(){
    try{
        account->modifyinfo(ui->lpass->text().toStdString(),ui->lnome->text().toStdString(),ui->lcogn->text().toStdString(),ui->lloc->text().toStdString(),
                            ui->lind->text().toStdString(),ui->lspec->text().toStdString(),ui->lob->toPlainText().toStdString(),ui->ltel->text().toStdString(),
                            ui->lweb->text().toStdString(),ui->linter->toPlainText().toStdString());
    }catch(ErrState e){
        ErrorMex* wmess=new ErrorMex(e);
        wmess->show();
    }
    OkMex* kmex=new OkMex("Modifica Informazioni","Modifiche avvenute con successo");
    kmex->show();
    emit infoChanged();
    close();
}

moduserinfowindow::~moduserinfowindow()
{
    delete ui;
}
