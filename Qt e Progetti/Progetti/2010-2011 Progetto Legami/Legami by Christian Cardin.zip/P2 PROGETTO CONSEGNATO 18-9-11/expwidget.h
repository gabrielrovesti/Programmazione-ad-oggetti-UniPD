#ifndef EXPWIDGET_H
#define EXPWIDGET_H
#include <QWidget>
#include <QLabel>
#include <QPushButton>
#include <QPlainTextEdit>
#include "account.h"
#include "modexpwindow.h"
#include "azwidget.h"

/*Widget Esperienza: contiene informazioni sull'esperienza lavorativa che rappresenta.
 *Attraverso gli appositi pulsanti, l'account potrà modificare i campi informativi o rimuovere
 *del tutto l'esperienza. Se l'esperienza è collegata ad un'azienda, comparirà un azWidget al posto
 *del nome dell'azienda, e se cliccato mostrerà le informazioni ad essa relative.
 *L'azWidget e la finestra di modifica sono distrutte nel distruttore, gli altri elementi sono deallocati
 *automaticamente alla distruzione della classe.
*/

class expWidget:public QWidget{
    Q_OBJECT
public:
    expWidget(Account* acc,Exp* e,QWidget* parent=0);
    ~expWidget();
signals:
    void deleteClicked(Exp*,expWidget*);
public slots:
    void del();
    void mod();
    void reloadLabels();
    void disablebuttons();
private slots:
    void showazinfo(Azienda*);
private:
    Account* account;
    Exp* exp;
    QPlainTextEdit *desc;
    QLabel *nomeaz,*durata,*ruolo,*tit,*ldesc;
    QPushButton *modifica,*cancella;
    modExpWindow *modexp;
    azWidget *azwid;
    void buildLayers();
    void buildLabels();
    void buildButtons();
};

#endif // EXPWIDGET_H
