#ifndef OFFERTA_H
#define	OFFERTA_H
#include "utils.h"
#include "dataora.h"
#include <vector>
#include "pstring.h"
using std::vector;

class User;
class Azienda;
class Offerta{
private:
    int id;
    pstring titolo,localita,indirizzo,settore,descrizione,giornata,esperienza;
    pstring specifiche;
    dataora creazione;
    User* creatore;
    Azienda* azienda;
    vector<User*>* candidati;
    
public:
    Offerta(int _id,pstring _tit,pstring _reg,pstring _ind,pstring _sett,pstring _desc,pstring _gio,
            pstring _esp,User* _creat,Azienda* _az=0,dataora _creaz=dataora(),
            pstring _spec="",vector<User*>* _candidati=new vector<User*>);

    pstring gettitolo() const;
    pstring getlocalita() const;
    pstring getindirizzo() const;
    pstring getsettore() const;
    pstring getdescrizione() const;
    pstring getgiornata() const;
    pstring getexp() const;
    pstring getspecifiche() const;
    pstring getcreazione() const;
    User* getcreatore() const;
    Azienda* getazienda() const;
    int getid() const;
    pstring tostring() const;
    void unsetAzienda();
    vector<User*>* getcandidati() const;
    double somiglia(const Offerta& off) const;
    bool operator <(const Offerta& o) const;
    ~Offerta();
};

#endif	/* OFFERTA_H */

