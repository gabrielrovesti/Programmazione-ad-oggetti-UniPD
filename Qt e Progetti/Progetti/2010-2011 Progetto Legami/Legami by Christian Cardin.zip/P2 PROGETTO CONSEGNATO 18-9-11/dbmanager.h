#ifndef DBMANAGER_H
#define DBMANAGER_H
#include <QString>
#include <QFile>
#include <QTreeWidget>
#include <QtXml/qdom.h>
#include <QXmlStreamWriter>
#include "info.h"
#include "messaggio.h"
#include "offerta.h"
#include "gruppo.h"
 
#include <vector>
 
using std::vector;
class Contatto;
class Legami;
class Exp;

class DBmanager{
private:
    Legami* gestore;
    bool DBLocked;
    bool dirtBit;
    QFile file;
    QTreeWidget* treeAcc;
    QTreeWidget* treeCon;
    QTreeWidget* treeAzi;
    QTreeWidget* treeExp;
    QTreeWidget* treeSegn;
    QTreeWidget* treeOff;
    QTreeWidget* treeGro;

    //*****WRITE******
    void writeAccount(QXmlStreamWriter *xwriter,QTreeWidgetItem *item);
    void writeContatto(QXmlStreamWriter *xwriter,QTreeWidgetItem *item);
    void writeAzienda(QXmlStreamWriter *xwriter,QTreeWidgetItem *item);
    void writeExp(QXmlStreamWriter *xwriter,QTreeWidgetItem *item);
    void writeSegn(QXmlStreamWriter *xwriter,QTreeWidgetItem *item);
    void writeOff(QXmlStreamWriter *xwriter,QTreeWidgetItem *item);
    void writeGro(QXmlStreamWriter *xwriter,QTreeWidgetItem *item);
    //*****PARSE******
    void parseLegami(const QDomElement& element);
    void parseAccount(const QDomElement& element,QTreeWidgetItem* parent);
    void parseContatto(const QDomElement& element,QTreeWidgetItem* parent);
    void parseAzienda(const QDomElement& element,QTreeWidgetItem* parent);
    void parseExp(const QDomElement& element,QTreeWidgetItem* parent);
    void parseSegn(const QDomElement& element,QTreeWidgetItem* parent);
    void parseOff(const QDomElement& element,QTreeWidgetItem* parent);
    void parseGro(const QDomElement& element,QTreeWidgetItem* parent);

public:
    QTreeWidgetItem* findInTree(QTreeWidget* tree,QString first,QString second="",QString third="");
    DBmanager(Legami* gest=0,const pstring &filename="legami.xml");
    bool readfile() throw(ErrStateDb);
    void writexml();
    void clearmemory();
    //*****SAVE*****
    void saveAccount(UserInfo* info,tipoAcc tacc=BASIC,bool del=0);
    void saveContatto(User* prop);
    void saveAzienda(AzInfo* info,pstring adm="",bool del=0);
    void saveExp(pstring user,vector<Exp*>* exp);
    void saveSegn(pstring user,vector<Messaggio*>* exp);
    void saveOff(Offerta* off,bool del=0);
    void saveGro(Gruppo* g,bool del=0);
    ~DBmanager();
};

#endif // DBMANAGER_H
