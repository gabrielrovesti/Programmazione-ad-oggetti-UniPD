/********************************************************************************
** Form generated from reading UI file 'newexpwindow.ui'
**
** Created: Sun Sep 18 16:34:32 2011
**      by: Qt User Interface Compiler version 4.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEWEXPWINDOW_H
#define UI_NEWEXPWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QDateEdit>
#include <QtGui/QFormLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPlainTextEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_newExpWindow
{
public:
    QWidget *layoutWidget;
    QVBoxLayout *vmainlayout;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout;
    QFormLayout *formLayout_5;
    QLabel *label_5;
    QDateEdit *inizio;
    QSpacerItem *horizontalSpacer;
    QFormLayout *formLayout_6;
    QLabel *label_6;
    QDateEdit *fine;
    QCheckBox *activity;
    QFormLayout *formLayout;
    QLabel *label;
    QLineEdit *nome;
    QFormLayout *formLayout_3;
    QLabel *label_3;
    QLineEdit *tit;
    QFormLayout *formLayout_2;
    QLabel *label_2;
    QLineEdit *ru;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_4;
    QSpacerItem *horizontalSpacer_2;
    QPlainTextEdit *desc;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *chiudi;
    QPushButton *ok;
    QSpacerItem *horizontalSpacer_4;

    void setupUi(QWidget *newExpWindow)
    {
        if (newExpWindow->objectName().isEmpty())
            newExpWindow->setObjectName(QString::fromUtf8("newExpWindow"));
        newExpWindow->resize(503, 379);
        QSizePolicy sizePolicy(QSizePolicy::MinimumExpanding, QSizePolicy::MinimumExpanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(newExpWindow->sizePolicy().hasHeightForWidth());
        newExpWindow->setSizePolicy(sizePolicy);
        layoutWidget = new QWidget(newExpWindow);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 20, 432, 323));
        vmainlayout = new QVBoxLayout(layoutWidget);
        vmainlayout->setObjectName(QString::fromUtf8("vmainlayout"));
        vmainlayout->setContentsMargins(0, 0, 0, 0);
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        formLayout_5 = new QFormLayout();
        formLayout_5->setObjectName(QString::fromUtf8("formLayout_5"));
        formLayout_5->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
        label_5 = new QLabel(layoutWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        formLayout_5->setWidget(0, QFormLayout::LabelRole, label_5);

        inizio = new QDateEdit(layoutWidget);
        inizio->setObjectName(QString::fromUtf8("inizio"));

        formLayout_5->setWidget(0, QFormLayout::FieldRole, inizio);


        horizontalLayout->addLayout(formLayout_5);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        formLayout_6 = new QFormLayout();
        formLayout_6->setObjectName(QString::fromUtf8("formLayout_6"));
        formLayout_6->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
        label_6 = new QLabel(layoutWidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        formLayout_6->setWidget(0, QFormLayout::LabelRole, label_6);

        fine = new QDateEdit(layoutWidget);
        fine->setObjectName(QString::fromUtf8("fine"));

        formLayout_6->setWidget(0, QFormLayout::FieldRole, fine);


        horizontalLayout->addLayout(formLayout_6);

        activity = new QCheckBox(layoutWidget);
        activity->setObjectName(QString::fromUtf8("activity"));

        horizontalLayout->addWidget(activity);


        verticalLayout_2->addLayout(horizontalLayout);

        formLayout = new QFormLayout();
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label);

        nome = new QLineEdit(layoutWidget);
        nome->setObjectName(QString::fromUtf8("nome"));

        formLayout->setWidget(0, QFormLayout::FieldRole, nome);


        verticalLayout_2->addLayout(formLayout);

        formLayout_3 = new QFormLayout();
        formLayout_3->setObjectName(QString::fromUtf8("formLayout_3"));
        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        formLayout_3->setWidget(0, QFormLayout::LabelRole, label_3);

        tit = new QLineEdit(layoutWidget);
        tit->setObjectName(QString::fromUtf8("tit"));

        formLayout_3->setWidget(0, QFormLayout::FieldRole, tit);


        verticalLayout_2->addLayout(formLayout_3);

        formLayout_2 = new QFormLayout();
        formLayout_2->setObjectName(QString::fromUtf8("formLayout_2"));
        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        formLayout_2->setWidget(0, QFormLayout::LabelRole, label_2);

        ru = new QLineEdit(layoutWidget);
        ru->setObjectName(QString::fromUtf8("ru"));

        formLayout_2->setWidget(0, QFormLayout::FieldRole, ru);


        verticalLayout_2->addLayout(formLayout_2);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setSizeConstraint(QLayout::SetMinimumSize);
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_2->addWidget(label_4);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);


        verticalLayout->addLayout(horizontalLayout_2);

        desc = new QPlainTextEdit(layoutWidget);
        desc->setObjectName(QString::fromUtf8("desc"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(desc->sizePolicy().hasHeightForWidth());
        desc->setSizePolicy(sizePolicy1);

        verticalLayout->addWidget(desc);


        verticalLayout_2->addLayout(verticalLayout);


        vmainlayout->addLayout(verticalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_3);

        chiudi = new QPushButton(layoutWidget);
        chiudi->setObjectName(QString::fromUtf8("chiudi"));

        horizontalLayout_3->addWidget(chiudi);

        ok = new QPushButton(layoutWidget);
        ok->setObjectName(QString::fromUtf8("ok"));

        horizontalLayout_3->addWidget(ok);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_4);


        vmainlayout->addLayout(horizontalLayout_3);


        retranslateUi(newExpWindow);

        QMetaObject::connectSlotsByName(newExpWindow);
    } // setupUi

    void retranslateUi(QWidget *newExpWindow)
    {
        newExpWindow->setWindowTitle(QApplication::translate("newExpWindow", "Form", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("newExpWindow", "*Inizio", 0, QApplication::UnicodeUTF8));
        inizio->setDisplayFormat(QApplication::translate("newExpWindow", "dd/MM/yyyy", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("newExpWindow", "Fine", 0, QApplication::UnicodeUTF8));
        fine->setDisplayFormat(QApplication::translate("newExpWindow", "dd/MM/yyyy", 0, QApplication::UnicodeUTF8));
        activity->setText(QApplication::translate("newExpWindow", "In Attivita", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("newExpWindow", "*Nome Azienda", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("newExpWindow", "Titolo", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("newExpWindow", "Ruolo", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("newExpWindow", "*Descrizione", 0, QApplication::UnicodeUTF8));
        chiudi->setText(QApplication::translate("newExpWindow", "Chiudi", 0, QApplication::UnicodeUTF8));
        ok->setText(QApplication::translate("newExpWindow", "Ok", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class newExpWindow: public Ui_newExpWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEWEXPWINDOW_H
