#include "offerta.h"
#include "info.h"
#include "user.h"
#include "azienda.h"

Offerta::Offerta(int _id, pstring _tit, pstring _reg, pstring _ind, pstring _sett,
                 pstring _desc, pstring _gio, pstring _esp, User *_creat,
                 Azienda *_az, dataora _creaz, pstring _spec,
                 vector<User *> *_candidati):id(_id),titolo(_tit),localita(_reg),
        indirizzo(_ind),settore(_sett),descrizione(_desc),giornata(_gio),
        esperienza(_esp),specifiche(_spec),creazione(_creaz),creatore(_creat),azienda(_az),
        candidati(_candidati){}


pstring Offerta::gettitolo() const{return titolo;}
    pstring Offerta::getlocalita() const{return localita;}
    pstring Offerta::getindirizzo() const{return indirizzo;}
    pstring Offerta::getsettore() const{return settore;}
    pstring Offerta::getdescrizione() const{return descrizione;}
    pstring Offerta::getgiornata() const{return giornata;}
    pstring Offerta::getexp() const{return esperienza;}
    pstring Offerta::getspecifiche() const{return specifiche;}
    pstring Offerta::getcreazione() const{return creazione.getdata();}
    User* Offerta::getcreatore() const{return creatore;}
    Azienda* Offerta::getazienda() const{return azienda;}
    int Offerta::getid() const{return id;}
    vector<User*>* Offerta::getcandidati() const{return candidati;}



pstring Offerta::tostring() const{
        pstring out;
        out=creatore->getinfo()->getusername()+"##";
        if(azienda)
            out+=azienda->getinfo()->getnome();
        out+="##";
        out+=titolo+"##";
        out+=localita+"##";
        out+=indirizzo+"##";
        out+=settore+"##";
        out+=descrizione+"##";
        out+=giornata+"##";
        out+=esperienza+"##";
        out+=creazione.stamp();out+="##";
        out+=specifiche+"##";
        return out;
    }

    double Offerta::somiglia(const Offerta& off) const{
        double match=0,totcampi=0;
    if(off.titolo!=""){
        totcampi+=5;
        if(titolo.contains(off.titolo))match+=5;}
    if(off.settore!=""){
        totcampi+=3;
        if(settore.contains(off.settore))match+=3;}
    if(off.giornata!=""){
        totcampi+=3;
        if(giornata.toLower()==off.giornata.toLower())match+=3;}
        if(off.localita!=""){
        totcampi+=2;
        if(localita.toLower()==off.localita.toLower())match+=2;}
    if(off.descrizione!=""){
        totcampi++;
        if(descrizione.trimmed().contains(off.descrizione.trimmed()))match++;}
    if(totcampi==0) return 0;
    return match/totcampi*100.0;
    }

    bool Offerta::operator <(const Offerta& o) const{
       return id<o.id;
    }
    
    void Offerta::unsetAzienda(){
        azienda=0;
    }

    Offerta::~Offerta(){
        delete candidati;
    }
