/********************************************************************************
** Form generated from reading UI file 'modgroupinfowindow.ui'
**
** Created: Sun Sep 18 16:34:32 2011
**      by: Qt User Interface Compiler version 4.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MODGROUPINFOWINDOW_H
#define UI_MODGROUPINFOWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QFormLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPlainTextEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_modGroupinfowindow
{
public:
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_2;
    QFormLayout *formLayout;
    QLabel *label;
    QLineEdit *sett;
    QFormLayout *formLayout_2;
    QLabel *label_2;
    QLineEdit *web;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout;
    QLabel *label_4;
    QSpacerItem *verticalSpacer;
    QPlainTextEdit *desc;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer;
    QPushButton *chiudi;
    QPushButton *ok;
    QSpacerItem *horizontalSpacer_2;

    void setupUi(QWidget *modGroupinfowindow)
    {
        if (modGroupinfowindow->objectName().isEmpty())
            modGroupinfowindow->setObjectName(QString::fromUtf8("modGroupinfowindow"));
        modGroupinfowindow->resize(354, 259);
        layoutWidget = new QWidget(modGroupinfowindow);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 10, 335, 241));
        verticalLayout_2 = new QVBoxLayout(layoutWidget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        formLayout = new QFormLayout();
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label);

        sett = new QLineEdit(layoutWidget);
        sett->setObjectName(QString::fromUtf8("sett"));

        formLayout->setWidget(0, QFormLayout::FieldRole, sett);


        verticalLayout_2->addLayout(formLayout);

        formLayout_2 = new QFormLayout();
        formLayout_2->setObjectName(QString::fromUtf8("formLayout_2"));
        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        formLayout_2->setWidget(0, QFormLayout::LabelRole, label_2);

        web = new QLineEdit(layoutWidget);
        web->setObjectName(QString::fromUtf8("web"));

        formLayout_2->setWidget(0, QFormLayout::FieldRole, web);


        verticalLayout_2->addLayout(formLayout_2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        verticalLayout->addWidget(label_4);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);


        horizontalLayout->addLayout(verticalLayout);

        desc = new QPlainTextEdit(layoutWidget);
        desc->setObjectName(QString::fromUtf8("desc"));

        horizontalLayout->addWidget(desc);


        verticalLayout_2->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        chiudi = new QPushButton(layoutWidget);
        chiudi->setObjectName(QString::fromUtf8("chiudi"));

        horizontalLayout_2->addWidget(chiudi);

        ok = new QPushButton(layoutWidget);
        ok->setObjectName(QString::fromUtf8("ok"));

        horizontalLayout_2->addWidget(ok);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);


        verticalLayout_2->addLayout(horizontalLayout_2);


        retranslateUi(modGroupinfowindow);

        QMetaObject::connectSlotsByName(modGroupinfowindow);
    } // setupUi

    void retranslateUi(QWidget *modGroupinfowindow)
    {
        modGroupinfowindow->setWindowTitle(QApplication::translate("modGroupinfowindow", "Modifica Info Gruppo", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("modGroupinfowindow", "Settore", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("modGroupinfowindow", "Web", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("modGroupinfowindow", "Descrizione", 0, QApplication::UnicodeUTF8));
        chiudi->setText(QApplication::translate("modGroupinfowindow", "Chiudi", 0, QApplication::UnicodeUTF8));
        ok->setText(QApplication::translate("modGroupinfowindow", "Ok", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class modGroupinfowindow: public Ui_modGroupinfowindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MODGROUPINFOWINDOW_H
