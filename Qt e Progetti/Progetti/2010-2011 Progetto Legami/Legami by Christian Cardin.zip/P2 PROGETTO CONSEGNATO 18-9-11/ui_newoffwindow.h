/********************************************************************************
** Form generated from reading UI file 'newoffwindow.ui'
**
** Created: Sun Sep 18 16:34:32 2011
**      by: Qt User Interface Compiler version 4.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEWOFFWINDOW_H
#define UI_NEWOFFWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QGridLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPlainTextEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_newOffWindow
{
public:
    QWidget *widget;
    QVBoxLayout *verticalLayout_4;
    QGridLayout *gridLayout;
    QLabel *label;
    QLineEdit *tit;
    QLabel *label_6;
    QLineEdit *sett;
    QLabel *label_7;
    QLineEdit *ind;
    QLabel *label_9;
    QComboBox *gio;
    QLabel *label_5;
    QLineEdit *loc;
    QLabel *label_11;
    QComboBox *az;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout;
    QLabel *label_10;
    QSpacerItem *verticalSpacer;
    QPlainTextEdit *desc;
    QHBoxLayout *horizontalLayout_3;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_12;
    QSpacerItem *verticalSpacer_2;
    QPlainTextEdit *esp;
    QHBoxLayout *horizontalLayout_4;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_13;
    QSpacerItem *verticalSpacer_3;
    QPlainTextEdit *spec;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer;
    QPushButton *chiudi;
    QPushButton *ok;
    QSpacerItem *horizontalSpacer_2;

    void setupUi(QWidget *newOffWindow)
    {
        if (newOffWindow->objectName().isEmpty())
            newOffWindow->setObjectName(QString::fromUtf8("newOffWindow"));
        newOffWindow->resize(458, 443);
        widget = new QWidget(newOffWindow);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(10, 10, 437, 421));
        verticalLayout_4 = new QVBoxLayout(widget);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        verticalLayout_4->setContentsMargins(0, 0, 0, 0);
        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        tit = new QLineEdit(widget);
        tit->setObjectName(QString::fromUtf8("tit"));

        gridLayout->addWidget(tit, 0, 1, 1, 1);

        label_6 = new QLabel(widget);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        gridLayout->addWidget(label_6, 0, 2, 1, 2);

        sett = new QLineEdit(widget);
        sett->setObjectName(QString::fromUtf8("sett"));

        gridLayout->addWidget(sett, 0, 4, 1, 1);

        label_7 = new QLabel(widget);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        gridLayout->addWidget(label_7, 3, 0, 1, 1);

        ind = new QLineEdit(widget);
        ind->setObjectName(QString::fromUtf8("ind"));

        gridLayout->addWidget(ind, 3, 1, 1, 1);

        label_9 = new QLabel(widget);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        gridLayout->addWidget(label_9, 1, 2, 1, 1);

        gio = new QComboBox(widget);
        gio->setObjectName(QString::fromUtf8("gio"));

        gridLayout->addWidget(gio, 1, 4, 1, 1);

        label_5 = new QLabel(widget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout->addWidget(label_5, 1, 0, 1, 1);

        loc = new QLineEdit(widget);
        loc->setObjectName(QString::fromUtf8("loc"));

        gridLayout->addWidget(loc, 1, 1, 1, 1);

        label_11 = new QLabel(widget);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        gridLayout->addWidget(label_11, 3, 2, 1, 1);

        az = new QComboBox(widget);
        az->setObjectName(QString::fromUtf8("az"));

        gridLayout->addWidget(az, 3, 4, 1, 1);


        verticalLayout_4->addLayout(gridLayout);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label_10 = new QLabel(widget);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        verticalLayout->addWidget(label_10);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);


        horizontalLayout->addLayout(verticalLayout);

        desc = new QPlainTextEdit(widget);
        desc->setObjectName(QString::fromUtf8("desc"));

        horizontalLayout->addWidget(desc);


        verticalLayout_4->addLayout(horizontalLayout);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        label_12 = new QLabel(widget);
        label_12->setObjectName(QString::fromUtf8("label_12"));

        verticalLayout_2->addWidget(label_12);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer_2);


        horizontalLayout_3->addLayout(verticalLayout_2);

        esp = new QPlainTextEdit(widget);
        esp->setObjectName(QString::fromUtf8("esp"));

        horizontalLayout_3->addWidget(esp);


        verticalLayout_4->addLayout(horizontalLayout_3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        label_13 = new QLabel(widget);
        label_13->setObjectName(QString::fromUtf8("label_13"));

        verticalLayout_3->addWidget(label_13);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_3->addItem(verticalSpacer_3);


        horizontalLayout_4->addLayout(verticalLayout_3);

        spec = new QPlainTextEdit(widget);
        spec->setObjectName(QString::fromUtf8("spec"));

        horizontalLayout_4->addWidget(spec);


        verticalLayout_4->addLayout(horizontalLayout_4);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        chiudi = new QPushButton(widget);
        chiudi->setObjectName(QString::fromUtf8("chiudi"));

        horizontalLayout_2->addWidget(chiudi);

        ok = new QPushButton(widget);
        ok->setObjectName(QString::fromUtf8("ok"));

        horizontalLayout_2->addWidget(ok);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);


        verticalLayout_4->addLayout(horizontalLayout_2);


        retranslateUi(newOffWindow);

        QMetaObject::connectSlotsByName(newOffWindow);
    } // setupUi

    void retranslateUi(QWidget *newOffWindow)
    {
        newOffWindow->setWindowTitle(QApplication::translate("newOffWindow", "Form", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("newOffWindow", "Titolo", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("newOffWindow", "Settore", 0, QApplication::UnicodeUTF8));
        label_7->setText(QApplication::translate("newOffWindow", "Indirizzo", 0, QApplication::UnicodeUTF8));
        label_9->setText(QApplication::translate("newOffWindow", "Giornata", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("newOffWindow", "Localit\303\240", 0, QApplication::UnicodeUTF8));
        label_11->setText(QApplication::translate("newOffWindow", "Azienda", 0, QApplication::UnicodeUTF8));
        label_10->setText(QApplication::translate("newOffWindow", "Descrizione", 0, QApplication::UnicodeUTF8));
        label_12->setText(QApplication::translate("newOffWindow", "Esperienze", 0, QApplication::UnicodeUTF8));
        label_13->setText(QApplication::translate("newOffWindow", "Specifiche", 0, QApplication::UnicodeUTF8));
        chiudi->setText(QApplication::translate("newOffWindow", "Chiudi", 0, QApplication::UnicodeUTF8));
        ok->setText(QApplication::translate("newOffWindow", "Ok", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class newOffWindow: public Ui_newOffWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEWOFFWINDOW_H
