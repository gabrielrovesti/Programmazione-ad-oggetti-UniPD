#include "findgruppo.h"
#include "ui_findgruppo.h"

findGruppo::findGruppo(Account* acc,QWidget *parent) :
    QWidget(parent),
    ui(new Ui::findGruppo){
    ui->setupUi(this);
    tipoAcc tipo=acc->checktipoaccount();
    ui->soglia->setDisabled(true);
    connect(ui->cerca,SIGNAL(clicked()),this,SLOT(findPressed()));
    if(tipo==ADMIN || tipo==EXECUTIVE)
        connect(ui->simili,SIGNAL(toggled(bool)),ui->soglia,SLOT(setEnabled(bool)));
    else if(tipo==BUSINESS)
        ui->soglia->setValue(50);
    else if(tipo==BASIC){
        ui->simili->setDisabled(true);
        ui->soglia->setValue(100);
    }
    this->setWindowTitle("Ricerca gruppi");

}

void findGruppo::findPressed(){
    emit findclicked(ui->nome->text().trimmed(),ui->sett->text().trimmed(),ui->simili->isChecked(),ui->soglia->value());
    close();
}

bool findGruppo::close(){
    clearFields();
    return QWidget::close();
}

void findGruppo::clearFields(){
    ui->nome->setText("");
    ui->sett->setText("");
}


findGruppo::~findGruppo(){
    delete ui;
}
