#include "offwidget.h"
#include <QMessageBox>
#include <QBoxLayout>

offWidget::offWidget(Offerta *a,QWidget *parent):QPushButton(parent),off(a){
    cancella=new QPushButton("Rimuovi");
    dettagli=new QPushButton("Dettagli");
    elimina=new  QPushButton("Elimina");
    elimina->hide();
    connect(cancella,SIGNAL(clicked()),this,SLOT(del()));
    connect(dettagli,SIGNAL(clicked()),this,SLOT(vedidett()));
    connect(this,SIGNAL(clicked()),this,SLOT(click()));
    buildLabels();
    buildLayers();
    this->setFlat(true);
    this->setMaximumHeight(200);
}

void offWidget::buildLabels(){
    nome=new QLabel("<b>"+QString::fromStdString(off->gettitolo())+"</b>");
    nomeaz=new QLabel("<b>Creata il: "+QString::fromStdString(off->getcreazione())+"</b>");
    desc=new QPlainTextEdit(QString::fromStdString(off->getdescrizione()));
    desc->setReadOnly(true);
    desc->setMaximumSize(550,100);
    desc->setSizePolicy(QSizePolicy::Preferred,QSizePolicy::Preferred);
    desc->setTextInteractionFlags(Qt::NoTextInteraction);
}

void offWidget::buildLayers(){
    QVBoxLayout *v1=new QVBoxLayout();
    QVBoxLayout *v2=new QVBoxLayout();
    QHBoxLayout *h1=new QHBoxLayout();
    QHBoxLayout *hlabel=new QHBoxLayout();
    //labels
    ldesc=new QLabel("Descrizione:");
    hlabel->addWidget(ldesc);
    hlabel->addStretch();
    v1->addWidget(nome);
    v1->addWidget(nomeaz);
    v1->addLayout(hlabel);
    v1->addWidget(desc);
    v1->addStretch();
    //pulsante
    v2->addWidget(cancella);
    v2->addWidget(elimina);
    v2->addWidget(dettagli);
    v2->addStretch();
    //main layout
    h1->addLayout(v1);
    h1->addLayout(v2);
    h1->setSizeConstraint(QLayout::SetMinimumSize);
    setLayout(h1);
}

void offWidget::del(){
    emit deleteClicked(off,this);
}

void offWidget::vedidett(){
    emit vedidettagli(off);
}

void offWidget::hidedesc(){
    desc->hide();
    ldesc->hide();
    this->setFlat(false);
    this->setDisabled(false);
}

void offWidget::disablebuttons(){
    cancella->setVisible(false);
    dettagli->setVisible(false);
    this->setDisabled(true);
}

void offWidget::click(){
    emit clicked(off);
}

void offWidget::enableadmin(){   //modifica le azioni adattadole all'amministratore dell'offerta
    cancella->setVisible(false);
    elimina->setVisible(true);
    cancella->disconnect();
    connect(elimina,SIGNAL(clicked()),this,SLOT(del()));
}
