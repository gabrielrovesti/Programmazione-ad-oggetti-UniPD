#ifndef UPGRADEFORM_H
#define UPGRADEFORM_H
#include <QComboBox>
#include <QPushButton>
#include "legami.h"

/*Form simile alla login: chiede di scegliere il proprio grado e, se è superiore a quello attuale,
 *esegue l'upgrade richiamando il metodo apposito di Legami. A processo terminato chiude la finestra.
 *Ogni widget qui contenuto è deallocato automaticamente insieme alla classe.
 */

class UpgradeForm:public QWidget{
    Q_OBJECT
public:
    UpgradeForm(Legami* gest,QWidget *parent=0);
public slots:
    bool close();
private slots:
    void upgradeClicked();
    void EnableButtonUp();
private:
    void clearFields();
    Legami* gestore;
    QPushButton *up;
    QPushButton *bclose;
    QLineEdit *luser;
    QLineEdit *lpass;
    QComboBox *type;
};

#endif // UPGRADEFORM_H
