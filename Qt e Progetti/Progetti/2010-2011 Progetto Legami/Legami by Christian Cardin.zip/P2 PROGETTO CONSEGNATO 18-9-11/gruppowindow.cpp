#include "gruppowindow.h"
#include "errormex.h"

gruppoWindow::gruppoWindow(Account *acc, QWidget *parent):QWidget(parent),account(acc){

    QPushButton* find=new QPushButton("Ricerca Gruppo");
    newgroup=new QPushButton("Crea nuovo Gruppo");
    add=new QPushButton("Iscriviti a questo Gruppo");
    connect(add,SIGNAL(clicked()),this,SLOT(addGruppo()));
    add->hide();
    ngw=new newGroupWindow();
    connect(newgroup,SIGNAL(clicked()),ngw,SLOT(show()));
    connect(ngw,SIGNAL(createGroup(QString,QString,QString,QString)),
            this,SLOT(createGroup(QString,QString,QString,QString)));
    info=0;
    searchArea=new QScrollArea();
    searchArea->setSizePolicy(QSizePolicy::Fixed,QSizePolicy::Minimum);
    vertical=new QVBoxLayout();  //layout della searchArea
    searchArea->setLayout(vertical);

    infoArea=new QScrollArea();
    infoArea->setWidgetResizable(true);

    findgroup=new findGruppo(account);
    connect(find,SIGNAL(clicked()),findgroup,SLOT(show()));
    connect(findgroup,SIGNAL(findclicked(QString,QString,bool,int)),
            this,SLOT(loadGroup(QString,QString,bool,int)));


    QHBoxLayout *hbutt=new QHBoxLayout(); //layout pulsanti
    hbutt->addWidget(find);
    hbutt->addSpacing(82);
    hbutt->addWidget(newgroup);
    hbutt->addWidget(add);
    hbutt->addStretch();
    QHBoxLayout *hmain=new QHBoxLayout(); //layout widgets
    hmain->addWidget(searchArea);
    hmain->addWidget(infoArea);
    hmain->setSizeConstraint(QLayout::SetNoConstraint);
    QVBoxLayout *vmain=new QVBoxLayout();  //layout principale
    vmain->addLayout(hbutt);
    vmain->addLayout(hmain);
    setLayout(vmain);
}


void gruppoWindow::loadGroup(QString no,QString sett,bool si,int so){
    vector<Gruppo*> gruppi=account->findgruppi(no.toStdString(),sett.toStdString(),si,so);

    QLayoutItem *child;         //svuota completamente il layout della searchArea e pulisce la memoria dai vecchi dati
     while ((child = vertical->takeAt(0)) != 0) {
         if(child->widget())
             delete child->widget();
         else if(child->spacerItem())
             delete child->spacerItem();
         else if(child->layout())
             delete child->layout();
     }
     //numero risultati
    QLabel *resoult=new QLabel(QString::number(gruppi.size())+" risultati");
    QFrame *line=new QFrame();
    line->setFrameShape(QFrame::HLine);
    vertical->addWidget(resoult);
    vertical->addWidget(line);
    groupWidget *temp;

    for(int i=gruppi.size()-1;i>=0;i--){       //scorre il vettore in ordine inverso e crea i groupWidgets
        temp=new groupWidget(gruppi[i]);
        temp->disablebuttons();
        temp->setDisabled(false);
        vertical->addWidget(temp);
        connect(temp,SIGNAL(clicked(Gruppo*)),this,SLOT(loadInfo(Gruppo*)));
    }
    vertical->addStretch();
    if(info)
        info->hide();
    if(add->isVisible()){
        add->hide();
    }
}



void gruppoWindow::loadInfo(Gruppo* gro){
    add->setVisible(true);
    if(info){
        if(info->getgruppo()==gro){   //se ho cliccato lo stesso pulsante di prima, non faccio nulla
            if(info->isHidden())
                info->setVisible(true);//ma se la finestra di info non è attiva, la mostra
            return;
        }
        delete infoArea->takeWidget();     //rimuove ed elimina il widget con le informazioni precedenti
   }
    info=new groupInfoWidget(gro,account);
    infoArea->setWidget(info);           //setta le nuove info
    info->hidetabs();
    info->setVisible(true);

}

void gruppoWindow::addGruppo(){
    Gruppo* gro=info->getgruppo();
    try{
        account->addgruppo(gro);
    }
    catch(ErrState e){
        ErrorMex *werr=new ErrorMex(e);
        werr->show();
        return;
    }
    OkMex *ok=new OkMex("Iscrizione avvenuta.","Il Gruppo e' stato inserito correttamente nella tua lista");
    ok->show();
    emit GruppoAggiunto(gro);
}

void gruppoWindow::createGroup(QString nome,QString desc,QString sett,QString web){
    Gruppo* gro;
    try{
        gro=account->newgruppo(nome.toStdString(),desc.toStdString(),sett.toStdString(),web.toStdString());
    }
    catch(ErrState e){
        ErrorMex *werr=new ErrorMex(e);
        werr->show();
        return;
    }
    OkMex *ok=new OkMex("Creazione avvenuta!","Il gruppo e' stato inserito correttamente nella tua lista");
    ok->show();
    emit GruppoAggiunto(gro);
}

gruppoWindow::~gruppoWindow(){
    if(info)
        delete info;
    delete findgroup;
    delete ngw;

    QLayoutItem *child;         //svuota completamente il layout della searchArea e pulisce la memoria dai vecchi dati
     while ((child = vertical->takeAt(0)) != 0) {
         if(child->widget())
             delete child->widget();
         else if(child->spacerItem())
             delete child->spacerItem();
         else if(child->layout())
             delete child->layout();
     }
}
