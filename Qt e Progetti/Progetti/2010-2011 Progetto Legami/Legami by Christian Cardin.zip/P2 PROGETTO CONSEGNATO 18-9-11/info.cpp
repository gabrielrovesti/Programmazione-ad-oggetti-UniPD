#include "info.h"

UserInfo::UserInfo(pstring _username,pstring _psw,pstring _nome,pstring _cognome,
            bool _sex, pstring _localita,pstring _indirizzo,pstring _email,
            pstring _spec,pstring _obiet,dataora _nascita,dataora _iscriz,pstring _tel,
            pstring _web,pstring _interessi):username(_username),password(_psw),nome(_nome),
            cognome(_cognome),localita(_localita),indirizzo(_indirizzo),email(_email),
            specializzazioni(_spec),obiettivi(_obiet),telefono(_tel),web(_web),
            interessi(_interessi),nascita(_nascita),iscrizione(_iscriz),sex(_sex){}

pstring UserInfo::getnome() const{return nome;}
pstring UserInfo::getusername() const{return username;}
pstring UserInfo::getpassword() const{return password;}
pstring UserInfo::getcognome() const{return cognome;}
pstring UserInfo::getlocalita() const{return localita;}
pstring UserInfo::getindirizzo() const{return indirizzo;}
pstring UserInfo::gettelefono() const{return telefono;}
pstring UserInfo::getemail() const{return email;}
pstring UserInfo::getweb() const{return web;}
pstring UserInfo::getinteressi() const{return interessi;}
pstring UserInfo::getspec() const{return specializzazioni;}
pstring UserInfo::getobiettivi() const{return obiettivi;}
pstring UserInfo::getnascita() const{return nascita.getdata();}
pstring UserInfo::getiscrizione() const{return iscrizione.getdata();}
bool UserInfo::getsex() const{return sex;}
bool UserInfo::checkpsw(pstring _psw)const{return password==_psw;}

void UserInfo::modifyInfo(pstring _psw, pstring _nome, pstring _cognome,
                          pstring _localita, pstring _indirizzo, pstring _spec,
                          pstring _obiet, pstring _tel, pstring _web, pstring _interessi)throw(ErrStateInfo){
    _psw=_psw.trimmed();
    if(_psw=="")throw ErrStateInfo(1,1);
    _nome=_nome.trimmed();
    if(_nome=="")throw ErrStateInfo(1,2);
    _cognome=_cognome.trimmed();
    if(_cognome=="")throw ErrStateInfo(1,3);
    _localita=_localita.trimmed();
    if(_localita=="")throw ErrStateInfo(1,5);
    _indirizzo=_indirizzo.trimmed();
    if(_indirizzo=="")throw ErrStateInfo(1,6);
    _spec=_spec.trimmed();
    if(_spec=="")throw ErrStateInfo(1,7);
    _obiet=_obiet.trimmed();
    if(_obiet=="")throw ErrStateInfo(1,8);
    _tel=_tel.trimmed();
    _web=_web.trimmed();
    _interessi=_interessi.trimmed();

    cognome=_cognome;
    indirizzo=_indirizzo;
    interessi=_interessi;
    nome=_nome;
    obiettivi=_obiet;
    password=_psw;
    localita=_localita;
    specializzazioni=_spec;
    telefono=_tel;
    web=_web;
}

double UserInfo::somiglia(const UserInfo& inf) const{
    double match=0,totcampi=0;
    //username pesa 5
    if(inf.username!=""){
        totcampi+=5;
        if(username.trimmed().toLower()==inf.username.trimmed().toLower())match+=5;}
    //nome e cognome valgono 3
    if(inf.cognome!=""){
        totcampi+=3;
        if(cognome.trimmed().toLower()==inf.cognome.trimmed().toLower())match+=3;}
    if(inf.nome!=""){
        totcampi+=3;
        if(nome.trimmed().toLower()==inf.nome.trimmed().toLower())match+=3;}
    //la specializzazione vale 2
    if(inf.specializzazioni!=""){
        totcampi+=2;;
        if(specializzazioni.trimmed().contains(inf.specializzazioni.trimmed()))match+=2;}
    //località e data di nascita valgono 1
    if(inf.localita!=""){
        totcampi++;
        if(localita.trimmed().toLower()==inf.localita.trimmed().toLower())match++;}
    if(inf.nascita!=0){
        totcampi++;
        if(nascita==inf.nascita)match++;}
    if(totcampi==0) return 0;

    return match/totcampi*100.0;
}

pstring UserInfo::tostring() const{
    pstring out;
    out=password;out+="##";
    out+=nome;out+="##";
    out+=cognome;out+="##";
    if(!sex) out+=0;
    else     out+=1;
    out+="##";
    out+=localita;out+="##";
    out+=indirizzo;out+="##";
    out+=email;out+="##";
    out+=specializzazioni;out+="##";
    out+=obiettivi;out+="##";
    out+=nascita.stamp();out+="##";
    out+=iscrizione.stamp();out+="##";
    out+=telefono;out+="##";
    out+=web;out+="##";
    out+=interessi;
    return out;
}

AzInfo::AzInfo(pstring _nome,pstring _localita,pstring _indirizzo, pstring _settore,pstring _desc,
               pstring _tipo,pstring _dim,pstring _web,pstring _telefono,pstring _email):nome(_nome),
               localita(_localita),indirizzo(_indirizzo),settore(_settore),
               descrizione(_desc),tipo(_tipo),dimensione(_dim),web(_web),telefono(_telefono),email(_email){}

pstring AzInfo::getnome() const{return nome;}
pstring AzInfo::getlocalita() const{return localita;}
pstring AzInfo::getindirizzo() const{return indirizzo;}
pstring AzInfo::gettelefono() const{return telefono;}
pstring AzInfo::getemail() const{return email;}
pstring AzInfo::getdim() const{return dimensione;}
pstring AzInfo::gettipo() const{return tipo;}
pstring AzInfo::getdesc() const{return descrizione;}
pstring AzInfo::getsettore() const{return settore;}
pstring AzInfo::getweb() const{return web;}

void AzInfo::modifyInfo(pstring loc, pstring ind, pstring desc,
                        pstring dim, pstring w, pstring tel, pstring em){
    loc=loc.trimmed();
    if(loc!="") localita=loc;
    ind=ind.trimmed();
    if(ind!="") indirizzo=ind;
    desc=desc.trimmed();
    if(desc!="") descrizione=desc;
    dim=dim.trimmed();
    if(dim!="") dimensione=dim;
    web=w.trimmed();
    telefono=tel.trimmed();
    email=em.trimmed();
}


double AzInfo::somiglia(const AzInfo& info) const{
    double match=0,totcampi=0;
    if(info.nome!=""){
        totcampi+=5;
        if(nome.trimmed().toLower()==info.nome.trimmed().toLower())match+=5;}
    if(info.settore!=""){
        totcampi+=3;
        if(settore.trimmed().contains(info.settore.trimmed()))match+=3;}
    if(info.tipo!=""){
        totcampi+=3;
        if(tipo.trimmed().toLower()==info.tipo.trimmed().toLower())match+=3;}
    //località  1
    if(info.localita!=""){
        totcampi++;
        if(localita.trimmed().toLower()==info.localita.trimmed().toLower())match++;}
    if(totcampi==0) return 0;
    return match/totcampi*100.0;
}

pstring AzInfo::tostring() const{
    pstring out;
    out=localita;out+="##";
    out+=indirizzo;out+="##";
    out+=settore;out+="##";
    out+=descrizione;out+="##";
    out+=tipo;out+="##";
    out+=dimensione;out+="##";
    out+=web;out+="##";
    out+=telefono;out+="##";
    out+=email;
    return out;
}

GroupInfo::GroupInfo(pstring _nome,   pstring _desc, pstring _settore,
             dataora _creaz,pstring _web):
             nome(_nome),descrizione(_desc),settore(_settore),
             web(_web),creazione(_creaz){}

pstring GroupInfo::getnome() const{return nome;}
pstring GroupInfo::getdesc() const{return descrizione;}
pstring GroupInfo::getsettore() const{return settore;}
pstring GroupInfo::getweb() const{return web;}
pstring GroupInfo::getcreazione() const{return creazione.getdata();}
void GroupInfo::modifyInfo(pstring sett, pstring desc, pstring w){
    desc=desc.trimmed();
    if(desc!="") descrizione=desc;
    sett=sett.trimmed();
    if(sett!="") settore=sett;
    web=w.trimmed();

}
    void GroupInfo::setsettore(pstring s){settore=s;}
    void GroupInfo::setdescr(pstring d){descrizione=d;}

    void GroupInfo::setweb(pstring w){web=w;}
    void GroupInfo::setnome(pstring n){nome=n;}
double GroupInfo::somiglia(const GroupInfo& info) const{
 double match=0,totcampi=0;
    //nome pesa 5
    if(info.nome!=""){
        totcampi+=5;
        if(nome.trimmed().toLower()==info.nome.trimmed().toLower())match+=5;}
    //settore vale 3
    if(info.settore!=""){
        totcampi+=3;
        if(settore.trimmed().contains(info.settore.trimmed()))match+=3;}
    if(totcampi==0) return 0;
    return match/totcampi*100.0;
}

pstring GroupInfo::tostring()const{
    pstring out= descrizione+"##"+settore+"##";
    out+=creazione.stamp();
    out+="##"+web;
    return out;
}
