#include "user.h"
#include "gruppo.h"

Gruppo::Gruppo(GroupInfo* _info,User* admin, vector<User*>* _iscr, vector<Discussione*>* _disc):
               quickinfo(_info),amministratore(admin),iscritti(_iscr),discussioni(_disc){
    if(iscritti==0)
        iscritti=new vector<User*>;
}

GroupInfo* Gruppo::getinfo() const{return quickinfo;}
vector<User*>* Gruppo::getiscritti() const{return iscritti;}
vector<Discussione*>* Gruppo::getdiscussioni() const{return discussioni;}

vector<User*>::iterator Gruppo::position(User* l) const{
    vector<User*>::iterator it=iscritti->begin();
    while(it!=iscritti->end() && *it!=l)
        it++;
    return it;
}

bool Gruppo::is_iscritto(User * us) const{
    vector<User*>::iterator it=position(us);
    if(it==iscritti->end())
        return false;
    else
        return true;
}

//se un utente è già iscritto ritorna false, altrimenti lo iscrive
bool Gruppo::addUtente(User* l){
        if(position(l)!=iscritti->end())  //trovato utente tra gli iscritti
            return false;
        iscritti->push_back(l);
    return true;
}

bool Gruppo::removeutente(User* l){
    vector<User*>::iterator it=position(l);
    if(it==iscritti->end())
            return false;
    iscritti->erase(it);
    return true;

}

bool Gruppo::removediscussione(Discussione * disc){
    vector<Discussione*>::iterator it=discussioni->begin();
    while(it<discussioni->end() && (*it)!=disc)    //cerca la discussione
        it++;
    if(it==discussioni->end())   //se non la trova restituisce false
            return false;
    discussioni->erase(it);    //altrimenti la elimina del tutto
    delete disc;
    return true;
}

void Gruppo::newdiscussione(Discussione* d){discussioni->push_back(d);}
User* Gruppo::getadmin() const{return amministratore;}
void Gruppo::setadmin(User* _u){amministratore=_u;}

Gruppo::~Gruppo(){
    delete quickinfo;
    delete iscritti;
    for(unsigned int i=0;i<discussioni->size();i++)
            delete (*discussioni)[i];
    delete discussioni;
}
