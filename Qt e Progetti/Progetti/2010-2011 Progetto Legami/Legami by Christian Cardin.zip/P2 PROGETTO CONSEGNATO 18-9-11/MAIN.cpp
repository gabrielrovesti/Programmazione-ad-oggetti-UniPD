#include <QApplication>
#include "mainpage.h"
#include "pstring.h"

int main(int argc, char** argv){
    QApplication application(argc,argv);
    MainPage *mai=new MainPage();
    mai->show();
    return application.exec();
}


