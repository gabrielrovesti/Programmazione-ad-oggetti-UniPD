#include "newexpwindow.h"
#include "ui_newexpwindow.h"
#include "errormex.h"

newExpWindow::newExpWindow(Account* acc,QWidget *parent) :
    QWidget(parent),gestore(acc->getgestore()),account(acc),
    ui(new Ui::newExpWindow){
    ui->setupUi(this);
    ui->vmainlayout->setMargin(10);
    setLayout(ui->vmainlayout);
    connect(ui->chiudi,SIGNAL(clicked()),this,SLOT(close()));
    connect(ui->ok,SIGNAL(clicked()),this,SLOT(newexp()));
    connect(ui->activity,SIGNAL(toggled(bool)),ui->fine,SLOT(setDisabled(bool)));
    setWindowTitle("Nuova Esperienza");
    ui->inizio->setDate(QDate(1970,01,01));
    ui->fine->setDate(QDate(1970,01,01));

}

void newExpWindow::newexp(){
    QDateTime inizio(ui->inizio->date());
    QDateTime fine(ui->fine->date());
    Exp* exp;
    int iniziostamp=inizio.toTime_t()+8600;
    int finestamp;
    if(ui->activity->isChecked())
        finestamp=0;
    else
        finestamp=fine.toTime_t()+8600;
    Azienda* azienda=0;
    vector<Azienda*> vec;
    if(ui->nome->text().trimmed()!=""){
        vec=gestore->findaziende(AzInfo(ui->nome->text().toStdString(),"","","","","",""));
        if(vec.size()==1){
            QString mex="E' stata trovata un'azienda con lo stesso nome da te inserito.\nVuoi collegarla alla tua esperienza?";
            int r=QMessageBox::question(this,"Richiesta di conferma",mex,QMessageBox::Yes,QMessageBox::No);
            if(r==QMessageBox::Yes)
                azienda=vec[0];
        }
    }
    try{
        exp=account->newlavoro(iniziostamp,finestamp,ui->desc->toPlainText().toStdString(),azienda,
                           ui->nome->text().toStdString(),ui->tit->text().toStdString(),ui->ru->text().toStdString());
    }catch(ErrState e){
        ErrorMex* wmess=new ErrorMex(e);
        wmess->show();
        return;
    }
    OkMex* kmex=new OkMex("Modifica Esperienza","Modifiche avvenute con successo");
    kmex->show();
    emit expCreated(exp);
    close();
}

bool newExpWindow::close(){
    clearFields();
    return QWidget::close();
}

void newExpWindow::clearFields(){
    ui->inizio->setDate(QDate(1970,01,01));
    ui->fine->setDate(QDate(1970,01,01));
    ui->desc->setPlainText("");
    ui->nome->setText("");
    ui->tit->setText("");
    ui->ru->setText("");
    ui->activity->setChecked(false);
}

newExpWindow::~newExpWindow(){
    delete ui;
}
