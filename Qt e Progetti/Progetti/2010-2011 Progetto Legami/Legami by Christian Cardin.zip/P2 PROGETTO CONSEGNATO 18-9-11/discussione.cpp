#include "discussione.h"

Discussione::Discussione(User* _creatore, pstring _argomento,
        dataora _creazione, vector<Messaggio*>* _mex):
        creatore(_creatore),argomento(_argomento),creazione(_creazione),messaggi(_mex){}

void Discussione::insertmex(Messaggio* m){if(m)messaggi->push_back(m);}
User* Discussione::getcreatore() const{return creatore;}
pstring Discussione::getargomento() const{return argomento;}
pstring Discussione::getdata() const{return creazione.getdata();}
pstring Discussione::getora() const{return creazione.getora();}

pstring Discussione::tostring()const{
    pstring out,mex="";
    out=creatore->getinfo()->getusername()+"##"+argomento+"##";out+=creazione.stamp() ;
    out+="@";
    for(unsigned int i=0;i<messaggi->size();i++){
        if(!mex.isEmpty()) mex+="|";
        mex+=(*messaggi)[i]->tostring();
    }
    return out+mex;
}

vector<Messaggio*>* Discussione::getmessaggi() const{return messaggi;}

int Discussione::getNumMex() const{return messaggi->size();}

Discussione::~Discussione(){
    for(unsigned int i=0;i<messaggi->size();i++)
            delete (*messaggi)[i];
        delete messaggi;
}
