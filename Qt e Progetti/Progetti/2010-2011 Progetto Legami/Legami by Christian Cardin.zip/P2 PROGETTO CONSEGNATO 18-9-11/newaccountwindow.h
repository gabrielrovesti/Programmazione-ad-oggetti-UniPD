#ifndef NEWACCOUNTWINDOW_H
#define NEWACCOUNTWINDOW_H
#include <QWidget>
class Legami;
class Account;

namespace Ui {
    class newAccountWindow;
}

/* Finestra per la creazione di un nuovo account. L'utente inserisce i dati e una volta accettato si tenta
 * la creazione di un nuovo account. Se l'operazione ha successo, viene emesso un segnale con l'account creato.
 * Il metodo close() è stato ridefinito in modo che tutti i campi vengano svuotati dal loro precedente contenuto.
 * Gli oggetti vengono distrutti automaticamente alla distruzione della finestra.
 */

class newAccountWindow : public QWidget{
    Q_OBJECT

public:
    explicit newAccountWindow(Legami* _gestore,QWidget *parent = 0);
    ~newAccountWindow();
public slots:
    bool close();
private slots:
    void Accepted();


private:
    Legami* gestore;
    void clearFields();
    Ui::newAccountWindow *ui;
};

#endif // NEWACCOUNTWINDOW_H
