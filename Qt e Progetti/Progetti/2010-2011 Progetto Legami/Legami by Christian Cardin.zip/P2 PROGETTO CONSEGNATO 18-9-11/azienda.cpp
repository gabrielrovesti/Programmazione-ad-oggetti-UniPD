#include "azienda.h"
#include "user.h"
Azienda::Azienda(AzInfo* _info, User* _resp):quickinfo(_info),
         amministratore(_resp){
    linked_offerte=new vector<Offerta*>();
}

AzInfo* Azienda::getinfo() const{return quickinfo;}

User* Azienda::getadmin() const{return amministratore;}
void Azienda::setadmin(User* _u){amministratore=_u;}

void Azienda::link(Offerta *_l){
    if(_l)
        linked_offerte->push_back(_l);
}

vector<Offerta*>* Azienda::getlinked() const{return linked_offerte;}

Azienda::~Azienda(){
    linked_offerte->clear();
    delete quickinfo;
    delete linked_offerte;
}
