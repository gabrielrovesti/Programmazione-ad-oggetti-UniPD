#include "legami.h"
#include "gruppo.h"
#include "azienda.h"
#include "utils.h"
#include "offerta.h"
#include "dbmanager.h"
#include "messaggio.h"
#include "dataora.h"
#include <algorithm>
using std::sort;

Legami::Legami(){
      usermap=new map<pstring,Account*>;
      groupmap=new map<pstring,Gruppo*>;
      azmap=new map<pstring,Azienda*>;
      offertemap=new map<int,Offerta*>;

      db=new DBmanager(this,"legami.xml");
      db->readfile();
 }

void Legami::WriteOnDb(){
    db->writexml();
}

void Legami::clear(){
    map<pstring,Account*>::iterator itus=usermap->begin();
    for(;itus!=usermap->end();itus++)
        delete itus->second;
    usermap->clear();
    map<pstring,Azienda*>::iterator itaz=azmap->begin();
    for(;itaz!=azmap->end();itaz++)
        delete itaz->second;
    azmap->clear();
    map<pstring,Gruppo*>::iterator itgr=groupmap->begin();
    for(;itgr!=groupmap->end();itgr++)
        delete itgr->second;
    groupmap->clear();
    map<int,Offerta*>::iterator itoff=offertemap->begin();
    for(;itoff!=offertemap->end();itoff++)
        delete itoff->second;
    offertemap->clear();
}

vector<User*> Legami::findutenti(const UserInfo& info, User* richiedente, bool simili, int soglia,int limite)const{
    vector<User*> v;
    double percent;
    int inseriti=0;
    map<pstring,Account*>::iterator it=usermap->begin();
    for(;it!=usermap->end() && inseriti<limite;it++){
        if(it->second!=richiedente){
           percent=it->second->getinfo()->somiglia(info);
           if(!simili && percent==100){   //inserimento in tempo costante
               v.push_back(it->second);
               inseriti++;
           }
           else                          //esegue un inserimento in tempo O(n)
               if(simili && percent>=soglia){
                   vector<User*>::iterator j=v.end();

                   while(j!=v.begin() && (*(j-1))->getinfo()->somiglia(info)<percent)
                       j--;
                   v.insert(j,(it->second));
                   inseriti++;
               }
        }
    }
    return v;
}

vector<Offerta*> Legami::findofferte(const Offerta& off, bool simili, int soglia,int limite)const{
    vector<Offerta*> v;
    double percent;
    int inseriti=0;
    map<int,Offerta*>::iterator it=offertemap->begin();
    for(;it!=offertemap->end()&& inseriti<limite;it++){
       percent=it->second->somiglia(off);
       if(!simili && percent==100){   //inserimento in tempo costante
           v.push_back(it->second);
           inseriti++;
       }
       else                          //esegue un inserimento in tempo O(n)
           if(simili && percent>=soglia){
               vector<Offerta*>::iterator j=v.end();

               while(j!=v.begin() && (*(j-1))->somiglia(off)<percent)
                   j--;
               v.insert(j,(it->second));
               inseriti++;
           }
    }
    return v;
}

vector<Gruppo*> Legami::findgruppi(const GroupInfo& info, bool simili, int soglia,int limite)const{
    vector<Gruppo*> v;
    double percent;
    int inseriti=0;
    map<pstring,Gruppo*>::iterator it=groupmap->begin();
    for(;it!=groupmap->end()&& inseriti<limite;it++){
       percent=it->second->getinfo()->somiglia(info);
       if(!simili && percent==100){   //inserimento in tempo costante
           v.push_back(it->second);
           inseriti++;
       }
       else                          //esegue un inserimento in tempo O(n)
           if(simili && percent>=soglia){
               vector<Gruppo*>::iterator j=v.end();

               while(j!=v.begin() && (*(j-1))->getinfo()->somiglia(info)<percent)
                   j--;
               v.insert(j,it->second);
               inseriti++;
           }
    }
    return v;
}

vector<Azienda*> Legami::findaziende(const AzInfo& info, bool simili, int soglia,int limite)const{
    vector<Azienda*> v;
    double percent;
    int inseriti=0;
    map<pstring,Azienda*>::iterator it=azmap->begin();
    for(;it!=azmap->end()&& inseriti<limite;it++){
       percent=it->second->getinfo()->somiglia(info);
       if(!simili && percent==100){   //inserimento in tempo costante
           v.push_back(it->second);
           inseriti++;
       }
       else                          //esegue un inserimento in tempo O(n)
           if(simili && percent>=soglia){
               vector<Azienda*>::iterator j=v.end();

               while(j!=v.begin() && (*(j-1))->getinfo()->somiglia(info)<percent)
                   j--;
               v.insert(j,it->second);
               inseriti++;
           }
    }
    return v;
}

void Legami::iscriviutente(pstring tipo,pstring _username, pstring _psw,pstring _cpsw, pstring _nome,
        pstring _cognome, bool _sex, pstring _localita, pstring _indirizzo,
        pstring _email, pstring _spec, pstring _obiet, dataora _nascita, pstring _tel,
        pstring _web, pstring _interessi){
    _username=_username.trimmed();
    _nome=_nome.trimmed();_cognome=_cognome.trimmed();
    _localita=_localita.trimmed();
    _indirizzo=_indirizzo.trimmed();
    _email=_email.trimmed();
    _spec=_spec.trimmed();
    _obiet=_obiet.trimmed();
    _tel=_tel.trimmed();
    _web=_web.trimmed();
    _localita=_localita.trimmed();
    _interessi=_interessi.trimmed();
    if(_username=="")throw ErrStateContact(3,4);
    if(_nome=="")throw ErrStateContact(3,5);
    if(_cognome=="")throw ErrStateContact(3,10);
    if(_indirizzo=="")throw ErrStateContact(3,6);
    if(_email=="")throw ErrStateContact(3,7);
    if(_spec=="")throw ErrStateContact(3,8);
    if(_obiet=="")throw ErrStateContact(3,9);
    if(_localita=="")throw ErrStateContact(3,15);
    if(_psw.trimmed()=="")throw ErrStateContact(3,16);
    if(_psw!=_cpsw) throw ErrStateContact(3,17);
    map<pstring,Account*>::iterator it;
    it=usermap->find(_username);
    if(it!=usermap->end()) throw ErrStateContact(3,3);

    if(_nascita.anno()>(dataora().anno()-18)||_nascita.anno()<(dataora().anno()-100))
        throw ErrStateContact(3,11);
    UserInfo* info=new UserInfo(_username, _psw, _nome, _cognome, _sex,
             _localita, _indirizzo, _email,_spec, _obiet,_nascita,dataora(),_tel,
             _web, _interessi);
    Account* a=0;
    tipoAcc t=BASIC;
    if(tipo=="BASIC"){
        a=new Account(info,this);
        t=BASIC;
    }
    else if(tipo=="BUSINESS"){
        a=new Business(info,this);
        t=BUSINESS;
    }
    else if(tipo=="EXECUTIVE"){
        a=new Executive(info,this);
        t=EXECUTIVE;
    }
    (*usermap)[_username]=a;
    db->saveAccount(info,t);
}

Account* Legami::login(pstring user, pstring psw)const{
    user.trimmed();

    map<pstring,Account*>::iterator it;

    it=usermap->find(user);         //Attenzione! Il login è Case-Sensitive
    if(it==usermap->end()) throw ErrStateContact(4,12);
    if(!it->second->getinfo()->checkpsw(psw))throw ErrStateContact(4,13);
    return it->second;
}

void Legami::addcontatto(User* prop,User* _con,pstring _tag)throw(ErrStateContact){
        pstring actual;
        vector<Contatto>* contatti=prop->getcontatti();
        vector< Tag >* personal_tag=prop->get_ptag();
        pstring usnm=_con->getinfo()->getusername();
        bool superato=false; //indica che non abbiamo ancora trovato uno username
                             //che viene dopo in ordine alfabetico di quello dell'utente da inserire
        vector<Contatto>::iterator it=contatti->begin();
        while(it!=contatti->end() && !superato){
            actual=(*it)->getinfo()->getusername();
            if(usnm==actual) throw ErrStateContact(1,1); //esiste già il collegamento con quell'utente!
            if(usnm>actual) superato=true;
            else it++;
        }
        //inserisce il contatto nel giusto ordine alfabetico
        _tag=_tag.toLower();
        _tag.trimmed();
        contatti->insert(it,Contatto(_con,_tag));
        for(unsigned int i=0;i<personal_tag->size();i++)
            if(_tag==(*personal_tag)[i].first){
                (*personal_tag)[i].second++;
                return;                  //se il tag è presente incrementa il numero delle occorrenze
            }
        personal_tag->push_back( make_pair(_tag,1) );   //altrimenti lo aggiunge con occorrenza 1
        db->saveContatto(prop);
}

Account* Legami::upgrade(Account *a, tipoAcc newtipo){
    tipoAcc tipoutente=a->checktipoaccount();
    if(newtipo<=tipoutente) throw ErrStateContact(5,14);  //il nuovo tipo è minore di quello attuale
    map<pstring,Account*>::iterator it;
    it=usermap->find(a->getinfo()->getusername());       //trovo l'utente nella mappa
    if(it==usermap->end()) throw ErrStateContact(5,12);  //non c'è...
    pstring username=a->getinfo()->getusername();
    db->saveAccount(a->getinfo(),newtipo);              //salva le informazioni dell'utente con il nuovo tipo
    WriteOnDb();                                        //scrive i dati nel db
    clear();                                            //azzera strutture dati
    db->clearmemory();                                  //resetta memoria DBmanager
    db->readfile();                                     //ricarica strutture dati con account e relativi indirizzi aggiornati
    return usermap->find(username)->second;
}

void Legami::sendsegn(User* mit, User* dest, pstring _ogg, pstring _mex,dataora date)throw (ErrStateExp){
    map<pstring,Account*>::iterator it;
    it=usermap->find(dest->getinfo()->getusername());
    if(it==usermap->end()) throw ErrStateExp(5,10);
    Messaggio *m=new Messaggio(mit,_ogg,_mex,date);
    it->second->addSegnalazione(m);
    db->saveSegn(dest->getinfo()->getusername(),dest->getcurriculum()->getseg());
}

void Legami::iscriviagruppo(User* _u, Gruppo* _g)throw(ErrStateGroup){
    map<pstring,Account*>::iterator it_u;
    map<pstring,Gruppo*>::iterator it_g;
    it_u=usermap->find(_u->getinfo()->getusername());
    if(it_u==usermap->end())        //non esiste utente
        throw ErrStateGroup(1,10);
    pstring gname=_g->getinfo()->getnome();
    it_g=groupmap->find(gname);
    if(it_g==groupmap->end())        //non esiste gruppo
        throw ErrStateGroup(1,9);
    if(!it_g->second->addUtente(_u)) //già iscritto
        throw ErrStateGroup(1,2);
    db->saveGro(it_g->second);
}

void Legami::removedagruppo(User* _u, Gruppo* _g)throw(ErrStateGroup){
     map<pstring,Gruppo*>::iterator it;
     it=groupmap->find(_g->getinfo()->getnome());
     if(it==groupmap->end())
         throw ErrStateGroup(2,9);
     if(!_g->removeutente(_u))
         throw ErrStateGroup(2,10);
      db->saveGro(_g);
}

Gruppo* Legami::creategroup(User *admin, pstring _nome,   pstring _desc, pstring _settore, pstring _web)throw (ErrStateGroup){
    if(admin==0)throw ErrStateGroup(3,8);
    map<pstring,Gruppo*>::iterator it;
    it=groupmap->find(_nome);
    if(it!=groupmap->end())
        throw ErrStateGroup(3,12);
    Gruppo* g=new Gruppo(new GroupInfo(_nome,_desc,_settore,dataora(),_web),admin);
    (*groupmap)[_nome]=g;
    db->saveGro(g);
    return g;
}

void Legami::deletegroup(User* admin, Gruppo* _g)throw(ErrStateGroup){
    map<pstring,Gruppo*>::iterator itg;
    itg=groupmap->find(_g->getinfo()->getnome());
    if(itg==groupmap->end()) throw ErrStateGroup(4,9);   //se il gruppo non esiste
    if(!(_g->getadmin()==admin)) throw ErrStateGroup(4,13); // se l'utente non è l'amministratore

    map<pstring,Account*>::iterator it=usermap->begin();
    for(;it!=usermap->end();it++){
        vector<Gruppo*>::iterator it_g=it->second->is_presente(_g);
        if(it_g!=it->second->getgruppi()->end())
            it->second->getgruppi()->erase(it_g);       //rimuove il gruppo dagli iscritti
    }
    db->saveGro(itg->second,1);
    groupmap->erase(itg);
    delete _g;

}

void Legami::setgroupinfo(Gruppo* _g, User* newadmin,pstring desc, pstring sett,pstring web)throw(ErrStateInfo){
    GroupInfo* inf=_g->getinfo();
    if(newadmin!=0) _g->setadmin(newadmin);
    inf->modifyInfo(desc,sett,web);
    db->saveGro(_g);
}

Discussione* Legami::adddiscussione(Gruppo* _g, User* autore, pstring tit)throw(ErrStateGroup){
    Discussione* disc=new Discussione(autore,tit);
    _g->newdiscussione(disc);
    db->saveGro(_g);
    return disc;
}

void Legami::deletediscussione(Gruppo *g, Discussione *disc)throw(ErrStateGroup){
    if(!g->removediscussione(disc))
        throw ErrStateGroup(7,1);     //non c'è la discussione
    db->saveGro(g);
}

Messaggio* Legami::addpost(Gruppo* _g, Discussione* _d, User* autore, pstring text, pstring ogg)throw(ErrStateGroup){
    vector<Discussione*>* disc=_g->getdiscussioni();
    vector<Discussione*>::iterator it=disc->begin();
    while(it!=disc->end() && *it!= _d)
        it++;
    if(it==disc->end()) throw ErrStateGroup(6,16);
    Messaggio* mess=new Messaggio(autore,ogg,text);
    _d->insertmex(mess);
    db->saveGro(_g);
    return mess;
}

Azienda* Legami::createaz(User* admin, pstring nome, pstring localita,
        pstring indirizzo, pstring settore, pstring descrizione, pstring t,
        pstring dimensione, pstring web, pstring telefono, pstring email)throw (ErrStateAz){
    if(admin==0)throw ErrStateGroup(3,11);
    map<pstring,Azienda*>::iterator it;
    it=azmap->find(nome);
    if(it!=azmap->end())
        throw ErrStateAz(1,12);
    Azienda* a=new Azienda(new AzInfo(nome, localita, indirizzo,   settore, descrizione,
                t, dimensione, web, telefono, email),admin);
    (*azmap)[nome]=a;
    db->saveAzienda(a->getinfo(),admin->getinfo()->getusername());
    return a;

}

void Legami::setazinfo(Azienda* a, User* admin,   pstring localita,
        pstring indirizzo, pstring descrizione, pstring dimensione, pstring web, pstring telefono,
        pstring email) throw(ErrStateInfo){
    AzInfo* inf=a->getinfo();
    if(admin!=a->getadmin()) throw ErrStateInfo(2,0);
    inf->modifyInfo(localita,indirizzo,descrizione,dimensione,web,telefono,email);

    db->saveAzienda(a->getinfo());
}

void Legami::deleteaz(User* admin, Azienda* a)throw(ErrStateAz){
    map<pstring,Azienda*>::iterator ita;
    ita=azmap->find(a->getinfo()->getnome());
    if(ita==azmap->end()) throw ErrStateAz(4,14);
    map<pstring,Account*>::iterator it=usermap->begin();
    vector<Exp*>* exp;
    vector<Exp*>::iterator ie;
    for(;it!=usermap->end();it++){  //per tutti gli utenti controlla le esperienze e rimuove i collegamenti con l'azienda
        exp=it->second->getcurriculum()->getexp();
        for(ie=exp->begin();ie!=exp->end();ie++){   //iterail vettore delle esperienze
            if((*ie)->getente()==a)
                (*ie)->modifydeleted_ente();  //rimuove il link all'azienda e imposta il nome_ente al suo posto
        }
        db->saveExp(it->first,it->second->getcurriculum()->getexp()); //salva le info sulle esperienze
        try{
            it->second->removeazienda(a);     //rimuove l'azienda dalla lista dell'utente. Se non ce l'ha interrompe
            db->saveContatto(it->second);     //l'operazione e passa al successivo
        }
        catch(ErrStateAz e){
            if(admin==it->second){            //se si è tentato di eliminare il collegamento dall'admin
                vector<Azienda*>* aziende=it->second->getaziende();
                vector<Azienda*>::iterator itazi=aziende->begin(); //viene eliminato manualmente
                bool trovato=false;
                while(itazi!=aziende->end() && !trovato){
                    if(a==(*itazi)) trovato=true;
                    else itazi++;
                }
                if(trovato){
                    aziende->erase(itazi);
                    db->saveContatto(it->second);
                }
            }
        }   //altrimenti non fa nulla
    } //fine ciclo
    vector<Offerta*>* off=ita->second->getlinked();
    vector<Offerta*>::iterator io;
    for(io=off->begin();io!=off->end();io++){   //itera il vettore delle offerte collegate
        (*io)->unsetAzienda();                 //rimuove il link all'azienda.
        db->saveOff(*io);                     //salva l'offerta
    }
    db->saveAzienda(a->getinfo(),"",true);
    delete ita->second; //cancella l'azienda definitivamente
    azmap->erase(ita);  //toglie la riga ad essa associata
}

void Legami::candidautente(User *u, Offerta *_o)throw(ErrStateOff){
    if(_o->getcreatore()==u) throw ErrStateOff(1,16);
    int actual;
    int id=_o->getid();
    bool superato=false;
    vector<Offerta*>* candidature=u->getcandidature();
    vector<Offerta*>::iterator it=candidature->begin();
    while(it!=candidature->end() && !superato){  //inserimento in ordine di id crescente
        actual=(*it)->getid();
        if(id==actual) throw ErrStateOff(1,10); //esiste già il collegamento con quell'offerta!
        if(actual>id) superato=true;
        else it++;
    }
    candidature->insert(it,_o);             //inserisce nel posto giusto nella lista dell'utente
    _o->getcandidati()->push_back(u);    //inserisce tra i candidati dell'offerta
    sort(_o->getcandidati()->begin(),_o->getcandidati()->end()); //ordina la lista in ordine alfabetico
    db->saveOff(_o);
}

void Legami::toglicandidatura(User *u, Offerta *_o)throw(ErrStateOff){
    int id=_o->getid();
    bool trovato=false;
    vector<Offerta*>* candidature=u->getcandidature();
    vector<Offerta*>::iterator it=candidature->begin();
    while(it!=candidature->end() && !trovato){
        if(id==(*it)->getid()) trovato=true;
        else it++;
    }
    if(trovato) candidature->erase(it);
    else throw ErrStateOff(2,9);
    trovato=false;
    vector<User*>* candidati=_o->getcandidati();
    vector<User*>::iterator itc=candidati->begin();
    while(itc!=candidati->end() && !trovato){
        if(u->getinfo()->getusername()==(*itc)->getinfo()->getusername()) trovato=true;
        else itc++;
    }
    if(trovato) candidati->erase(itc);
    db->saveOff(_o);
}

Offerta* Legami::createoffer(User* admin, pstring tit, pstring loc, pstring ind,
        pstring sett, pstring desc, pstring gior, pstring esp,
        Azienda* az, pstring spec){
    int id=offertemap->size()+1;
    Offerta* off=new Offerta(id,tit,loc,ind,sett,desc,gior,esp,admin,az,dataora(),spec);
    if(az) az->link(off);

    (*offertemap)[id]=off;
    db->saveOff(off);
    return off;
}

void Legami::deleteoff(Executive* admin, Offerta* o)throw(ErrStateOff){
    //cerca l'offerta nella mappa. Controlla se esiste e se l'utente è amministratore
    map<int,Offerta*>::iterator ito=offertemap->find(o->getid());
    if(ito==offertemap->end()) throw ErrStateOff(4,14);
    if(o->getcreatore()!=admin) throw ErrStateOff(4,13);
    //inizializza vector per i candidati da togliere dall'offerta
    vector<User*>* iscritti=o->getcandidati();  //candidati all'offerta da eliminare
    vector<User*>::iterator it=iscritti->begin();
    Account* cand;

    //it assume sempre iscritti->begin() perchè toglidaofferta() modifica l'array
    for(;it<iscritti->end();it=iscritti->begin()){
        cand=dynamic_cast<Account*>(*it);    //conversione
        cand->toglidaofferta(o);             //elimina il collegamento dal candidato, e dall'offerta
    }

    bool trovato=false;
    vector<Offerta*>* proposte=admin->get_poff();
    vector<Offerta*>::iterator itoff=proposte->begin();
    while(itoff!=proposte->end() && !trovato){
        if((*itoff)->getid()==o->getid())
            trovato=true;
        else itoff++;
    }
    proposte->erase(itoff); //toglie l'offerta dall'elenco del suo creatore
    db->saveOff(o,1);       //salva lo stato
    delete ito->second;     //cancella l'offerta definitivamente
    offertemap->erase(ito); //toglie la riga ad essa associata
}

void Legami::Save(AzInfo *info, pstring admin, bool del){db->saveAzienda(info,admin,del);}
void Legami::Save(pstring prop, vector<Exp *> *exp){db->saveExp(prop,exp);}
void Legami::Save(pstring prop, vector<Messaggio *> *segn){db->saveSegn(prop,segn);}
void Legami::Save(User *prop){db->saveContatto(prop);}
void Legami::Save(UserInfo *info, tipoAcc tacc, bool del){db->saveAccount(info,tacc,del);}

Legami::~Legami(){
clear();
delete db;
delete usermap;
delete groupmap;
delete azmap;
delete offertemap;
}
