#include "segnform.h"
#include "ui_segnform.h"

segnForm::segnForm(QString soggetto,QWidget *parent):QWidget(parent),ui(new Ui::segnForm){
    ui->setupUi(this);
    this->setWindowTitle("Segnala "+soggetto);
    ui->ok->setDisabled(true);
    connect(ui->ogg,SIGNAL(textChanged(QString)),this,SLOT(enableok()));
    connect(ui->tex,SIGNAL(textChanged()),this,SLOT(enableok()));
    connect(ui->chiudi,SIGNAL(clicked()),this,SLOT(close()));
    connect(ui->ok,SIGNAL(clicked()),this,SLOT(accept()));
}

void segnForm::accept(){
    emit okpressed(ui->ogg->text().trimmed(), ui->tex->toPlainText().trimmed());
    close();
}

void segnForm::enableok(){
    if(ui->ogg->text().trimmed()=="" || ui->tex->toPlainText().trimmed()=="")
        ui->ok->setDisabled(true);
    else
        ui->ok->setEnabled(true);
}

bool segnForm::close(){
    clearFields();
    return QWidget::close();
}

void segnForm::clearFields(){
    ui->ogg->setText("");
    ui->tex->setPlainText("");
}

segnForm::~segnForm(){
    delete ui;
}
