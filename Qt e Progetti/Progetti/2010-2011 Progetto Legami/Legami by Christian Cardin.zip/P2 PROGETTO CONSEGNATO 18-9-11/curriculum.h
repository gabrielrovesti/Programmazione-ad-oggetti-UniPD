#ifndef CURRICULUM_H
#define	CURRICULUM_H
#include "exp.h"
#include <vector>
#include "pstring.h"
using std::vector;
class Messaggio;

//l'inserimento di un elemento avviene in tempo medio O(n/2)
//sia le esperienze che le segnalazioni sono ordinate in modo decrescente
//rispetto alla data (le prime sono le più recenti)
class Curriculum{
private:
    vector<Exp*>* esperienze;
    vector<Messaggio*>* segnalazioni;
public:
    Curriculum(vector<Exp*>* _exp=new vector<Exp*>,vector<Messaggio*>* _seg=new vector<Messaggio*>);
    Exp* insertExp(dataora _inizio, dataora _fin, pstring _descr,
                   Azienda* _l, pstring _nome, pstring _tit, pstring _ruolo);
    void insertSeg(Messaggio* _seg);
    bool is_presente(Exp* _exp) const;
    bool is_presente(Messaggio* _seg) const;
    bool deleteExp(Exp* _exp);  //false se l'esperienza non esiste
    bool deleteSeg(Messaggio* _seg);  //false se la Messaggio non esiste
    vector<Exp*>* getexp() const;
    vector<Messaggio*>* getseg() const;
    ~Curriculum();

};


#endif	/* CURRICULUM_H */

