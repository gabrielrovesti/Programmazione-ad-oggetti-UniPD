#ifndef FINDOFFERTE_H
#define FINDOFFERTE_H

#include <QWidget>
#include "account.h"
namespace Ui {
    class findOfferte;
}

/*Finestra di ricerca delle offerte di lavoro. Viene richiesto di specificare alcuni campi e di impstare le opzioni di ricerca:
 *viene fatto un controllo sul tipo dell'account e vengono abilitate di conseguenza delle funzionalità.
 *Gli oggetti vengono distrutti automaticamente alla distruzione della finestra.
*/

class findOfferte : public QWidget{
    Q_OBJECT
public:
    explicit findOfferte(Account* acc,QWidget *parent = 0);
    ~findOfferte();
signals:
    void findclicked(QString,QString,QString,QString,QString,bool,int);
private slots:
    void findpressed();
public slots:
    bool close();
private:
    void clearFields();
    Account* account;
    Ui::findOfferte *ui;
};

#endif // FINDOFFERTE_H
