#include "findaziende.h"
#include "ui_findaziende.h"

findAziende::findAziende(Account* acc,QWidget *parent):QWidget(parent),account(acc),ui(new Ui::findAziende){
    ui->setupUi(this);
    tipoAcc tipo=acc->checktipoaccount();
    ui->soglia->setDisabled(true);
    connect(ui->cerca,SIGNAL(clicked()),this,SLOT(findpressed()));
    if(tipo==ADMIN || tipo==EXECUTIVE)
        connect(ui->simili,SIGNAL(toggled(bool)),ui->soglia,SLOT(setEnabled(bool)));
    else if(tipo==BUSINESS)
        ui->soglia->setValue(50);
    else if(tipo==BASIC){
        ui->simili->setDisabled(true);
        ui->soglia->setValue(100);
    }
    this->setWindowTitle("Ricerca Aziende");

}

void findAziende::findpressed(){
    emit findclicked(ui->nome->text(),ui->sett->text(),ui->tip->text(),ui->loc->text(),ui->simili->isChecked(),ui->soglia->value());
    close();
}

bool findAziende::close(){
    clearFields();
    return QWidget::close();
}

void findAziende::clearFields(){
    ui->nome->setText("");
    ui->sett->setText("");
    ui->tip->setText("");
    ui->loc->setText("");
}


findAziende::~findAziende(){
    delete ui;
}
