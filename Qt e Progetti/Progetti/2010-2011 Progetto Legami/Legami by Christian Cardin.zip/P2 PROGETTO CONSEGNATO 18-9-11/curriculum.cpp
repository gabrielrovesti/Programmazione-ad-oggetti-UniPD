#include "curriculum.h"
#include "messaggio.h"
Curriculum::Curriculum(vector<Exp*>* _exp, vector<Messaggio*>* _seg):
                       esperienze(_exp),segnalazioni(_seg){}

Exp* Curriculum::insertExp(dataora _inizio, dataora _fin, pstring _descr,
                           Azienda *_l, pstring _nome, pstring _tit, pstring _ruolo){

    Exp* _exp=new Exp(_inizio,_fin,_descr,_l,_nome,_tit,_ruolo);
    vector<Exp*>::iterator it=esperienze->begin();
    while(it!=esperienze->end() && (*_exp)<(**it))
        it++;
    esperienze->insert(it,_exp);
    return _exp;
}

void Curriculum::insertSeg(Messaggio* _seg){
    vector<Messaggio*>::iterator it=segnalazioni->begin();
    while(it!=segnalazioni->end() && (*_seg)<(**it))
        it++;
    segnalazioni->insert(it,_seg);
}

bool Curriculum::is_presente(Exp* _exp) const{
    for(unsigned int i=0;i<esperienze->size();i++)
        if(_exp==(*esperienze)[i])
            return true;
    return false;
}

bool Curriculum::is_presente(Messaggio* _seg) const{
    for(unsigned int i=0;i<segnalazioni->size();i++)
        if(_seg==(*segnalazioni)[i])
            return true;
    return false;
}

bool Curriculum::deleteExp(Exp* _exp){
    vector<Exp*>::iterator it=esperienze->begin();
    for(;it!=esperienze->end();it++)
        if(*_exp==**it){
            esperienze->erase(it);
            return true;
        }
    return false;
}

bool Curriculum::deleteSeg(Messaggio* _seg){
    vector<Messaggio*>::iterator it=segnalazioni->begin();
    for(;it!=segnalazioni->end();it++)
        if(_seg==*it){
            segnalazioni->erase(it);
            return true;
        }
    return false;
}



vector<Exp*>* Curriculum::getexp() const{return esperienze;}
vector<Messaggio*>* Curriculum::getseg() const{return segnalazioni;}

Curriculum::~Curriculum(){
    for(unsigned int i=0;i<esperienze->size();i++)
            delete (*esperienze)[i];
        delete esperienze;
    for(unsigned int i=0;i<segnalazioni->size();i++)
            delete (*segnalazioni)[i];
        delete segnalazioni;
}
