#include "qwidget_add.h"

QWidget_add::QWidget_add(QWidget *parent) :
    QWidget(parent)
{
}
