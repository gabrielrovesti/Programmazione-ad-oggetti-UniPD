#ifndef QWIDGET_ADD_H
#define QWIDGET_ADD_H

#include <QWidget>

class QWidget_add : public QWidget{
    Q_OBJECT
public:
    explicit QWidget_add(QWidget *parent = 0);
private:

signals:
    
public slots:
    
};

#endif // QWIDGET_ADD_H
