// Dialog.cpp
// Graphical user interface components
#include <QtGui>
#include "Dialog.h"

Dialog::Dialog() 
{
    createMenu();
    createHorizontalGroupBox();
    createGridGroupBox();

    bigEditor = new QTextEdit();
    
    // Layout principale della dialog
    // The QVBoxLayout class lines up widgets vertically.
    QVBoxLayout* mainLayout = new QVBoxLayout;

    mainLayout->setMenuBar(menuBar);
    mainLayout->addWidget(horizontalGroupBox);
    mainLayout->addWidget(gridGroupBox);
    mainLayout->addWidget(bigEditor);
    setLayout(mainLayout);
}

void Dialog::createHorizontalGroupBox()
{
    horizontalGroupBox = new QGroupBox();
    // The QHBoxLayout class lines up widgets horizontally.
    QHBoxLayout* layout = new QHBoxLayout;
    
    buttons[0] = new QPushButton("Nuovo");
    layout->addWidget(buttons[0]);
    // connessione signal-slot
    connect(buttons[0], SIGNAL(clicked()), this, SLOT(create()));
    
    buttons[1] = new QPushButton("Inserisci");
    layout->addWidget(buttons[1]);
    // connessione signal-slot
    connect(buttons[1], SIGNAL(clicked()), this, SLOT(insert()));
 
    buttons[2] = new QPushButton("Cerca");
    layout->addWidget(buttons[2]);
    // connessione signal-slot
    connect(buttons[2], SIGNAL(clicked()),this, SLOT(search()));
     
    buttons[3] = new QPushButton("Cancella");
    layout->addWidget(buttons[3]);
    // connessione signal-slot
    connect(buttons[3], SIGNAL(clicked()),this, SLOT(deleteitem()));

    horizontalGroupBox->setLayout(layout);
}

// slot
void Dialog::create() {
  // cont punta ad un nuovo Contenitore
  cont = new Container<SmartItem>();
  smallEditor->setText(tr("Creato"));
  bigEditor->clear();
}

// slot
void Dialog::insert() {
  cont->insert();
  smallEditor->setText(tr("Inserito"));
  bigEditor->clear();
}

// slot
void Dialog::search() {
  cont->find();
  bigEditor->setText(tr("Cercato e ... trovato/non trovato"));
  smallEditor->clear();
}

// slot
void Dialog::deleteitem() {
  cont->erase();
  smallEditor->setText(tr("Cancellato"));
  bigEditor->clear();
}


void Dialog::createMenu()
{
    menuBar = new QMenuBar;
    fileMenu = new QMenu(tr("&File"), this);
    exitAction = fileMenu->addAction(tr("E&xit"));
    menuBar->addMenu(fileMenu);
    // connessione signal-slot
    connect(exitAction, SIGNAL(triggered()), this, SLOT(accept()));
}

void Dialog::createGridGroupBox()
{
    gridGroupBox = new QGroupBox;
    QGridLayout* layout = new QGridLayout;

    for (int i = 0; i < NumGridRows; ++i) {
	labels[i] = new QLabel(tr("Line %1:").arg(i + 1));
	lineEdits[i] = new QLineEdit;
	layout->addWidget(labels[i], i + 1, 0);
	layout->addWidget(lineEdits[i], i + 1, 1);
    }

    smallEditor = new QTextEdit;
    QFont font = smallEditor->font();
    font.setPointSize(font.pointSize() + 8);
    smallEditor->setFont(font);
   
    layout->addWidget(smallEditor, 0, 2, 4, 1);
    layout->setColumnStretch(1, 10);
    layout->setColumnStretch(2, 20);
    gridGroupBox->setLayout(layout);
}
