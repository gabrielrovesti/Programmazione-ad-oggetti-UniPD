// Dialog.h
#ifndef DIALOG_H
#define DIALOG_H

#include "logica.h"

#include <QDialog>
#include <QAction>
#include <QDialogButtonBox>
#include <QGroupBox>
#include <QLabel>
#include <QLineEdit>
#include <QMenu>
#include <QMenuBar>
#include <QPushButton>
#include <QTextEdit>
#include <QVBoxLayout>

/* La classe della finestra principale derivata da QDialog

The QDialog class is the base class of dialog windows.
A dialog window is a top-level window mostly used for 
short-term tasks and brief communications with the user. */ 
class Dialog : public QDialog
{
  /* 
     This macro must be included in all classes 
     that contain signals and/or slots.
     It defines the functions that are implemented in 
     the meta-object (.moc) file.
  */
    Q_OBJECT

public:
    // costruttore
    Dialog();

public slots:
    // lista degli slot
    void create();
    void insert();  
    void search();
    void deleteitem();
  
private:
    // (puntatore ad un) contenitore di SmartItem
    // link tra view e model
    Container<SmartItem>* cont; 

    // metodi di set-up di Dialog
    void createMenu();
    void createHorizontalGroupBox();
    void createGridGroupBox();

    // Componenti grafiche di Dialog

    /* The QMenuBar class provides a horizontal menu bar.
       A menu bar consists of a list of pull-down menu items. 
       You add menu items with addMenu(). */
    QMenuBar* menuBar;
    /* The QGroupBox widget provides a group box frame with a title.
       A group box provides a frame, a title and a keyboard shortcut, 
       and displays various other widgets inside itself. */
    QGroupBox* horizontalGroupBox;
    QGroupBox* gridGroupBox;
    /* The QTextEdit class provides a widget that is used to edit and 
       display both plain and rich text. */
    QTextEdit* smallEditor;
    QTextEdit* bigEditor;

    enum { NumGridRows = 3, NumButtons = 4 };
    /* The QLabel widget provides a text or image display.
       QLabel is used for displaying text or an image. 
       No user interaction functionality is provided. */
    QLabel* labels[NumGridRows];
    /* The QLineEdit widget is a one-line text editor.
       A line edit allows the user to enter and edit a 
       single line of plain text with a useful collection of 
       editing functions, including undo and redo, 
       cut and paste, and drag and drop. */
    QLineEdit* lineEdits[NumGridRows];
    /* The QPushButton widget provides a command button.
       Push (click) a button to command the computer to 
       perform some action, or to answer a question. */
    QPushButton* buttons[NumButtons];
    /* The QMenu class provides a menu widget for use in menu bars, 
       context menus, and other popup menus. */
    QMenu* fileMenu;
    /* The QAction class provides an abstract user interface action 
       that can be inserted into widgets. Since the user expects 
       each command to be performed in the same way, regardless of 
       the user interface used, it is useful to represent each command 
       as an action. Actions can be added to menus and toolbars. */
    QAction* exitAction;
};

#endif
