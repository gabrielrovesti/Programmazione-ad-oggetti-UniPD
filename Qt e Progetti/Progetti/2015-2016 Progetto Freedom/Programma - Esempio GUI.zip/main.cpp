// main.cpp
#include <QApplication>
#include "Dialog.h"

/* da usare questo prototipo di main per eventuali parametri da
   linea di comando */
int main(int argc, char* argv[]) {   
  // La classe QApplication controlla il flusso di esecuzione della GUI
  QApplication app(argc, argv);
 
  // Finestra Principale
  Dialog dialog;
  
  // il main passa il controllo a QT
  return dialog.exec();
}
