// logica.h
#include <string>
using std::string;

// Template di classe contenitore 
template <class T>
class Container { 
 public:
  // funzionalita` pubbliche di Container
  void insert() {}
  void erase() {}
  void find() {}
};

// Classe BASE
class Base {
 public:
  // distruttore virtuale per avere una classe base polimorfa
  virtual ~Base() {} 
  
  // esempio di metodo pubblico
  bool m() { return true; } 
};

// Classe DERIVATA
class Derived1: public Base {
 public:  
  // esempio di metodo pubblico
  string f() { return "Derived1::f"; }
};

// Classe DERIVATA
class Derived2: public Base {
 public:
  // esempio di metodo pubblico
  string g() { return "Derived2::g"; }
};

// Classe di puntatori smart "polimorfi"
class SmartItem {
 private: 
  Base* ptr;
 public:
  // metodi di puntatori smart
  Base& operator*() const {return *ptr;}
  // ...
};
