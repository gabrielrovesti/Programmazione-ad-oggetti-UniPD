class BadDim extends Throwable{
	public BadDim()
	{
		System.out.print("Le dimensioni delle matrici non sono compatibili per svolgere l'operazione\n");
	}
}