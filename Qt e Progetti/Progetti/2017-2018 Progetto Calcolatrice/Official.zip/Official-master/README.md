# Official
Progetto per l'esame di Programmazione ad Oggetti, Laurea Informatica.
Official è una calcolatrice su matrici, che rende disponibili le più comuni operazioni del calcolo matriciale.
