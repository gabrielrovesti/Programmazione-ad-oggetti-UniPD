
public class DimensioniNonCorrette extends Throwable{
	public DimensioniNonCorrette(){
	System.out.print("le dimensioni delle due matrici non sono compatibili per svolgere l'operazione");}
	
}