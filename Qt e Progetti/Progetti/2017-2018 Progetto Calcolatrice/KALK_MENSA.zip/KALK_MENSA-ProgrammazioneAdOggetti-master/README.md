# KALK_MENSA-ProgrammazioneAdOggetti
Progetto svolto nell'ambito del corso Programmazione ad Oggetti 2017/2018.
