// Listaspesa.cpp

#include "listaspesa.h"



// da togliere?

//ostream& operator<<(ostream& os, const ListaSpesa& ls){
//	int i=1;
//	for (vector<string>::const_iterator cit = ls._listaSpesa.begin() ; cit != ls._listaSpesa.end(); cit++){
//		os<<i<<")"<<*cit<<endl;
//		i++;
//	}
//	return os;
//}
