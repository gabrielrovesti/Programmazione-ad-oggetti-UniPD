#include "linea.h"

// OK
Linea::Linea() {
    Linea::pixel = 100;
    Linea::dpi = 72;
    Linea::color = *(new HexColor());
}

// OK
Linea::Linea(int p) {
    Linea::pixel = p;
    Linea::dpi = 72;
    Linea::color = *(new HexColor());
}

// OK
Linea::Linea(int p, int d) {
    Linea::pixel = p;
    Linea::dpi = d;
    Linea::color = *(new HexColor());
}

// OK
Linea::Linea(int p, int d, HexColor c) {
    Linea::pixel = p;
    Linea::dpi = d;
    Linea::color = c;
}

// OK
void Linea::setLunghezza(int p) {
    Linea::pixel = p;
}

// OK
void Linea::setRisoluzione(int d) {
    Linea::dpi = d;
}

// OK
void Linea::setColor(HexColor c) {
    Linea::color = c;
}

// OK
int Linea::getLunghezza() const {
    return Linea::pixel;
}

// OK
int Linea::getRisoluzione() const {
    return Linea::dpi;
}

// OK
HexColor Linea::getColor() const {
    return Linea::color;
}

// OK
void Linea::setLungCm(double l) {
    Linea::pixel = static_cast<int> (Linea::dpi*(l/2.54)); // l/2.54 converte la lunghezza l da cm a pollici
    if ((Linea::dpi*(l/2.54))-Linea::pixel > 0) Linea::pixel++; // Arrotondo per eccesso
}

// OK
void Linea::setLungInch(double l) {
    Linea::pixel = static_cast<int> (Linea::dpi*l);
    if ((Linea::dpi*l)-Linea::pixel > 0) Linea::pixel++; // Arrotondo per eccesso
}

// OK
double Linea::getLungCm() const {
    double p = static_cast<double>(Linea::pixel);
    double d = static_cast<double>(Linea::dpi);
    return ((p/d)*2.54);
}

// OK
double Linea::getLungInch() const {
    double p = static_cast<double>(Linea::pixel);
    double d = static_cast<double>(Linea::dpi);
    return (p/d);
}

// OK
Stat Linea::getInfo() const {
    Stat t = Stat();
    t.l = this->getLunghezza();
    t.lCm = this->getLungCm();
    t.lInch = this->getLungInch();
    t.dpi = this->getRisoluzione();
    t.color += this->getColor().getColor();
    return t;
}

// Overloading degli operatori
Linea Linea::operator+(const Linea& x) {
    Linea aux;
    int valore = this->getLunghezza() + x.getLunghezza();
    aux.setLunghezza(valore);
    aux.setRisoluzione(this->getRisoluzione());
    return aux;
}

Linea Linea::operator-(const Linea& x) {
    Linea aux;
    int valore = this->getLunghezza() - x.getLunghezza();
    if (valore<=0) valore=1;
    aux.setLunghezza(valore);
    aux.setRisoluzione(this->getRisoluzione());
    return aux;
}

        // Non so come includere Area senza che la gerarchia vada in conflitto.
        // la implementer� come funzione esterna
        // Area Linea::operator*(const Linea& x);

Linea Linea::operator/(const Linea& x) {
    throw exc_Linea_div_Linea();
}

// Overloading di operatori
Linea Linea::operator+(const HexColor& x) {
    Linea aux;
    HexColor c;
    int value = x.getColorDec() + this->color.getColorDec();
    c.setColorDec(value);
    aux.setColor(c);
    aux.setLunghezza(pixel);
    aux.setRisoluzione(dpi);
    return aux;
}

Linea Linea::operator-(const HexColor& x){
    Linea aux;
    HexColor c;
    int value = this->color.getColorDec() - x.getColorDec();
    if (value<0) value=0;
    c.setColorDec(value);
    aux.setColor(c);
    aux.setLunghezza(pixel);
    aux.setRisoluzione(dpi);
    return aux;
}

Linea Linea::operator*(const HexColor& x){
    Linea aux;
    HexColor c = HexColor(x.getColor());
    aux.setColor(c);
    aux.setLunghezza(pixel);
    aux.setRisoluzione(dpi);
    return aux;
}

Linea Linea::operator/(const HexColor& x) {
    Linea aux;
    aux.setLunghezza(pixel);
    aux.setRisoluzione(dpi);
    aux.setColor(color);
    if (color.getColorDec() == x.getColorDec()) {
        aux.setColor(HexColor("000000"));
    }
    return aux;
}
