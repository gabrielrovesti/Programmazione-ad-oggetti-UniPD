#ifndef AREA_H
#define AREA_H

#include "linea.h" 

class Area : public Linea {
    protected:
        int altezza;
	public:
		Area();
		Area(int h);
		Area(int l, int h);
		Area(int l, int h, int d);
		Area(int l, int h, int d, HexColor c);
		
		int getAltezza() const;
		void setAltezza(int h);
		
		double getAltezzaCm() const;
		void setAltezzaCm(double h);
		
		double getAltezzaInch() const;
		void setAltezzaInch(double h);
		
		virtual Stat getInfo() const;

        // Overloading di operatori
        Area operator+(const HexColor& x);
        Area operator-(const HexColor& x);
        Area operator*(const HexColor& x);
        Area operator/(const HexColor& x);

        // Overloading di operatori
        Area operator+(const Linea& x);
        Area operator-(const Linea& x);
        Area operator*(const Linea& x);
        Linea operator/(const Linea& x);

        // Overloading di operatori
        Area operator+(const Area& x);
        Area operator-(const Area& x);
        Area operator*(const Area& x);
        Area operator/(const Area& x);
};

#endif // AREA_H
