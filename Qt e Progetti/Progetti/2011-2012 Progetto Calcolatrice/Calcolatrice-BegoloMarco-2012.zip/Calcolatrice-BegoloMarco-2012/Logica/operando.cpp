#include "operando.h"
/*
  Il metodo Operando::getInfo() non � stato definito virtuale puro.
  Questo perch� se fosse stato definito virtuale puro la classe
  Operando sarebbe diventata una classe astratta, quindi non sarebbe
  stato possibile dichiarare ed inizializzare oggetti di tipo Operando.
  In realt� non vengono inizializzati oggetti di tipo Operando, solo
  puntatori ad oggetti il cui tipo dinamico sar� Linea, Area o HexColor.
*/
Stat Operando::getInfo() const {
    Stat t = Stat();
    return t;
}
Operando::~Operando() {}
