#include "logica.h"

// OK
Logica::Logica() {
    operatore = -1;
    op1 = 0;
    op2 = 0;
    result = 0;
}

// OK
Stat Logica::getInfo(const Operando& a) const {
    return a.getInfo();
}

Operando* Logica::getOp1() const {
    return op1;
}
Operando* Logica::getOp2() const {
    return op2;
}
Operando* Logica::getResult() const {
    return result;
}
Operando* Logica::getSelected() const {
    return selected;
}

// OK
void Logica::newLinea(int p, int d) {
    Linea* l = new Linea(p,d);
    Logica::linee.push_back(l);
}

// OK
Linea* Logica::getLinea(int i){
	Linea* p;
	vector<Linea*>::iterator it=linee.begin();
    for(int k=0;it<linee.end();it++,k++) {
        if (k==i) p=*it;
    }
    return p;
}

// OK
void Logica::newArea(int l, int h, int d) {
    Area* a = new Area(l, h, d);
    Logica::aree.push_back(a);
}

// OK
Area* Logica::getArea(int i) {
	Area* p;
	vector<Area*>::iterator it=aree.begin();
	for(int k=0;it<aree.end();it++,k++) {
        if (k==i) p=*it;
    }
    return p;
}

// OK
void Logica::newColor(string c) {
    HexColor* colore = new HexColor(c);
    Logica::colori.push_back(colore);
}

// 0:Linee, 1:Aree, 2:Colori
int Logica::getVectorSize(int i) const {
    if (i<0) i=0;
    if (i>2) i=2;
    if (i==0) return linee.size();
    if (i==1) return aree.size();
    return colori.size();
}

// OK
HexColor* Logica::getColor(int i) {
	HexColor* p;
	vector<HexColor*>::iterator it=colori.begin();
	for(int k=0;it<colori.end();it++,k++){
	   if (k==i) p=*it;
    }
    return p;
}

// OK
void Logica::setOperator(int o) {
    operatore=o;
}

// OK
void Logica::insertFirstOp(Operando* op) {
    op1 = op;
}

// OK
void Logica::insertSecondOp(Operando* op) {
    op2 = op;
}

// OK
void Logica::esegui() {
    if (op1 && op2 && (operatore>=0)){

        HexColor* o1h = dynamic_cast<HexColor*>(op1);
        HexColor* o2h = dynamic_cast<HexColor*>(op2);
        Linea* o1l = dynamic_cast<Linea*>(op1);
        Linea* o2l = dynamic_cast<Linea*>(op2);
        Area* o1a = dynamic_cast<Area*>(op1);
        Area* o2a = dynamic_cast<Area*>(op2);

// HexColor op1 *operator* HexColor op2
        if ( o1h && o2h ) {
            // HexColor op1 + HexColor op2
            if (operatore == 0) {
                hexcolorResult = (*o1h)+(*o2h);
                result = &hexcolorResult;
            }
            // HexColor op1 - HexColor op2
            else if (operatore == 1) {
                hexcolorResult = (*o1h)-(*o2h);
                result = &hexcolorResult;
            }
            // HexColor op1 * HexColor op2
            else if (operatore == 2) {
                hexcolorResult = (*o1h)*(*o2h);
                result = &hexcolorResult;
            }
            // HexColor op1 / HexColor op2
            else if (operatore == 3) {
                hexcolorResult = (*o1h)/(*o2h);
                result = &hexcolorResult;
            }
        }

// HexColor op1 *operator* Linea op2
        if ( o1h && o2l && !(o2a) ) {
            // HexColor op1 + Linea op2
            if (operatore == 0) {
                hexcolorResult = Logica::sum(*o1h,*o2l);
                result = &hexcolorResult;
            }
            // HexColor op1 - Linea op2
            else if (operatore == 1) {
                hexcolorResult = Logica::sub(*o1h,*o2l);
                result = &hexcolorResult;
            }
            // HexColor op1 * Linea op2
            else if (operatore == 2) {
                hexcolorResult = Logica::mult(*o1h,*o2l);
                result = &hexcolorResult;
            }
            // HexColor op1 / Linea op2
            else if (operatore == 3) {
                hexcolorResult = Logica::div(*o1h,*o2l);
                result = &hexcolorResult;
            }
        }

// HexColor op1 *operator* Area op2
        if ( o1h && o2a ) {
            // HexColor op1 + Area op2
            if (operatore == 0) {
                hexcolorResult = Logica::sum(*o1h,*o2a);
                result = &hexcolorResult;
            }
            // HexColor op1 - Area op2
            else if (operatore == 1) {
                hexcolorResult = Logica::sub(*o1h,*o2a);
                result = &hexcolorResult;
            }
            // HexColor op1 * Area op2
            else if (operatore == 2) {
                hexcolorResult = Logica::mult(*o1h,*o2a);
                result = &hexcolorResult;
            }
            // HexColor op1 / Area op2
            else if (operatore == 3) {
                hexcolorResult = Logica::div(*o1h,*o2a);
                result = &hexcolorResult;
            }
        }

// Linea op1 *operator* HexColor op2
        if ( o1l && o2h && !(o1a)) {
            // Linea op1 + HexColor op2
            if (operatore == 0) {
                lineaResult = (*o1l)+(*o2h);
                result = &lineaResult;
            }
            // Linea op1 - HexColor op2
            else if (operatore == 1) {
                lineaResult = (*o1l)-(*o2h);
                result = &lineaResult;
            }
            // Linea op1 * HexColor op2
            else if (operatore == 2) {
                lineaResult = (*o1l)*(*o2h);
                result = &lineaResult;
            }
            // Linea op1 / HexColor op2
            else if (operatore == 3) {
                lineaResult = (*o1l)/(*o2h);
                result = &lineaResult;
            }
        }

// Linea op1 *operator* Linea op2
        if ( o1l && o2l && !(o1a) && !(o2a) ) {
            // Linea op1 + Linea op2
            if (operatore == 0) {
                lineaResult = (*o1l)+(*o2l);
                result = &lineaResult;
            }
            // Linea op1 - Linea op2
            else if (operatore == 1) {
                lineaResult = (*o1l)-(*o2l);
                result = &lineaResult;
            }
            // Linea op1 * Linea op2
            else if (operatore == 2) {
                areaResult = Logica::mult(*o1l,*o2l);
                result = &areaResult;
            }
            // Linea op1 / Linea op2
            else if (operatore == 3) {
                lineaResult = (*o1l)/(*o2l);
                result = &lineaResult;
            }
        }

// Linea op1 *operator* Area op2
        if ( o1l && o2a && !(o1a) ) {
            // Linea op1 + Area op2
            if (operatore == 0) {
                lineaResult = Logica::sum(*o1l,*o2a);
                result = &lineaResult;
            }
            // Linea op1 - Area op2
            else if (operatore == 1) {
                lineaResult = Logica::sub(*o1l,*o2a);
                result = &lineaResult;
            }
            // Linea op1 * Area op2
            else if (operatore == 2) {
                lineaResult = Logica::mult(*o1l,*o2a);
                result = &lineaResult;
            }
            // Linea op1 / Area op2
            else if (operatore == 3) {
                lineaResult = Logica::div(*o1l,*o2a);
                result = &lineaResult;
            }
        }

// Area op1 *operator* HexColor op2
        if ( o1a && o2h ) {
            // Area op1 + HexColor op2
            if (operatore == 0) {
                areaResult = (*o1a)+(*o2h);
                result = &areaResult;
            }
            // Area op1 - HexColor op2
            else if (operatore == 1) {
                areaResult = (*o1a)-(*o2h);
                result = &areaResult;
            }
            // Area op1 * HexColor op2
            else if (operatore == 2) {
                areaResult = (*o1a)*(*o2h);
                result = &areaResult;
            }
            // Area op1 / HexColor op2
            else if (operatore == 3) {
                areaResult = (*o1a)/(*o2h);
                result = &areaResult;
            }
        }

// Area op1 *operator* Linea op2
        if ( o1a && o2l && !(o2a) ) {
            // Area op1 + Linea op2
            if (operatore == 0) {
                areaResult = (*o1a)+(*o2l);
                result = &areaResult;
            }
            // Area op1 - Linea op2
            else if (operatore == 1) {
                areaResult = (*o1a)-(*o2l);
                result = &areaResult;
            }
            // Area op1 * Linea op2
            else if (operatore == 2) {
                areaResult = (*o1a)*(*o2l);
                result = &areaResult;
            }
            // Area op1 / Linea op2
            else if (operatore == 3) {
                lineaResult = (*o1a)/(*o2l);
                result = &lineaResult;
            }
        }

// Area op1 *operator* Area op2
        if ( o1a && o2a ) {
            // Area op1 + Area op2
            if (operatore == 0) {
                areaResult = (*o1a)+(*o2a);
                result = &areaResult;
            }
            // Area op1 - Area op2
            else if (operatore == 1) {
                areaResult = (*o1a)-(*o2a);
                result = &areaResult;
            }
            // Area op1 * Area op2
            else if (operatore == 2) {
                areaResult = (*o1a)*(*o2a);
                result = &areaResult;
            }
            // Area op1 / Area op2
            else if (operatore == 3) {
                areaResult = (*o1a)/(*o2a);
                result = &areaResult;
            }
        }

    }
}

// OK
void Logica::clear() {
    op1 = 0;
    op2 = 0;
    result = 0;
}

// OK
bool Logica::saveResult() {
    Linea* linea = dynamic_cast<Linea*>(result);
    Area* area = dynamic_cast<Area*>(result);
    HexColor* colore = dynamic_cast<HexColor*>(result);

    if (area) {
        Area* a = new Area(area->getLunghezza(), area->getAltezza(),area->getRisoluzione(), area->getColor());
        Logica::aree.push_back(a);
    }
    else if (linea) {
        Linea* l = new Linea(linea->getLunghezza(),linea->getRisoluzione(), linea->getColor());
        Logica::linee.push_back(l);
    }
    else if (colore) {
        HexColor* c = new HexColor(colore->getColor());
        Logica::colori.push_back(c);
    }
    else return false;
    return true;
}

// OK
void Logica::setSelected(Operando* sel) {
    selected = sel;
}

// OK
void Logica::setOp1(Operando* op) {
    op1 = op;
}

// OK
void Logica::setOp2(Operando* op) {
    op2 = op;
}


// Operatori per HexColor op1, Linea op2
HexColor Logica::sum(HexColor& x, Linea& y) {
    HexColor aux;
    int valore = x.getColorDec() + y.getColor().getColorDec();
    if (valore>16777215) valore = 16777215;
    aux.setColorDec(valore);
    return aux;
}

HexColor Logica::sub(HexColor& x, Linea& y) {
    HexColor aux;
    int valore = x.getColorDec() - y.getColor().getColorDec();
    if (valore<0) valore = -(valore);
    aux.setColorDec(valore);
    return aux;
}

HexColor Logica::mult(HexColor& x, Linea& y) {
    HexColor aux = HexColor(y.getColor().getColor());
    return aux;
}

HexColor Logica::div(HexColor& x, Linea& y) {
    throw exc_HexColor_div_Linea();
}

// Operatori per HexColor op1, Area op2
HexColor Logica::sum(HexColor& x, Area& y) {
    HexColor aux;
    int valore = x.getColorDec() + y.getColor().getColorDec();
    if (valore>16777215) valore = 16777215;
    aux.setColorDec(valore);
    return aux;
}

HexColor Logica::sub(HexColor& x, Area& y) {
    HexColor aux;
    int valore = x.getColorDec() - y.getColor().getColorDec();
    if (valore<0) valore = -(valore);
    aux.setColorDec(valore);
    return aux;
}

HexColor Logica::mult(HexColor& x, Area& y) {
    HexColor aux = HexColor(y.getColor().getColor());
    return aux;
}

HexColor Logica::div(HexColor& x, Area& y) {
    throw exc_HexColor_div_Area();
}

// Operatori per Linea op1, Linea op2
Area Logica::mult(Linea& x, Linea& y) {
    Area aux = Area(x.getLunghezza(),y.getLunghezza(),x.getRisoluzione());
    return aux;
}

// Operatori per Linea op1, Area op2
Linea Logica::sum(Linea& x, Area& y){
    throw exc_Linea_sum_Area();
}
Linea Logica::sub(Linea& x, Area& y){
    throw exc_Linea_sub_Area();
}
Linea Logica::mult(Linea& x, Area& y){
    throw exc_Linea_mult_Area();
}
Linea Logica::div(Linea& x, Area& y){
    throw exc_Linea_div_Area();
}
