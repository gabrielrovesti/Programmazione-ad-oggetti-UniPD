#ifndef HEXCOLOR_H
#define HEXCOLOR_H

#include "operando.h"
#include "stat.h"
#include <math.h>
#include <string>
using std::string;

class HexColor: public Operando {
    private:
        // Questa funione serve solo per pulire una stringa e mantenere solo i caratteri esadecimali
        // Inoltre, posso scegliere tramite intero n quanti caratteri mantenere (a partire dal FONDO della stringa)
        static string puliStringa(string s, int n=6);
        // Questa funzione serve a convertire gli ultimi n caratteri di una stringa esadecimale in intero
        static int valueOf(string c, int n);

    protected:
        int color;
        static const char c[];
        
    public:        
        HexColor();
        HexColor(string c);
        HexColor(int r, int g, int b);

        virtual Stat getInfo() const;

        void setColor(string c);
        void setColorDec(int c);
        string getColor() const;
        int getColorDec() const;

        void setR(string r);
        void setG(string g);
        void setB(string b);
        string getR() const;
        string getG() const;
        string getB() const;

        void setRdec(int r); // 0<r<255
        void setGdec(int g); // 0<g<255
        void setBdec(int b); // 0<b<255
        int getRdec() const; // return x| 0<x<255
        int getGdec() const; // return x| 0<x<255
        int getBdec() const; // return x| 0<x<255

        // Overloading di operatori
        HexColor operator+(const HexColor& x);
        HexColor operator-(const HexColor& x);
        HexColor operator*(const HexColor& x);
        HexColor operator/(const HexColor& x);

        
};

#endif // HEXCOLOR_H
