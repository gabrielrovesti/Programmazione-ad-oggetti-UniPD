#include "area.h"
// OK
Area::Area(): Linea(), altezza(100) {};
Area::Area(int h): Linea(), altezza(h) {};
Area::Area(int l, int h): Linea(l), altezza(h) {};
Area::Area(int l, int h, int d): Linea(l,d), altezza(h) {};
Area::Area(int l, int h, int d, HexColor c): Linea(l,d,c), altezza(h) {};

// OK
int Area::getAltezza() const{
    return Area::altezza;
}

// OK
void Area::setAltezza(int h) {
    Area::altezza = h;
}

// OK
double Area::getAltezzaCm() const {
    double h = static_cast<double>(Area::altezza);
    double d = static_cast<double>(Linea::dpi);
    return ((h/d)*2.54);
}

// OK
void Area::setAltezzaCm(double h) {
    Area::altezza = static_cast<int> (Linea::dpi*(h/2.54)); // l/2.54 converte l'altezza h da cm a pollici
    if ((Linea::dpi*(h/2.54))-Area::altezza > 0) Area::altezza++; // Arrotondo per eccesso
}

// OK
double Area::getAltezzaInch() const {
    double h = static_cast<double>(Area::altezza);
    double d = static_cast<double>(Linea::dpi);
    return (h/d);
}

// OK
void Area::setAltezzaInch(double h) {
    Area::altezza = static_cast<int> (Linea::dpi*h);
    if ((Linea::dpi*h)-Area::altezza > 0) Area::altezza++; // Arrotondo per eccesso
}

// OK
Stat Area::getInfo() const {
    Stat t = Stat();
    t.l = this->getLunghezza();
    t.lCm = this->getLungCm();
    t.lInch = this->getLungInch();
    t.h = this->getAltezza();
    t.hCm = this->getAltezzaCm();
    t.hInch = this->getAltezzaInch();
    t.dpi = this->getRisoluzione();
    t.color += this->getColor().getColor();
    return t;
}

// Overloading di operatori
Area Area::operator+(const HexColor& x) {
    Area aux;
    aux.setAltezza(altezza);
    aux.setLunghezza(pixel);
    aux.setRisoluzione(dpi);
    HexColor c;
    int value = color.getColorDec() + x.getColorDec();
    if (value>16777215) value=16777215;
    c.setColorDec(value);
    aux.setColor(c);
    return aux;
}

Area Area::operator-(const HexColor& x) {
    Area aux;
    aux.setAltezza(altezza);
    aux.setLunghezza(pixel);
    aux.setRisoluzione(dpi);
    HexColor c;
    int value = color.getColorDec() - x.getColorDec();
    if (value<0) value=0;
    c.setColorDec(value);
    aux.setColor(c);
    return aux;
}

Area Area::operator*(const HexColor& x) {
    Area aux;
    aux.setAltezza(altezza);
    aux.setLunghezza(pixel);
    aux.setRisoluzione(dpi);
    HexColor c = HexColor(x.getColor());
    aux.setColor(c);
    return aux;
}

Area Area::operator/(const HexColor& x) {
    Area aux;
    aux.setAltezza(altezza);
    aux.setLunghezza(pixel);
    aux.setRisoluzione(dpi);
    aux.setColor(color);
    if (color.getColorDec() == x.getColorDec()) {
        aux.setColor(HexColor("000000"));
    }
    return aux;
}

// Overloading di operatori
Area Area::operator+(const Linea& x) {
    throw exc_Area_sum_Linea();
}
Area Area::operator-(const Linea& x) {
    throw exc_Area_sub_Linea();
}
Area Area::operator*(const Linea& x) {
    throw exc_Area_mult_Linea();
}
Linea Area::operator/(const Linea& x) {
    Linea aux = Linea(0,dpi,color);
    if (x.getLunghezza()==pixel) {
        aux.setLunghezza(altezza);
        return aux;
    }
    else if (x.getLunghezza()==altezza) {
        aux.setLunghezza(pixel);
        return aux;
    }
    else throw failure_Area_div_Linea();
}

// Overloading di operatori
Area Area::operator+(const Area& x) {
    Area aux;
    aux.setAltezza(altezza);
    aux.setColor(color);
    aux.setRisoluzione(dpi);
    int newLung = pixel+x.getLunghezza();
    aux.setLunghezza(newLung);
    return aux;
}
Area Area::operator-(const Area& x) {
    Area aux;
    aux.setAltezza(altezza);
    aux.setColor(color);
    aux.setRisoluzione(dpi);
    int newLung = pixel-x.getLunghezza();
    if (newLung<=0) newLung = 1;
    aux.setLunghezza(newLung);
    return aux;
}
Area Area::operator*(const Area& x) {
    Area aux;
    aux.setColor(color);
    aux.setRisoluzione(dpi);
    int newLung = pixel+x.getLunghezza();
    int newH = altezza+x.getAltezza();
    aux.setLunghezza(newLung);
    aux.setAltezza(newH);
    return aux;
}
Area Area::operator/(const Area& x) {
    Area aux;
    aux.setColor(color);
    aux.setRisoluzione(dpi);
    int newLung = pixel-x.getLunghezza();
    int newH = altezza-x.getAltezza();
    if (newLung<=0) newLung=1;
    if (newH<=0) newH=1;
    aux.setLunghezza(newLung);
    aux.setAltezza(newH);
    return aux;
}
