#ifndef OPERANDO_H
#define OPERANDO_H

#include "stat.h"

class Operando {
	public:
        virtual Stat getInfo() const;
        virtual ~Operando();
};

#endif // OPERANDO_H
