#ifndef STAT_H
#define STAT_H

#include <string>
#include <iostream>
using std::string;
using std::cout;
using std::endl;

// La classe Stat ha lo scopo di fungere da trasportatore di dati. 
// Per questo gli attributi sono stati dichiarati public

class Stat {
    public:
        int l;
        double lCm;
        double lInch;
        int h;
        double hCm;
        double hInch;
        int dpi;
        string color;
        
        // Costruttore
		Stat();
};

#endif // STAT_H
