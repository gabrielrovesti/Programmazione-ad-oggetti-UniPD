#include "hexcolor.h"

#include <iostream>
using namespace std;

const char HexColor::c[] = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};

// OK
string HexColor::puliStringa(string s, int n) {
    string rawInput = s;
    string input = "";
    string car;
    string suffisso = "";
    for (int i=0; i<n;i++) suffisso+="0";
    // "Pulisco" la stringa di input da eventuali valori NON esadecimali
    for (int i=(rawInput.size()-1); i>=0; i--) {
        car = rawInput[i];
        if ((car.compare("9")<=0 && car.compare("0")>=0) || 
            (car.compare("f")<=0 && car.compare("a")>=0) ||
            (car.compare("F")<=0 && car.compare("A")>=0)) {
            // Se il carattere � compreso fra 'a' e 'f' lo metto maiuscolo, sottraendo 32 posizioni della tabella ASCII
            if ((car.compare("f")<=0 && car.compare("a")>=0)) car = car[0]-32;
            input = ""+car+input;
        }
    }
    input = suffisso+input;
    input = input.substr(input.size()-n,n);
    return input;
}

// OK
int HexColor::valueOf(string c, int n) {
    string s = puliStringa(c,n);
    string car;
    int colore = 0;
    int val;
    for (int i=0; i<n; i++) {
        car = s[(n-1)-i];
        if ((car.compare("9")<=0 && car.compare("0")>=0)) val = 0+car[0]-48;
        else val = 10+car[0]-65;
        colore += val*(static_cast<int>(pow(16,i)));
    }
    return colore;
}

// OK
HexColor::HexColor() {
    HexColor::color = 0;
}

// OK
HexColor::HexColor(string c) {
    HexColor::color = valueOf(c,6);
}

// OK
HexColor::HexColor(int r, int g, int b) {
    if (r<0) r=0;
    if (r>255) r=255;
    if (g<0) g=0;
    if (g>255) g=255;
    if (b<0) g=0;
    if (b>255) g=255;
    int c = b + g*256 + r*65536;
    HexColor::color = c;
}

// OK
void HexColor::setColor(string c) {
    HexColor::color = valueOf(c,6);
}
// OK
void HexColor::setColorDec(int c) {
    HexColor::color = c;
    if (c>16777215) HexColor::color = 16777215;
    else if (c<0) HexColor::color = 0;
}

// OK
string HexColor::getColor() const {
    string output = "";
    int x = HexColor::color;
    int y = x;
    int div = 1048576;
    for (int i=0; i<6; i++) {
        y = x/div;
        x = x%div;
        output += HexColor::c[y];
        div = div/16;
    }
    return output;
}

// OK
int HexColor::getColorDec() const {
    return HexColor::color;
}

// OK
void HexColor::setR(string r) {
    (*this).HexColor::setRdec(valueOf(r,2));
}

// OK
void HexColor::setG(string g) {
     (*this).HexColor::setGdec(valueOf(g,2));
}

// OK
void HexColor::setB(string b) {
     (*this).HexColor::setBdec(valueOf(b,2));
}

// OK
string HexColor::getR() const {
    string output = "";
    int x = HexColor::color;
    int y = x;
    int div = 1048576;
    for (int i=0; i<2; i++) {
        y = x/div;
        x = x%div;
        output += HexColor::c[y];
        div = div/16;
    }
    return output;
}

// OK
string HexColor::getG() const {
    string output = "";
    int x = HexColor::color%65536;
    int y = x;
    int div = 4096;
    for (int i=0; i<2; i++) {
        y = x/div;
        x = x%div;
        output += HexColor::c[y];
        div = div/16;
    }
    return output;
}

// OK
string HexColor::getB() const {
    string output = "";
    int x = HexColor::color%256;
    int y = x;
    int div = 16;
    for (int i=0; i<2; i++) {
        y = x/div;
        x = x%div;
        output += HexColor::c[y];
        div = div/16;
    }
    return output;
}

// OK
void HexColor::setRdec(int r) {
    int x = r;
    if (x>255) x=255;
    else if (x<0) x=0;
    x=x*65536; // moltiplico x (valore fra 0 e 255) per 16^4, in questo modo il numero influir� solo sulla prima e seconda cifra hex
    HexColor::color = HexColor::color%65536; // Rimuovo la 1^ e 2^ cifre hex pi� significative
    HexColor::color += x;
}

// OK
void HexColor::setGdec(int g) {
    int x = g;
    if (x>255) x=255;
    else if (x<0) x=0;
    x=x*256; // moltiplico x (valore fra 0 e 255) per 16^2, in questo modo il numero influir� solo sulla terza e quarta cifra hex
    HexColor::color = HexColor::color-(HexColor::color%65536)+(HexColor::color%256); // Rimuovo la 3^ e 4^ cifre hex pi� significative
    HexColor::color += x;
}

// OK
void HexColor::setBdec(int b) {
    int x = b;
    if (x>255) x=255;
    else if (x<0) x=0;
    HexColor::color = HexColor::color-(HexColor::color%256); // Rimuovo la 5^ e 6^ cifre hex pi� significative
    HexColor::color += x;
}

// OK
int HexColor::getRdec() const {
    return HexColor::color/65536;
}

// OK
int HexColor::getGdec() const {
    return (HexColor::color%65536)/256;
}

// OK
int HexColor::getBdec() const {
    return HexColor::color%256;
}

// OK
Stat HexColor::getInfo() const {
    Stat t = Stat();
    t.color += this->getColor();
    return t;
}

// Overloading di operatori:
// HexColor op1 operator HexColor op2
HexColor HexColor::operator+(const HexColor& x) {
    HexColor aux;
    int result = HexColor::color + x.HexColor::getColorDec();
    if (result>16777215) aux.setColorDec(16777215);
    else if (result<0) aux.setColorDec(0);
    else aux.setColorDec(result);
    return aux;
}

HexColor HexColor::operator-(const HexColor& x) {
    HexColor aux;
    int result = HexColor::color - x.HexColor::getColorDec();
    if (result<0) result = -(result); // abs(result)
    if (result>16777215) aux.setColorDec(16777215);
    else aux.setColorDec(result);
    return aux;
}

HexColor HexColor::operator*(const HexColor& x) {
    int r = this->getRdec() + x.getRdec();
    if (r<0) r = 0;
    if (r>255) r=255;
    int g = this->getGdec() + x.getGdec();
    if (g<0) g = 0;
    if (g>255) g=255;
    int b = this->getBdec() + x.getBdec();
    if (b<0) b = 0;
    if (b>255) b=255;
    HexColor aux = HexColor(r,g,b);
    return aux;
}

HexColor HexColor::operator/(const HexColor& x) {
    int r = this->getRdec() - x.getRdec();
    if (r<0) r = 0;
    if (r>255) r=255;
    int g = this->getGdec() - x.getGdec();
    if (g<0) g = 0;
    if (g>255) g=255;
    int b = this->getBdec() - x.getBdec();
    if (b<0) b = 0;
    if (b>255) b=255;
    HexColor aux = HexColor(r,g,b);
    return aux;
}

