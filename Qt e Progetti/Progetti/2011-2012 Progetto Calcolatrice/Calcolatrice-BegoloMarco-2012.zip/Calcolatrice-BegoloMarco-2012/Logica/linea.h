#ifndef LINEA_H
#define LINEA_H

#include "operando.h"
#include "hexcolor.h"
#include "stat.h"
#include "errors.h"

class Linea: public Operando {
    protected:
        int pixel;
        int dpi;
        HexColor color;
    public:
        Linea();
        Linea(int p);
        Linea(int p, int d);
        Linea(int p, int d, HexColor c);

        void setLunghezza(int p);
        void setRisoluzione(int d);
        void setColor(HexColor c);
        int getLunghezza() const;
        int getRisoluzione() const;
        HexColor getColor() const;

        void setLungCm(double l);
        void setLungInch(double l);
        double getLungCm() const;
        double getLungInch() const;
        
        virtual Stat getInfo() const;

        // Overloading di operatori
        Linea operator+(const Linea& x);
        Linea operator-(const Linea& x);
        // Non so come includere Area senza che la gerarchia vada in conflitto.
        // la implementer� come funzione esterna
        // Area operator*(const Linea& x);
        Linea operator/(const Linea& x);

        // Overloading di operatori
        Linea operator+(const HexColor& x);
        Linea operator-(const HexColor& x);
        Linea operator*(const HexColor& x);
        Linea operator/(const HexColor& x);

};

#endif // LINEA_H
