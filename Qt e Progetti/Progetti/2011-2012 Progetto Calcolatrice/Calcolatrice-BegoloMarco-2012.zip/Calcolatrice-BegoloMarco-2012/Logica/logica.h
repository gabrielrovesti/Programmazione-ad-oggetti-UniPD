#ifndef LOGICA_H
#define LOGICA_H

#include "area.h"
#include "errors.h"
#include <vector>
#include <typeinfo>
using namespace std;

class Logica {
    private:
        Operando* op1;
        Operando* op2;
        Operando* result;
        Linea lineaResult;
        Area areaResult;
        HexColor hexcolorResult;
        Operando* selected;
        vector<Linea*> linee;
        vector<Area*> aree;
        vector<HexColor*> colori;
        int operatore;
	public:
        Logica();
        
        Stat getInfo(const Operando& a) const;
        Operando* getOp1() const;
        Operando* getOp2() const;
        Operando* getResult() const;
        Operando* getSelected() const;
        
        void newLinea(int p, int d);
        void newArea(int l, int h, int d);
        void newColor(string c);
        int getVectorSize(int i) const;
        
        Linea* getLinea(int i);
        Area* getArea(int i);
        HexColor* getColor(int i);
        
        void setOperator(int o); // 0:add , 1:sub , 2:mult , 3:div
        void insertFirstOp(Operando* op);
        void insertSecondOp(Operando* op);
        void esegui();
        void clear();

        bool saveResult();
        void setSelected(Operando* sel);
        void setOp1(Operando* op);
        void setOp2(Operando* op);

        /*
          Le seguenti funzioni statiche sono un'alternativa
          all'overloading dei corrispondenti operatori. Questo
          perch� l'implementazione degli operatori necessita di
          opportuni #include delle classi che trattano, tuttavia
          nei seguenti casi ( ad esempio HexColor op1 + Linea op2)
          genera conflitti a causa di #include ciclici (nell'esempio
          precedente la classe HexColor, per implemetare
          l'overloading di operator+ avrebbe dovuto includere
          il file linea.h, il quale a sua volta include il file
          hexcolor.h)
        */
        // Operazioni: HexColor op1, Linea op2
        static HexColor sum(HexColor& x,Linea& y);
        static HexColor sub(HexColor& x,Linea& y);
        static HexColor mult(HexColor& x,Linea& y);
        static HexColor div(HexColor& x,Linea& y);

        // Operazioni: HexColor op1, Area op2
        static HexColor sum(HexColor& x,Area& y);
        static HexColor sub(HexColor& x,Area& y);
        static HexColor mult(HexColor& x,Area& y);
        static HexColor div(HexColor& x,Area& y);

        // Operazioni: Linea op1, Linea op2
        static Area mult(Linea& x, Linea& y);

        // Operazioni: Linea op1, Area op2
        static Linea sum(Linea& x, Area& y);
        static Linea sub(Linea& x, Area& y);
        static Linea mult(Linea& x, Area& y);
        static Linea div(Linea& x, Area& y);
};

#endif // LOGICA_H
