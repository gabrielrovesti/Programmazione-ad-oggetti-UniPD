#ifndef ERRORS_H
#define ERRORS_H

class exc_HexColor_div_Linea {};

class exc_HexColor_div_Area {};

class exc_Linea_div_Linea {};

class exc_Linea_sum_Area {};
class exc_Linea_sub_Area {};
class exc_Linea_mult_Area {};
class exc_Linea_div_Area {};

class exc_Area_sum_Linea {};
class exc_Area_sub_Linea {};
class exc_Area_mult_Linea {};
class failure_Area_div_Linea {}; // Quest'eccezione � differente. L'operazione � consentita, ma non sempre restituisce un risultato

#endif // ERRORS_H
