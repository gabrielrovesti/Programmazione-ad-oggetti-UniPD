#include "stat.h"

Stat::Stat() {
    // Assegno dei valori di default che saranno "unici", ovvero riconoscibili nella logica.
    Stat::l = -1;
    Stat::lCm = -1;
    Stat::lInch = -1;
    Stat::h = -1;
    Stat::hCm = -1;
    Stat::hInch = -1;
    Stat::dpi = -1;
    Stat::color = "#";
}
