#include <QApplication>

#include "Grafica/grafica.h"
#include <QIcon>
#include <QString>

int main( int argc, char **argv ) {
    QApplication a( argc, argv );
    QIcon icon = QIcon("icon.png");
    a.setWindowIcon(icon);
    Grafica g;
    g.setGeometry(100,100,900,700);
    g.show();
    return a.exec();
}
