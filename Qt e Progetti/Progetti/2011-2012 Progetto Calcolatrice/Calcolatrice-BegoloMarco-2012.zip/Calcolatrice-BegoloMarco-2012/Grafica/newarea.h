#ifndef NEWAREA_H
#define NEWAREA_H

#include <QWidget>
#include <QGridLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QGroupBox>
#include <QRadioButton>
#include <QMessageBox>
#include <QString>

#include "../Logica/logica.h"

class NewArea : public QWidget {
    Q_OBJECT
public:
    NewArea(Logica* log, QWidget *parent = 0);
private:
    Logica* logic;
    QGroupBox*  boxNewLine;
    QGridLayout* boxGrid ;
    QGridLayout* struttura;
    QGroupBox* udmBox;
    QGridLayout* udmGrid;
    QLineEdit* ris;
    QLineEdit* length;
    QLineEdit* height;
    QPushButton* create;
    int udm;
public slots:
    void saveArea();
    void setPx();
    void setCm();
    void setInch();
signals:
    void areaAdded();

};

#endif // NEWAREA_H
