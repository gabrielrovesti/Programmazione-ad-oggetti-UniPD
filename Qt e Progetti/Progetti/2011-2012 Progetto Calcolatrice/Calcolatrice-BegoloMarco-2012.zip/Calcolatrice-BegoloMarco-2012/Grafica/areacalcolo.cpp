#include "areacalcolo.h"

AreaCalcolo::AreaCalcolo(Logica* l, QWidget *parent): QWidget(parent) {
    logic = l;
    struttura = new QGridLayout(this);

    // PRIMO OPERANDO
    QLabel* label1op = new QLabel(tr(" 1� Operando"));
    linea1op = new QLineEdit();
    button1op = new QPushButton(tr("Add ^"));

    struttura->addWidget(label1op,0,0);
    struttura->addWidget(linea1op,1,0);
    struttura->addWidget(button1op,2,0);

    // SELEZIONE OPERATORE
    operators = new Operatori();
    struttura->addWidget(operators, 0, 1, 3, 1);

    // SECONDO OPERANDO
    QLabel* label2op = new QLabel(tr(" 2� Operando"));
    linea2op = new QLineEdit();
    button2op = new QPushButton(tr("Add ^"));

    struttura->addWidget(label2op,0,2);
    struttura->addWidget(linea2op,1,2);
    struttura->addWidget(button2op,2,2);

    // BUTTON "=" (esegui)
    uguale = new QPushButton(tr("="),this);
    struttura->addWidget(uguale, 1,3);

    // RISULTATO
    QLabel* labelRisultato = new QLabel(tr(" Risultato"));
    risultato = new QLineEdit();
    saveButton = new QPushButton(tr("Salva"));

    // BUTTON ""=" (esegui)"Clear"
    QPushButton* clear = new QPushButton(tr("Clear"),this);
    struttura->addWidget(clear, 2,3);

    struttura->addWidget(labelRisultato,0,4);
    struttura->addWidget(risultato,1,4);
    struttura->addWidget(saveButton,2,4);

    connect(button1op, SIGNAL(clicked()), this, SLOT(addOp1()));
    connect(button2op, SIGNAL(clicked()), this, SLOT(addOp2()));
    connect(clear, SIGNAL(clicked()), this, SLOT(clear()));
    connect(uguale, SIGNAL(clicked()), this, SLOT(esegui()));
    connect(operators, SIGNAL(operatorChanged()), this, SLOT(setOperator()));
    connect(saveButton, SIGNAL(clicked()), this, SLOT(saveResult()));

}

QString AreaCalcolo::getStringValue(Operando* op) const{
    Stat info = logic->getInfo(*op);

    QString l = QString(tr(""));
    QString h = QString(tr(""));
    QString d = QString(tr(""));
    QString px = QString(tr(""));

    QString c = QString::fromStdString(info.color);
    if ((info.l)>0) {
        l = QString::number(info.l);
        px = QString(tr("px "));
    }
    if (info.h>0) h = "x"+QString::number(info.h);
    if (info.dpi>0) d = "@"+QString::number(info.dpi)+"dpi ";
    QString valore = l+h+px+d+c;
    return valore;
}

void AreaCalcolo::setOperator(){
    logic->setOperator(operators->getSelectedOperator());
}

void AreaCalcolo::addOp1() {
    Operando* selected = logic->getSelected();
    logic->setOp1(selected);
    if (selected) { // Altrimenti da errore di segmentation fault
        Operando* op1 = logic->getOp1();
        QString valore = getStringValue(op1);
        linea1op->setText(valore);
    }
}

void AreaCalcolo::addOp2() {
    Operando* selected = logic->getSelected();
    logic->setOp2(selected);
    if (selected) { // Altrimenti da errore di segmentation fault
        Operando* op2 = logic->getOp2();
        QString valore = getStringValue(op2);
        linea2op->setText(valore);
    }
}

void AreaCalcolo::clear() {
    logic->clear();
    linea1op->setText(tr(""));
    linea2op->setText(tr(""));
    risultato->setText(tr(""));
}

#include <iostream>
using namespace std;

void AreaCalcolo::esegui() {
    if ((logic->getOp1()) && (logic->getOp2()) && (operators->getSelectedOperator()>=0)) {
        QMessageBox* errorMsg = new QMessageBox();
        errorMsg->setWindowTitle(QString(tr("Errore!")));
        errorMsg->setText(QString(tr("Impossibile effettuare l'operazione.")));
        try {
            logic->esegui();
            Operando* op = logic->getResult();
            if (op) { // Se op==0 verrebbe provocata un'eccezione
                QString valore = getStringValue(op);
                risultato->setText(valore);
            }
            else {
                QMessageBox* noResultMsg = new QMessageBox();
                noResultMsg->setWindowTitle(QString(tr("Errore!")));
                noResultMsg->setInformativeText(QString(tr("Impossibile calcolare il risultato.")));
                noResultMsg->exec();
                clear();
            }
        }
        catch (exc_HexColor_div_Linea) {
            errorMsg->setInformativeText(QString(tr("Un tipo HexColor non � divisibile per un tipo Linea")));
            errorMsg->exec();
        }
        catch (exc_HexColor_div_Area) {
            errorMsg->setInformativeText(QString(tr("Un tipo HexColor non � divisibile per un tipo Area")));
            errorMsg->exec();
        }
        catch (exc_Linea_div_Linea) {
            errorMsg->setInformativeText(QString(tr("Un tipo Linea non � divisibile per un tipo Linea")));
            errorMsg->exec();
        }
        catch (exc_Linea_sum_Area) {
            errorMsg->setInformativeText(QString(tr("Un tipo Linea non � sommabile ad un tipo Area")));
            errorMsg->exec();
        }
        catch (exc_Linea_sub_Area) {
            errorMsg->setInformativeText(QString(tr("Ad un tipo Linea non pu� essere sottratto un tipo Area")));
            errorMsg->exec();
        }
        catch (exc_Linea_mult_Area) {
            errorMsg->setInformativeText(QString(tr("Un tipo Linea non � moltiplicabile per un tipo Area")));
            errorMsg->exec();
        }
        catch (exc_Linea_div_Area) {
            errorMsg->setInformativeText(QString(tr("Un tipo Linea non � divisibile per un tipo Area")));
            errorMsg->exec();
        }
        catch (exc_Area_sum_Linea) {
            errorMsg->setInformativeText(QString(tr("Un tipo Area non � sommabile ad un tipo Linea")));
            errorMsg->exec();
        }
        catch (exc_Area_sub_Linea) {
            errorMsg->setInformativeText(QString(tr("Ad un tipo Area non � possibile sottrarre un tipo Linea")));
            errorMsg->exec();
        }
        catch (exc_Area_mult_Linea) {
            errorMsg->setInformativeText(QString(tr("Un tipo Area non � moltiplicabile per un tipo Linea")));
            errorMsg->exec();
        }
        catch (failure_Area_div_Linea) {
            errorMsg->setInformativeText(QString(tr("Nessuno dei lati dell'area � uguale alla lunghezza della linea, perci� non � stato possibile effettuare la divisione")));
            errorMsg->exec();
        }
    }
    else {
        QMessageBox* msgBox = new QMessageBox();
        msgBox->setWindowTitle(QString(tr("Errore!")));
        msgBox->setText(QString(tr("Inserisci entrambi gli operandi e seleziona un operatore.")));
        msgBox->exec();
    }
}

void AreaCalcolo::saveResult() {
    bool success = logic->saveResult();
    this->clear();
    if (success) emit itemAdded();
}
