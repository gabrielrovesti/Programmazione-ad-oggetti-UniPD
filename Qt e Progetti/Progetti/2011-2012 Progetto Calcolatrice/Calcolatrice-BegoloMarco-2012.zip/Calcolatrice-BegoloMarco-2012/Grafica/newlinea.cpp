#include "newlinea.h"

NewLinea::NewLinea(Logica* log, QWidget *parent) : QWidget(parent) {
    logic = log;
    struttura = new QGridLayout(this);
    boxNewLine = new QGroupBox(tr("Crea nuova Linea"));
    boxGrid = new QGridLayout();

    QLabel* l = new QLabel(tr("L:"));
    length = new QLineEdit();
    QLabel* r = new QLabel(tr("Ris:"));
    ris = new QLineEdit();

    boxGrid->addWidget(l,0,0);
    boxGrid->addWidget(length,0,1);
    boxGrid->addWidget(r,1,0);
    boxGrid->addWidget(ris,1,1);

    udmBox = new QGroupBox();
    udmGrid = new QGridLayout(this);

    QRadioButton* px = new QRadioButton(tr("px"));
    QRadioButton* cm = new QRadioButton(tr("cm"));
    QRadioButton* inch = new QRadioButton(tr("inch"));
    px->setChecked(true);
    udm=0;

    udmGrid->addWidget(px,0,0);
    udmGrid->addWidget(cm,1,0);
    udmGrid->addWidget(inch,2,0);

    udmBox->setLayout(udmGrid);

    boxGrid->addWidget(udmBox,0,2);

    create = new QPushButton(tr("Crea"));

    boxGrid->addWidget(create,2,1);

    boxNewLine->setLayout(boxGrid);
    struttura->addWidget(boxNewLine,0,0);

    connect(create, SIGNAL(clicked()), this, SLOT(saveLinea()));

    connect(px, SIGNAL(clicked()),this,SLOT(setPx()));
    connect(cm, SIGNAL(clicked()),this,SLOT(setCm()));
    connect(inch, SIGNAL(clicked()),this,SLOT(setInch()));

}

void NewLinea::saveLinea() {
    int pixel;
    //La seguente conversione � sicura, se il testo non � STRETTAMENTE un double la conversione restituisce 0
    double lengthValue = (length->text()).toDouble();
    int lengthValueInt = (length->text()).toInt();
    int dpi = (ris->text()).toInt();

    QMessageBox errorMsg;
    errorMsg.setWindowTitle(tr("Errore!"));
    bool error = false;

    QMessageBox warningMsg;
    warningMsg.setWindowTitle(tr("Attenzione!"));
    bool warning = false;

    // Controlli su "length"
    QString qstr = QString(length->text());
    QString emptyString = QString(tr(""));
    if (QString::compare(qstr, emptyString)==0) {
        errorMsg.setInformativeText(tr("La stringa vuota non � valida. Inserire una lunghezza valida"));
        error = true;
    }

    if (lengthValue==0) {
        warningMsg.setText(tr("Hai inserito il valore 0 come lunghezza, oppure un numero non valido."));
        warningMsg.setInformativeText(tr("La nuova linea avr� lunghezza pari a 1px"));
        warning = true;
    }

    // Controlli sull'unit� di misura
    if (udm==1) pixel = static_cast<int>(lengthValue*dpi*2.54);
    else if (udm==2) pixel = static_cast<int>(lengthValue*dpi);
    else pixel = lengthValueInt;

    // Controlli sui dpi
    if (dpi==0) {
        errorMsg.setText(tr("Il valore dei dpi non � valido. Inserire un intero diverso da 0"));
        error = true;
    }

    if (error) errorMsg.exec();
    else {
        if (pixel==0) pixel=1;
        if (warning) warningMsg.exec();
        logic->newLinea(pixel,dpi);
        emit lineaAdded();
    }
}

void NewLinea::setPx() {
    udm = 0;
    update();
    repaint();
}

void NewLinea::setCm() {
    udm = 1;
    update();
    repaint();
}

void NewLinea::setInch() {
    udm = 2;
    update();
    repaint();
}


