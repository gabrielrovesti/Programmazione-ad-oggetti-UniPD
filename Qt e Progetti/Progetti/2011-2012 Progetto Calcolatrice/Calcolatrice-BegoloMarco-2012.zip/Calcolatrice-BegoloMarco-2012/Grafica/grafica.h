#ifndef GRAFICA_H
#define GRAFICA_H

#include <QMainWindow>
#include <QScrollArea>
#include <QMenuBar>

#include "grid.h"
#include "../Logica/logica.h"

class Grafica: public QMainWindow {
    Q_OBJECT

    public:
        QWidget* central;
        QScrollArea* scroll;

        Grafica(QWidget* = 0);


};

#endif // GRAFICA_H
