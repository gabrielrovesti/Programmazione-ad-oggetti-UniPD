#include "areacreazione.h"

AreaCreazione::AreaCreazione(Logica* logic, QWidget *parent): QWidget(parent) {
    struttura = new QGridLayout(this);
    NewLinea* nl = new NewLinea(logic);
    NewArea* na = new NewArea(logic);
    NewColor* nc = new NewColor(logic);
    struttura->addWidget(nl,0,0);
    struttura->addWidget(na,0,1);
    struttura->addWidget(nc,0,2);

    connect(nc, SIGNAL(colorAdded()), this, SLOT(addColor()));
    connect(nl, SIGNAL(lineaAdded()), this, SLOT(addLinea()));
    connect(na, SIGNAL(areaAdded()), this, SLOT(addArea()));
}

void AreaCreazione::addColor() {
    emit itemAdded();
}

void AreaCreazione::addLinea() {
    emit itemAdded();
}

void AreaCreazione::addArea() {
    emit itemAdded();
}
