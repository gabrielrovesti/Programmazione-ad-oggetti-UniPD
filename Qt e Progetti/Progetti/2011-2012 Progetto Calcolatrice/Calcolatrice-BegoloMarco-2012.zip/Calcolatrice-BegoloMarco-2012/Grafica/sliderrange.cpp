#include "sliderrange.h"

SliderRange::SliderRange(QWidget *parent): QWidget(parent) {
    slider = new QSlider(Qt::Horizontal);
    decValue = new QLineEdit(tr("0"));
    decValue->setFixedWidth(35);
    slider->setRange(0,255);

    connect(slider, SIGNAL(valueChanged(int)), this, SLOT(changeDecValue(int)));
    connect(decValue, SIGNAL(textChanged(QString)), this, SLOT(setValue(QString)));

    QGridLayout* struttura = new QGridLayout();
    struttura->addWidget(slider,0,0);
    struttura->addWidget(decValue,0,1);
    setLayout(struttura);
    setFocusProxy(slider);
}

int SliderRange::value() const {
    return slider->value();
}

void SliderRange::setValue(QString v) {
    slider->setValue(v.toInt());
    emit valueChanged(v.toInt());
}

void SliderRange::changeDecValue(int v) {
    QString str;
    str.append(QString("%1").arg(v));
    decValue->setText(str);
    emit valueChanged(v);
}

void SliderRange::setRange(int min, int max) {
    if (min<0 || max>255 || min>max) {
        qWarning("I valori devono essere in un range di 0..255\n Il primo deve essere minore del secondo");
        return;
    }
    slider->setRange(min, max);
}

void SliderRange::changeRedFromHex(QString s) {
    string str = s.toStdString();
    HexColor c = HexColor(str);
    slider->setValue(c.getRdec());
}

void SliderRange::changeGreenFromHex(QString s) {
    string str = s.toStdString();
    HexColor c = HexColor(str);
    slider->setValue(c.getGdec());
}

void SliderRange::changeBlueFromHex(QString s) {
    string str = s.toStdString();
    HexColor c = HexColor(str);
    slider->setValue(c.getBdec());
}
