#include "areaselezione.h"

AreaSelezione::AreaSelezione(Logica* l, QWidget *parent): QWidget(parent) {
    logic = l;
    struttura = new QGridLayout(this);

    selectLinee = new QListWidget();
    selectAree = new QListWidget();
    selectColori = new QListWidget();
    QLabel* selectLineeLabel = new QLabel(tr(" Linee"));
    QLabel* selectAreeLabel = new QLabel(tr(" Aree"));
    QLabel* selectColoriLabel = new QLabel(tr(" Colori"));

    for (int i=0;i<logic->getVectorSize(0);i++) {
        selectLinee->addItem(QString::number(i));
    }
    for (int i=0;i<logic->getVectorSize(1);i++) {
        selectAree->addItem(QString::number(i));
    }
    for (int i=0;i<logic->getVectorSize(2);i++) {
        selectColori->addItem(QString::number(i));
    }

    selectLinee->setFixedSize(150,200);
    selectAree->setFixedSize(150,200);
    selectColori->setFixedSize(150,200);

    struttura->addWidget(selectLineeLabel,0,0);
    struttura->addWidget(selectAreeLabel,0,1);
    struttura->addWidget(selectColoriLabel,0,2);
    struttura->addWidget(selectLinee,1,0);
    struttura->addWidget(selectAree,1,1);
    struttura->addWidget(selectColori,1,2);

    groupBox = new BoxDettagli(logic);
    struttura->addWidget(groupBox,0,3,2,1);

    connect(selectColori, SIGNAL(itemActivated(QListWidgetItem*)), groupBox, SLOT(aggiornaDettagliColore(QListWidgetItem*)));
    connect(selectColori, SIGNAL(itemClicked(QListWidgetItem*)), groupBox, SLOT(aggiornaDettagliColore(QListWidgetItem*)));

    connect(selectLinee, SIGNAL(itemActivated(QListWidgetItem*)), groupBox, SLOT(aggiornaDettagliLinea(QListWidgetItem*)));
    connect(selectLinee, SIGNAL(itemClicked(QListWidgetItem*)), groupBox, SLOT(aggiornaDettagliLinea(QListWidgetItem*)));

    connect(selectAree, SIGNAL(itemActivated(QListWidgetItem*)), groupBox, SLOT(aggiornaDettagliArea(QListWidgetItem*)));
    connect(selectAree, SIGNAL(itemClicked(QListWidgetItem*)), groupBox, SLOT(aggiornaDettagliArea(QListWidgetItem*)));

}
