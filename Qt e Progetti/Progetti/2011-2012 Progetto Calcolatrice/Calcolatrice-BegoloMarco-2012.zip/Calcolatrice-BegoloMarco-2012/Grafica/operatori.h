#ifndef OPERATORI_H
#define OPERATORI_H

#include <QWidget>
#include <QGridLayout>
#include <QPushButton>
#include <QRadioButton>
#include <QGroupBox>

class Operatori : public QWidget {
    Q_OBJECT
public:
    Operatori(QWidget *parent = 0);
    int getSelectedOperator() const; // 0:add , 1:sub , 2:mult , 3:div
private:
    int selected;
    QGridLayout* struttura;
    QGroupBox* createBox() const;
signals:
    void operatorChanged();
public slots:
    void selectAdd();
    void selectSub();
    void selectMult();
    void selectDiv();
};

#endif // OPERATORI_H
