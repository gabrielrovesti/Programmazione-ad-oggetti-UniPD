#ifndef AREACALCOLO_H
#define AREACALCOLO_H

#include <QWidget>
#include <QGridLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QMessageBox>

#include "operatori.h"
#include "../Logica/logica.h"

class AreaCalcolo : public QWidget {
    Q_OBJECT
public:
    AreaCalcolo(Logica* l, QWidget *parent = 0);
private:
    Logica* logic;
    QGridLayout* struttura;
    QLineEdit* linea1op;
    QLineEdit* linea2op;
    QPushButton* button1op;
    QPushButton* button2op;
    QPushButton* uguale;
    QLineEdit* risultato;
    QPushButton* saveButton;
    Operatori* operators;
    QString getStringValue(Operando* op) const;
signals:
    void itemAdded();
public slots:
    void setOperator();
    void addOp1();
    void addOp2();
    void clear();
    void esegui();
    void saveResult();
};

#endif // AREACALCOLO_H
