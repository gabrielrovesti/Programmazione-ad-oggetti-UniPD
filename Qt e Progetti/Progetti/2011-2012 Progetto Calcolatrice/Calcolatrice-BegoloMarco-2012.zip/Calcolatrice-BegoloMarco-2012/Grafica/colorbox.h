#ifndef COLORBOX_H
#define COLORBOX_H

#include <QWidget>
#include <QPainter>
#include "../Logica/hexcolor.h"

class ColorBox : public QWidget {
    Q_OBJECT
public:
    ColorBox(QWidget *parent = 0);
    int getRed() const {return red;}
    int getGreen() const {return green;}
    int getBlue() const {return blue;}
private:
    int red;
    int green;
    int blue;
public slots:
    void setRed(int r);
    void setGreen(int g);
    void setBlue(int b);
signals:
    void colorChanged(QString s);
protected:
    void paintEvent(QPaintEvent* );
    
};

#endif // COLORBOX_H
