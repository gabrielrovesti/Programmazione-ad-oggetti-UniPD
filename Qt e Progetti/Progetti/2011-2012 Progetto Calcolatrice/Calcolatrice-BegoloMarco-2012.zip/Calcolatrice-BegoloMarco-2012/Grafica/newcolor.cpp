#include "newcolor.h"

NewColor::NewColor(Logica* l, QWidget *parent): QWidget(parent) {
    logic = l;

    struttura = new QGridLayout(this);
    QGroupBox* boxNewLine = new QGroupBox(tr("Crea nuovo Colore"));
    QGridLayout* boxGrid = new QGridLayout();

    QLabel* redLabel = new QLabel(tr("R:"));
    QLabel* greenLabel = new QLabel(tr("G:"));
    QLabel* blueLabel = new QLabel(tr("B:"));

    redSlider = new SliderRange();
    redSlider->setRange(0,255);
    greenSlider = new SliderRange();
    greenSlider->setRange(0,255);
    blueSlider = new SliderRange();
    blueSlider->setRange(0,255);

    colorBox = new ColorBox();
    colorBox->setFixedSize(50,100);

    c = HexColor(colorBox->getRed(),colorBox->getGreen(),colorBox->getBlue());
    QString qstr = QString::fromStdString("#"+c.getColor());
    hexColor = new QLineEdit(qstr);
    create = new QPushButton(tr("Crea"));

    connect(redSlider, SIGNAL(valueChanged(int)), this, SLOT(setRed(int)));
    connect(greenSlider, SIGNAL(valueChanged(int)), this, SLOT(setGreen(int)));
    connect(blueSlider, SIGNAL(valueChanged(int)), this, SLOT(setBlue(int)));
    connect(colorBox, SIGNAL(colorChanged(QString)), hexColor, SLOT(setText(QString)));
    connect(hexColor, SIGNAL(textChanged(QString)), redSlider, SLOT(changeRedFromHex(QString)));
    connect(hexColor, SIGNAL(textChanged(QString)), greenSlider, SLOT(changeGreenFromHex(QString)));
    connect(hexColor, SIGNAL(textChanged(QString)), blueSlider, SLOT(changeBlueFromHex(QString)));
    connect(create, SIGNAL(clicked()), this, SLOT(saveColor()));


    boxGrid->addWidget(redLabel,0,0);
    boxGrid->addWidget(greenLabel,1,0);
    boxGrid->addWidget(blueLabel,2,0);
    boxGrid->addWidget(redSlider,0,1);
    boxGrid->addWidget(greenSlider,1,1);
    boxGrid->addWidget(blueSlider,2,1);
    boxGrid->addWidget(colorBox,0,2,3,1);
    boxGrid->addWidget(hexColor,3,1);
    boxGrid->addWidget(create,4,1);


    boxNewLine->setLayout(boxGrid);
    struttura->addWidget(boxNewLine,0,0);
}

void NewColor::setRed(int r) {
    colorBox->setRed(r);
}

void NewColor::setGreen(int g) {
    colorBox->setGreen(g);
}

void NewColor::setBlue(int b) {
    colorBox->setBlue(b);
}

void NewColor::saveColor() {
    logic->newColor((hexColor->text().QString::toStdString()));
    emit colorAdded();
}
