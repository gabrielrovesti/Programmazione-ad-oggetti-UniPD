#ifndef SELECTUDM_H
#define SELECTUDM_H

#include <QWidget>
#include <QGridLayout>
#include <QPushButton>
#include <QRadioButton>
#include "selectudm.h"

class selectUDM : public QWidget {
    Q_OBJECT
public:
    selectUDM(QWidget *parent = 0);
    QGridLayout* struttura;
    
};

#endif // SELECTUDM_H
