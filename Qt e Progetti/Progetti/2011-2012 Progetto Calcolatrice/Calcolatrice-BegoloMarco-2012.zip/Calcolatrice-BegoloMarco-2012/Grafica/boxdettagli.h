#ifndef BOXDETTAGLI_H
#define BOXDETTAGLI_H

#include <QWidget>
#include <QGridLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QGroupBox>
#include <QImage>
#include <QRadioButton>
#include <QListWidgetItem>
#include <string>
#include "colorbox.h"
#include "../Logica/logica.h"

using std::string;

class BoxDettagli : public QWidget {
    Q_OBJECT
public:
    BoxDettagli(Logica* log, QWidget *parent = 0);
    QGroupBox* groupBox;

private:
    Logica* logic;
    QGridLayout* struttura;
    QGroupBox* createBox();
    QGridLayout* boxGrid;
    QLineEdit* width;
    QLineEdit* height;
    QLineEdit* ris;
    QLineEdit* color;
    ColorBox* colorBox;
    QListWidgetItem* selectedItem;
    QGroupBox*  udmBox;
    int index;
    int udm;
signals:
    void cambioUDMlinea(QListWidgetItem* i);
    void cambioUDMarea(QListWidgetItem* i);
public slots:
    void aggiornaDettagliColore(QListWidgetItem* i);
    void aggiornaDettagliLinea(QListWidgetItem* i);
    void aggiornaDettagliArea(QListWidgetItem* i);
    void setPx();
    void setCm();
    void setInch();


};

#endif // BOXDETTAGLI_H
