#ifndef NEWCOLOR_H
#define NEWCOLOR_H

#include <QWidget>
#include <QGridLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QGroupBox>
#include <QRadioButton>
#include <QSlider>
#include <QTextEdit>
#include <QColor>
#include <QString>
#include <QApplication>
#include "colorbox.h"
#include "sliderrange.h"

#include "../Logica/logica.h"
#include "../Logica/hexcolor.h"

class NewColor : public QWidget {
    Q_OBJECT
private:
    QGridLayout* struttura;
    ColorBox* colorBox;
    SliderRange* redSlider;
    SliderRange* greenSlider;
    SliderRange* blueSlider;
    QLineEdit* hexColor;
    QPushButton* create;
    Logica* logic;
    HexColor c;
public:
    NewColor(Logica* l, QWidget *parent = 0);
public slots:
    void setRed(int r);
    void setGreen(int g);
    void setBlue(int b);
    void saveColor();
signals:
    void colorAdded();
};

#endif // NEWCOLOR_H
