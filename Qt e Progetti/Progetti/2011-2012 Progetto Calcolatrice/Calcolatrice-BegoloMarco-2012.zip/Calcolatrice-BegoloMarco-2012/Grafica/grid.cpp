#include "grid.h"

Grid::Grid(Logica* l, QWidget *parent): QWidget(parent) {
    logic = l;
    griglia = new QGridLayout(this);

    a1 = new AreaCalcolo(logic);
    griglia->addWidget(a1,0,0);

    a2 = new AreaSelezione(logic);
    griglia->addWidget(a2,1,0);

    a3 = new AreaCreazione(logic);
    griglia->addWidget(a3,2,0);

    connect(a3, SIGNAL(itemAdded()), this, SLOT(addItem()));
    connect(a1, SIGNAL(itemAdded()), this, SLOT(addItem()));
}

void Grid::addItem() {
    AreaSelezione* temp = new AreaSelezione(logic);
    griglia->addWidget(temp,1,0);
    delete a2;
    a2 = new AreaSelezione(logic); //important
    griglia->removeWidget(temp);
    griglia->addWidget(a2,1,0); //important
    delete temp;
    temp=0;
}
