#ifndef AREACREAZIONE_H
#define AREACREAZIONE_H

#include <QWidget>
#include <QGridLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>

#include "newlinea.h"
#include "newarea.h"
#include "newcolor.h"
#include "../Logica/logica.h"

class AreaCreazione : public QWidget {
    Q_OBJECT
public:
    AreaCreazione(Logica* logic, QWidget *parent = 0);
private:
    QGridLayout* struttura;
signals:
    void itemAdded();
public slots:
    void addColor();
    void addLinea();
    void addArea();

};

#endif // AREACREAZIONE_H
