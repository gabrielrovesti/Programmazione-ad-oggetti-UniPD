#ifndef NEWLINEA_H
#define NEWLINEA_H

#include <QWidget>
#include <QGridLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QGroupBox>
#include <QRadioButton>
#include <QMessageBox>
#include <QString>

#include "../Logica/logica.h"

class NewLinea : public QWidget {
    Q_OBJECT
public:
    NewLinea(Logica* log, QWidget *parent = 0);
private:
    Logica* logic;
    QGroupBox*  boxNewLine;
    QGridLayout* boxGrid ;
    QGridLayout* struttura;
    QGroupBox* udmBox;
    QGridLayout* udmGrid;
    QLineEdit* ris;
    QLineEdit* length;
    QPushButton* create;
    int udm;
public slots:
    void saveLinea();
    void setPx();
    void setCm();
    void setInch();
signals:
    void lineaAdded();

};

#endif // NEWLINEA_H
