#include "grafica.h"
#include <QLineEdit>

Grafica::Grafica(QWidget* parent): QMainWindow(parent) {
    Logica* logic = new Logica();
    Grid* central = new Grid(logic);
    scroll = new QScrollArea(this);
    scroll->setWidget(central);
    setCentralWidget(scroll);
}
