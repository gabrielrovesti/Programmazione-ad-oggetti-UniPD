#ifndef SLIDERRANGE_H
#define SLIDERRANGE_H

#include <QWidget>
#include <QSlider>
#include <QLineEdit>
#include <QGridLayout>
#include <string>
#include "../Logica/hexcolor.h"
using std::string;


class SliderRange : public QWidget {
    Q_OBJECT
private:
    QSlider* slider;
    QLineEdit* decValue;
public:
    SliderRange(QWidget *parent = 0);
    int value() const;
    void setRange(int min, int max);
signals:
    void valueChanged(int newvalue);
public slots:
    void setValue(QString v);
    void changeDecValue(int v);
    void changeRedFromHex(QString s);
    void changeGreenFromHex(QString s);
    void changeBlueFromHex(QString s);
};

#endif // SLIDERRANGE_H
