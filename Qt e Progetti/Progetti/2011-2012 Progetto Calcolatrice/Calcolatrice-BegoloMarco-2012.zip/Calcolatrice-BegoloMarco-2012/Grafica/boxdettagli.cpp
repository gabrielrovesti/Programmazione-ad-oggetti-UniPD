#include "boxdettagli.h"

BoxDettagli::BoxDettagli(Logica *log, QWidget *parent): QWidget(parent) {
    logic = log;
    udm = 0;
    groupBox = new QGroupBox(tr("Dettagli"));
    udmBox = new QGroupBox();

    boxGrid = new QGridLayout();
    QGridLayout* udmGrid = new QGridLayout();

    // Info
    QLabel* l = new QLabel(tr("    L:"));
    QLabel* h = new QLabel(tr("    H:"));
    QLabel* r = new QLabel(tr("  Ris:"));

    boxGrid->addWidget(l,0,0);
    boxGrid->addWidget(h,1,0);
    boxGrid->addWidget(r,2,0);

    width = new QLineEdit(tr(""));
    width->setReadOnly(true);
    height = new QLineEdit(tr(""));
    height->setReadOnly(true);
    ris = new QLineEdit(tr(""));
    ris->setReadOnly(true);

    boxGrid->addWidget(width,0,1);
    boxGrid->addWidget(height,1,1);
    boxGrid->addWidget(ris,2,1);



    // Selezione unit� di misura
    QRadioButton* px = new QRadioButton(tr("px"));
    QRadioButton* cm = new QRadioButton(tr("cm"));
    QRadioButton* inch = new QRadioButton(tr("inch"));
    px->setChecked(true);

    udmGrid->addWidget(px,0,0);
    udmGrid->addWidget(cm,1,0);
    udmGrid->addWidget(inch,2,0);

    udmBox->setLayout(udmGrid);
    boxGrid->addWidget(udmBox,0,3,2,1);



    // Colore
    QLabel* c = new QLabel(tr("Color:"));
    color = new QLineEdit(tr("#"));
    color->setReadOnly(true);
    colorBox = new ColorBox();
    colorBox->setFixedSize(50,50);
    colorBox->hide();

    boxGrid->addWidget(c,3,0);
    boxGrid->addWidget(color,3,1,1,2);
    boxGrid->addWidget(colorBox,3,3);


    groupBox->setLayout(boxGrid);
    struttura = new QGridLayout(this);
    struttura->setColumnMinimumWidth(0,300);
    struttura->addWidget(groupBox,0,0);

    width->setDisabled(true);
    height->setDisabled(true);
    ris->setDisabled(true);
    udmBox->setDisabled(true);
    color->setDisabled(true);
    colorBox->setDisabled(true);


    connect(px, SIGNAL(clicked()),this,SLOT(setPx()));
    connect(cm, SIGNAL(clicked()),this,SLOT(setCm()));
    connect(inch, SIGNAL(clicked()),this,SLOT(setInch()));

    connect(this, SIGNAL(cambioUDMlinea(QListWidgetItem*)),this,SLOT(aggiornaDettagliLinea(QListWidgetItem*)));
    connect(this, SIGNAL(cambioUDMarea(QListWidgetItem*)),this,SLOT(aggiornaDettagliArea(QListWidgetItem*)));
}

void BoxDettagli::aggiornaDettagliColore(QListWidgetItem* i) {
    selectedItem=i;
    width->setText(tr(""));
    height->setText(tr(""));
    ris->setText(tr(""));
    width->setDisabled(true);
    height->setDisabled(true);
    ris->setDisabled(true);
    udmBox->setDisabled(true);
    color->setDisabled(false);
    colorBox->show();

    index = (i->text()).toInt();
    HexColor* col = logic->getColor(index);
    logic->setSelected(col);

    string str = (logic->getColor(index))->getColor();
    color->setText("#"+QString::fromStdString(str));
    HexColor c = HexColor(str);
    colorBox->setRed(c.getRdec());
    colorBox->setGreen(c.getGdec());
    colorBox->setBlue(c.getBdec());

    boxGrid->update();
    repaint();
}

void BoxDettagli::aggiornaDettagliLinea(QListWidgetItem* i) {
    selectedItem=i;
    width->setText(tr(""));
    height->setText(tr(""));
    ris->setText(tr(""));
    color->setText(tr("#"));
    width->setDisabled(false);
    height->setDisabled(true);
    ris->setDisabled(false);
    udmBox->setDisabled(false);
    color->setDisabled(false);
    colorBox->show();

    index = (i->text()).toInt();
    Linea* linea = logic->getLinea(index);
    logic->setSelected(linea);

    Stat t = linea->getInfo();
    // stampo la lunghezza
    if (udm==0) width->setText(QString::number(t.l));
    else if (udm==1) width->setText(QString::number(t.lCm));
    else width->setText(QString::number(t.lInch));
    // stampo la risoluzione
    ris->setText(QString::number(t.dpi));
    // stampo il colore
    HexColor c = HexColor(linea->getColor());
    color->setText("#"+QString::fromStdString(c.getColor()));
    colorBox->setRed(c.getRdec());
    colorBox->setGreen(c.getGdec());
    colorBox->setBlue(c.getBdec());

    update();
    repaint();
}

void BoxDettagli::aggiornaDettagliArea(QListWidgetItem* i) {
    selectedItem = i;
    width->setText(tr(""));
    height->setText(tr(""));
    ris->setText(tr(""));
    color->setText(tr("#"));
    width->setDisabled(false);
    height->setDisabled(false);
    ris->setDisabled(false);
    udmBox->setDisabled(false);
    color->setDisabled(false);
    colorBox->show();

    index = (i->text()).toInt();
    Area* area = logic->getArea(index);
    logic->setSelected(area);

    Stat t = area->getInfo();
    // stampo la lunghezza
    if (udm==0) width->setText(QString::number(t.l));
    else if (udm==1) width->setText(QString::number(t.lCm));
    else width->setText(QString::number(t.lInch));
    // stampo l'altezza
    if (udm==0) height->setText(QString::number(t.h));
    else if (udm==1) height->setText(QString::number(t.hCm));
    else height->setText(QString::number(t.hInch));
    // stampo la risoluzione
    ris->setText(QString::number(t.dpi));
    // stampo il colore
    HexColor c = HexColor(area->getColor());
    color->setText("#"+QString::fromStdString(c.getColor()));
    colorBox->setRed(c.getRdec());
    colorBox->setGreen(c.getGdec());
    colorBox->setBlue(c.getBdec());

    update();
    repaint();
}

void BoxDettagli::setPx() {
    udm = 0;
    if (QString::compare(width->text(),QString(tr("")))!=0) { // true: � una linea o un'area
        if (QString::compare(height->text(),QString(tr("")))!=0) { // true: � un'area
            emit cambioUDMarea(selectedItem);
        }
        else { // � una linea
            emit cambioUDMlinea(selectedItem);
        }
    }

}

void BoxDettagli::setCm() {
    udm = 1;
    if (QString::compare(width->text(),QString(tr("")))!=0) { // true: � una linea o un'area
        if (QString::compare(height->text(),QString(tr("")))!=0) { // true: � un'area
            emit cambioUDMarea(selectedItem);
        }
        else { // � una linea
            emit cambioUDMlinea(selectedItem);
        }
    }
}

void BoxDettagli::setInch() {
    udm = 2;
    if (QString::compare(width->text(),QString(tr("")))!=0) { // true: � una linea o un'area
        if (QString::compare(height->text(),QString(tr("")))!=0) { // true: � un'area
            emit cambioUDMarea(selectedItem);
        }
        else { // � una linea
            emit cambioUDMlinea(selectedItem);
        }
    }
}

