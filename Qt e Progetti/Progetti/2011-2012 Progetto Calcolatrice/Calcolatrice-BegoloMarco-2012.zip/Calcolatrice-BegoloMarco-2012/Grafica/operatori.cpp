#include "operatori.h"

Operatori::Operatori(QWidget *parent): QWidget(parent) {
    struttura = new QGridLayout(this);
    selected = -1;

    QGroupBox* groupBox = new QGroupBox(tr("Seleziona Operatore"));
    QGridLayout* structOperatori = new QGridLayout();

    QRadioButton *radio1 = new QRadioButton(tr("+"));
    QRadioButton *radio2 = new QRadioButton(tr("-"));
    QRadioButton *radio3 = new QRadioButton(tr("*"));
    QRadioButton *radio4 = new QRadioButton(tr("/"));

    structOperatori->addWidget(radio1,0,0);
    structOperatori->addWidget(radio2,0,1);
    structOperatori->addWidget(radio3,1,0);
    structOperatori->addWidget(radio4,1,1);

    connect(radio1, SIGNAL(clicked()), this, SLOT(selectAdd()));
    connect(radio2, SIGNAL(clicked()), this, SLOT(selectSub()));
    connect(radio3, SIGNAL(clicked()), this, SLOT(selectMult()));
    connect(radio4, SIGNAL(clicked()), this, SLOT(selectDiv()));

    groupBox->setLayout(structOperatori);
    struttura->addWidget(groupBox,0,0);
}

void Operatori::selectAdd() {
    selected=0;
    emit operatorChanged();
}

void Operatori::selectSub() {
    selected=1;
    emit operatorChanged();
}

void Operatori::selectMult() {
    selected=2;
    emit operatorChanged();
}

void Operatori::selectDiv() {
    selected=3;
    emit operatorChanged();
}

int Operatori::getSelectedOperator() const {
    return selected;
}
