#ifndef GRID_H
#define GRID_H

#include <QWidget>
#include <QGridLayout>
#include "areacalcolo.h"
#include "areaselezione.h"
#include "areacreazione.h"

class Grid : public QWidget {
    Q_OBJECT
public:
    Grid(Logica* l, QWidget *parent = 0);
private:
    Logica* logic;
    QGridLayout* griglia;
    AreaCalcolo* a1;
    AreaSelezione* a2;
    AreaCreazione* a3;
public slots:
    void addItem();
signals:
    void refreshItemList();
    
};

#endif // GRID_H
