#ifndef AREASELEZIONE_H
#define AREASELEZIONE_H

#include <QWidget>
#include <QGridLayout>
#include <QLabel>
#include <QPushButton>
#include <QListWidget>

#include "boxdettagli.h"
#include "../Logica/logica.h"

class AreaSelezione : public QWidget {
    Q_OBJECT
public:
    AreaSelezione(Logica* l, QWidget *parent = 0);
private:
    QGridLayout* struttura;
    Logica* logic;
    QListWidget* selectLinee;
    QListWidget* selectAree;
    QListWidget* selectColori;
    BoxDettagli* groupBox;


};

#endif // AREASELEZIONE_H
