#include "newarea.h"

NewArea::NewArea(Logica* log, QWidget *parent) : QWidget(parent) {

    logic = log;
    struttura = new QGridLayout(this);
    boxNewLine = new QGroupBox(tr("Crea nuova Area"));
    boxGrid = new QGridLayout();

    QLabel* l = new QLabel(tr("L:"));
    length = new QLineEdit();
    QLabel* r = new QLabel(tr("Ris:"));
    ris = new QLineEdit();
    QLabel* h = new QLabel(tr("H:"));
    height = new QLineEdit();

    boxGrid->addWidget(l,0,0);
    boxGrid->addWidget(length,0,1);
    boxGrid->addWidget(h,1,0);
    boxGrid->addWidget(height,1,1);
    boxGrid->addWidget(r,2,0);
    boxGrid->addWidget(ris,2,1);

    udmBox = new QGroupBox();
    udmGrid = new QGridLayout(this);

    QRadioButton* px = new QRadioButton(tr("px"));
    QRadioButton* cm = new QRadioButton(tr("cm"));
    QRadioButton* inch = new QRadioButton(tr("inch"));
    px->setChecked(true);
    udm=0;

    udmGrid->addWidget(px,0,0);
    udmGrid->addWidget(cm,1,0);
    udmGrid->addWidget(inch,2,0);

    udmBox->setLayout(udmGrid);
    boxGrid->addWidget(udmBox,0,2,2,1);

    create = new QPushButton(tr("Crea"));
    boxGrid->addWidget(create,3,1);

    boxNewLine->setLayout(boxGrid);
    struttura->addWidget(boxNewLine,0,0);

    connect(create, SIGNAL(clicked()), this, SLOT(saveArea()));

    connect(px, SIGNAL(clicked()),this,SLOT(setPx()));
    connect(cm, SIGNAL(clicked()),this,SLOT(setCm()));
    connect(inch, SIGNAL(clicked()),this,SLOT(setInch()));
}

void NewArea::saveArea() {
    int pixelL;
    int pixelH;
    //Le seguente conversione sono sicure, se il testo non � STRETTAMENTE un double la conversione restituisce 0
    double lengthValue = (length->text()).toDouble();
    double heightValue = (height->text()).toDouble();

    int lengthValueInt = (length->text()).toInt();
    int heightValueInt = (height->text()).toInt();
    int dpi = (ris->text()).toInt();


    QMessageBox errorMsg;
    errorMsg.setWindowTitle(tr("Errore!"));
    bool error = false;

    QMessageBox warningMsg;
    warningMsg.setWindowTitle(tr("Attenzione!"));
    bool warning = false;

    // Controlli su "length"
    QString qstr = QString(length->text());
    QString emptyString = QString(tr(""));
    if (QString::compare(qstr, emptyString)==0) {
        errorMsg.setInformativeText(tr("La stringa vuota non � valida. Inserire una lunghezza valida"));
        error = true;
    }

    if (lengthValue==0) {
        warningMsg.setText(tr("Hai inserito il valore 0 come lunghezza, oppure un numero non valido."));
        warningMsg.setInformativeText(tr("La nuova area avr� lunghezza pari a 1px"));
        warning = true;
    }

    // Controlli su "height"
    qstr = QString(height->text());
    emptyString = QString(tr(""));
    if (QString::compare(qstr, emptyString)==0) {
        errorMsg.setInformativeText(tr("La stringa vuota non � valida. Inserire un'altezza valida"));
        error = true;
    }

    if (heightValue==0) {
        warningMsg.setText(tr("Hai inserito il valore 0 come altezza, oppure un numero non valido."));
        warningMsg.setInformativeText(tr("La nuova Area avr� altezza pari a 1px"));
        warning = true;
    }

    // Controlli sull'unit� di misura
    if (udm==1) {
        pixelL = static_cast<int>(lengthValue*dpi*2.54);
        pixelH = static_cast<int>(heightValue*dpi*2.54);
    }
    else if (udm==2) {
        pixelL = static_cast<int>(lengthValue*dpi);
        pixelH = static_cast<int>(heightValue*dpi);
    }
    else {
        pixelL = lengthValueInt;
        pixelH = heightValueInt;
    }

    // Controlli sui dpi
    if (dpi==0) {
        errorMsg.setText(tr("Il valore dei dpi non � valido. Inserire un intero diverso da 0"));
        error = true;
    }

    if (error) errorMsg.exec();
    else {
        if (pixelL==0) pixelL=1;
        if (pixelH==0) pixelH=1;
        if (warning) warningMsg.exec();
        logic->newArea(pixelL,pixelH,dpi);
        emit areaAdded();
    }

}

void NewArea::setPx() {
    udm = 0;
    update();
    repaint();
}

void NewArea::setCm() {
    udm = 1;
    update();
    repaint();
}

void NewArea::setInch() {
    udm = 2;
    update();
    repaint();
}


