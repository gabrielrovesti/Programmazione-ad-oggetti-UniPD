# CandiVal
Progetto di Programmazione ad Oggetti A.A 2018-2019.
Università di Padova.
