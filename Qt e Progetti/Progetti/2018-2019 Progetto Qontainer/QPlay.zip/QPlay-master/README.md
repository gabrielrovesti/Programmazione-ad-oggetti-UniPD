# QPlay

QPlay è stato sviluppato nell'anno accademico 2018/2019 come progetto del corso Programmazione ad oggetti tenuto dal prof. Ranzato. 

È un applicazione che consente, tramite l'uso di un contenitore, la gestione e visualizzazione di file audio-visivi di vario tipo. 
L'utente può inserire, modificare, eliminare file, eseguire ricerche in base a diversi campi dati e caricare/salvare su disco la propria lista di file.
