#include "exception.h"

Exception::Exception(const std::string & ER): errorMessage(ER) {}
