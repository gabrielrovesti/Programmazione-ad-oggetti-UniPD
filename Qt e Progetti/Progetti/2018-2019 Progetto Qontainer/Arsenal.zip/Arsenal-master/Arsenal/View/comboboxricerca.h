#ifndef COMBOBOXRICERCA_H
#define COMBOBOXRICERCA_H

#include <QComboBox>

class comboboxRicerca : public QComboBox
{
    Q_OBJECT

public:
    comboboxRicerca(QWidget *parent =nullptr);
};

#endif // COMBOBOXRICERCA_H
