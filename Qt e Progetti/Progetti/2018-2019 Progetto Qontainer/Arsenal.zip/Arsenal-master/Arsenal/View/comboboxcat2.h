#ifndef COMBOBOXCAT2_H
#define COMBOBOXCAT2_H

#include <QComboBox>

class comboboxCat2 : public QComboBox
{
    Q_OBJECT

public:
    comboboxCat2(QWidget *parent =nullptr);
};

#endif // COMBOBOXCAT2_H
