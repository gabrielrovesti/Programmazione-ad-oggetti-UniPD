#ifndef COMBOBOXTIPO_H
#define COMBOBOXTIPO_H

#include <QComboBox>

class comboboxTipo : public QComboBox
{
    Q_OBJECT

public:
   comboboxTipo(QWidget *parent=nullptr);
};

#endif // COMBOBOXTIPO_H
