#ifndef COMBOBOXMIRINO_H
#define COMBOBOXMIRINO_H

#include <QComboBox>

class comboboxMirino : public QComboBox
{
    Q_OBJECT

public:
    comboboxMirino(QWidget *parent=nullptr);
};

#endif // COMBOBOXMIRINO_H
