#ifndef COMBOBOXCAT1_H
#define COMBOBOXCAT1_H

#include <QComboBox>

class comboboxCat1 : public QComboBox
{
    Q_OBJECT

public:
    comboboxCat1(QWidget *parent =nullptr);
};

#endif // COMBOBOXCAT1_H
