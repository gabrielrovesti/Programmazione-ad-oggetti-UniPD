# Qontainer-Norvarads
## Progetto di programmazione ad oggetti, anno accademico 2018/2019, UNIPD
### La copia di questo progetto o anche solo di parti di esso NON e' concessa per la realizzazione dei vostri progetti ed ovviamente **non e' permessa dal professore**. Declino ogni resposabilita' derivante dall'uso illecito di questo codice sorgente.
Per maggiori informazioni fare riferimento al file *relazione.pdf*.
![Qontainer homepage](https://raw.githubusercontent.com/marcoDallas/Qontainer-Norvarads/master/homepage.png)

L'eventuale copyright delle immagini utilizzate nel progetto va ai rispettivi proprietari.
