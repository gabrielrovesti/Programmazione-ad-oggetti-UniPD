#ifndef SPELL_H
#define SPELL_H

#endif // SPELL_H
