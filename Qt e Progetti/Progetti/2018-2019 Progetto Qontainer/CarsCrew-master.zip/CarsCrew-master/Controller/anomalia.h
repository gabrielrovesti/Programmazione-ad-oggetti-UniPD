#ifndef ANOMALIA_H
#define ANOMALIA_H


class Anomalia
{
private:
      char err;
public:
      Anomalia(char x='d');
      char getError() const;
};

#endif // ANOMALIA_H
