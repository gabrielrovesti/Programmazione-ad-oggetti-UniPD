# Progetto-di-Programmazione-ad-Oggetti
Progetto Universitario a.a.: 2018-2019
Sviluppo di un applicazione Model View Controller con Qt
