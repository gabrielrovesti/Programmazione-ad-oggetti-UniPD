#include "viewinterface.h"

ViewInterface::ViewInterface(QWidget* parent): QWidget(parent) {}

ViewInterface::~ViewInterface() {}
