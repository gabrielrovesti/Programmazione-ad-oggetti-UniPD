# ProgettoP2

Voto ottenuto: tra ottimo ed eccellente

https://nbviewer.jupyter.org/github/Archetipo95/Progetto-Programmazione-Oggetti-CitySharing/blob/master/relazione.pdf
