#ifndef ACCUMULATOR_H
#define ACCUMULATOR_H

class Accumulator{
	
};

#endif /* ACCUMULATOR_H */
