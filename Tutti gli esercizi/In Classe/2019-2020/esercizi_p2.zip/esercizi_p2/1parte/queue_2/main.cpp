#include "header.h"

int main(){
    queue<int> a;
    a.add(10).add(17).add(13);
    std::cout << a << std::endl;
    return 0;
}