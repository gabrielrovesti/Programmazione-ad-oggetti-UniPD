#include "trialbero.h"

int main(){
  trialbero<int> tree;
  return 0;
}
